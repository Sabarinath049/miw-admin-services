import snowflake.connector
from snowflake.connector import ProgrammingError
import json
import os
import logging
from utils import get_file_format_query, get_stage_query, format_query_list, save_queries_to_file
import argparse

from dotenv import load_dotenv
print(load_dotenv())
LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
logging.basicConfig(level=getattr(logging, LOG_LEVEL, logging.INFO), format=LOG_FORMAT)
logger = logging.getLogger(__name__)

def connect_to_snowflake(user, token, account, role='ACCOUNTADMIN', use_oauth=True) -> snowflake.connector.SnowflakeConnection:
    """
    Establish a connection to Snowflake.

    :param user: Snowflake username
    :param password: Snowflake password
    :param account: Snowflake account identifier
    :param role: Snowflake role to assume (default: ACCOUNTADMIN)

    :return: Snowflake connection object
    """
    try:
        if use_oauth:
            logger.info("Connecting to Snowflake using OAuth token.")
            conn = snowflake.connector.connect(
                account=account,
                user=user,
                authenticator="oauth",
                token=token,
                role=role
            )
        else:
            logger.info("Connecting to Snowflake using username and password.")
            conn = snowflake.connector.connect(
                user=user,
                password=password,
                account=account,
                role=role
            )
        logger.info("Successfully connected to Snowflake.")
        return conn
    except ProgrammingError as e:
        logger.error(f"Programming error occurred: {e}")
    except Exception as e:
        logger.error(f"An error occurred: {e}")

def generate_rename_db_statements(cursor, database_name) -> str:
    """
    Generate SQL statements to rename a database in Snowflake.

    :param cursor: Snowflake cursor object
    :param database_name: Name of the database to rename

    :return: List of SQL statements to rename the database
    """
    try:
        cursor.execute("SHOW DATABASES LIKE %s", (database_name,))
        result = cursor.fetchone()

        if result:
            backup_name = f"BKP_{database_name}"
            rename_sql = f"-- Renaming database {database_name} to {backup_name}\n"
            rename_sql += f"ALTER DATABASE {database_name} RENAME TO {backup_name};\n"
            return rename_sql
        else:
            logger.warning(f"Database '{database_name}' does not exist.")
            return f"-- Database '{database_name}' does not exist."
    except Exception as e:
        logger.error(f"Error generating rename statements: {e}")

def generate_full_backup_restore_sqls(cursor, backup_db, new_db, json_files_folder) -> list[str]:
    """
    Generate SQL statements to backup and restore objects from one database to another.

    :param cursor: Snowflake cursor object
    :param backup_db: Name of the backup database
    :param new_db: Name of the new database to restore objects into

    :return: List of SQL statements for backup and restore
    """
    queries = []

    # Use the backup DB
    # cursor.execute(f"USE DATABASE {backup_db}")
    # Get all schemas excluding INFORMATION_SCHEMA
    print(backup_db)
    cursor.execute(f"SHOW SCHEMAS IN DATABASE {backup_db}")
    schemas = [row[1] for row in cursor.fetchall() if row[1].upper() != 'INFORMATION_SCHEMA']
    queries.append(f"USE DATABASE {new_db};\n\n")

    for schema in schemas:
        roles = []
        is_json_file_exists = os.path.exists(os.path.join(json_files_folder, f"{schema}.json"))
        if is_json_file_exists:
            with open(os.path.join(json_files_folder, f"{schema}.json"), 'r') as json_file:
                json_data = json.load(json_file)
            roles = json_data.get("access_roles", [])

        logger.info(f"Processing schema: {schema}")
        # cursor.execute(f"USE SCHEMA {backup_db}.{schema}")

        # Create schema in target DB
        # queries.append(f"CREATE SCHEMA IF NOT EXISTS {new_db}.{schema};\n\n")
        queries.append(f"USE SCHEMA {new_db}.{schema};\n\n")

        object_queries = {
            "TABLE": f"SHOW TABLES IN {backup_db}.{schema}",
            "VIEW": f"SHOW VIEWS IN {backup_db}.{schema}",
            "PROCEDURE": f"SHOW PROCEDURES IN SCHEMA {backup_db}.{schema}",
            "SEQUENCE": f"SHOW SEQUENCES IN SCHEMA {backup_db}.{schema}",
            "FILE FORMAT": f"SHOW FILE FORMATS IN SCHEMA {backup_db}.{schema}",
            "STAGE": f"SHOW STAGES IN SCHEMA {backup_db}.{schema}",
            # Function is handled separately after the main loop
        }

        for obj_type, query in object_queries.items():
            try:
                cursor.execute(query)
                rows = cursor.fetchall()
            except Exception as e:
                logger.error(f"Error fetching {obj_type}s in {backup_db}.{schema}: {e}")
                queries.append(f"-- Unable to show {obj_type}s in {backup_db}.{schema}: {str(e)}\n\n")
                continue

            for row in rows:
                try:

                    # Table handling
                    if obj_type == "TABLE":
                        logger.debug("Fetching table:", row)
                        # Fetched table: (datetime.datetime(2025, 7, 20, 22, 55, 30, 554000, tzinfo=<DstTzInfo 'America/Los_Angeles' PDT-1 day, 17:00:00 DST>), 'CUSTOMERS', 'BKP_TEST_DB', 'CUSTOMER_SCHEMA', 'TABLE', '', '', 20, 2560, 'ACCOUNTADMIN', '1', 'OFF', 'OFF', 'OFF', None, None, 'N', 'N', 'ROLE', 'N', 'N', 'N', 'N', 'N')
                        table_name = row[1]
                        # CTAS
                        queries.append(
                            f"-- Creating table {table_name} in {new_db}.{schema}\n"
                        )
                        queries.append(
                            f"CREATE OR REPLACE TABLE {new_db}.{schema}.{table_name} AS SELECT * FROM {backup_db}.{schema}.{table_name};\n\n"
                        )
                        queries.append(
                            f"-- Granting ownership of table {table_name} for roles {roles}\n"
                        )
                        for role in roles:
                            queries.append(
                                f"GRANT OWNERSHIP ON TABLE {new_db}.{schema}.{table_name} TO ROLE {role};\n"
                            )
                        queries.append("\n")
                    # View handling
                    elif obj_type == "VIEW":
                        logger.debug("Fetching view:", row)
                        # Fetched_view: (datetime.datetime(2025, 7, 20, 23, 0, 0, 240000, tzinfo=<DstTzInfo 'America/Los_Angeles' PDT-1 day, 17:00:00 DST>), 'ACTIVE_CUSTOMERS_VIEW', '', 'BKP_TEST_DB', 'CUSTOMER_SCHEMA', 'ACCOUNTADMIN', '', 'CREATE OR REPLACE VIEW Test_DB.customer_schema.active_customers_view AS\nSELECT\n    CustomerID,\n    FirstName,\n    LastName,\n    Email,\n    City\nFROM\n    Test_DB.customer_schema.Customers\nWHERE\n    City IS NOT NULL;', 'false', 'false', 'ROLE', 'OFF')
                        view_def = row[7]
                        view_def = view_def.replace(f"{backup_db}.{schema}", f"{new_db}.{schema}")
                        view_def = view_def.replace(f"{backup_db}", f"{new_db}")
                        queries.append(
                            f"-- Creating view {row[1]} in {new_db}.{schema}\n"
                        )
                        queries.append(view_def + "\n\n")
                        if is_json_file_exists:
                            queries.append(
                                f"-- Granting ownership on view {row[1]} for roles {roles}\n"
                            )
                            for role in roles:
                                queries.append(
                                    f"GRANT OWNERSHIP ON VIEW {new_db}.{schema}.{row[1]} TO ROLE {role};\n"
                                )
                            queries.append("\n")
                    # Procedure handling
                    elif obj_type == "PROCEDURE":
                        is_user_defined = 'user-defined' in row[9].lower()
                        if is_user_defined:
                            logger.debug("Fetching procedure:", row)
                            # Fetched procedure: (datetime.datetime(2025, 7, 21, 1, 42, 4, 24000, tzinfo=<DstTzInfo 'America/Los_Angeles' PDT-1 day, 17:00:00 DST>), 'ADD_TWO_NUMBERS_PROC', 'CUSTOMER_SCHEMA', 'N', 'N', 'N', 2, 2, 'ADD_TWO_NUMBERS_PROC(NUMBER, NUMBER) RETURN NUMBER', 'user-defined procedure', 'BKP_TEST_DB', 'N', 'N', 'N', '', '')
                            proc_name = row[1]
                            proc_name_with_args = row[8].split(")")[0] + ")"  # e.g., (NUMBER, NUMBER)
                            full_proc_name = f"{backup_db}.{schema}.{proc_name_with_args}"
                            try:
                                cursor.execute(f"SELECT GET_DDL('PROCEDURE', '{full_proc_name}')")
                                proc_def = cursor.fetchone()[0]
                                queries.append(
                                    f"-- Creating procedure {proc_name} in {new_db}.{schema}\n"
                                )
                                proc_def = proc_def.replace(f"{backup_db}.{schema}", f"{new_db}.{schema}")
                                proc_def = proc_def.replace(f"{backup_db}", f"{new_db}")
                                queries.append(proc_def+ "\n\n")
                                if is_json_file_exists:
                                    queries.append(
                                        f"-- Granting ownership on procedure {proc_name} for roles {roles}\n"
                                    )
                                    for role in roles:
                                        queries.append(
                                            f"GRANT OWNERSHIP ON PROCEDURE {new_db}.{schema}.{full_proc_name} TO ROLE {role};\n"
                                        )
                                    queries.append("\n")

                            except Exception as e:
                                logger.error(f"Error fetching procedure body for {full_proc_name}: {str(e)}")
                                queries.append(f"-- Unable to fetch procedure body for {full_proc_name} || {str(e)}\n\n")
                    # Sequence handling
                    elif obj_type == "SEQUENCE":
                        logger.debug("Fetching sequence:", row)
                        # Fetched sequence: ('TEST_SEQ', 'BKP_TEST_DB', 'CUSTOMER_SCHEMA', 5, 1, datetime.datetime(2025, 7, 21, 3, 56, 21, 396000, tzinfo=<DstTzInfo 'America/Los_Angeles' PDT-1 day, 17:00:00 DST>), 'ACCOUNTADMIN', '', 'ROLE', 'Y')
                        seq_name = row[0]
                        current_value = row[3]
                        start_value = row[4]
                        comment = row[7]
                        is_ordered = row[9] == 'Y'
                        queries.append(
                            f"-- Creating sequence {seq_name} in {new_db}.{schema}\n"
                        )
                        queries.append(
                            f"CREATE OR REPLACE SEQUENCE {new_db}.{schema}.{seq_name} START = {current_value} INCREMENT = 1 "
                            f"COMMENT = '{comment}' {'ORDER' if is_ordered else 'NOORDER'};\n\n"
                        )
                        if is_json_file_exists:
                            queries.append(
                                f"-- Granting ownership on sequence {seq_name} for roles {roles}\n"
                            )
                            for role in roles:
                                queries.append(
                                    f"GRANT OWNERSHIP ON SEQUENCE {new_db}.{schema}.{seq_name} TO ROLE {role};\n"
                                )
                            queries.append("\n")
                    # File Format handling
                    elif obj_type == "FILE FORMAT":
                        logger.debug("Fetching file format:", row)
                        # (datetime.datetime(2025, 7, 21, 4, 35, 55, 956000, tzinfo=<DstTzInfo 'America/Los_Angeles' PDT-1 day, 17:00:00 DST>), 'CUSTOMER_CSV_FORMAT', 'BKP_TEST_DB', 'CUSTOMER_SCHEMA', 'CSV', 'ACCOUNTADMIN', 'Test CSV file format for BKP_Test_DB in CUSTOMER_SCHEMA', '{"TYPE":"CSV","RECORD_DELIMITER":"\\n","FIELD_DELIMITER":",","FILE_EXTENSION":null,"SKIP_HEADER":1,"PARSE_HEADER":false,"DATE_FORMAT":"AUTO","TIME_FORMAT":"AUTO","TIMESTAMP_FORMAT":"AUTO","BINARY_FORMAT":"HEX","ESCAPE":"NONE","ESCAPE_UNENCLOSED_FIELD":"\\\\","TRIM_SPACE":true,"FIELD_OPTIONALLY_ENCLOSED_BY":"NONE","NULL_IF":["NULL","null"],"COMPRESSION":"AUTO","ERROR_ON_COLUMN_COUNT_MISMATCH":true,"VALIDATE_UTF8":true,"SKIP_BLANK_LINES":false,"REPLACE_INVALID_CHARACTERS":false,"EMPTY_FIELD_AS_NULL":true,"SKIP_BYTE_ORDER_MARK":true,"ENCODING":"UTF8","MULTI_LINE":true}', 'ROLE')
                        queries.append(
                            f"-- Creating file format {row[1]} in {new_db}.{schema}\n"
                        )
                        queries.append(
                            get_file_format_query(new_db, schema, row) + "\n\n"
                        )
                        if is_json_file_exists:
                            queries.append(
                                f"-- Granting ownership on file format {row[1]} for roles {roles}\n"
                            )
                            for role in roles:
                                queries.append(
                                    f"GRANT OWNERSHIP ON FILE FORMAT {new_db}.{schema}.{row[1]} TO ROLE {role};\n"
                                )
                            queries.append("\n")
                    # Stage handling
                    elif obj_type == "STAGE":
                        logger.debug("Fetching stage:", row)
                        # (datetime.datetime(2025, 7, 21, 5, 43, 53, 475000, tzinfo=<DstTzInfo 'America/Los_Angeles' PDT-1 day, 17:00:00 DST>), 'TEST_STAGE', 'BKP_TEST_DB', 'CUSTOMER_SCHEMA', '', 'N', 'N', 'ACCOUNTADMIN', 'Internal stage for testing in BKP_Test_DB.CUSTOMER_SCHEMA', None, 'INTERNAL', None, None, None, None, 'ROLE', 'N')
                        queries.append(
                            f"-- Creating stage {row[1]} in {new_db}.{schema}\n"
                        )
                        queries.append(
                            get_stage_query(new_db, schema, row) + "\n\n"
                        )
                        if is_json_file_exists:
                            queries.append(
                                f"-- Granting ownership on stage {row[1]} for roles {roles}\n"
                            )
                            for role in roles:
                                queries.append(
                                    f"GRANT OWNERSHIP ON STAGE {new_db}.{schema}.{row[1]} TO ROLE {role};\n"
                                )
                            queries.append("\n")
                    # Task handling
                    elif obj_type == "TASK":
                        task_name = row[1]
                        queries.append(
                            f"-- Creating task {task_name} in {new_db}.{schema}\n"
                        )
                        queries.append(
                            f"-- Task {task_name} needs manual recreation due to schedule/dependency complexity\n\n"
                        )
                except Exception as e:
                    logger.error(f"Error processing {obj_type} {row[1]}: {e}")
                    queries.append(f"-- Failed to copy {obj_type} {row[1]}: {str(e)}\n\n")

        # Handle user-defined functions
        try:
            cursor.execute(f"SHOW USER FUNCTIONS IN SCHEMA {backup_db}.{schema}")
            for row in cursor.fetchall():
                logger.debug("Fetching user-defined function:", row)
                function_db = row[0]
                function_name = row[1]
                function_name_with_arg_sig = row[8].split(")")[0] + ")"  # e.g., (NUMBER, NUMBER)

                if function_name.upper().startswith("SYSTEM$"):
                    continue

                full_func_name = f"{backup_db}.{schema}.{function_name_with_arg_sig}"
                try:
                    cursor.execute(f"SELECT GET_DDL('FUNCTION', '{full_func_name}')")
                    ddl = cursor.fetchone()[0]
                    ddl = ddl.replace(f"{backup_db}.{schema}", f"{new_db}.{schema}")
                    ddl = ddl.replace(f"{backup_db}", f"{new_db}")
                    queries.append(f"-- Creating function {function_name} in {new_db}.{schema}\n")
                    queries.append(ddl + "\n\n")
                    if is_json_file_exists:
                        queries.append(
                            f"-- Granting ownership on function {function_name} for roles {roles}\n"
                        )
                        for role in roles:
                            queries.append(
                                f"GRANT OWNERSHIP ON FUNCTION {new_db}.{schema}.{function_name_with_arg_sig} TO ROLE {role};\n"
                            )
                        queries.append("\n")
                except Exception as e:
                    logger.error(f"Error fetching function body for {full_func_name}: {str(e)}")
                    queries.append(f"-- Unable to fetch function body for {full_func_name} || {str(e)}\n\n")
        except Exception as e:
            logger.error(f"Error fetching user-defined functions in schema {backup_db}.{schema}: {e}")
            queries.append(f"-- Unable to list user-defined functions in schema {schema}: {str(e)}\n\n")
    return queries

def generate_role_access_query(json_folder):
    """
    Generate SQL statements to grant role access based on JSON files in the specified folder.

    :param json_folder: Path to the folder containing JSON files with role access information

    :return: List of SQL statements for granting role access
    """
    queries = []

    for json_file in os.listdir(json_folder):
        if json_file.endswith(".json"):
            with open(os.path.join(json_folder, json_file), "r") as f:
                josn_data = json.load(f)
                schema_name = josn_data.get("schema_name")
                parent_db_name = josn_data.get("parent_db_name")
                access_roles = josn_data.get("access_roles", [])
                for role in access_roles:
                    queries.append(f"-- Granting usage on schema {parent_db_name}.{schema_name} to role {role}\n")
                    queries.append(f"GRANT USAGE ON SCHEMA {parent_db_name}.{schema_name} TO ROLE {role};\n\n")

    return queries

if __name__ == "__main__":
    '''
    # Backup Operation 1: Rename Database
    # Backup Operation 2: Generate Full Backup and Restore SQLs
    # Backup Operation 3: Generate Role Access SQLs
    # -- optional arguement for saving it as file
    '''
    user = os.getenv('USER')
    password = os.getenv('SF_PASSWORD')
    account = os.getenv('ACCOUNT_NAME')
    role = os.getenv('SF_ROLE')
    database_name = os.getenv('DATABASE_NAME')
    schema_folder = os.getenv('SCHEMA_FOLDER', 'schemas')
    new_database_name=os.getenv('restored_db')
    token = os.getenv('OAUTH_TOKEN')
    if not user or not (token or password) or not account:
        logger.error("Snowflake credentials are not set in the environment variables.")
        exit(1)
    parser = argparse.ArgumentParser(description="Snowflake Database Backup and Restore Script")
    parser.add_argument('--operation', choices=['1', '2', '3'], required=True, help="Choose the operation: 1 for Rename Database, 2 for Full Backup and Restore, 3 for Role Access SQLs")
    parser.add_argument('--file', action='store_true', help="Save the generated SQLs to a file")
    parser.add_argument('--not-oauth', action='store_true', help="Use username and password instead of OAuth token for authentication")
    args = parser.parse_args()


    logger.debug("USER: %s", user)
    logger.debug("SF_PASSWORD: %s", password)
    logger.debug("ACCOUNT_NAME: %s", account)
    logger.debug("SF_ROLE: %s", role)
    logger.debug("OAUTH_TOKEN: %s", token)
    logger.debug("DATABASE_NAME: %s", database_name)
    logger.debug("NEW_DATABASE_NAME: %s", new_database_name)
    logger.debug("SCHEMA_FOLDER: %s", schema_folder)

    connection = connect_to_snowflake(user, token, account, role, not args.not_oauth)
    if connection:
        logger.info("Connection established successfully.")
        cursor = connection.cursor()
        cursor.execute("SELECT CURRENT_ROLE()")
        role_result = cursor.fetchone()
        logger.info(f"Current role: {role_result[0]}")
        if args.operation == '1':
            rename_statement = generate_rename_db_statements(cursor, database_name)
            if rename_statement:
                if args.file:
                    operation_name = f"{database_name}_rename_database_statements"
                    filename = save_queries_to_file(rename_statement, operation_name)
                    logger.info(f"Rename database SQL saved to {filename}")
                else:
                    print("Generated SQL to rename database:")
                    print(rename_statement)
                    logger.info("Rename database SQL printed to console.")
            else:
                logger.warning("No rename statement generated.")
        elif args.operation == '2':
            backup_database_name = f"BKP_{database_name}"
            # backup_database_name = "SBX_DTD_MIW_DB"
            queries = generate_full_backup_restore_sqls(cursor, backup_database_name, new_database_name, schema_folder)
            if queries:
                formatted_queries = format_query_list(queries)
                if args.file:
                    operation_name = f"{new_database_name}_backup_restore_statements"
                    filename = save_queries_to_file(formatted_queries, operation_name)
                    logger.info(f"Backup and restore SQLs saved to {filename}")
                else:
                    print("Generated SQLs for backup and restore:")
                    print(formatted_queries)
                    logger.info("Backup and restore SQLs printed to console.")
            else:
                logger.warning("No queries generated for backup and restore.")
        elif args.operation == '3':
            if schema_folder:
                role_access_queries = generate_role_access_query(schema_folder)
                if role_access_queries:
                    formatted_role_queries = format_query_list(role_access_queries)
                    if args.file:
                        operation_name = f"{database_name}_role_access_statements"
                        filename = save_queries_to_file(formatted_role_queries, operation_name)
                        logger.info(f"Role access SQLs saved to {filename}")
                    else:
                        print("Generated SQLs for role access:")
                        print(formatted_role_queries)
                        logger.info("Role access SQLs printed to console.")
                else:
                    logger.warning("No role access queries generated.")
            else:
                logger.error("Schema folder is not specified. Please set the SCHEMA_FOLDER environment variable.")
                exit(1)
        else:
            logger.error("Invalid operation selected. Please choose 1, 2, or 3.")
            exit(1)
        cursor.close()
        connection.close()
    else:
        logger.error("Failed to establish connection.")