#!/bin/bash

###############################################################################
# Script: Catalog Integration State Cleanup
# Description: Removes catalog integration entries from Terraform state using JSON metadata files.
# Author: Ravi Pawar
###############################################################################

set -ex

if ! command -v terraform &> /dev/null; then
  echo "Installing Terraform..."

  curl -s -o terraform.zip https://releases.hashicorp.com/terraform/1.6.6/terraform_1.6.6_linux_amd64.zip
  unzip -o terraform.zip
  mv terraform /usr/local/bin/
fi

terraform -v

MODE="${MODE:-catalog_cleanup}"

# ✅ Terraform directory (infra repo)
TERRAFORM_DIR="$CODEBUILD_SRC_DIR_admin/snowflake"

# ✅ Catalog integration JSON files
BASE_DIR="$CODEBUILD_SRC_DIR/snowflake/catalog_integrations"

export CODEBUILD_ENV="dev"
export ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

echo "🔍 Scanning catalog integration metadata..."

# ✅ Ensure Terraform directory exists
if [ ! -d "$TERRAFORM_DIR" ]; then
  echo "❌ Terraform directory not found: $TERRAFORM_DIR"
  exit 1
fi

# ✅ Move into Terraform working directory
cd "$TERRAFORM_DIR"
echo "📍 Running Terraform from: $(pwd)"

# Loop through catalog integration JSON files
find "$BASE_DIR" -type f -name "*.json" | while read -r file; do

    echo "---------------------------------------------"
    echo "📄 Processing file: $file"

    # Extract subgroup
    subgroup=$(jq -r '.enterprise_or_func_subgrp_name' "$file" | tr '[:upper:]' '[:lower:]')

    if [[ -z "$subgroup" || "$subgroup" == "null" ]]; then
        echo "⚠️ Skipping (no subgroup found)"
        continue
    fi

    echo "🌐 Subgroup: $subgroup"

    filename=$(basename "$file")

    echo "⚙️ Running terraform init for subgroup: $subgroup..."

    terraform init \
      -reconfigure \
      -backend-config="bucket=minerva-${CODEBUILD_ENV}-corp-miw-tfstate-${ACCOUNT_ID}-useast1" \
      -backend-config="key=snowflake/${CODEBUILD_ENV}/${subgroup}/snowflake.json" \
      -backend-config="region=us-east-1"


    echo "📦 Listing state for module.catalog_integrations[\"$filename\"]"

    echo "####################################### $subgroup Start"


      terraform state list | \
      grep "module.catalog_integrations\[\"$filename\"\]" | \
      while read -r addr; do
          echo "🗑 Removing: $addr"
          terraform state rm "$addr"
      done


    echo "####################################### $subgroup End"

done

echo "✅ Catalog integration cleanup complete"