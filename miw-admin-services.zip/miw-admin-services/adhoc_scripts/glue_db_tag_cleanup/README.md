# AWS Glue DB Tag Utilities

This workspace contains two scripts:

- `glue_db_tag_cleanup.py` – removes selected tags from one or all Glue databases.
- `show_glue_db_tags.py` – shows selected tags for one or all Glue databases.

## Prerequisites

- Python 3.8+
- `boto3`

Install dependency:

```bash
pip install boto3
```

## Credentials setup

1. Copy `aws_credentials.ini.example` to `aws_credentials.ini`.
2. Fill in your AWS credentials.

## Script usage

### 1) Remove tags

```bash
python glue_db_tag_cleanup.py --db <db_name>
python glue_db_tag_cleanup.py --all-dbs
```

Optional flags:

- `--region <aws-region>` (default: `us-east-1`)
- `--credentials-file <path>` (default: `aws_credentials.ini`)
- `--tags <tag1> <tag2>`
  - Also supports comma-separated form, e.g. `--tags DataClassification,PICategory`
  - Default tags: `DataClassification`, `PICategory`
- `--dry-run`
  - Preview what would be removed without deleting tags
- `--yes`
  - Skip confirmation prompt when default tags are used

Examples:

```bash
python glue_db_tag_cleanup.py --db sales_db --tags Owner DataClassification
python glue_db_tag_cleanup.py --all-dbs --region us-west-2
python glue_db_tag_cleanup.py --all-dbs --dry-run
python glue_db_tag_cleanup.py --all-dbs --yes
```

### 2) Show tags

```bash
python show_glue_db_tags.py --db <db_name>
python show_glue_db_tags.py --all-dbs
```

Optional flags:

- `--region <aws-region>` (default: `us-east-1`)
- `--credentials-file <path>` (default: `aws_credentials.ini`)
- `--tags <tag1> <tag2>`
  - Also supports comma-separated form
  - Default tags: `DataClassification`, `PICategory`
- `--show-all-tags`
  - Shows every tag on the database(s)
  - Overrides the `--tags` filter

Examples:

```bash
python show_glue_db_tags.py --db sales_db
python show_glue_db_tags.py --all-dbs --tags PICategory
python show_glue_db_tags.py --all-dbs --show-all-tags
```

## Notes

- Use either `--db` or `--all-dbs` (exactly one is required).
- Tag removal only runs for tags that already exist on a database.
- If `--tags` is not provided in cleanup, the default tags are used and the script asks for confirmation before removal (unless `--yes` is provided).
- Both scripts print a final summary table that includes only databases where matching tags were found.
- Cleanup summary is shown for both actual removal and `--dry-run` preview mode.
- Both summaries include totals: `Total DB scanned`, `DB with matches`, and `Total tags matched`.
