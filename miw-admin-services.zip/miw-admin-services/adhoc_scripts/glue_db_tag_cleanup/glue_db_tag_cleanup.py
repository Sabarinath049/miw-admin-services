#!/usr/bin/env python3

import argparse
import boto3
import configparser
from botocore.exceptions import ClientError

CREDENTIALS_FILE = "aws_credentials.ini"
REGION = "us-east-1"  # Change if required

# Tags to remove
TAGS_TO_REMOVE = [
    "DataClassification",
    "PICategory"
]


def parse_tags(raw_tags):
    parsed_tags = []
    for raw_tag in raw_tags:
        parts = [part.strip() for part in raw_tag.split(",") if part.strip()]
        parsed_tags.extend(parts)

    unique_tags = []
    seen = set()
    for tag in parsed_tags:
        if tag not in seen:
            seen.add(tag)
            unique_tags.append(tag)

    return unique_tags


def parse_args():
    parser = argparse.ArgumentParser(
        description="Remove specific AWS Glue database tags"
    )

    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument(
        "--db",
        help="Glue database name to process"
    )
    mode_group.add_argument(
        "--all-dbs",
        action="store_true",
        help="Process all Glue databases"
    )

    parser.add_argument(
        "--region",
        default=REGION,
        help=f"AWS region (default: {REGION})"
    )
    parser.add_argument(
        "--credentials-file",
        default=CREDENTIALS_FILE,
        help=(
            f"Path to AWS credentials INI file "
            f"(default: {CREDENTIALS_FILE})"
        )
    )
    parser.add_argument(
        "--tags",
        nargs="+",
        default=None,
        help=(
            "Tags to remove. Accepts space-separated values and/or "
            "comma-separated entries. "
            f"(default: {', '.join(TAGS_TO_REMOVE)})"
        )
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview tag removals without making any changes"
    )
    parser.add_argument(
        "--yes",
        action="store_true",
        help="Skip confirmation prompt when default tags are used"
    )

    args = parser.parse_args()
    args.using_default_tags = args.tags is None

    if args.tags is None:
        args.tags = list(TAGS_TO_REMOVE)
    else:
        args.tags = parse_tags(args.tags)

    if not args.tags:
        raise ValueError("At least one tag must be provided via --tags")

    return args


def confirm_default_tag_removal(tags):
    tags_text = ", ".join(tags)
    response = input(
        f"No --tags provided. Default tags will be removed ({tags_text}). Continue? [y/N]: "
    ).strip().lower()
    return response in {"y", "yes"}


def create_session(credentials_file, region):
    config = configparser.ConfigParser()
    config.read(credentials_file)

    profiles = config.sections()
    if not profiles:
        raise Exception(f"No profiles found in {credentials_file}")

    # Take the first profile from the file
    profile = profiles[0]
    creds = config[profile]

    print(f"Using profile: {profile}")

    session = boto3.Session(
        aws_access_key_id=creds["aws_access_key_id"],
        aws_secret_access_key=creds["aws_secret_access_key"],
        aws_session_token=creds.get("aws_session_token"),
        region_name=region,
    )

    return session


def get_database_arns(glue, account_id, region, selected_db=None):
    if selected_db:
        try:
            glue.get_database(Name=selected_db)
        except ClientError as e:
            raise Exception(
                f"Failed to fetch database '{selected_db}': {e}"
            )

        db_arn = f"arn:aws:glue:{region}:{account_id}:database/{selected_db}"
        return [(selected_db, db_arn)]

    database_arns = []
    paginator = glue.get_paginator("get_databases")

    for page in paginator.paginate():
        for db in page["DatabaseList"]:
            db_name = db["Name"]
            db_arn = f"arn:aws:glue:{region}:{account_id}:database/{db_name}"
            database_arns.append((db_name, db_arn))

    return database_arns


def print_summary_table(summary_rows, total_db_scanned, dry_run=False):
    db_with_matches = len(summary_rows)
    total_tags_matched = sum(len(row["tags"]) for row in summary_rows)

    if not summary_rows:
        print("\nSummary: No databases found with the requested tags.")
        print(f"Total DB scanned: {total_db_scanned}")
        print(f"DB with matches: {db_with_matches}")
        print(f"Total tags matched: {total_tags_matched}")
        return

    action_header = "Would Remove" if dry_run else "Removed"
    headers = ["Database", "Tags Found", action_header]
    table_rows = []

    for row in summary_rows:
        db_name = row["database"]
        tags_text = ", ".join(row["tags"])
        action_value = "Yes"
        table_rows.append([db_name, tags_text, action_value])

    col_widths = []
    for idx, header in enumerate(headers):
        max_cell = max(len(r[idx]) for r in table_rows)
        col_widths.append(max(len(header), max_cell))

    def format_row(values):
        return "| " + " | ".join(
            value.ljust(col_widths[idx]) for idx, value in enumerate(values)
        ) + " |"

    separator = "+-" + "-+-".join("-" * width for width in col_widths) + "-+"

    print("\nSummary:")
    print(separator)
    print(format_row(headers))
    print(separator)
    for row in table_rows:
        print(format_row(row))
    print(separator)
    print(f"Total DB scanned: {total_db_scanned}")
    print(f"DB with matches: {db_with_matches}")
    print(f"Total tags matched: {total_tags_matched}")


def remove_matching_tags(glue, db_name, db_arn, tags_to_remove, dry_run=False):
    existing_tags = glue.get_tags(ResourceArn=db_arn).get("Tags", {})
    tags_present = [tag for tag in tags_to_remove if tag in existing_tags]

    if not tags_present:
        print(f"- No matching tags found on {db_name}")
        return []

    if dry_run:
        print(f"~ Dry run: would remove {tags_present} from {db_name}")
        return tags_present

    glue.untag_resource(
        ResourceArn=db_arn,
        TagsToRemove=tags_present
    )
    print(f"✓ Removed {tags_present} from {db_name}")
    return tags_present


def main():
    args = parse_args()

    if args.using_default_tags and not args.dry_run and not args.yes:
        if not confirm_default_tag_removal(args.tags):
            print("Operation cancelled by user.")
            return

    session = create_session(args.credentials_file, args.region)

    glue = session.client("glue")
    sts = session.client("sts")

    account_id = sts.get_caller_identity()["Account"]

    try:
        targets = get_database_arns(
            glue,
            account_id,
            args.region,
            selected_db=args.db
        )
    except Exception as e:
        print(f"✗ {e}")
        return

    summary_rows = []

    for db_name, db_arn in targets:
        try:
            tags_found = remove_matching_tags(
                glue,
                db_name,
                db_arn,
                args.tags,
                dry_run=args.dry_run
            )
            if tags_found:
                summary_rows.append({
                    "database": db_name,
                    "tags": tags_found,
                })
        except ClientError as e:
            print(f"✗ Failed for {db_name}: {e}")

    print_summary_table(
        summary_rows,
        total_db_scanned=len(targets),
        dry_run=args.dry_run
    )


if __name__ == "__main__":
    main()