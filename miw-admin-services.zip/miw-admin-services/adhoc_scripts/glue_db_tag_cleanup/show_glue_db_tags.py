#!/usr/bin/env python3

import argparse
import boto3
import configparser
from botocore.exceptions import ClientError

CREDENTIALS_FILE = "aws_credentials.ini"
REGION = "us-east-1"
TAGS_TO_SHOW = [
    "DataClassification",
    "PICategory"
]


def parse_tags(raw_tags):
    parsed_tags = []
    for raw_tag in raw_tags:
        parts = [part.strip() for part in raw_tag.split(",") if part.strip()]
        parsed_tags.extend(parts)

    unique_tags = []
    seen = set()
    for tag in parsed_tags:
        if tag not in seen:
            seen.add(tag)
            unique_tags.append(tag)

    return unique_tags


def parse_args():
    parser = argparse.ArgumentParser(
        description="Show AWS Glue database tags"
    )

    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument(
        "--db",
        help="Glue database name to process"
    )
    mode_group.add_argument(
        "--all-dbs",
        action="store_true",
        help="Process all Glue databases"
    )

    parser.add_argument(
        "--region",
        default=REGION,
        help=f"AWS region (default: {REGION})"
    )
    parser.add_argument(
        "--credentials-file",
        default=CREDENTIALS_FILE,
        help=(
            f"Path to AWS credentials INI file "
            f"(default: {CREDENTIALS_FILE})"
        )
    )
    parser.add_argument(
        "--tags",
        nargs="+",
        default=TAGS_TO_SHOW,
        help=(
            "Tags to display. Accepts space-separated values and/or "
            "comma-separated entries. "
            f"(default: {', '.join(TAGS_TO_SHOW)})"
        )
    )
    parser.add_argument(
        "--show-all-tags",
        action="store_true",
        help="Show all tags on each database (overrides --tags filter)"
    )

    args = parser.parse_args()
    args.tags = parse_tags(args.tags)

    if not args.tags:
        raise ValueError("At least one tag must be provided via --tags")

    return args


def create_session(credentials_file, region):
    config = configparser.ConfigParser()
    config.read(credentials_file)

    profiles = config.sections()
    if not profiles:
        raise Exception(f"No profiles found in {credentials_file}")

    profile = profiles[0]
    creds = config[profile]

    print(f"Using profile: {profile}")

    return boto3.Session(
        aws_access_key_id=creds["aws_access_key_id"],
        aws_secret_access_key=creds["aws_secret_access_key"],
        aws_session_token=creds.get("aws_session_token"),
        region_name=region,
    )


def get_database_arns(glue, account_id, region, selected_db=None):
    if selected_db:
        try:
            glue.get_database(Name=selected_db)
        except ClientError as e:
            raise Exception(
                f"Failed to fetch database '{selected_db}': {e}"
            )

        db_arn = f"arn:aws:glue:{region}:{account_id}:database/{selected_db}"
        return [(selected_db, db_arn)]

    database_arns = []
    paginator = glue.get_paginator("get_databases")

    for page in paginator.paginate():
        for db in page["DatabaseList"]:
            db_name = db["Name"]
            db_arn = f"arn:aws:glue:{region}:{account_id}:database/{db_name}"
            database_arns.append((db_name, db_arn))

    return database_arns


def print_summary_table(summary_rows, total_db_scanned):
    db_with_matches = len(summary_rows)
    total_tags_matched = sum(len(row["tags"]) for row in summary_rows)

    if not summary_rows:
        print("\nSummary: No databases found with matching tags.")
        print(f"Total DB scanned: {total_db_scanned}")
        print(f"DB with matches: {db_with_matches}")
        print(f"Total tags matched: {total_tags_matched}")
        return

    headers = ["Database", "Tags Found", "Tag Count"]
    table_rows = []

    for row in summary_rows:
        db_name = row["database"]
        tags_text = ", ".join(row["tags"])
        tag_count = str(len(row["tags"]))
        table_rows.append([db_name, tags_text, tag_count])

    col_widths = []
    for idx, header in enumerate(headers):
        max_cell = max(len(r[idx]) for r in table_rows)
        col_widths.append(max(len(header), max_cell))

    def format_row(values):
        return "| " + " | ".join(
            value.ljust(col_widths[idx]) for idx, value in enumerate(values)
        ) + " |"

    separator = "+-" + "-+-".join("-" * width for width in col_widths) + "-+"

    print("\nSummary:")
    print(separator)
    print(format_row(headers))
    print(separator)
    for row in table_rows:
        print(format_row(row))
    print(separator)
    print(f"Total DB scanned: {total_db_scanned}")
    print(f"DB with matches: {db_with_matches}")
    print(f"Total tags matched: {total_tags_matched}")


def print_db_tags(glue, db_name, db_arn, tags_to_show, show_all_tags=False):
    response = glue.get_tags(ResourceArn=db_arn)
    tags = response.get("Tags", {})

    if show_all_tags:
        display_tags = tags
    else:
        display_tags = {key: value for key, value in tags.items() if key in tags_to_show}

    print(f"\nDatabase: {db_name}")
    print(f"ARN: {db_arn}")

    if not display_tags:
        if show_all_tags:
            print("No tags found.")
        else:
            print("No matching tags found.")
        return []

    print("Tags:")
    for key, value in display_tags.items():
        print(f"  {key} = {value}")

    return list(display_tags.keys())


def main():
    args = parse_args()
    session = create_session(args.credentials_file, args.region)

    glue = session.client("glue")
    sts = session.client("sts")

    account_id = sts.get_caller_identity()["Account"]

    try:
        targets = get_database_arns(
            glue,
            account_id,
            args.region,
            selected_db=args.db
        )
    except Exception as e:
        print(f"✗ {e}")
        return

    summary_rows = []

    for db_name, db_arn in targets:
        try:
            tags_found = print_db_tags(
                glue,
                db_name,
                db_arn,
                args.tags,
                show_all_tags=args.show_all_tags
            )
            if tags_found:
                summary_rows.append({
                    "database": db_name,
                    "tags": tags_found,
                })
        except ClientError as e:
            print(f"✗ Failed for {db_name}: {e}")

    print_summary_table(summary_rows, total_db_scanned=len(targets))


if __name__ == "__main__":
    main()
    