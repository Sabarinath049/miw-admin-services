#!/bin/bash

###############################################################################
# Script: Snowflake Backup, Restore & Compare Utility
# Description: Handles Snowflake database backup (clone), Terraform state backup, restore operations, and data comparison using metadata-driven execution.
# Author: Ravi Pawar
###############################################################################

MODE="${MODE:-backup}"  # default to backup if not set
env="prd"
metadata_dir="$CODEBUILD_SRC_DIR"
export SCHEMA_FOLDER="$CODEBUILD_SRC_DIR/snowflake/schemas/"
secret_arn="arn:aws:secretsmanager:us-east-1:255914130710:secret:minerva-prd-corp-miw-snowflake-secretsmanager-secret-oYJadC"
export SF_ROLE="MINERVA_DTD_MIW_DBADMIN_SNF_PRD"
export WAREHOUSE="PRD_DTD_MIW_PIPLN_SNF_01_WH"

# Python version and requirements
python --version
pip install -r "$CODEBUILD_SRC_DIR_admin/requirements.txt"

# Install SnowSQL silently if not present
if ! command -v snowsql >/dev/null 2>&1; then
  echo "Installing SnowSQL..."
  curl -sO https://sfc-repo.snowflakecomputing.com/snowsql/bootstrap/1.2/linux_x86_64/snowsql-1.2.24-linux_x86_64.bash
  SNOWSQL_INSTALL_DIR="$HOME/.snowsql"
  mkdir -p "$SNOWSQL_INSTALL_DIR"
  echo -e "$SNOWSQL_INSTALL_DIR\n" | bash snowsql-1.2.24-linux_x86_64.bash
  export PATH="$SNOWSQL_INSTALL_DIR:$PATH"
fi

"$HOME/.snowsql/snowsql" -v

# Fetch credentials
secret_json=$(aws secretsmanager get-secret-value --secret-id "$secret_arn" --query 'SecretString' --output text)
export ACCOUNT_NAME=$(echo "$secret_json" | jq -r '.account')
export CLIENT_ID=$(echo "$secret_json" | jq -r '.client_id')
export CLIENT_SECRET=$(echo "$secret_json" | jq -r '.client_secret')
export SCOPE=$(echo "$secret_json" | jq -r '.scope')
export USER=$(echo "$secret_json" | jq -r '.user')

echo "🔐 Generating OAuth token..."
token_response=$(curl -s -X POST "https://login.microsoftonline.com/57368c21-b8cf-42cf-bd0b-43ecd4bc62ae/oauth2/v2.0/token" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "grant_type=client_credentials" \
    -d "client_id=${CLIENT_ID}" \
    -d "client_secret=${CLIENT_SECRET}" \
    -d "scope=${SCOPE}")
export OAUTH_TOKEN=$(echo "$token_response" | jq -r '.access_token')
echo "✅ OAuth token retrieved successfully"

  if [ "$MODE" == "backup" ]; then
      # Declare unified associative array
      declare -A domain_map

      # Group metadata files by domain or domain_or_prodgrp
      for file in $(find "$metadata_dir" -type f -name "*.json"); do
        key=$(grep -o '"enterprise_or_func_subgrp_name"[[:space:]]*:[[:space:]]*"[^"]*"' "$file" \
              | sed 's/.*: *"\([^"]*\)".*/\1/')
        if [ -n "$key" ]; then
            domain_map["$key"]+="$file"$'\n'
        fi
      done

      # Display grouped results
      echo -e "\n📦 Grouped by domain_or_prodgrp:"
      for key in "${!domain_map[@]}"; do
          echo -e "\n🔑 Value: $key"
          echo "${domain_map[$key]}"
      done

      # Process all domains and databases
      for key in "${!domain_map[@]}"; do
          echo -e "\n🌐 Processing domain: $key"
          files="${domain_map[$key]}"
          db_files=$(echo "$files" | grep '/databases/' | awk -F/ '{print $NF}' | sed 's/\.json$//')
          schema_files=$(echo "$files" | grep '/schemas/' | awk -F/ '{print $NF}' | sed 's/\.json$//')

          for db in $db_files; do
              backup_db="BKP_$db"
              echo "CREATE DATABASE $backup_db CLONE $db"
          done

          for schema in $schema_files; do
            echo
            echo "### Commands for schema: $schema"
            echo "terraform state list \\"
            echo "  | awk '/module\\.schema\\[\"enriched_${schema}\\.json\"\\]/{print}' \\"
            echo "  | grep -v 'snowflake_schema\\.miw_schema\$' \\"
            echo "  | while IFS= read -r addr; do"
            echo "      echo \"Removing: \$addr\""
            echo "      terraform state rm \"\$addr\""
            echo "    done"
          done
      done

        echo "☁️ Backing up tfstate files from S3..."
        timestamp=$(date +"%Y%m%d-%H%M%S")
        aws s3 cp s3://minerva-${env}-corp-miw-tfstate-255914130710-useast1/snowflake/prd/ \
                 s3://minerva-${env}-corp-miw-tfstate-255914130710-useast1/backup_$timestamp/snowflake/prd/ \
                 --recursive --region us-east-1

  elif [ "$MODE" == "restore" ] && [ -n "$restored_db" ] && [ "$restored_db" != "null" ] && [ -n "$DATABASE_NAME" ] && [ "$DATABASE_NAME" != "null" ]; then

      python "$CODEBUILD_SRC_DIR_admin/generate_query.py" --operation 2

  elif [ "$MODE" == "compare" ]; then
     echo "🔍 Comparing $restored_db with $DATABASE_NAME..."


    compare_query() {
        local query="$1"
        local label="$2"

        echo "🔸 Comparing $label..."

        if [ -z "$restored_db" ] || [ -z "$DATABASE_NAME" ]; then
            echo "⚠️ Skipping $label comparison: database name is empty."
            return
        fi

        # Check if databases exist
        for db in "$restored_db" "$DATABASE_NAME"; do
            db_check=$(snowsql --authenticator oauth --token "$OAUTH_TOKEN" --accountname "$ACCOUNT_NAME" \
                --rolename "$SF_ROLE" --warehouse "$WAREHOUSE" \
                -q "SHOW DATABASES LIKE '$db';" -o output_format=csv -o header=false)
            if ! echo "$db_check" | grep -q "$db"; then
                echo "❌ Database $db does not exist. Skipping $label comparison."
                return
            fi
        done

        # Run queries and extract only data rows
        new_output=$(snowsql --authenticator oauth --token "$OAUTH_TOKEN" --accountname "$ACCOUNT_NAME" \
            --rolename "$SF_ROLE" --warehouse "$WAREHOUSE" \
            -q "USE DATABASE $restored_db; $query" -o output_format=csv -o header=false 2>&1 | grep '^"')

        bkp_output=$(snowsql --authenticator oauth --token "$OAUTH_TOKEN" --accountname "$ACCOUNT_NAME" \
            --rolename "$SF_ROLE" --warehouse "$WAREHOUSE" \
            -q "USE DATABASE $DATABASE_NAME; $query" -o output_format=csv -o header=false 2>&1 | grep '^"')

        # Check for SQL errors
        if [[ "$new_output" == *"SQL compilation error"* || "$bkp_output" == *"SQL compilation error"* ]]; then
            echo "⚠️ Skipping $label comparison due to SQL error."
            echo "🔍 Error in restored_db output: $new_output"
            echo "🔍 Error in $DATABASE_NAME output: $bkp_output"
            return
        fi

        # Compare sorted outputs
        if diff <(echo "$new_output" | sort) <(echo "$bkp_output" | sort) >/dev/null; then
            echo "✅ $label match"
        else
            echo "❌ $label mismatch"
            echo "🔁 Differences:"
            diff <(echo "$new_output" | sort) <(echo "$bkp_output" | sort)
            exit 1
        fi
    }

      compare_query "SELECT TABLE_SCHEMA, TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' ORDER BY 1,2;" "Table structure"
      compare_query "SELECT TABLE_SCHEMA, TABLE_NAME, ROW_COUNT FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' ORDER BY 1,2;" "Row counts"
      compare_query "SHOW VIEWS;" "Views"
      compare_query "SHOW PROCEDURES;" "Procedures"
      compare_query "SHOW FUNCTIONS;" "Functions"

      echo "🎉 All checks passed. $restored_db is identical to $DATABASE_NAME."
  fi
