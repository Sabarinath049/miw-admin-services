#!/bin/bash

FILE=${1:-"glueUP_config.json"}
REGION=${2:-"us-east-1"}
ENV=${3:-"PRD"}
ACCOUNT_TYPE=${4:-"LH"}

# Usage:
# ./glue_UP_create_or_update.sh [json-file] [region] [env] [account_type]
# Example:
# ./glue_UP_create_or_update.sh glue_UP_config.json us-east-1 PRD LH

if [ ! -f "$FILE" ]; then
  echo "JSON file $FILE not found!"
  exit 1
fi

echo "ENV: $ENV"
echo "ACCOUNT_TYPE: $ACCOUNT_TYPE"
echo "Reading usage profiles from $FILE..."
echo "----------------------------------------"

# Loop through profile suffixes (XSML, SML, etc.)
for PROFILE_SUFFIX in $(jq -r 'keys[]' "$FILE"); do

  PROFILE_NAME="${ENV}_${ACCOUNT_TYPE}_${PROFILE_SUFFIX}"

  echo ""
  echo "Processing profile: $PROFILE_NAME"

  # Extract config template
  CONFIG=$(jq -c --arg key "$PROFILE_SUFFIX" '.[$key]' "$FILE")

  echo "$CONFIG" > /tmp/${PROFILE_NAME}.json

  # Check if exists
  aws glue get-usage-profile \
      --name "$PROFILE_NAME" \
      --region "$REGION" > /dev/null 2>&1

  if [ $? -eq 0 ]; then
    echo "Profile exists. Updating..."
    aws glue update-usage-profile \
        --name "$PROFILE_NAME" \
        --configuration file:///tmp/${PROFILE_NAME}.json \
        --region "$REGION"
  else
    echo "Profile does not exist. Creating..."
    aws glue create-usage-profile \
        --name "$PROFILE_NAME" \
        --configuration file:///tmp/${PROFILE_NAME}.json \
        --region "$REGION"
  fi

  if [ $? -eq 0 ]; then
    echo "SUCCESS: $PROFILE_NAME ✅"
  else
    echo "FAILED: $PROFILE_NAME ❌"
  fi

  rm -f /tmp/${PROFILE_NAME}.json

done

echo ""
echo "----------------------------------------"
echo "All profiles processed."
