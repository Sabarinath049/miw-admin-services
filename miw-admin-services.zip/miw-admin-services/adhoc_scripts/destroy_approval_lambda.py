###############################################################################
# Script      : CodePipeline Approval Function
# Description : Resolves PR information, validates Terraform destroy-count
#               artifacts, and performs automatic/manual approval decisions.
# Author      : Ravi Pawar
###############################################################################

import json
import os
import re
import time

import boto3
import urllib3
from botocore.exceptions import ClientError


# ---------------------------------------------------------
# AWS clients
# ---------------------------------------------------------

codepipeline = boto3.client("codepipeline")
sts = boto3.client("sts")
s3 = boto3.client("s3")
sns = boto3.client("sns")

http = urllib3.PoolManager()


# ---------------------------------------------------------
# Constants
# ---------------------------------------------------------

REPO_PATH = "Minerva/miw-object-provisioning"
GIT_API_BASE = "https://git.cglcloud.com/api/v3"
PR_WEB_BASE = (
    "https://git.cglcloud.com/"
    "Minerva/miw-object-provisioning/pull"
)


# ---------------------------------------------------------
# General helpers
# ---------------------------------------------------------

def get_github_token():
    """
    Retrieve the GitHub Enterprise token from the Lambda
    environment variables.
    """
    token = os.environ.get("GITHUB_TOKEN")

    return token.strip() if token else None


def git_api_get(url, token):
    """
    Call the GitHub Enterprise API and return decoded JSON.
    """
    if not token:
        print("[ERROR] GITHUB_TOKEN is not configured")
        return None

    try:
        headers = {
            "Authorization": f"token {token}",
            "Accept": "application/json"
        }

        response = http.request(
            "GET",
            url,
            headers=headers,
            timeout=urllib3.Timeout(
                connect=5.0,
                read=15.0
            ),
            retries=False
        )

        if response.status != 200:
            response_body = response.data.decode(
                "utf-8",
                errors="replace"
            )

            print(
                "[ERROR] Git API request failed. "
                f"Status={response.status}, "
                f"URL={url}, "
                f"Response={response_body[:500]}"
            )

            return None

        return json.loads(
            response.data.decode("utf-8")
        )

    except Exception as e:
        print(
            "[ERROR] Git API request failed. "
            f"URL={url}, Error={e}"
        )

        return None


# ---------------------------------------------------------
# CodePipeline helpers
# ---------------------------------------------------------

def get_object_sha_from_state(pipeline_name, retries=3):
    """
    Retrieve the current miw-object-provisioning source revision
    from the CodePipeline Source stage.
    """
    if not pipeline_name:
        return None

    for attempt in range(1, retries + 1):
        try:
            state = codepipeline.get_pipeline_state(
                name=pipeline_name
            )

            for stage in state.get("stageStates", []):
                if stage.get("stageName") != "Source":
                    continue

                for action in stage.get("actionStates", []):
                    action_name = (
                        action.get("actionName") or ""
                    ).lower()

                    if (
                        "object" in action_name
                        or "provision" in action_name
                    ):
                        revision = (
                            action.get("currentRevision") or {}
                        ).get("revisionId")

                        if revision:
                            print(
                                "[DEBUG] Source revision found: "
                                f"{revision}"
                            )

                            return revision

        except Exception as e:
            print(
                "[WARN] Unable to read pipeline state. "
                f"Attempt={attempt}/{retries}, "
                f"Error={e}"
            )

        time.sleep(1)

    return None

"""
Validate that the current PR HEAD SHA matches the most recently
generated destroy-count artifact.

This prevents older PR revisions from being selected when multiple
artifacts exist under the same S3 bucket PR folder and ensures
we always use the latest validated revision.
"""

def latest_sha_matches_pr_head_sha(
    bucket_name,
    pr_number,
    pr_head_sha
):

    try:

        response = s3.list_objects_v2(
            Bucket=bucket_name,
            Prefix=f"destroy_count/{pr_number}/"
        )

        contents = response.get(
            "Contents",
            []
        )

        if not contents:

            print(
                f"[WARN] No artifacts found for "
                f"PR={pr_number}"
            )

            return False

        latest_object = max(
            contents,
            key=lambda x: x["LastModified"]
        )

        latest_sha = (
            latest_object["Key"]
            .split("/")[-1]
            .replace(".txt", "")
        )

        print(
            f"[INFO] PR={pr_number} "
            f"LatestSHA={latest_sha} "
            f"CurrentHeadSHA={pr_head_sha}"
        )

        return latest_sha == pr_head_sha

    except Exception as e:

        print(
            f"[ERROR] Failed latest SHA validation "
            f"for PR={pr_number}: {e}"
        )

        return False


# ---------------------------------------------------------
# Pull request helpers
# ---------------------------------------------------------

def is_manual_execution(pipeline_name, execution_id):
    """
    Return True when CodePipeline was manually started.
    """

    if not pipeline_name or not execution_id:
        return False

    try:
        response = codepipeline.get_pipeline_execution(
            pipelineName=pipeline_name,
            pipelineExecutionId=execution_id
        )

        trigger = (
            response
            .get("pipelineExecution", {})
            .get("trigger", {})
        )

        trigger_type = trigger.get("triggerType")

        print(
            f"[DEBUG] Trigger type: {trigger_type}"
        )

        return (
            trigger_type ==
            "StartPipelineExecution"
        )

    except Exception as e:
        print(
            f"[WARN] Trigger detection failed: {e}"
        )

        return False

def get_pr_from_sha(sha, token, bucket_name):

    if not sha or not token:
        return None

    url = (
        f"{GIT_API_BASE}/repos/{REPO_PATH}/"
        f"commits/{sha}/pulls"
    )

    data = git_api_get(url, token)

    if not isinstance(data, list) or not data:
        return None

    print(
        f"[DEBUG] Candidate PRs: "
        f"{[p.get('number') for p in data]}"
    )

    # Only merged PRs are eligible for deployment approval.
    # Open or closed-but-unmerged PRs are ignored.

    merged_prs = [
        pr for pr in data
        if pr.get("merged_at")
    ]

    print(
        f"[DEBUG] Merged PRs: "
        f"{[p.get('number') for p in merged_prs]}"
    )

    matching_prs = []

    for pr in merged_prs:

        pr_number = str(pr["number"])

        head_sha = get_pr_head_sha(
            pr_number,
            token
        )

        if not head_sha:
            continue

        key = (
            f"destroy_count/{pr_number}/"
            f"{head_sha}.txt"
        )

        print(
            f"[DEBUG] Checking S3 key: {key}"
        )

        try:

            # A candidate PR is considered valid only if a destroy-count
            # artifact exists for the current HEAD SHA.

            s3.head_object(
                Bucket=bucket_name,
                Key=key
            )

            # Ensure the current PR HEAD SHA matches the most recently
            # generated artifact for this PR before accepting it as a
            # deployment candidate.

            if not latest_sha_matches_pr_head_sha(
                bucket_name,
                pr_number,
                head_sha
            ):

                print(
                    f"[INFO] Rejecting PR={pr_number}. "
                    f"Current HEAD SHA is not the "
                    f"latest artifact in folder."
                )

                continue

            print(
                f"[INFO] Matching destroy file "
                f"found for PR={pr_number}"
            )

        except ClientError:

            print(
                f"[WARN] Destroy-count artifact not found "
                f"for PR={pr_number}, SHA={head_sha}. "
                f"Proceeding with PR selection."
            )

        matching_prs.append({
            "pr_number": pr_number,
            "merged_at": pr.get("merged_at")
        })

    if len(matching_prs) == 1:

        print(
            f"[INFO] Single matching PR found: "
            f"{matching_prs[0]['pr_number']}"
        )

        return matching_prs[0]["pr_number"]

    elif len(matching_prs) > 1:

        print(
        f"[WARN] Multiple matching PRs survived all "
        f"validation filters: {matching_prs}"
        )

        # Multiple valid PR candidates are unexpected but possible.
        # Select the most recently merged PR as the final tie-breaker.

        matching_prs.sort(
            key=lambda x: x["merged_at"],
            reverse=True
        )

        print(
            f"[WARN] Multiple matching PRs found. "
            f"Selecting latest merged PR: "
            f"{matching_prs[0]['pr_number']}"
        )

        return matching_prs[0]["pr_number"]

    print(
        f"[ERROR] No matching destroy-count file "
        f"found for commit SHA={sha}"
    )

    return None

def get_pr_head_sha(pr_number, token):
    """
    Retrieve the current HEAD commit SHA for a pull request.

    The returned SHA is used to locate the destroy-count object
    generated for the exact PR revision.
    """
    if not str(pr_number).isdigit():
        print(
            "[WARN] Invalid PR number for SHA lookup: "
            f"{pr_number}"
        )

        return None

    url = (
        f"{GIT_API_BASE}/repos/{REPO_PATH}/"
        f"pulls/{pr_number}"
    )

    data = git_api_get(
        url,
        token
    )

    if not data:
        return None

    head_sha = (
        data
        .get("head", {})
        .get("sha")
    )

    if not head_sha:
        print(
            f"[ERROR] Head SHA not found for "
            f"PR {pr_number}"
        )

        return None

    print(
        f"[INFO] Current head SHA for "
        f"PR {pr_number}: {head_sha}"
    )

    return head_sha


# ---------------------------------------------------------
# Destroy-count helper
# ---------------------------------------------------------

def get_destroy_count(bucket, pr_number, pr_head_sha):
    """
    Retrieve the destroy count for the exact PR revision.

    Expected S3 object:

    destroy_count/<PR_NUMBER>/<PR_HEAD_SHA>.txt
    """
    if not pr_head_sha:
        print(
            "[WARN] PR head SHA is unavailable"
        )

        return None

    key = (
        f"destroy_count/{pr_number}/"
        f"{pr_head_sha}.txt"
    )

    print(
        "[INFO] Reading destroy count: "
        f"s3://{bucket}/{key}"
    )

    try:

        obj = s3.get_object(
            Bucket=bucket,
            Key=key
        )

        body = (
            obj["Body"]
            .read()
            .decode("utf-8")
            .strip()
        )

        if not re.fullmatch(r"\d+", body):
            print(
                f"[ERROR] Invalid destroy count content: "
                f"'{body}'"
            )
            return None

        return int(body)

    except ClientError as e:
        error_code = (
            e.response
            .get("Error", {})
            .get("Code")
        )

        if error_code in (
            "NoSuchKey",
            "NoSuchObject",
            "404"
        ):
            print(
                "[WARN] Destroy count not found for "
                f"PR={pr_number}, "
                f"SHA={pr_head_sha}"
            )
        else:
            print(
                "[ERROR] Unable to read destroy count "
                f"from S3: {e}"
            )

        return None

    except Exception as e:
        print(
            "[ERROR] Unexpected destroy-count "
            f"error: {e}"
        )

        return None


# ---------------------------------------------------------
# Notification helper
# ---------------------------------------------------------

def publish_helper_sns(
    topic_arn,
    pipeline_name,
    stage_name,
    action_name,
    env,
    pr_number,
    pr_head_sha,
    destroy_count,
    needs_approval,
    approval_reason=None
):
    """
    Send approval information to the configured helper SNS topic.
    """
    if not topic_arn:
        print(
            "[INFO] No approver SNS topic configured"
        )

        return

    try:
        # Subject
        if str(pr_number).isdigit():
            subject = (
                f"CodePipeline Approval: {pipeline_name} | PR: {pr_number}"
            )
        else:
            subject = (
                f"CodePipeline Approval: {pipeline_name} | PR: Not Identified"
            )

        # PR link
        if str(pr_number).isdigit():
            pr_link = (
                f"{PR_WEB_BASE}/{pr_number}"
            )
        else:
            pr_link = "N/A"

        # Approval status
        approval_status = (
            "YES"
            if needs_approval
            else "NO"
        )

        # Destroy count display
        display_destroy_count = (
            destroy_count
            if destroy_count is not None
            else "No destroy count file found"
        )

        # Include deployment context and approval rationale so approvers
        # can understand why manual intervention is required without
        # reviewing CloudWatch logs.

        message = (
            f"CodePipeline Approval: {pipeline_name}\n\n"
            f"Project Name   : {pipeline_name}\n"
            f"Stage          : {stage_name}\n"
            f"Action         : {action_name}\n"
            f"Environment    : {env}\n"
            f"PR Number      : {pr_number}\n"
            f"PR Link        : {pr_link}\n"
            f"PR Head SHA    : {pr_head_sha or 'Unavailable'}\n"
            f"Destroy Count  : {display_destroy_count}\n"
            f"Approval Needed: {approval_status}\n\n"
            f"Description:\n"
            f"{approval_reason or 'Manual review required.'}\n\n"
            f"AWS Console:\n"
            f"https://us-east-1.console.aws.amazon.com/"
            f"codesuite/codepipeline/pipelines/"
            f"{pipeline_name}/view\n"
        )

        sns.publish(
            TopicArn=topic_arn,
            Subject=subject[:100],
            Message=message
        )

        print(
            "[INFO] Approval notification sent"
        )

    except Exception as e:
        print(
            f"[ERROR] SNS publish failed: {e}"
        )


# ---------------------------------------------------------
# Lambda handler
# ---------------------------------------------------------

def lambda_handler(event, context):
    print("[DEBUG] Lambda event received")

    # -----------------------------------------------------
    # Validate SNS event
    # -----------------------------------------------------

    if not isinstance(event, dict):
        print(
            "[ERROR] Lambda event is not a JSON object"
        )

        return {
            "autoApproved": False,
            "reason": "Invalid event"
        }

    records = event.get("Records", [])

    if not records:
        print(
            "[ERROR] Event does not contain SNS records"
        )

        return {
            "autoApproved": False,
            "reason": "SNS record missing"
        }

    sns_record = records[0].get("Sns", {})
    raw_message = sns_record.get("Message")

    if not raw_message:
        print(
            "[ERROR] SNS message is empty"
        )

        return {
            "autoApproved": False,
            "reason": "SNS message missing"
        }

    try:
        detail = json.loads(raw_message)

    except json.JSONDecodeError as e:
        print(
            "[ERROR] SNS message is not valid JSON: "
            f"{e}"
        )

        return {
            "autoApproved": False,
            "reason": "Invalid SNS JSON"
        }

    approval = detail.get("approval", {})

    if not approval:
        print(
            "[ERROR] Approval details are missing "
            "from SNS message"
        )

        return {
            "autoApproved": False,
            "reason": "Approval details missing"
        }

    # -----------------------------------------------------
    # Read event and environment values
    # -----------------------------------------------------

    env = (
        os.environ.get("ENV") or "dev"
    ).lower()

    account_id = (
        sts.get_caller_identity()["Account"]
    )

    pipeline_name = approval.get(
        "pipelineName"
    )

    stage_name = approval.get(
        "stageName"
    )

    action_name = approval.get(
        "actionName"
    )

    approval_token = approval.get(
        "token"
    )

    execution_id = approval.get(
        "pipelineExecutionId"
    )

    if not pipeline_name:
        print(
            "[ERROR] pipelineName is missing "
            "from approval event"
        )

        return {
            "autoApproved": False,
            "reason": "Pipeline name missing"
        }

    if not stage_name:
        print(
            "[ERROR] stageName is missing "
            "from approval event"
        )

        return {
            "autoApproved": False,
            "reason": "Stage name missing"
        }

    if not action_name:
        print(
            "[ERROR] actionName is missing "
            "from approval event"
        )

        return {
            "autoApproved": False,
            "reason": "Action name missing"
        }

    # CodeBuild uploads the destroy count to the logging bucket.
    bucket_name = (
        f"minerva-{env}-corp-miw-logging-"
        f"{account_id}-useast1"
    )

    github_token = get_github_token()
    approval_reason = None

    # -----------------------------------------------------
    # Retrieve Source revision
    # -----------------------------------------------------

    source_revision = get_object_sha_from_state(
        pipeline_name
    )

    # -----------------------------------------------------
    # Determine PR number
    # -----------------------------------------------------

    pr_number = None

    # Unable to correlate the deployment revision to a valid PR.
    # Require manual review to prevent accidental approvals.

    if not pr_number:
        pr_number = get_pr_from_sha(
            source_revision,
            github_token,
            bucket_name
        )

    if not pr_number:

        approval_reason = (
            "Unable to identify a PR associated "
            "with the current deployment revision."
        )

        pr_number = "Not Identified"

    manual_execution = False

    if execution_id:
        manual_execution = is_manual_execution(
            pipeline_name,
            execution_id
        )

    # -----------------------------------------------------
    # Retrieve destroy count for current PR revision
    # -----------------------------------------------------

    pr_head_sha = None
    destroy_count = None

    if str(pr_number).isdigit():
        pr_head_sha = get_pr_head_sha(
            pr_number,
            github_token
        )

        if pr_head_sha:
            destroy_count = get_destroy_count(
                bucket_name,
                pr_number,
                pr_head_sha
            )

    print(
        f"[INFO] Pipeline={pipeline_name} "
        f"PR={pr_number} "
        f"SHA={pr_head_sha} "
        f"DESTROY={destroy_count} "
        f"MANUAL={manual_execution}"
    )

    # -----------------------------------------------------
    # Approval decision
    # -----------------------------------------------------

    needs_approval = True

    if manual_execution:

        print(
            "[INFO] Manual pipeline execution: "
            "auto-approve"
        )

        needs_approval = False

    elif not str(pr_number).isdigit():

        approval_reason = (
            "No Pull Request could be identified for the current "
            "deployment revision. Contact MIW Support to "
            "investigate the issue manually."
        )

        print(
            "[WARN] PR number unavailable: "
            "requiring approval"
        )

    elif not pr_head_sha:

        approval_reason = (
            "Unable to retrieve the current "
            "PR HEAD SHA."
        )

        print(
            "[WARN] PR head SHA unavailable: "
            "requiring approval"
        )

    elif destroy_count is None:

        # Destroy-count file is unavailable for the current PR revision.
        # Existing behavior is to auto-approve because no deletion
        # information is available.

        approval_reason = (
            "Destroy count file was not found "
            "for the current PR revision."
        )

        print(
            "[WARN] Destroy count unavailable for "
            "current PR revision: auto-approving"
        )

        needs_approval = False

    # Resource deletions detected. Require manual approval before
    # allowing the deployment to proceed.

    elif destroy_count > 0:

        approval_reason = (
            f"Approval required because "
            f"{destroy_count} resource(s) will "
            f"be destroyed."
        )

        print(
            f"[INFO] Destroy count is {destroy_count}: "
            "requiring approval"
        )

    # No resources will be destroyed. Safe to continue with
    # automatic approval.

    else:
        print(
            "[INFO] Destroy count is zero: "
            "auto-approve"
        )

        needs_approval = False

    # -----------------------------------------------------
    # Manual approval required
    # -----------------------------------------------------

    # Send approval notification and stop the pipeline until a
    # reviewer manually approves the deployment.

    if needs_approval:
        helper_topic = os.environ.get(
            "APPROVER_INFO_SNS_ARN"
        )

        publish_helper_sns(
            helper_topic,
            pipeline_name,
            stage_name,
            action_name,
            env,
            pr_number,
            pr_head_sha,
            destroy_count,
            needs_approval,
            approval_reason=approval_reason
        )

        print(
            "[RESULT] Waiting for manual approval"
        )

        return {
            "autoApproved": False,
            "prNumber": pr_number,
            "prHeadSha": pr_head_sha,
            "destroyCount": destroy_count,
            "reason": "Manual approval required"
        }

    # -----------------------------------------------------
    # Auto-approval requires a valid approval token
    # -----------------------------------------------------

    if not approval_token:
        print(
            "[ERROR] Approval token is missing"
        )

        return {
            "autoApproved": False,
            "prNumber": pr_number,
            "prHeadSha": pr_head_sha,
            "destroyCount": destroy_count,
            "reason": "Approval token missing"
        }

    # -----------------------------------------------------
    # Submit approval result to CodePipeline
    # -----------------------------------------------------

    try:
        # Automatically approve the pipeline when approval criteria
        # do not require manual intervention.

        codepipeline.put_approval_result(
            pipelineName=pipeline_name,
            stageName=stage_name,
            actionName=action_name,
            token=approval_token,
            result={
                "status": "Approved",
                "summary": (
                    f"Auto-approved "
                    f"(PR={pr_number}, "
                    f"destroy={destroy_count})"
                )[:512]
            }
        )

        print(
            "[RESULT] Auto-approved"
        )

        return {
            "autoApproved": True,
            "prNumber": pr_number,
            "prHeadSha": pr_head_sha,
            "destroyCount": destroy_count
        }

    except ClientError as e:
        error_code = (
            e.response
            .get("Error", {})
            .get("Code", "Unknown")
        )

        error_message = (
            e.response
            .get("Error", {})
            .get("Message", str(e))
        )

        print(
            "[ERROR] Approval failed. "
            f"Code={error_code}, "
            f"Message={error_message}"
        )

        return {
            "autoApproved": False,
            "prNumber": pr_number,
            "prHeadSha": pr_head_sha,
            "destroyCount": destroy_count,
            "reason": f"Approval failed: {error_code}"
        }

    except Exception as e:
        print(
            f"[ERROR] Unexpected approval error: {e}"
        )

        return {
            "autoApproved": False,
            "prNumber": pr_number,
            "prHeadSha": pr_head_sha,
            "destroyCount": destroy_count,
            "reason": "Unexpected approval error"
        }