import json

def get_file_format_query(new_db, schema, row) -> str:
    """Formats a file format creation query based on the provided row data."""
    ff_name = row[1]
    ff_comment = row[6]
    ff_options = json.loads(row[7])

    def quote_or_literal(val):
        """Return val unquoted if it's AUTO, HEX, NONE; else quote it."""
        if val is None:
            return "''"
        upper_val = str(val).upper()
        if upper_val in ['AUTO', 'HEX', 'NONE']:
            return upper_val
        return f"'{val}'"
    
    # Handle ESCAPE_UNENCLOSED_FIELD properly
    escape_unenclosed = ff_options.get('ESCAPE_UNENCLOSED_FIELD', '\\\\')
    if escape_unenclosed == '\\':
        escape_unenclosed = "'\\\\'"
    else:
        escape_unenclosed = quote_or_literal(escape_unenclosed)

    # Format NULL_IF correctly
    null_if_vals = ff_options.get('NULL_IF', ['NULL', 'null'])
    null_if = "(" + ", ".join(f"'{v}'" for v in null_if_vals) + ")"
    
    query = (
        f"CREATE OR REPLACE FILE FORMAT {new_db}.{schema}.{ff_name} \n"
        f"\tTYPE = {quote_or_literal(ff_options['TYPE'])} \n"
        f"\tCOMMENT = '{ff_comment}' \n"
        f"\tRECORD_DELIMITER = '\\n' \n"
        f"\tFIELD_DELIMITER = ',' \n"
        f"\tSKIP_HEADER = {ff_options.get('SKIP_HEADER', 0)} \n"
        f"\tPARSE_HEADER = {str(ff_options.get('PARSE_HEADER', False)).upper()} \n"
        f"\tDATE_FORMAT = {quote_or_literal(ff_options.get('DATE_FORMAT', 'AUTO'))} \n"
        f"\tTIME_FORMAT = {quote_or_literal(ff_options.get('TIME_FORMAT', 'AUTO'))} \n"
        f"\tTIMESTAMP_FORMAT = {quote_or_literal(ff_options.get('TIMESTAMP_FORMAT', 'AUTO'))} \n"
        f"\tBINARY_FORMAT = {quote_or_literal(ff_options.get('BINARY_FORMAT', 'HEX'))} \n"
        f"\tESCAPE = {quote_or_literal(ff_options.get('ESCAPE', 'NONE'))} \n"
        f"\tESCAPE_UNENCLOSED_FIELD = {escape_unenclosed} \n"
        f"\tTRIM_SPACE = {str(ff_options.get('TRIM_SPACE', True)).upper()} \n"
        f"\tFIELD_OPTIONALLY_ENCLOSED_BY = {quote_or_literal(ff_options.get('FIELD_OPTIONALLY_ENCLOSED_BY', 'NONE'))} \n"
        f"\tNULL_IF = {null_if} \n"
        f"\tCOMPRESSION = {quote_or_literal(ff_options.get('COMPRESSION', 'AUTO'))} \n"
        f"\tERROR_ON_COLUMN_COUNT_MISMATCH = {str(ff_options.get('ERROR_ON_COLUMN_COUNT_MISMATCH', True)).upper()} \n"
        f"\tVALIDATE_UTF8 = {str(ff_options.get('VALIDATE_UTF8', True)).upper()} \n"
        f"\tSKIP_BLANK_LINES = {str(ff_options.get('SKIP_BLANK_LINES', False)).upper()} \n"
        f"\tREPLACE_INVALID_CHARACTERS = {str(ff_options.get('REPLACE_INVALID_CHARACTERS', False)).upper()} \n"
        f"\tEMPTY_FIELD_AS_NULL = {str(ff_options.get('EMPTY_FIELD_AS_NULL', True)).upper()} \n"
        f"\tSKIP_BYTE_ORDER_MARK = {str(ff_options.get('SKIP_BYTE_ORDER_MARK', True)).upper()} \n"
        f"\tENCODING = {quote_or_literal(ff_options.get('ENCODING', 'UTF8'))} \n"
        f"\tMULTI_LINE = {str(ff_options.get('MULTI_LINE', True)).upper()};\n"
    )
    return query

def get_stage_query(new_db, schema, row) -> str:
    """Formats a stage creation query based on the provided row data."""
    stage_name = row[1]
    stage_url = row[4] if row[4] else ''
    has_credentials = row[5] == 'Y'
    has_encryption_key = row[6] == 'Y'
    owner = row[7]
    comment = row[8] if row[8] else ''
    region = row[9] if row[9] else ''
    stage_type = row[10] if row[10] else 'INTERNAL'
    cloud = row[11] if row[11] else ''
    notification_channel = row[12] if row[12] else ''
    storage_integration = row[13] if row[13] else ''
    endpoint = row[14] if row[14] else ''
    directory_enabled = row[15] == 'Y'
    owner_role_type = row[16] if row[16] else 'ROLE'
    file_format = row[17] if len(row) > 17 and row[17] else ''

    query = f"CREATE OR REPLACE STAGE {new_db}.{schema}.{stage_name} \n"

    if stage_url:
        query += f"\tURL = '{stage_url}' \n"

    if storage_integration:
        query += f"\tSTORAGE_INTEGRATION = {storage_integration} \n"

    if has_credentials:
        query += f"\tCREDENTIALS = (AWS_KEY_ID = 'your_key_id' AWS_SECRET_KEY = 'your_secret_key') \n"

    if has_encryption_key:
        query += f"\tENCRYPTION = (TYPE = 'AWS_SSE_KMS' KMS_KEY_ID = 'your_kms_key_id') \n"

    if file_format:
        query += f"\tFILE_FORMAT = (FORMAT_NAME = '{file_format}') \n"

    query += f"\tDIRECTORY = ( ENABLE = {'TRUE' if directory_enabled else 'FALSE'} ) \n"

    if comment:
        query += f"\tCOMMENT = '{comment}' \n"

    if region:
        query += f"\tREGION = '{region}' \n"

    if cloud:
        query += f"\tCLOUD = '{cloud}' \n"

    if notification_channel:
        query += f"\tNOTIFICATION_CHANNEL = '{notification_channel}' \n"

    if endpoint:
        query += f"\tENDPOINT = '{endpoint}' \n"

    query = query.strip() + ";"

    return query

def format_query_list(queries) -> str:
    """Formats a list of queries into a single string with proper line breaks."""
    queries_str = ""
    for sql in queries:
        queries_str += sql
    return queries_str

def save_queries_to_file(queries, op_name):
    """Saves the formatted queries to a file."""
    with open(f"{op_name}.sql", "w") as file:
        file.write(format_query_list(queries))
    return f"{op_name}.sql"