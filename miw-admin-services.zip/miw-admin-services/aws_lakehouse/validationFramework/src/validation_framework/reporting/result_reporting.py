import csv
import json
from collections import defaultdict
from pathlib import Path
from typing import Dict, List


SEPARATOR_LENGTH = 60


def format_results_by_status(results: List[Dict]) -> Dict[str, Dict[str, List[Dict]]]:
    grouped = {
        "Passed": defaultdict(list),
        "Failed": defaultdict(list),
        "Skipped": defaultdict(list),
    }

    for result in results:
        if result.get("rule_id") == "FILE_SUMMARY":
            continue

        status = str(result.get("status", "FAILED")).upper()
        file_name = result.get("file_path", "unknown_file")
        if status == "PASSED":
            bucket = "Passed"
        elif status == "FAILED":
            bucket = "Failed"
        else:
            bucket = "Skipped"

        grouped[bucket][file_name].append(
            {
                "rule_id": result.get("rule_id"),
                "rule_name": result.get("rule_name"),
                "status": status,
                "severity": result.get("severity"),
                "message": result.get("message"),
                "recommendation": result.get("recommendation"),
                "evidence": result.get("evidence", {}),
            }
        )

    return {
        "Passed": dict(grouped["Passed"]),
        "Failed": dict(grouped["Failed"]),
        "Skipped": dict(grouped["Skipped"]),
    }


def summarize_results(results: List[Dict]) -> Dict[str, int]:
    rule_results = [item for item in results if item.get("rule_id") != "FILE_SUMMARY"]
    failed = [item for item in rule_results if str(item.get("status", "")).upper() == "FAILED"]
    skipped = [item for item in rule_results if str(item.get("status", "")).upper() == "SKIPPED"]
    passed = [item for item in rule_results if str(item.get("status", "")).upper() == "PASSED"]
    failed_warnings = [item for item in failed if str(item.get("severity", "")).upper() == "WARN"]
    failed_errors = [item for item in failed if str(item.get("severity", "")).upper() != "WARN"]
    return {
        "total_rules": len(rule_results),
        "passed": len(passed),
        "failed": len(failed),
        "skipped": len(skipped),
        "failed_errors": len(failed_errors),
        "failed_warnings": len(failed_warnings),
    }


def build_file_summary_rows(results: List[Dict]) -> List[Dict[str, str]]:
    per_file = defaultdict(
        lambda: {
            "passed": 0,
            "failed": 0,
            "failed_errors": 0,
            "failed_warnings": 0,
            "resource_type": "",
            "account_name": "",
        }
    )

    for item in results:
        if item.get("rule_id") == "FILE_SUMMARY":
            continue

        file_path = item.get("file_path", "unknown_file")
        status = str(item.get("status", "FAILED")).upper()
        severity = str(item.get("severity", "ERROR")).upper()

        # Capture resource_type and account_name from first occurrence
        if not per_file[file_path]["resource_type"]:
            per_file[file_path]["resource_type"] = (
                str(item.get("resource_type", "")).strip() or "unknown"
            )
        if not per_file[file_path]["account_name"]:
            per_file[file_path]["account_name"] = (
                str(item.get("account_name", "")).strip() or ""
            )

        if status == "PASSED":
            per_file[file_path]["passed"] += 1
            continue

        if status == "SKIPPED":
            continue

        per_file[file_path]["failed"] += 1
        if severity == "WARN":
            per_file[file_path]["failed_warnings"] += 1
        else:
            per_file[file_path]["failed_errors"] += 1

    rows: List[Dict[str, str]] = []
    for file_path in sorted(per_file.keys()):
        metrics = per_file[file_path]
        # Skip files with no rules (all were skipped)
        if metrics["passed"] == 0 and metrics["failed"] == 0:
            continue
        verdict = "PASSED" if metrics["failed"] == 0 else "FAILED"
        rows.append(
            {
                "filename": Path(file_path).name,
                "resource_type": metrics["resource_type"],
                "account_name": metrics["account_name"],
                "passed": str(metrics["passed"]),
                "failed": f"{metrics['failed']} ({metrics['failed_errors']},{metrics['failed_warnings']})",
                "failed_total": str(metrics["failed"]),
                "failed_errors": str(metrics["failed_errors"]),
                "failed_warnings": str(metrics["failed_warnings"]),
                "verdict": verdict,
            }
        )
    return rows


def build_detailed_csv_rows(results: List[Dict]) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []

    for item in results:
        if item.get("rule_id") == "FILE_SUMMARY":
            continue

        status = str(item.get("status", "FAILED")).upper()
        file_path = str(item.get("file_path", "unknown_file"))
        file_name = Path(file_path).name
        rulepack_name = str(item.get("rulepack_name", "unknown_rulepack"))
        resource_type = str(item.get("resource_type", "unknown"))

        error_info = {}
        if status == "FAILED":
            error_info = {
                "rule_id": item.get("rule_id"),
                "rule_name": item.get("rule_name"),
                "severity": item.get("severity"),
                "message": item.get("message"),
                "recommendation": item.get("recommendation"),
                "evidence": item.get("evidence", {}),
            }

        rows.append(
            {
                "resource_type": resource_type,
                "file_name": file_name,
                "rulepack_name": rulepack_name,
                "status": status,
                "error_info": json.dumps(error_info, ensure_ascii=False),
            }
        )

    return rows


def _build_file_summary_table_lines(rows: List[Dict[str, str]]) -> List[str]:
    if not rows:
        return ["No files were validated."]

    headers = {
        "filename": "FILE NAME",
        "resource_type": "RESOURCE TYPE",
        "account_name": "ACCOUNT NAME",
        "passed": "PASSED",
        "failed": "FAILED (ERRORS,WARNINGS)",
        "verdict": "VERDICT",
    }

    filename_width = max(len(headers["filename"]),
                         max(len(row["filename"]) for row in rows))
    resource_type_width = max(len(headers["resource_type"]),
                              max(len(row.get("resource_type", "")) for row in rows))
    account_name_width = max(len(headers["account_name"]),
                             max(len(row.get("account_name", "")) for row in rows))
    passed_width = max(len(headers["passed"]),
                       max(len(row["passed"]) for row in rows))
    failed_width = max(len(headers["failed"]),
                       max(len(row["failed"]) for row in rows))
    verdict_width = max(len(headers["verdict"]),
                        max(len(row["verdict"]) for row in rows))

    separator = (
        f"+-{'-' * filename_width}-+-{'-' * resource_type_width}-"
        f"+-{'-' * account_name_width}-+-{'-' * passed_width}-"
        f"+-{'-' * failed_width}-+-{'-' * verdict_width}-+"
    )

    lines = [
        "VALIDATION SUMMARY",
        separator,
        (
            f"| {headers['filename']:<{filename_width}} "
            f"| {headers['resource_type']:<{resource_type_width}} "
            f"| {headers['account_name']:<{account_name_width}} "
            f"| {headers['passed']:<{passed_width}} "
            f"| {headers['failed']:<{failed_width}} "
            f"| {headers['verdict']:<{verdict_width}} |"
        ),
        separator,
    ]

    for row in rows:
        lines.append(
            (
                f"| {row['filename']:<{filename_width}} "
                f"| {row.get('resource_type', ''):<{resource_type_width}} "
                f"| {row.get('account_name', ''):<{account_name_width}} "
                f"| {row['passed']:<{passed_width}} "
                f"| {row['failed']:<{failed_width}} "
                f"| {row['verdict']:<{verdict_width}} |"
            )
        )

    lines.append(separator)
    return lines


def build_file_summary_table_text(rows: List[Dict[str, str]]) -> str:
    lines = _build_file_summary_table_lines(rows)
    if not rows:
        return lines[0]
    return "\n" + "\n".join(lines)


def write_summary_table_file(
    output_path: Path,
    file_rows: List[Dict[str, str]],
    summary: Dict[str, int],
    show_skipped: bool,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    lines = _build_file_summary_table_lines(file_rows)
    with output_path.open("w", encoding="utf-8") as handle:
        for line in lines:
            handle.write(line + "\n")
        handle.write("\n")
        if show_skipped:
            handle.write(
                "Summary: "
                f"{summary['passed']} passed, "
                f"{summary['failed']} failed "
                f"({summary['failed_errors']} errors, {summary['failed_warnings']} warnings), "
                f"{summary['skipped']} skipped, "
                f"{summary['total_rules']} total\n"
            )
        else:
            total_without_skipped = summary["passed"] + summary["failed"]
            handle.write(
                "Summary: "
                f"{summary['passed']} passed, "
                f"{summary['failed']} failed "
                f"({summary['failed_errors']} errors, {summary['failed_warnings']} warnings), "
                f"{total_without_skipped} total\n"
            )


def write_txt_report(
    output_path: Path,
    grouped_results: Dict[str, Dict[str, List[Dict]]],
    summary: Dict[str, int],
    file_rows: List[Dict[str, str]],
    show_passed: bool,
    show_skipped: bool,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as txt_file:
        txt_file.write("VALIDATION RESULTS\n")
        txt_file.write("=" * SEPARATOR_LENGTH + "\n\n")

        if file_rows:
            lines = _build_file_summary_table_lines(file_rows)
            for line in lines:
                txt_file.write(line + "\n")
            txt_file.write("\n")

        if show_passed and grouped_results["Passed"]:
            txt_file.write("✓ PASSED VALIDATIONS\n")
            for file_path, rules in grouped_results["Passed"].items():
                txt_file.write(f"  File: {Path(file_path).name}\n")
                for rule in rules:
                    txt_file.write(
                        f"    ✓ [{rule.get('rule_id', 'N/A')}] {rule.get('rule_name', 'N/A')}: "
                        f"{rule.get('message', 'Validation passed')}\n"
                    )

        if grouped_results["Failed"]:
            txt_file.write("\n✗ FAILED VALIDATIONS\n")
            for file_path, rules in grouped_results["Failed"].items():
                txt_file.write(f"  File: {Path(file_path).name}\n")
                for rule in rules:
                    txt_file.write(
                        f"    ✗ [{rule.get('rule_id', 'N/A')}] {rule.get('rule_name', 'N/A')} "
                        f"(Severity: {rule.get('severity', 'ERROR')}): {rule.get('message', 'Validation failed')}"
                    )
                    recommendation = rule.get("recommendation")
                    if recommendation:
                        txt_file.write(f"      Recommendation: {recommendation}\n")
                    evidence = rule.get("evidence")
                    if evidence:
                        txt_file.write(f"      Evidence: {json.dumps(evidence, ensure_ascii=False)}\n\n")

        if show_skipped and grouped_results["Skipped"]:
            txt_file.write("\n↷ SKIPPED VALIDATIONS\n")
            for file_path, rules in grouped_results["Skipped"].items():
                txt_file.write(f"  File: {Path(file_path).name}\n")
                for rule in rules:
                    txt_file.write(
                        f"    ↷ [{rule.get('rule_id', 'N/A')}] {rule.get('rule_name', 'N/A')}: "
                        f"{rule.get('message', 'Validation skipped')}\n"
                    )

        txt_file.write("\n" + "=" * SEPARATOR_LENGTH + "\n")
        if show_skipped:
            txt_file.write(
                "Summary: "
                f"{summary['passed']} passed, "
                f"{summary['failed']} failed "
                f"({summary['failed_errors']} errors, {summary['failed_warnings']} warnings), "
                f"{summary['skipped']} skipped, "
                f"{summary['total_rules']} total\n"
            )
        else:
            total_without_skipped = summary["passed"] + summary["failed"]
            txt_file.write(
                "Summary: "
                f"{summary['passed']} passed, "
                f"{summary['failed']} failed "
                f"({summary['failed_errors']} errors, {summary['failed_warnings']} warnings), "
                f"{total_without_skipped} total\n"
            )


def write_csv_report(output_path: Path, detailed_rows: List[Dict[str, str]]) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8", newline="") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["resource_type", "file_name", "rulepack_name", "status", "error_info"])
        for row in detailed_rows:
            writer.writerow(
                [
                    row["resource_type"],
                    row["file_name"],
                    row["rulepack_name"],
                    row["status"],
                    row["error_info"],
                ]
            )


def build_validation_results_text(
    grouped_results: Dict[str, Dict[str, List[Dict]]],
    summary: Dict[str, int],
    file_rows: List[Dict[str, str]],
    show_passed: bool,
    show_skipped: bool,
) -> str:
    lines: List[str] = []
    lines.append("\n" + "=" * SEPARATOR_LENGTH)
    lines.append("VALIDATION RESULTS")
    lines.append("=" * SEPARATOR_LENGTH)
    lines.append(build_file_summary_table_text(file_rows))

    if show_passed and grouped_results["Passed"]:
        lines.append("\n✓ PASSED VALIDATIONS")
        for file_path, rules in grouped_results["Passed"].items():
            lines.append(f"  File: {Path(file_path).name}")
            for rule in rules:
                lines.append(
                    f"    ✓ [{rule.get('rule_id', 'N/A')}] {rule.get('rule_name', 'N/A')}: "
                    f"{rule.get('message', 'Validation passed')}"
                )

    if grouped_results["Failed"]:
        lines.append("\n✗ FAILED VALIDATIONS")
        for file_path, rules in grouped_results["Failed"].items():
            lines.append(f"  File: {Path(file_path).name}")
            for rule in rules:
                lines.append(
                    f"    ✗ [{rule.get('rule_id', 'N/A')}] {rule.get('rule_name', 'N/A')} "
                    f"(Severity: {rule.get('severity', 'ERROR')}): {rule.get('message', 'Validation failed')}"
                )
                recommendation = rule.get("recommendation")
                if recommendation:
                    lines.append(f"      Recommendation: {recommendation}")
                evidence = rule.get("evidence")
                if evidence:
                    lines.append(f"      Evidence: {json.dumps(evidence, ensure_ascii=False)}")

    if show_skipped and grouped_results["Skipped"]:
        lines.append("\n↷ SKIPPED VALIDATIONS")
        for file_path, rules in grouped_results["Skipped"].items():
            lines.append(f"  File: {Path(file_path).name}")
            for rule in rules:
                lines.append(
                    f"    ↷ [{rule.get('rule_id', 'N/A')}] {rule.get('rule_name', 'N/A')}: "
                    f"{rule.get('message', 'Validation skipped')}"
                )

    lines.append("\n" + "=" * SEPARATOR_LENGTH)
    if show_skipped:
        lines.append(
            "Summary: "
            f"{summary['passed']} passed, "
            f"{summary['failed']} failed "
            f"({summary['failed_errors']} errors, {summary['failed_warnings']} warnings), "
            f"{summary['skipped']} skipped, "
            f"{summary['total_rules']} total"
        )
    else:
        total_without_skipped = summary["passed"] + summary["failed"]
        lines.append(
            "Summary: "
            f"{summary['passed']} passed, "
            f"{summary['failed']} failed "
            f"({summary['failed_errors']} errors, {summary['failed_warnings']} warnings), "
            f"{total_without_skipped} total"
        )
    lines.append("=" * SEPARATOR_LENGTH + "\n")
    return "\n".join(lines)
