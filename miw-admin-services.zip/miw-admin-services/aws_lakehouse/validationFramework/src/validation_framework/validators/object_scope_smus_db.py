import json
import yaml
import re

# ✅ -----------------------------
# Result Builders
# ✅ -----------------------------
def build_result(rule_id, rule_name, status, severity, file_path, message, recommendation=None, evidence=None):
    return {
        "rule_id": rule_id,
        "rule_name": rule_name,
        "status": status,
        "severity": severity,
        "file_path": file_path,
        "message": message,
        "recommendation": recommendation,
        "evidence": evidence or {}
    }

def build_file_summary_result(file_path, status, message, passed_rules, failed_rules, skipped_rules, total_rules, context=None):
    return {
        "rule_id": "FILE_SUMMARY",
        "rule_name": "file_summary",
        "status": status,
        "severity": "INFO" if status == "PASSED" else "ERROR",
        "file_path": file_path,
        "message": message,
        "recommendation": None,
        "evidence": {
            "passed_rules": passed_rules,
            "failed_rules": failed_rules,
            "skipped_rules": skipped_rules,            
            "total_rules": total_rules,
            "env": (context or {}).get("env")
        }
    }


def get_nested_value(data, path):
    """
    Fetch nested field using dot notation
    Example: access_to_resources.glue_databases
    """
    keys = path.split(".")
    value = data

    for k in keys:
        if isinstance(value, dict):
            value = value.get(k)
        else:
            return []

    # ✅ Normalize to list
    if value is None:
        return []

    if isinstance(value, list):
        return value

    return [value]


# ✅ -----------------------------
# Main Validate Function
# ✅ -----------------------------
def validate(file_paths, rules, context=None):

    results = []

    for file_path in file_paths:
        payload = load_yaml_or_json(file_path)
        file_rule_results = []

        if payload is None:
            results.append(build_result(
                "FILE_LOAD_ERROR",
                "file_load_error",
                "FAILED",
                "ERROR",
                file_path,
                f"Unable to load file: {file_path}"
            ))
            continue

        for rule_id, rule in rules.items():

            if not rule.get("enabled", True):
                continue

            rule_type = rule.get("type")

            if rule_type == "list_pattern_allowed":
                result = _list_pattern_allowed(rule_id, rule, payload, file_path)

            elif rule_type == "list_conditional_pattern":
                result = _list_conditional_pattern(rule_id, rule, payload, file_path, context)
            
            elif rule_type == "list_pattern_not_allowed":
                result = _list_pattern_not_allowed(rule_id, rule, payload, file_path)

            else:
                result = build_result(
                    rule_id,
                    rule.get("name"),
                    "FAILED",
                    rule.get("severity", "ERROR"),
                    file_path,
                    f"Unsupported rule type: {rule_type}"
                )


            file_rule_results.append(result)
            results.append(result)

        # ✅ Summary calculation
        passed_rules = sum(1 for r in file_rule_results if r["status"] == "PASSED")
        failed_rules = sum(1 for r in file_rule_results if r["status"] == "FAILED")
        skipped_rules = sum(1 for r in file_rule_results if r["status"] == "SKIPPED")

        summary_status = "PASSED" if failed_rules == 0 else "FAILED"
        summary_message = (
            "All validations passed for file"
            if summary_status == "PASSED"
            else "One or more validations failed for file"
        )

        results.append(build_file_summary_result(
            file_path,
            summary_status,
            summary_message,
            passed_rules,
            failed_rules,
            skipped_rules,
            len(file_rule_results),
            context
        ))

    return results

# ✅ -----------------------------
# File Loader
# ✅ -----------------------------
def load_yaml_or_json(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            if file_path.endswith(".json"):
                return json.load(f)
            return yaml.safe_load(f)
    except Exception:
        return None

    
# ✅ -----------------------------
# Rule 2: Allowed Core Layers
# ✅ -----------------------------
def _list_pattern_allowed(rule_id, rule, resource, file_path):
    field = rule.get("target_field")
    values = get_nested_value(resource, field)

    allowed_patterns = rule.get("params", {}).get("allowed_patterns", [])

    invalid = []

    for item in values:
        item_str = str(item)
        if not any(p in item_str for p in allowed_patterns):
            invalid.append(item_str)

    if not invalid:
        return build_result(
            rule_id,
            rule["name"],
            "PASSED",
            rule.get("severity", "ERROR"),
            file_path,
            rule["message"],
            evidence={field: values}
        )

    # If your business rule says invalid entries should be SKIPPED, keep SKIPPED here.
    # If invalid entries should fail validation, change SKIPPED -> FAILED.
    return build_result(
        rule_id,
        rule["name"],
        "SKIPPED",
        "INFO",
        file_path,
        f"Some values are outside the allowed patterns: {invalid}",
        rule.get("recommendation"),
        evidence={field: invalid}
    )


# ✅ -----------------------------
# Rule 3: RL + Account Enforcement
# ✅ -----------------------------
def _list_conditional_pattern(rule_id, rule, resource, file_path, context):
    field = rule.get("target_field")
    values = get_nested_value(resource, field)

    params = rule.get("params", {})
    restricted_patterns = params.get("restricted_patterns", [])
    exclude_patterns = params.get("exclude_patterns", [])

    allow_if_all = params.get("allow_if_all", {})
    required_contains = allow_if_all.get("contains", [])

    violations = []

    for item in values:
        item_str = str(item).strip()

        # Skip excluded cases
        if any(ex in item_str for ex in exclude_patterns):
            continue

        # Apply conditional validation only for restricted patterns
        if any(p in item_str for p in restricted_patterns):
            has_required_contains = all(cond in item_str for cond in required_contains)

            # ✅ Allow if DB starts with digits + ":" and ends with "_rl"
            has_required_prefix = bool(re.match(r"^\d+:", item_str)) and item_str.endswith("_rl")

            if not (has_required_contains and has_required_prefix):
                violations.append(item_str)

    if not violations:
        return build_result(
            rule_id,
            rule["name"],
            "PASSED",
            rule.get("severity", "ERROR"),
            file_path,
            rule["message"],
            evidence={field: values}
        )

    return build_result(
        rule_id,
        rule["name"],
        "SKIPPED",
        "INFO",
        file_path,
        rule["message"],
        rule.get("recommendation"),
        evidence={
            "violations": violations,
            "expected_pattern": "starts with digits + ':' and ends with '_rl'",
            "required_contains": required_contains
        }
    )

def _list_pattern_not_allowed(rule_id, rule, resource, file_path, context=None):
    field = rule.get("target_field")
    values = get_nested_value(resource, field)

    disallowed_patterns = rule.get("params", {}).get("disallowed_patterns", [])

    violations = []
    allowed_rl_exceptions = []

    for item in values:
        item_str = str(item).strip()

        # ✅ Allow if it starts with digits + ":" and ends with "_rl"
        # Example: 438465132548:minerva_dev_dp_agtr_cdp_apac_ekaaus_dev_fdp_db_rl
        if re.match(r"^\d+:", item_str) and item_str.endswith("_rl"):
            allowed_rl_exceptions.append(item_str)
            continue

        matched_patterns = [p for p in disallowed_patterns if p in item_str]
        if matched_patterns:
            violations.append({
                "value": item_str,
                "matched_patterns": matched_patterns
            })

    if violations:
        return build_result(
            rule_id,
            rule["name"],
            "FAILED",
            rule.get("severity", "ERROR"),
            file_path,
            rule["message"],
            rule.get("recommendation"),
            evidence={
                "violations": violations,
                "allowed_rl_exceptions": allowed_rl_exceptions
            }
        )

    return build_result(
        rule_id,
        rule["name"],
        "PASSED",
        rule.get("severity", "ERROR"),
        file_path,
        rule["message"],
        evidence={
            field: values,
            "allowed_rl_exceptions": allowed_rl_exceptions
        }
    )