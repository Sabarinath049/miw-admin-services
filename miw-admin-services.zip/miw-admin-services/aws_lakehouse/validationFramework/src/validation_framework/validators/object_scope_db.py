import json
import yaml


# ✅ -----------------------------
# Result Builders
# ✅ -----------------------------
def build_result(rule_id, rule_name, status, severity, file_path, message, recommendation=None, evidence=None):
    return {
        "rule_id": rule_id,
        "rule_name": rule_name,
        "status": status,
        "severity": severity,
        "file_path": file_path,
        "message": message,
        "recommendation": recommendation,
        "evidence": evidence or {}
    }


def build_file_summary_result(file_path, status, message, passed_rules, failed_rules, skipped_rules, total_rules, context=None):
    return {
        "rule_id": "FILE_SUMMARY",
        "rule_name": "file_summary",
        "status": status,
        "severity": "INFO" if status == "PASSED" else "ERROR",
        "file_path": file_path,
        "message": message,
        "recommendation": None,
        "evidence": {
            "passed_rules": passed_rules,
            "failed_rules": failed_rules,
            "skipped_rules": skipped_rules,
            "total_rules": total_rules,
            "env": (context or {}).get("env")
        }
    }


# ✅ -----------------------------
# Main Validate Function
# ✅ -----------------------------
def validate(file_paths, rules, context=None):

    results = []

    for file_path in file_paths:
        payload = load_yaml_or_json(file_path)
        file_rule_results = []

        if payload is None:
            results.append(build_result(
                "FILE_LOAD_ERROR",
                "file_load_error",
                "FAILED",
                "ERROR",
                file_path,
                f"Unable to load file: {file_path}"
            ))
            continue

        for rule_id, rule in rules.items():

            if not rule.get("enabled", True):
                continue

            rule_type = rule.get("type")

            if rule_type == "pattern_allowed":
                result = _pattern_allowed(rule_id, rule, payload, file_path)

            elif rule_type == "pattern_not_allowed":
                result = _pattern_not_allowed(rule_id, rule, payload, file_path)

            elif rule_type == "multi_field_condition":
                result = _multi_field_condition(rule_id, rule, payload, file_path)
                
            elif rule_type == "list_conditional_pattern":
                result = _list_conditional_pattern(rule_id, rule, payload, file_path, context)

            else:
                result = build_result(
                    rule_id,
                    rule.get("name"),
                    "FAILED",
                    rule.get("severity", "ERROR"),
                    file_path,
                    f"Unsupported rule type: {rule_type}"
                )

            file_rule_results.append(result)
            # results.append(result)
								 
        passed_rules = sum(1 for r in file_rule_results if r["status"] == "PASSED")
        failed_rules = sum(1 for r in file_rule_results if r["status"] == "FAILED")
        skipped_rules = sum(1 for r in file_rule_results if r["status"] == "SKIPPED")

        results.extend(file_rule_results)

        # ✅ Accurate summary status
        if failed_rules > 0:
            summary_status = "FAILED"
            summary_message = "One or more validations failed for file"
        elif passed_rules > 0:
            summary_status = "PASSED"
            summary_message = "All applicable validations passed for file"
        else:
            summary_status = "SKIPPED"
            summary_message = "No applicable validations found for file"

        summary_status = "PASSED" if failed_rules == 0 else "FAILED"
        summary_message = (
            "All validations passed for file"
            if summary_status == "PASSED"
            else "One or more validations failed for file"
        )

        results.append(build_file_summary_result(
            file_path,
            summary_status,
            summary_message,
            passed_rules,
            failed_rules,
            skipped_rules,
            len(file_rule_results),
            context
        ))

    return results


# ✅ -----------------------------
# Pattern Allowed
# PASS if match
# SKIPPED if not applicable
# ✅ -----------------------------
def _pattern_allowed(rule_id, rule, resource, file_path):

    field = rule.get("target_field")
    value = str(resource.get(field, ""))

    params = rule.get("params", {})
    include_patterns = params.get("include_patterns", [])
    exclude_patterns = params.get("exclude_patterns", [])

    # ✅ Exclusion override
    if any(ex in value for ex in exclude_patterns):
        return build_result(
            rule_id,
            rule["name"],
            "SKIPPED",
            "INFO",
            file_path,
            f"{value} excluded from this rule",
            evidence={field: value}
        )

    # ✅ Match
    if any(p in value for p in include_patterns):
        return build_result(
            rule_id,
            rule["name"],
            "PASSED",
            rule["severity"],
            file_path,
            f"{value} matches allowed pattern",
            evidence={field: value}
        )

    # ✅ Not applicable
    return build_result(
        rule_id,
        rule["name"],
        "SKIPPED",
        "INFO",
        file_path,
        f"{value} not applicable",
        evidence={field: value}
    )


# ✅ -----------------------------
# Pattern NOT Allowed
# FAIL only if restricted pattern found
# ✅ -----------------------------
def _pattern_not_allowed(rule_id, rule, resource, file_path):

    field = rule.get("target_field")
    value = resource.get(field, "")

    params = rule.get("params", {})
    include_patterns = params.get("include_patterns", [])
    exclude_patterns = params.get("exclude_patterns", [])

    # Exclusion override
    if any(ex in value for ex in exclude_patterns):
        return build_result(
            rule_id,
            rule["name"],
            "PASSED",
            rule["severity"],
            file_path,
            f"Excluded pattern matched for {value}",
            evidence={field: value}
        )

    # Restricted → FAIL
    if any(p in value for p in include_patterns):
        return build_result(
            rule_id,
            rule["name"],
            "FAILED",
            rule["severity"],
            file_path,
            rule["message"],
            rule.get("recommendation"),
            evidence={field: value}
        )

    return build_result(
        rule_id,
        rule["name"],
        "PASSED",
        rule["severity"],
        file_path,
        "No restricted pattern found",
        evidence={field: value}
    )


# ✅ -----------------------------
# Multi-field Condition
# PASS if match
# SKIPPED if not applicable
# ✅ -----------------------------
def _multi_field_condition(rule_id, rule, resource, file_path):

    params = rule.get("params", {})
    conditions = params.get("conditions", [])
    logic = params.get("match_logic", "AND")

    results = []

    for cond in conditions:
        field = cond["field"]
        operator = cond["operator"]
        expected = cond.get("value")
        actual = resource.get(field)

        if operator == "equals":
            results.append(actual == expected)
        elif operator == "starts_with":
            results.append(str(actual).startswith(expected))
        elif operator == "contains":
            results.append(expected in str(actual))
        else:
            results.append(False)

    final_result = all(results) if logic == "AND" else any(results)

    if final_result:
        return build_result(
            rule_id,
            rule["name"],
            "PASSED",
            rule["severity"],
            file_path,
            "Condition satisfied",
            evidence=resource
        )

    return build_result(
        rule_id,
        rule["name"],
        "SKIPPED",
        "INFO",
        file_path,
        "Condition not applicable",
        evidence=resource
    )

def _list_conditional_pattern(rule_id, rule, resource, file_path, context):

    field = rule.get("target_field")
    value = resource.get(field, "")

    params = rule.get("params", {})
    restricted_patterns = params.get("restricted_patterns", [])

    allow_if_all = params.get("allow_if_all", {})
    
    account_id = (context or {}).get("account_id", "")

    required_contains = allow_if_all.get("contains", [])
    required_prefix = (allow_if_all.get("starts_with") or "").replace("${account_id}", account_id)

    # ✅ If NOT restricted → SKIPPED
    if not any(p in value for p in restricted_patterns):
        return build_result(
            rule_id,
            rule["name"],
            "SKIPPED",
            "INFO",
            file_path,
            "Not applicable for this DB",
            evidence={field: value}
        )

    # ✅ Check RL conditions
    has_required_contains = all(cond in value for cond in required_contains)
    has_required_prefix = value.startswith(required_prefix) if required_prefix else True

    if has_required_contains and has_required_prefix:
        return build_result(
            rule_id,
            rule["name"],
            "PASSED",
            rule["severity"],
            file_path,
            "Valid RL access",
            evidence={field: value}
        )

    return build_result(
        rule_id,
        rule["name"],
        "SKIPPED",
        "INFO",
        file_path,
        rule["message"],
        rule.get("recommendation"),
        evidence={field: value}
    )


# ✅ -----------------------------
# File Loader
# ✅ -----------------------------
def load_yaml_or_json(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            if file_path.endswith(".json"):
                return json.load(f)
            return yaml.safe_load(f)
    except Exception:
        return None
