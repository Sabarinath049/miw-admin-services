import json
import yaml


# ✅ -----------------------------
# Result Builders
# ✅ -----------------------------
def build_result(rule_id, rule_name, status, severity, file_path, message, recommendation=None, evidence=None):
    return {
        "rule_id": rule_id,
        "rule_name": rule_name,
        "status": status,
        "severity": severity,
        "file_path": file_path,
        "message": message,
        "recommendation": recommendation,
        "evidence": evidence or {}
    }

def build_file_summary_result(file_path, status, message, passed_rules, failed_rules, skipped_rules, total_rules, context=None):
    return {
        "rule_id": "FILE_SUMMARY",
        "rule_name": "file_summary",
        "status": status,
        "severity": "INFO" if status == "PASSED" else "ERROR",
        "file_path": file_path,
        "message": message,
        "recommendation": None,
        "evidence": {
            "passed_rules": passed_rules,
            "failed_rules": failed_rules,
            "skipped_rules": skipped_rules,            
            "total_rules": total_rules,
            "env": (context or {}).get("env")
        }
    }


# ✅ -----------------------------
# Main Validate Function
# ✅ -----------------------------
def validate(file_paths, rules, context=None):

    results = []

    for file_path in file_paths:
        payload = load_yaml_or_json(file_path)
        file_rule_results = []

        if payload is None:
            results.append(build_result(
                "FILE_LOAD_ERROR",
                "file_load_error",
                "FAILED",
                "ERROR",
                file_path,
                f"Unable to load file: {file_path}"
            ))
            continue

        for rule_id, rule in rules.items():

            if not rule.get("enabled", True):
                continue

            rule_type = rule.get("type")

            if rule_type == "multi_field_condition":
                result = _multi_field_condition(rule_id, rule, payload, file_path)
            else:
                result = build_result(
                    rule_id,
                    rule.get("name"),
                    "FAILED",
                    rule.get("severity", "ERROR"),
                    file_path,
                    f"Unsupported rule type: {rule_type}"
                )

            file_rule_results.append(result)
            results.append(result)

        any_passed = any(r["status"] == "PASSED" for r in file_rule_results)

        # ✅ If none passed → mark all as FAILED
        if not any_passed:
            for r in file_rule_results:
                if r["status"] == "SKIPPED":
                    r["status"] = "FAILED"
                    r["message"] = "No matching rule found"

        # ✅ Summary calculation
        passed_rules = sum(1 for r in file_rule_results if r["status"] == "PASSED")
        failed_rules = sum(1 for r in file_rule_results if r["status"] == "FAILED")
        skipped_rules = sum(1 for r in file_rule_results if r["status"] == "SKIPPED")

        summary_status = "PASSED" if failed_rules == 0 else "FAILED"
        summary_message = (
            "All validations passed for file"
            if summary_status == "PASSED"
            else "One or more validations failed for file"
        )

        results.append(build_file_summary_result(
            file_path,
            summary_status,
            summary_message,
            passed_rules,
            failed_rules,
            skipped_rules,
            len(file_rule_results),
            context
        ))

    return results


# ✅ -----------------------------
# Multi-field Condition Logic
# ✅ -----------------------------
def _multi_field_condition(rule_id, rule, resource, file_path):

    params = rule.get("params", {})
    conditions = params.get("conditions", [])
    match_logic = params.get("match_logic", "AND")

    results = []

    for cond in conditions:
        field = cond.get("field")
        operator = cond.get("operator")
        expected = cond.get("value")

        actual = resource.get(field)

        if operator == "equals":
            results.append(actual == expected)

        elif operator == "contains":
            results.append(expected in str(actual))

        elif operator == "starts_with":
            results.append(str(actual).startswith(expected))

        else:
            results.append(False)

    final_result = all(results) if match_logic == "AND" else any(results)

    if final_result:
        return build_result(
            rule_id,
            rule["name"],
            "PASSED",
            rule["severity"],
            file_path,
            rule["message"],
            evidence=resource
        )

    return build_result(
        rule_id,
        rule["name"],
        "SKIPPED",
        "INFO",
        file_path,
        "Condition not applicable",
        rule.get("recommendation"),
        evidence=resource
    )


# ✅ -----------------------------
# File Loader
# ✅ -----------------------------
def load_yaml_or_json(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            if file_path.endswith(".json"):
                return json.load(f)
            return yaml.safe_load(f)
    except Exception:
        return None
