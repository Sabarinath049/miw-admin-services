"""
IAM Validation Checks for Compute and Lakehouse Accounts

Implements validation rules for:
1. IAM role naming conventions (CMP_IAM_001, LH_IAM_001)
2. IAM Glue DB access matrix checks (CMP_IAM_002, LH_IAM_002)
3. Resource Link write permission checks (CMP_IAM_003, LH_IAM_003)
4. IAM data_prefix naming convention checks (CMP_IAM_004, LH_IAM_004)
"""

import re
import yaml
from typing import Dict, List, Any, Tuple, Optional


# ✅ ----- Result Builders -----
def build_result(rule_id, rule_name, status, severity, file_path, message, recommendation=None, evidence=None):
    """Build a result dict for a single rule evaluation."""
    return {
        "rule_id": rule_id,
        "rule_name": rule_name,
        "status": status,
        "severity": severity,
        "file_path": file_path,
        "message": message,
        "recommendation": recommendation,
        "evidence": evidence or {}
    }


def build_file_summary_result(file_path, status, message, passed_rules, failed_rules, skipped_rules, total_rules, context=None):
    """Build a FILE_SUMMARY result."""
    return {
        "rule_id": "FILE_SUMMARY",
        "rule_name": "file_summary",
        "status": status,
        "severity": "INFO" if status == "PASSED" else "ERROR",
        "file_path": file_path,
        "message": message,
        "recommendation": None,
        "evidence": {
            "passed_rules": passed_rules,
            "failed_rules": failed_rules,
            "skipped_rules": skipped_rules,
            "total_rules": total_rules,
            "env": (context or {}).get("env")
        }
    }


# ✅ ----- Utility Functions -----
def load_yaml_or_json(file_path):
    """Load YAML or JSON file safely."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            if file_path.endswith('.json'):
                import json
                return json.loads(content)
            else:
                return yaml.safe_load(content)
    except Exception:
        return None


def extract_role_type(role_name: str) -> str:
    """
    Extract role type from role name.
    
    Role names follow patterns like:
    - corp_dtd_dev_procingestionengineer
    - agtr_apac_dev_procdataengineer
    - minerva_corp_dtd_procintegratedingestionengineer_dev
    """
    if not role_name:
        return ""
    
    # Match patterns: *_dev_procdataengineer, *_prd_procingestionengineer, etc.
    parts = role_name.split("_")
    for i, part in enumerate(parts):
        if part in ("dev", "prd", "sbx"):
            if i + 1 < len(parts):
                return "_".join(parts[i + 1:])
    
    return ""


def check_layer_type_match(layer_str, layer_type, layer_type_patterns):
    """
    Check if a layer matches a configured layer type pattern.
    
    Supports multiple match types:
    - prefix: matches if layer starts with pattern
    - suffix: matches if layer ends with pattern
    - substring: matches if pattern appears in layer (default)
    """
    if layer_type not in layer_type_patterns:
        # If no pattern config, use substring matching as fallback
        return layer_type in layer_str or layer_str in layer_type
    
    pattern_config = layer_type_patterns[layer_type]
    if not isinstance(pattern_config, dict):
        # Fallback to substring matching if config is malformed
        return layer_type in layer_str or layer_str in layer_type
    
    match_type = pattern_config.get("match_type", "substring")
    pattern = pattern_config.get("pattern", layer_type)
    pattern = str(pattern).lower()
    
    if match_type == "suffix":
        return layer_str.endswith(pattern)
    elif match_type == "prefix":
        return layer_str.startswith(pattern)
    else:  # substring (default)
        return pattern in layer_str or layer_str in pattern


# ✅ ----- Rule Validators -----
def check_iam_role_naming(rule_id, rule, resource, file_path):
    """CMP_IAM_001 / LH_IAM_001: Validate role naming convention."""
    role_name = resource.get("role_name", "")
    
    if not role_name:
        return build_result(
            rule_id, rule["name"], "FAILED", rule["severity"], file_path,
            "Role name cannot be empty",
            rule.get("recommendation"),
            {"role_name": role_name}
        )
    
    # Check for deprecated roles
    deprecated_roles = rule.get("params", {}).get("deprecated_roles", [])
    for deprecated in deprecated_roles:
        if deprecated in role_name:
            return build_result(
                rule_id, rule["name"], "FAILED", rule["severity"], file_path,
                f"Role type '{deprecated}' is deprecated and not allowed",
                rule.get("recommendation"),
                {"role_name": role_name, "deprecated_role": deprecated}
            )
    
    # Check naming patterns
    role_patterns = rule.get("params", {}).get("role_patterns", {})
    for role_type, pattern in role_patterns.items():
        if re.match(pattern, role_name):
            return build_result(
                rule_id, rule["name"], "PASSED", rule["severity"], file_path,
                rule["message"],
                evidence={"role_name": role_name, "matched_type": role_type}
            )
    
    # No pattern matched
    allowed_roles = list(role_patterns.keys())
    return build_result(
        rule_id, rule["name"], "FAILED", rule["severity"], file_path,
        f"Role name '{role_name}' does not follow approved naming convention",
        rule.get("recommendation"),
        {"role_name": role_name, "allowed_types": allowed_roles}
    )


def check_glue_db_access(rule_id, rule, resource, file_path):
    """CMP_IAM_002 / LH_IAM_002: Validate Glue database access matrix."""
    role_name = resource.get("role_name", "")
    role_type = extract_role_type(role_name)
    
    glue_db = resource.get("access_to_resources", {})
    if not isinstance(glue_db, dict):
        glue_db = {}
    
    glue_db = glue_db.get("glue_databases")
    if not glue_db:
        glue_db = {}
    
    read_layers = glue_db.get("read", []) if isinstance(glue_db, dict) and glue_db else []
    write_layers = glue_db.get("write", []) if isinstance(glue_db, dict) and glue_db else []
    
    # Load layer type patterns from config
    layer_type_patterns = rule.get("params", {}).get("layer_type_patterns", {})
    if not isinstance(layer_type_patterns, dict):
        layer_type_patterns = {}
    
    access_rules = rule.get("params", {}).get("access_rules", {})
    if not isinstance(access_rules, dict):
        access_rules = {}
    
    if role_type not in access_rules:
        return build_result(
            rule_id, rule["name"], "PASSED", rule["severity"], file_path,
            "No specific access rules defined for this role type",
            evidence={"role_type": role_type}
        )
    
    role_rules = access_rules[role_type]
    if not isinstance(role_rules, dict):
        role_rules = {}
    
    errors = []
    
    # Ensure read_layers and write_layers are always lists
    if not isinstance(read_layers, list):
        read_layers = [read_layers] if read_layers else []
    if not isinstance(write_layers, list):
        write_layers = [write_layers] if write_layers else []
    
    # Check required read access
    if role_rules.get("require_read") and not read_layers:
        errors.append(f"Role type '{role_type}' requires read access but none provided")
    
    # Check required write access
    if role_rules.get("require_write") and not write_layers:
        errors.append(f"Role type '{role_type}' requires write access but none provided")
    
    # Check allowed read layers
    allowed_read = role_rules.get("allowed_read_layers", [])
    if not isinstance(allowed_read, list):
        allowed_read = []
    
    if allowed_read and read_layers:
        for layer in read_layers:
            layer_str = str(layer).lower()
            # Check if layer matches any allowed type
            matches_allowed = False
            for allowed in allowed_read:
                allowed_str = str(allowed).lower()
                if check_layer_type_match(layer_str, allowed_str, layer_type_patterns):
                    matches_allowed = True
                    break
            
            if not matches_allowed:
                errors.append(f"Read access to layer '{layer}' not allowed. Allowed: {allowed_read}")
    
    # Check allowed write layers
    allowed_write = role_rules.get("allowed_write_layers", [])
    if not isinstance(allowed_write, list):
        allowed_write = []
    
    disallowed_write = role_rules.get("disallowed_write_layers", [])
    if not isinstance(disallowed_write, list):
        disallowed_write = []
    
    if allowed_write and write_layers:
        for layer in write_layers:
            layer_str = str(layer).lower()
            # Check if layer matches any allowed type
            matches_allowed = False
            for allowed in allowed_write:
                allowed_str = str(allowed).lower()
                if check_layer_type_match(layer_str, allowed_str, layer_type_patterns):
                    matches_allowed = True
                    break
            
            if not matches_allowed:
                errors.append(f"Write access to layer '{layer}' not allowed. Allowed: {allowed_write}")
    
    if disallowed_write and write_layers:
        for layer in write_layers:
            layer_str = str(layer).lower()
            # Check if layer matches any disallowed type
            is_disallowed = False
            for disallowed in disallowed_write:
                disallowed_str = str(disallowed).lower()
                if check_layer_type_match(layer_str, disallowed_str, layer_type_patterns):
                    is_disallowed = True
                    break
            
            if is_disallowed:
                errors.append(f"Write access to layer '{layer}' is disallowed")
    
    if errors:
        return build_result(
            rule_id, rule["name"], "FAILED", rule["severity"], file_path,
            "; ".join(errors),
            rule.get("recommendation"),
            {"role_type": role_type, "read_layers": read_layers, "write_layers": write_layers}
        )
    
    return build_result(
        rule_id, rule["name"], "PASSED", rule["severity"], file_path,
        rule["message"],
        evidence={"role_type": role_type, "read_layers": read_layers, "write_layers": write_layers}
    )


def check_no_resource_link_write(rule_id, rule, resource, file_path):
    """CMP_IAM_003 / LH_IAM_003: Ensure no Resource Link write permissions."""
    glue_db = resource.get("access_to_resources", {})
    if not isinstance(glue_db, dict):
        glue_db = {}
    
    glue_db = glue_db.get("glue_databases")
    if not glue_db:
        glue_db = {}
    
    write_layers = glue_db.get("write", []) if isinstance(glue_db, dict) and glue_db else []
    if not isinstance(write_layers, list):
        write_layers = [write_layers] if write_layers else []
    
    for layer in write_layers:
        if not layer:
            continue
        layer_str = str(layer).lower()
        # Resource Links end with _rl suffix
        if layer_str.endswith("_rl") or "resource_link" in layer_str:
            return build_result(
                rule_id, rule["name"], "FAILED", rule["severity"], file_path,
                rule["message"],
                rule.get("recommendation"),
                {"layer_with_rl_write": layer}
            )
    
    return build_result(
        rule_id, rule["name"], "PASSED", rule["severity"], file_path,
        "No Resource Link write permissions requested",
        evidence={"write_layers": write_layers}
    )


def check_data_prefix_naming(rule_id, rule, resource, file_path):
    """CMP_IAM_004 / LH_IAM_004: Validate data_prefix naming convention."""
    access_to_resources = resource.get("access_to_resources", {})
    if not isinstance(access_to_resources, dict):
        access_to_resources = {}
    
    data_prefixes = access_to_resources.get("s3_prefixes", [])
    if not data_prefixes:
        data_prefixes = []
    
    if not data_prefixes:
        return build_result(
            rule_id, rule["name"], "PASSED", rule["severity"], file_path,
            "No S3 prefixes to validate"
        )
    
    if not isinstance(data_prefixes, list):
        data_prefixes = [data_prefixes] if data_prefixes else []
    
    nc1_pattern = rule.get("params", {}).get("nc1_bucket_pattern", "^$")
    nc2_pattern = rule.get("params", {}).get("nc2_bucket_pattern", "^$")
    
    nc1_regex = re.compile(nc1_pattern)
    nc2_regex = re.compile(nc2_pattern)
    
    invalid_prefixes = []
    for prefix in data_prefixes:
        if not prefix:
            continue
        # Each prefix must match either NC1 or NC2
        if not (nc1_regex.match(str(prefix)) or nc2_regex.match(str(prefix))):
            invalid_prefixes.append(prefix)
    
    if invalid_prefixes:
        return build_result(
            rule_id, rule["name"], "FAILED", rule["severity"], file_path,
            rule["message"],
            rule.get("recommendation"),
            {"invalid_prefixes": invalid_prefixes, "nc1_pattern": nc1_pattern, "nc2_pattern": nc2_pattern}
        )
    
    return build_result(
        rule_id, rule["name"], "PASSED", rule["severity"], file_path,
        "All S3 prefixes follow approved naming conventions",
        evidence={"prefixes_checked": data_prefixes}
    )


# ✅ ----- Main Validator -----
def validate(file_paths, rules, context=None):
    """
    Entry point called by validation framework.
    
    Args:
        file_paths: List of file paths to validate
        rules: Dict of rules from rulepack
        context: Optional context dict
    
    Returns:
        List of result dicts
    """
    results = []
    rule_handlers = {
        "iam_role_name_check": check_iam_role_naming,
        "iam_glue_db_access_check": check_glue_db_access,
        "iam_no_resource_link_write_check": check_no_resource_link_write,
        "iam_data_prefix_naming_check": check_data_prefix_naming,
    }
    
    for file_path in file_paths:
        payload = load_yaml_or_json(file_path)
        file_rule_results = []
        
        if payload is None:
            results.append(build_result(
                "FILE_LOAD_ERROR", "file_load_error", "FAILED", "ERROR", file_path,
                f"Unable to load or parse file: {file_path}"
            ))
            results.append(build_file_summary_result(
                file_path, "FAILED", "File could not be loaded", 0, 1, 0, 0, context
            ))
            continue
        
        # Apply each rule
        for rule_id, rule in rules.items():
            if not rule.get("enabled", True):
                continue
            
            rule_type = rule.get("type")
            handler = rule_handlers.get(rule_type)
            
            if handler:
                result = handler(rule_id, rule, payload, file_path)
            else:
                result = build_result(
                    rule_id, rule.get("name"), "FAILED", rule.get("severity", "ERROR"), file_path,
                    f"Unsupported rule type: {rule_type}"
                )
            
            file_rule_results.append(result)
        
        # Add summary
        passed = sum(1 for r in file_rule_results if r["status"] == "PASSED")
        failed = sum(1 for r in file_rule_results if r["status"] == "FAILED")
        skipped = sum(1 for r in file_rule_results if r["status"] == "SKIPPED")
        
        results.extend(file_rule_results)
        
        if failed > 0:
            summary_status = "FAILED"
            summary_msg = f"Validation failed: {failed} rule(s) failed"
        elif passed > 0:
            summary_status = "PASSED"
            summary_msg = f"All {passed} applicable rule(s) passed"
        else:
            summary_status = "SKIPPED"
            summary_msg = "No applicable rules found"
        
        results.append(build_file_summary_result(
            file_path, summary_status, summary_msg, passed, failed, skipped, len(file_rule_results), context
        ))
    
    return results
