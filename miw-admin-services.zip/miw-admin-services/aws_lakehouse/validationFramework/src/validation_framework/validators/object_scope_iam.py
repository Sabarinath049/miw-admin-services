import json
import yaml


# ✅ -----------------------------
# Result Builders
# ✅ -----------------------------
def build_result(rule_id, rule_name, status, severity, file_path, message, recommendation=None, evidence=None):
    return {
        "rule_id": rule_id,
        "rule_name": rule_name,
        "status": status,
        "severity": severity,
        "file_path": file_path,
        "message": message,
        "recommendation": recommendation,
        "evidence": evidence or {}
    }

def build_file_summary_result(file_path, status, message, passed_rules, failed_rules, skipped_rules, total_rules, context=None):
    return {
        "rule_id": "FILE_SUMMARY",
        "rule_name": "file_summary",
        "status": status,
        "severity": "INFO" if status == "PASSED" else "ERROR",
        "file_path": file_path,
        "message": message,
        "recommendation": None,
        "evidence": {
            "passed_rules": passed_rules,
            "failed_rules": failed_rules,
            "skipped_rules": skipped_rules,            
            "total_rules": total_rules,
            "env": (context or {}).get("env")
        }
    }

def validate(file_paths, rules, context=None):
    results = []

    for file_path in file_paths:
        payload = load_yaml_or_json(file_path)
        file_rule_results = []
        file_rule_status_map = {}

        if payload is None:
            results.append(build_result(
                "FILE_LOAD_ERROR",
                "file_load_error",
                "FAILED",
                "ERROR",
                file_path,
                f"Unable to load file: {file_path}"
            ))
            continue

        for rule_id, rule in rules.items():

            if not rule.get("enabled", True):
                continue

            if rule_id in {"CP_IAM_SCOPE_004", "CP_IAM_SCOPE_005"} and file_rule_status_map.get("CP_IAM_SCOPE_001") == "PASSED":
                result = build_result(
                    rule_id,
                    rule.get("name"),
                    "SKIPPED",
                    rule.get("severity", "ERROR"),
                    file_path,
                    "Skipped because CP_IAM_SCOPE_001 already passed",
                    evidence={"depends_on_rule": "CP_IAM_SCOPE_001"}
                )
                file_rule_results.append(result)
                file_rule_status_map[rule_id] = result["status"]
                continue

            rule_type = rule.get("type")

            if rule_type == "pattern_allowed":
                result = _pattern_allowed(rule_id, rule, payload, file_path)
            elif rule_type == "pattern_not_allowed":
                result = _pattern_not_allowed(rule_id, rule, payload, file_path)
            elif rule_type == "conditional_field_required":
                result = _conditional_field_required(rule_id, rule, payload, file_path)
            else:
                result = build_result(
                    rule_id,
                    rule.get("name"),
                    "FAILED",
                    rule.get("severity", "ERROR"),
                    file_path,
                    f"Unsupported rule type: {rule_type}"
                )

            file_rule_results.append(result)
            file_rule_status_map[rule_id] = result["status"]

        passed_rules = sum(1 for r in file_rule_results if r["status"] == "PASSED")
        failed_rules = sum(1 for r in file_rule_results if r["status"] == "FAILED")
        skipped_rules = sum(1 for r in file_rule_results if r["status"] == "SKIPPED")

        results.extend(file_rule_results)

        if failed_rules > 0:
            summary_status = "FAILED"
            summary_message = "One or more validations failed for file"
        elif passed_rules > 0:
            summary_status = "PASSED"
            summary_message = "All applicable validations passed for file"
        else:
            summary_status = "SKIPPED"
            summary_message = "No applicable validations found for file"

        results.append(build_file_summary_result(
            file_path,
            summary_status,
            summary_message,
            passed_rules,
            failed_rules,
            skipped_rules,
            len(file_rule_results),
            context
        ))

    return results

# ✅ -----------------------------
# Pattern Allowed Logic
# ✅ -----------------------------
def _pattern_allowed(rule_id, rule, resource, file_path):
    field = rule.get("target_field")
    value = resource.get(field, "")

    patterns = rule.get("params", {}).get("include_patterns", [])

    if any(pattern in value for pattern in patterns):
        return build_result(
            rule_id,
            rule["name"],
            "PASSED",
            rule["severity"],
            file_path,
            rule["message"],
            evidence={field: value}
        )

    return build_result(
        rule_id,
        rule["name"],
        "FAILED",
        rule["severity"],
        file_path,
        f"{value} does not match allowed IAM role patterns",
        rule.get("recommendation"),
        evidence={field: value}
    )




# ✅ -----------------------------
# Pattern Not Allowed Logic
# ✅ -----------------------------
def _pattern_not_allowed(rule_id, rule, resource, file_path):
    field = rule.get("target_field")
    value = str(resource.get(field, ""))

    disallowed_patterns = rule.get("params", {}).get("disallowed_patterns", [])

    matched_patterns = [pattern for pattern in disallowed_patterns if pattern in value]

    if matched_patterns:
        return build_result(
            rule_id,
            rule["name"],
            "FAILED",
            rule["severity"],
            file_path,
            rule["message"],
            rule.get("recommendation"),
            evidence={
                field: value,
                "matched_patterns": matched_patterns
            }
        )

    return build_result(
        rule_id,
        rule["name"],
        "PASSED",
        rule["severity"],
        file_path,
        f"{field} does not contain any disallowed patterns",
        evidence={field: value}
    )


# ✅ -----------------------------
# Conditional Field Required Logic
# ✅ -----------------------------
def _conditional_field_required(rule_id, rule, resource, file_path):
    params = rule.get("params", {})
    condition = params.get("condition", {})
    required_field = params.get("required_field")

    if not required_field:
        return build_result(
            rule_id,
            rule["name"],
            "FAILED",
            rule["severity"],
            file_path,
            "Missing required_field in rule params",
            rule.get("recommendation")
        )

    condition_matched = _evaluate_condition(resource, condition)

    # Rule not applicable -> SKIPPED
    if not condition_matched:
        return build_result(
            rule_id,
            rule["name"],
            "SKIPPED",
            rule["severity"],
            file_path,
            f"Condition not met for rule {rule_id}",
            evidence={"condition": condition}
        )

    # Important:
    # - False should be treated as present
    # - 0 should be treated as present
    # - None or blank string should be treated as missing
    required_value = resource.get(required_field, None)
    is_missing = (
        required_field not in resource or
        required_value is None or
        (isinstance(required_value, str) and required_value.strip() == "")
    )

    if is_missing:
        return build_result(
            rule_id,
            rule["name"],
            "FAILED",
            rule["severity"],
            file_path,
            rule["message"],
            rule.get("recommendation"),
            evidence={
                "required_field": required_field,
                "required_value": required_value,
                "condition": condition
            }
        )

    return build_result(
        rule_id,
        rule["name"],
        "PASSED",
        rule["severity"],
        file_path,
        rule["message"],
        evidence={
            "required_field": required_field,
            "required_value": required_value,
            "condition": condition
        }
    )


# ✅ -----------------------------
# Condition Evaluator
# ✅ -----------------------------
def _evaluate_condition(resource, condition):
    field = condition.get("field")
    operator = condition.get("operator")
    expected_value = condition.get("value")

    actual_value = resource.get(field)

    if operator == "contains":
        return str(expected_value) in str(actual_value or "")

    elif operator == "equals":
        return actual_value == expected_value

    elif operator == "not_equals":
        return actual_value != expected_value

    elif operator == "exists":
        return field in resource and actual_value is not None

    return False


# ✅ -----------------------------
# File Loader
# ✅ -----------------------------
def load_yaml_or_json(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            if file_path.endswith(".json"):
                return json.load(f)
            return yaml.safe_load(f)
    except Exception:
        return None