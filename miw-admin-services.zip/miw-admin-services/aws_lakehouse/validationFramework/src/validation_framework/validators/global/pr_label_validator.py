import os
import re
import requests
import importlib.util
from pathlib import Path
from typing import Dict, List, Optional

# ============================================================
# CONSTANTS
# ============================================================

BASE_API = "https://git.cglcloud.com/api/v3"
OWNER = "Minerva"
REPO = "miw-object-provisioning"


# ============================================================
# MODULE LOADER
# ============================================================

def load_parser_validator():
    here = Path(__file__).resolve().parent
    pv_path = here / "parser_validator.py"

    spec = importlib.util.spec_from_file_location(
        "parser_validator",
        str(pv_path)
    )

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore

    return module


PV = load_parser_validator()


# ============================================================
# PR NUMBER HANDLING
# ============================================================

def extract_pr_number(file_path: str) -> str:

    pr_number = os.getenv("PR_NUMBER")

    if pr_number:
        return pr_number

    match = re.search(r"(\d+)", os.path.basename(file_path))

    if match:
        return match.group(1)

    raise ValueError("Unable to determine PR number")


# ============================================================
# API CLIENT
# ============================================================

def create_session(token: str) -> requests.Session:

    if not token:
        raise ValueError("Missing Git token")

    session = requests.Session()

    session.headers.update({
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json"
    })

    return session


def fetch_pr_labels(
    session: requests.Session,
    pr_number: str
) -> List[str]:

    url = (
        f"{BASE_API.rstrip('/')}"
        f"/repos/{OWNER}/{REPO}/pulls/{pr_number}"
    )

    response = session.get(url)

    if response.status_code != 200:
        _raise_api_error(response, pr_number)

    data = response.json()

    return [
        label.get("name", "").strip()
        for label in data.get("labels", [])
    ]


def _raise_api_error(response, pr_number):

    if response.status_code == 401:
        raise Exception("Unauthorized (401)")

    if response.status_code == 403:
        raise Exception(f"Forbidden (403): {response.text}")

    raise Exception(
        f"Failed fetching PR #{pr_number}: "
        f"{response.status_code}"
    )


# ============================================================
# RULE EVALUATION
# ============================================================

def evaluate_mandatory_label_regex(
    rule,
    labels,
    file_label
):

    pattern = rule.get("params", {}).get("pattern")

    matched = any(
        re.match(pattern, label, re.IGNORECASE)
        for label in labels
    )

    failed = not matched

    return _build_rule_result(
        rule=rule,
        file_label=file_label,
        value=",".join(labels),
        failed=failed
    )


def evaluate_label_count_regex(
    rule,
    labels,
    file_label
):

    params = rule.get("params", {})

    pattern = params.get("pattern")

    min_count = params.get("min_count", 0)
    max_count = params.get("max_count", 9999)

    count = sum(
        1
        for label in labels
        if re.match(pattern, label, re.IGNORECASE)
    )

    failed = (
        count < min_count
        or count > max_count
    )

    return _build_rule_result(
        rule=rule,
        file_label=file_label,
        value=f"count={count}, labels={labels}",
        failed=failed
    )


def _build_rule_result(
    rule,
    file_label,
    value,
    failed
):

    if failed:

        return PV.build_result(
            rule.get("id"),
            rule.get("name"),
            "FAILED",
            rule.get("severity", "ERROR"),
            file_label,
            (
                rule.get("message")
                or "Validation failed"
            ).format(
                actual_value=value
            ),
            rule.get("recommendation"),
            {
                "actual_value": value
            }
        )

    return PV.build_result(
        rule.get("id"),
        rule.get("name"),
        "PASSED",
        rule.get("severity", "ERROR"),
        file_label,
        "Validation passed",
        None
    )


def evaluate_optional_label_regex(
    rule,
    labels,
    file_label
):

    params = rule.get("params", {})

    category_pattern = params.get("category_pattern")
    allowed_pattern = params.get("allowed_pattern")

    priority_labels = [
        label
        for label in labels
        if re.match(category_pattern, label, re.IGNORECASE)
    ]

    # Optional label not present → PASS
    if not priority_labels:
        return _build_rule_result(
            rule,
            file_label,
            ",".join(labels),
            False
        )

    # Fail if any matching category label is invalid
    invalid_labels = [
        label
        for label in priority_labels
        if not re.match(allowed_pattern, label, re.IGNORECASE)
    ]

    failed = len(invalid_labels) > 0

    return _build_rule_result(
        rule,
        file_label,
        ",".join(invalid_labels or labels),
        failed
    )


# ============================================================
# RULE DISPATCHER
# ============================================================

def apply_rule(
    rule,
    parsed_doc,
    file_label
):

    rule_type = rule.get("type")

    labels = parsed_doc.get("labels", [])

    if rule_type == "mandatory_label_regex":
        return [
            evaluate_mandatory_label_regex(
                rule,
                labels,
                file_label
            )
        ]

    if rule_type == "label_count_regex":
        return [
            evaluate_label_count_regex(
                rule,
                labels,
                file_label
            )
        ]

    if rule_type == "optional_label_regex":
        return [
            evaluate_optional_label_regex(
                rule,
                labels,
                file_label
            )
        ]

    return [
        PV.build_result(
            rule.get("id"),
            rule.get("name"),
            "FAILED",
            "ERROR",
            file_label,
            f"Unknown rule type: {rule_type}",
            None
        )
    ]


# ============================================================
# MAIN VALIDATION ENGINE
# ============================================================

def validate(
    file_paths: List[str],
    rules: Dict,
    context: Optional[Dict] = None
):

    token = os.getenv("secret")

    session = create_session(token)

    results = []

    for file_path in file_paths:

        try:
            pr_number = extract_pr_number(file_path)

            labels = fetch_pr_labels(
                session,
                pr_number
            )

            parsed_doc = {
                "labels": labels
            }

            file_label = f"PR#{pr_number}"

            for rule_id, rule in rules.items():

                if not rule.get("enabled", True):
                    continue

                rule["id"] = rule_id

                results.extend(
                    apply_rule(
                        rule,
                        parsed_doc,
                        file_label
                    )
                )

        except Exception as e:

            results.append(
                PV.build_result(
                    "PR_LABEL_ERROR",
                    "PR_LABEL_ERROR",
                    "FAILED",
                    "ERROR",
                    file_path,
                    str(e),
                    None
                )
            )

    return results