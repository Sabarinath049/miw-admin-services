import os
import re
import requests
import importlib.util
from pathlib import Path
from typing import Dict, List, Optional, Any
from difflib import SequenceMatcher

# ============================================================
# CONSTANTS
# ============================================================

BASE_API = "https://git.cglcloud.com/api/v3"
OWNER = "Minerva"
REPO = "miw-object-provisioning"

DEFAULT_TEMPLATE_VALUES = {
    "q1_objective": (
        "Provisioning a new resource to support ingestion of customer "
        "transaction data for reporting and analytics."
    ),
    "q2_data_flow": (
        "Batch ingestion of daily files from an upstream ERP system, "
        "transformed and consumed by BI dashboards."
    ),
    "q3_priority": (
        "High priority; needed before quarter-end reporting. "
        "Yes, aware of the SLA and aligned with project timelines."
    ),
    "q4_approval": (
        "Yes, approved on 12-Sep and currently in RfD state. "
        "Naming conventions followed: <domain>_<purpose>_<env>."
    ),
    "q5_compute": (
        "Medium compute sizing recommended by MIW; "
        "AD group finance_analytics_team created; "
        "access will be both programmatic and console-based."
    ),
    "q6_dependencies": (
        "Dependency on upstream file delivery from vendor; "
        "risk of delay if vendor onboarding slips."
    ),
}


# ============================================================
# MODULE LOADER
# ============================================================

def load_parser_validator():
    here = Path(__file__).resolve().parent
    pv_path = here / "parser_validator.py"

    spec = importlib.util.spec_from_file_location("parser_validator", str(pv_path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore

    return module


PV = load_parser_validator()


# ============================================================
# FILE / INPUT HANDLING
# ============================================================

def extract_pr_number(file_path: str) -> str:
    """Extract PR number from filename or file content."""
    
    pr = os.getenv("PR_NUMBER") if os.getenv("PR_NUMBER") else _extract_digits(os.path.basename(file_path))

    if pr:
        print(f"#### [DEBUG] {pr} found in environment variables")
        return pr

    raise ValueError(f"PR number not found in {file_path}")


def _extract_digits(text: Optional[str]) -> Optional[str]:
    if not text:
        return None
    match = re.search(r"(\d{2,})", text)
    return match.group(1) if match else None


def _safe_read(file_path: str) -> Optional[str]:
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return None


# ============================================================
# API CLIENT
# ============================================================

def create_session(token: str) -> requests.Session:
    if not token:
        raise ValueError("Missing token")

    session = requests.Session()
    session.headers.update({
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json"
    })
    return session


def fetch_pr_body(session: requests.Session, pr_number: str) -> str:
    url = f"{BASE_API.rstrip('/')}/repos/{OWNER}/{REPO}/pulls/{pr_number}"

    resp = session.get(url)

    if resp.status_code == 200:
        return resp.json().get("body", "") or ""

    _raise_api_error(resp, pr_number)


def _raise_api_error(resp, pr_number):
    if resp.status_code == 401:
        raise Exception("Unauthorized (401)")
    if resp.status_code == 403:
        raise Exception(f"Forbidden (403): {resp.text}")
    raise Exception(f"Failed PR #{pr_number}: {resp.status_code}")


# ============================================================
# PARSING
# ============================================================

def extract_intake_answers(pr_body: str) -> Dict[str, Optional[str]]:
    """Extract structured answers from PR body."""
    normalized = _normalize_text(pr_body)

    collected = _collect_answers(normalized)

    return {
        "objective": _join(collected[1]),
        "data_flow": _join(collected[2]),
        "priority": _join(collected[3]),
        "approval": _join(collected[4]),
        "compute": _join(collected[5]),
        "dependencies": _join(collected[6]),
    }


def _normalize_text(text: str) -> str:
    return (text or "").replace("\r\n", "\n").replace("\r", "\n")


def _collect_answers(text: str) -> Dict[int, List[str]]:
    q_header = re.compile(r"^\s*(?:#{1,6}\s*)?([1-6])\.\s+.*", re.IGNORECASE)

    collected = {i: [] for i in range(1, 7)}
    current_q = None

    for line in text.split("\n"):
        s = line.strip()

        match = q_header.match(s)
        if match:
            current_q = int(match.group(1))
            continue

        if not _is_valid_answer_line(s, current_q):
            continue

        collected[current_q].append(_clean_answer(s))

    return collected


def _is_valid_answer_line(line: str, current_q: Optional[int]) -> bool:
    if current_q is None:
        return False
    if not line or line == "---":
        return False
    if _is_example(line):
        return False
    return True


def _is_example(line: str) -> bool:
    s = line.lower()
    return "e.g." in s or "_e.g." in s or "example:" in s


def _clean_answer(line: str) -> str:
    return line.lstrip(">").strip()


def _join(lines: List[str]) -> Optional[str]:
    text = "\n".join(lines).strip()
    return text if text else None


# ============================================================
# RULE VALIDATION
# ============================================================

def evaluate_string_rule(rule, value, file_label):
    params = rule.get("params", {})
    disallowed = {str(x).strip().lower() for x in params.get("disallowed_values", [])}

    invalid = (
        not isinstance(value, str)
        or not value.strip()
        or value.strip().lower() in disallowed
    )

    return _build_rule_result(rule, file_label, value, invalid)


def _normalize(text: Any) -> str:
    if text is None:
        return ""

    text = str(text).lower().strip()

    # remove punctuation/special chars
    text = re.sub(r"[^\w\s]", "", text)

    # normalize whitespace
    text = re.sub(r"\s+", " ", text)

    return text.strip()


def evaluate_default_template_rule(rule, value, file_label):
    target_field = rule.get("target_field")

    expected_default = DEFAULT_TEMPLATE_VALUES.get(target_field)

    failed = False

    if expected_default:
        similarity = _similarity(value, expected_default)

        # exact match after normalization
        normalized_value = _normalize(value)
        normalized_default = _normalize(expected_default)

        if normalized_default in normalized_value:
            failed = True

        # near-copy of template
        elif similarity >= 0.90:
            failed = True

    return _build_rule_result(rule, file_label, value, failed)


def _build_rule_result(rule, file_label, value, failed: bool):
    if failed:
        return PV.build_result(
            rule.get("id"),
            rule.get("name"),
            "FAILED",
            rule.get("severity", "ERROR"),
            file_label,
            (rule.get("message") or "Invalid value").format(actual_value=value),
            rule.get("recommendation"),
            {"actual_value": value}
        )

    return PV.build_result(
        rule.get("id"),
        rule.get("name"),
        "PASSED",
        rule.get("severity", "ERROR"),
        file_label,
        "Validation passed",
        None
    )


def apply_rule(rule, parsed_doc, file_label):
    value = PV.get_value_by_path(parsed_doc, rule.get("target_field"))
    rule_type = rule.get("type")

    if rule_type == "string_not_empty_and_not_in":
        return [evaluate_string_rule(rule, value, file_label)]

    if rule_type == "not_default_template_value":
        return [evaluate_default_template_rule(rule, value, file_label)]

    return [_unknown_rule_result(rule, file_label)]


def _unknown_rule_result(rule, file_label):
    return PV.build_result(
        rule.get("id"),
        rule.get("name"),
        "FAILED",
        "ERROR",
        file_label,
        f"Unknown rule type: {rule.get('type')}",
        None
    )


# ============================================================
# MAIN ENGINE
# ============================================================

def validate(file_paths: List[str], rules: Dict, context: Optional[Dict] = None):

    token = os.getenv("secret")
    session = create_session(token)

    results = []

    for file_path in file_paths:
        results.extend(_process_file(file_path, rules, session))

    return results


def _process_file(file_path: str, rules: Dict, session: requests.Session):

    try:
        pr_number = extract_pr_number(file_path)
    except Exception as e:
        return [_error_result("PR_NUMBER", file_path, str(e))]

    file_label = f"PR#{pr_number}"

    try:
        pr_body = fetch_pr_body(session, pr_number)
    except Exception as e:
        return [_error_result("PR_FETCH", file_label, str(e))]

    parsed_doc = _build_document(pr_body)

    return _apply_rules(rules, parsed_doc, file_label)


def _build_document(pr_body: str) -> Dict[str, str]:
    answers = extract_intake_answers(pr_body)

    return {
        f"q{i}_{key}": (answers[key] or "").strip()
        for i, key in enumerate(
            ["objective", "data_flow", "priority", "approval", "compute", "dependencies"],
            start=1
        )
    }


def _apply_rules(rules, parsed_doc, file_label):
    results = []

    for rule_id, rule in (rules or {}).items():
        if not rule.get("enabled", True):
            continue

        rule["id"] = rule_id  # inject id once
        results.extend(apply_rule(rule, parsed_doc, file_label))

    return results


def _error_result(code, file_label, error_msg):
    return PV.build_result(
        code,
        code,
        "FAILED",
        "ERROR",
        file_label,
        error_msg,
        None
    )


def _similarity(a, b):
    return SequenceMatcher(
        None,
        _normalize(a),
        _normalize(b)
    ).ratio()