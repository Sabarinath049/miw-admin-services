import json
import re
from typing import Any, Dict, List, Optional

import yaml


def validate(file_paths: List[str], rules: Dict,
             context: Optional[Dict] = None) -> List[Dict]:
    """
    Entry point called by the wrapper script.
    """
    results = []

    for file_path in file_paths:
        payload = load_yaml_or_json(file_path)
        file_rule_results = []

        if payload is None:
            error_result = build_result(
                rule_id="FILE_LOAD_ERROR",
                rule_name="file_load_error",
                status="FAILED",
                severity="ERROR",
                file_path=file_path,
                message=f"Unable to load or parse file: {file_path}",
                recommendation="Check whether the file is valid YAML or JSON",
            )
            results.append(error_result)
            results.append(
                build_file_summary_result(
                    file_path=file_path,
                    status="FAILED",
                    message="Validation failed because the file could not be loaded",
                    passed_rules=0,
                    failed_rules=1,
                    total_rules=0,
                    context=context,
                ))
            continue

        for rule_id, rule in rules.items():
            resolved_rule = resolve_rule_with_context(rule, context)

            if not resolved_rule.get("enabled", False):
                continue

            rule_type = resolved_rule.get("type")

            if rule_type == "allowed_values_in_name":
                result = apply_allowed_values_in_name_rule(
                    file_path, payload, rule_id, resolved_rule)
            elif rule_type == "regex_match":
                result = apply_regex_rule(
                    file_path, payload, rule_id, resolved_rule)
            elif rule_type == "non_empty_check":
                result = apply_non_empty_check_rule(
                    file_path, payload, rule_id, resolved_rule)
            else:
                result = build_result(
                    rule_id=rule_id,
                    rule_name=resolved_rule.get("name"),
                    status="FAILED",
                    severity=resolved_rule.get(
                        "severity",
                        "ERROR"),
                    file_path=file_path,
                    message=f"Unsupported rule type: {rule_type}",
                    recommendation="Update the validator to support this rule type",
                )

            file_rule_results.append(result)
            results.append(result)

        passed_rules = sum(
            1 for r in file_rule_results if r.get("status") == "PASSED")
        failed_rules = sum(
            1 for r in file_rule_results if r.get("status") == "FAILED")

        summary_status = "PASSED" if failed_rules == 0 else "FAILED"
        summary_message = (
            "All validations passed for file"
            if summary_status == "PASSED"
            else "One or more validations failed for file"
        )

        results.append(build_file_summary_result(
            file_path=file_path,
            status=summary_status,
            message=summary_message,
            passed_rules=passed_rules,
            failed_rules=failed_rules,
            total_rules=len(file_rule_results),
            context=context,
        ))

    return results


def apply_allowed_values_in_name_rule(
        file_path: str,
        payload: Dict,
        rule_id: str,
        rule: Dict) -> Dict:
    """
    Validate values in target field against allowed/disallowed tokens.

    Supports target values as:
    - string
    - list of strings
    """
    target_field = rule.get("target_field")
    params = rule.get("params", {})

    value = get_nested_value(payload, target_field)
    if value is None:
        return build_result(
            rule_id=rule_id,
            rule_name=rule.get("name"),
            status="FAILED",
            severity=rule.get("severity", "ERROR"),
            file_path=file_path,
            message=f"Target field '{target_field}' not found in file",
            recommendation=rule.get("recommendation"),
        )

    values_to_check = value if isinstance(value, list) else [value]
    if not all(isinstance(item, str) for item in values_to_check):
        return build_result(
            rule_id=rule_id,
            rule_name=rule.get("name"),
            status="FAILED",
            severity=rule.get(
                "severity",
                "ERROR"),
            file_path=file_path,
            message=f"Target field '{target_field}' must be a string or list of strings",
            recommendation=rule.get("recommendation"),
        )

    allowed_values = [str(item).lower()
                      for item in params.get("allowed_values", [])]
    disallowed_values = [str(item).lower()
                         for item in params.get("disallowed_values", [])]
    require_all_allowed_values = bool(params.get("require_all_allowed_values"))
    if rule_id == "LH_RP_001":
        require_all_allowed_values = True

    disallowed_values_found: List[str] = []
    values_missing_allowed: List[str] = []
    found_allowed_values: set = set()

    for current_value in values_to_check:
        normalized_value = current_value.lower()
        tokens = [token for token in re.split(
            r"[_/\-]+", normalized_value) if token]

        found_disallowed = [
            token for token in tokens if token in disallowed_values]
        if found_disallowed:
            disallowed_values_found.extend(found_disallowed)

        found_allowed_values.update(
            token for token in tokens if token in allowed_values)

        contains_allowed = any(token in allowed_values for token in tokens)
        if allowed_values and not contains_allowed:
            values_missing_allowed.append(current_value)

    if disallowed_values_found:
        message = rule.get(
            "message", "Disallowed values found in target field")
        return build_result(
            rule_id=rule_id,
            rule_name=rule.get("name"),
            status="FAILED",
            severity=rule.get(
                "severity",
                "ERROR"),
            file_path=file_path,
            message=message.format(
                disallowed_values_found=", ".join(
                    sorted(
                        set(disallowed_values_found)))),
            recommendation=rule.get("recommendation"),
            evidence={
                "target_field": target_field,
                "actual_value": value,
                "allowed_values": allowed_values,
                "disallowed_values": disallowed_values,
                "disallowed_values_found": sorted(
                    set(disallowed_values_found)),
            },
        )

    if values_missing_allowed:
        return build_result(
            rule_id=rule_id,
            rule_name=rule.get("name"),
            status="FAILED",
            severity=rule.get("severity", "ERROR"),
            file_path=file_path,
            message="One or more values do not include any allowed token",
            recommendation=rule.get("recommendation"),
            evidence={
                "target_field": target_field,
                "actual_value": value,
                "allowed_values": allowed_values,
                "values_missing_allowed": values_missing_allowed,
            },
        )

    missing_required_allowed_values = sorted(
        set(allowed_values) - found_allowed_values)
    if require_all_allowed_values and missing_required_allowed_values:
        return build_result(
            rule_id=rule_id,
            rule_name=rule.get("name"),
            status="FAILED",
            severity=rule.get("severity", "ERROR"),
            file_path=file_path,
            message=(
                "All configured allowed values must be present in resource policy"
            ),
            recommendation=rule.get("recommendation"),
            evidence={
                "target_field": target_field,
                "actual_value": value,
                "allowed_values": allowed_values,
                "missing_allowed_values": missing_required_allowed_values,
                "found_allowed_values": sorted(found_allowed_values),
            },
        )

    return build_result(
        rule_id=rule_id,
        rule_name=rule.get("name"),
        status="PASSED",
        severity=rule.get("severity", "ERROR"),
        file_path=file_path,
        message="Validation passed",
        recommendation=rule.get("recommendation"),
    )


def apply_regex_rule(
        file_path: str,
        payload: Dict,
        rule_id: str,
        rule: Dict) -> Dict:
    """
    Apply regex validation for a string or list of strings.
    For list targets, every element must match.
    """
    target_field = rule.get("target_field")
    pattern = rule.get("params", {}).get("pattern")
    pattern = render_pattern_with_payload_lower(pattern, payload)

    value = get_nested_value(payload, target_field)
    if value is None:
        return build_result(
            rule_id=rule_id,
            rule_name=rule.get("name"),
            status="FAILED",
            severity=rule.get("severity", "ERROR"),
            file_path=file_path,
            message=f"Target field '{target_field}' not found in file",
            recommendation=rule.get("recommendation"),
        )

    values_to_check = value if isinstance(value, list) else [value]
    if not all(isinstance(item, str) for item in values_to_check):
        return build_result(
            rule_id=rule_id,
            rule_name=rule.get("name"),
            status="FAILED",
            severity=rule.get(
                "severity",
                "ERROR"),
            file_path=file_path,
            message=f"Target field '{target_field}' must be a string or list of strings",
            recommendation=rule.get("recommendation"),
        )

    try:
        mismatches = [item for item in values_to_check if re.match(
            pattern, item) is None]
    except re.error as regex_error:
        return build_result(
            rule_id=rule_id,
            rule_name=rule.get("name"),
            status="FAILED",
            severity=rule.get("severity", "ERROR"),
            file_path=file_path,
            message=f"Invalid regex pattern in rule: {regex_error}",
            recommendation="Fix the regex in the rulepack pattern field",
            evidence={
                "target_field": target_field,
                "actual_value": value,
                "expected_pattern": pattern,
            },
        )

    if mismatches:
        failure_message = rule.get(
            "message") or "Target value does not match required regex pattern"
        return build_result(
            rule_id=rule_id,
            rule_name=rule.get("name"),
            status="FAILED",
            severity=rule.get("severity", "ERROR"),
            file_path=file_path,
            message=failure_message,
            recommendation=rule.get("recommendation"),
            evidence={
                "target_field": target_field,
                "actual_value": value,
                "expected_pattern": pattern,
                "mismatched_values": mismatches,
            },
        )

    return build_result(
        rule_id=rule_id,
        rule_name=rule.get("name"),
        status="PASSED",
        severity=rule.get("severity", "ERROR"),
        file_path=file_path,
        message="Validation passed",
        recommendation=rule.get("recommendation"),
    )


def render_pattern_with_payload_lower(
        pattern: Any, payload: Dict[str, Any]) -> Any:
    """
    Replace placeholders in regex pattern with lower-cased payload values.
    Supports ${field}, $field, and {field} forms.
    Leaves unresolved placeholders unchanged.
    """
    if not isinstance(pattern, str):
        return pattern

    rendered = pattern

    def replace_dollar(match):
        key = match.group(1) or match.group(2)
        value = get_nested_value(payload, key)
        return str(value).lower() if value is not None else match.group(0)

    rendered = re.sub(
        r"\$\{([A-Za-z_][A-Za-z0-9_\.]*)\}|\$([A-Za-z_][A-Za-z0-9_\.]*)",
        replace_dollar,
        rendered,
    )

    for key in re.findall(r"\{([A-Za-z_][A-Za-z0-9_\.]*)\}", rendered):
        value = get_nested_value(payload, key)
        if value is not None:
            rendered = rendered.replace("{" + key + "}", str(value).lower())

    return rendered


def apply_non_empty_check_rule(
        file_path: str,
        payload: Dict,
        rule_id: str,
        rule: Dict) -> Dict:
    """
    Evaluate one or more python expressions from rule.params.python_expression.

    Optional params.regex_pattern can be used to validate target_field values
    when provided.
    """
    params = rule.get("params", {})
    expressions = params.get("python_expression", [])

    if isinstance(expressions, str):
        expressions = [expressions]

    if not isinstance(expressions, list) or not expressions:
        return build_result(
            rule_id=rule_id,
            rule_name=rule.get("name"),
            status="FAILED",
            severity=rule.get(
                "severity",
                "ERROR"),
            file_path=file_path,
            message="No python_expression configured for non_empty_check rule",
            recommendation="Add params.python_expression as a string or list of expressions",
        )

    failed_expressions = []
    missing_fields_all = []

    safe_globals = {"__builtins__": {}}
    safe_locals_base = {
        "lower": lambda x: str(x).lower(),
        "str": str,
        "len": semantic_len,
    }

    payload_locals = {}
    if isinstance(payload, dict):
        for key, val in payload.items():
            if isinstance(key, str) and key.isidentifier():
                payload_locals[key] = val

    for expression in expressions:
        normalized_expression = normalize_python_expression(expression)
        rendered_expression, missing_fields = render_expression_with_payload(
            normalized_expression, payload)

        if missing_fields:
            missing_fields_all.extend(missing_fields)
            failed_expressions.append({
                "expression": expression,
                "rendered_expression": rendered_expression,
                "reason": f"Missing fields: {', '.join(sorted(set(missing_fields)))}",
            })
            continue

        try:
            safe_locals = dict(safe_locals_base)
            safe_locals.update(payload_locals)
            evaluation_result = eval(
                rendered_expression, safe_globals, safe_locals)
        except Exception as expression_error:
            failed_expressions.append({
                "expression": expression,
                "rendered_expression": rendered_expression,
                "reason": f"Evaluation error: {expression_error}",
            })
            continue

        if not bool(evaluation_result):
            failed_expressions.append({
                "expression": expression,
                "rendered_expression": rendered_expression,
                "reason": "Expression evaluated to False",
            })

    regex_patterns = params.get("regex_pattern", [])
    target_field = rule.get("target_field")

    if isinstance(regex_patterns, str):
        regex_patterns = [regex_patterns]

    if regex_patterns:
        target_value = get_nested_value(payload, target_field)
        if target_value is None:
            failed_expressions.append({
                "expression": "regex_pattern",
                "rendered_expression": "",
                "reason": f"Target field '{target_field}' not found for regex validation",
            })
        else:
            values_to_check = target_value if isinstance(
                target_value, list) else [target_value]
            if not all(isinstance(item, str) for item in values_to_check):
                failed_expressions.append({
                    "expression": "regex_pattern",
                    "rendered_expression": "",
                    "reason": f"Target field '{target_field}' must be a string or list of strings for regex validation",
                })
            else:
                for item in values_to_check:
                    for pattern in regex_patterns:
                        try:
                            if re.match(pattern, item) is None:
                                failed_expressions.append({
                                    "expression": "regex_pattern",
                                    "rendered_expression": item,
                                    "reason": f"Value '{item}' does not match regex '{pattern}'",
                                })
                        except re.error as regex_error:
                            failed_expressions.append({
                                "expression": "regex_pattern",
                                "rendered_expression": item,
                                "reason": f"Invalid regex pattern '{pattern}': {regex_error}",
                            })

    if failed_expressions:
        return build_result(
            rule_id=rule_id,
            rule_name=rule.get("name"),
            status="FAILED",
            severity=rule.get(
                "severity",
                "ERROR"),
            file_path=file_path,
            message=render_text_with_payload(
                rule.get(
                    "message",
                    "One or more non_empty checks failed"),
                payload),
            recommendation=render_text_with_payload(
                rule.get("recommendation"),
                payload),
            evidence={
                "failed_expressions": failed_expressions,
                "missing_fields": sorted(
                    set(missing_fields_all)),
            },
        )

    return build_result(
        rule_id=rule_id,
        rule_name=rule.get("name"),
        status="PASSED",
        severity=rule.get("severity", "ERROR"),
        file_path=file_path,
        message="Validation passed",
        recommendation=render_text_with_payload(
            rule.get("recommendation"), payload),
    )


def semantic_len(value: Any) -> int:
    """
    Domain-aware length used by non_empty_check expressions.

    Behavior:
    - None -> 0
    - string -> len(value.strip())
    - list/tuple/set -> count of non-empty semantic elements
    - dict -> regular len(dict)
    - other scalars -> len(str(value).strip())
    """
    if value is None:
        return 0

    if isinstance(value, str):
        return len(value.strip())

    if isinstance(value, (list, tuple, set)):
        return sum(1 for item in value if semantic_len(item) > 0)

    if isinstance(value, dict):
        return len(value)

    return len(str(value).strip())


def normalize_python_expression(expression: Any) -> str:
    """
    Normalize python_expression templates.
    Supports expressions wrapped like f"..." or f'...'.
    """
    if not isinstance(expression, str):
        return ""

    text = expression.strip()
    if len(text) >= 4 and text[0] in ("f",
                                      "F") and text[1] in ('"',
                                                           "'") and text[-1] == text[1]:
        return text[2:-1]
    return text


def render_expression_with_payload(
        expression: str, payload: Dict) -> (str, List[str]):
    """
    Replace {field_name} placeholders in expression with repr(payload[field_name]).
    Supports dot-path placeholders, e.g. {access_to_resources.s3_prefixes}
    """
    identifiers = re.findall(r"\{([A-Za-z_][A-Za-z0-9_\.]*)\}", expression)
    rendered = expression
    missing_fields = []

    for identifier in identifiers:
        value = get_nested_value(payload, identifier)
        if value is None:
            missing_fields.append(identifier)
            continue
        rendered = rendered.replace("{" + identifier + "}", repr(value))

    return rendered, missing_fields


def resolve_rule_with_context(rule: Dict,
                              context: Optional[Dict] = None) -> Dict:
    """Replace $key / ${key} placeholders in all rule string fields from context."""
    return replace_context_tokens(rule, context or {})


def replace_context_tokens(value: Any, context: Dict) -> Any:
    if isinstance(value, dict):
        return {k: replace_context_tokens(v, context)
                for k, v in value.items()}
    if isinstance(value, list):
        return [replace_context_tokens(item, context) for item in value]
    if isinstance(value, str):
        def _replace(match):
            key = match.group(1) or match.group(2)
            return str(context[key]) if key in context else match.group(0)
        return re.sub(
            r"\$([A-Za-z_][A-Za-z0-9_]*)|\$\{([A-Za-z_][A-Za-z0-9_]*)\}",
            _replace,
            value,
        )
    return value


def load_yaml_or_json(file_path: str) -> Optional[Dict]:
    try:
        with open(file_path, "r", encoding="utf-8") as fh:
            if file_path.endswith(".json"):
                return json.load(fh)
            return yaml.safe_load(fh)
    except Exception:
        return None


def get_nested_value(payload: Dict[str, Any], field_path: str) -> Any:
    """
    Resolve nested value using dot notation.
    """
    if field_path in (None, "", "."):
        return payload

    current = payload
    for key in field_path.split("."):
        if not key:
            continue
        if isinstance(current, list):
            if key.isdigit():
                idx = int(key)
                if idx < 0 or idx >= len(current):
                    return None
                current = current[idx]
                continue
            matched_values = [item[key] for item in current if isinstance(
                item, dict) and key in item]
            if not matched_values:
                return None
            current = matched_values[0]
            continue
        if not isinstance(current, dict) or key not in current:
            return None
        current = current[key]
    return current


def render_text_with_payload(template: Any, payload: Dict[str, Any]) -> Any:
    """
    Replace payload placeholders in text templates.
    Supports ${field}, $field, and {field} forms.
    Leaves unresolved placeholders unchanged.
    """
    if not isinstance(template, str):
        return template

    rendered = template

    def replace_dollar(match):
        key = match.group(1) or match.group(2)
        value = get_nested_value(payload, key)
        return str(value) if value is not None else match.group(0)

    rendered = re.sub(
        r"\$\{([A-Za-z_][A-Za-z0-9_\.]*)\}|\$([A-Za-z_][A-Za-z0-9_\.]*)",
        replace_dollar,
        rendered,
    )

    for key in re.findall(r"\{([A-Za-z_][A-Za-z0-9_\.]*)\}", rendered):
        value = get_nested_value(payload, key)
        if value is not None:
            rendered = rendered.replace("{" + key + "}", str(value))

    return rendered


def build_result(
    rule_id: str,
    rule_name: Optional[str],
    status: str,
    severity: str,
    file_path: str,
    message: str,
    recommendation: Optional[str] = None,
    evidence: Optional[Dict] = None,
) -> Dict:
    effective_status = (
        "WARNING"
        if status == "FAILED" and str(severity).strip().upper() == "WARNING"
        else status
    )

    return {
        "rule_id": rule_id,
        "rule_name": rule_name,
        "status": effective_status,
        "severity": severity,
        "file_path": file_path,
        "message": message,
        "recommendation": recommendation,
        "evidence": evidence or {},
    }


def build_file_summary_result(
    file_path: str,
    status: str,
    message: str,
    passed_rules: int,
    failed_rules: int,
    total_rules: int,
    context: Optional[Dict] = None,
) -> Dict:
    return {
        "rule_id": "FILE_SUMMARY",
        "rule_name": "file_summary",
        "status": status,
        "severity": "INFO" if status == "PASSED" else "ERROR",
        "file_path": file_path,
        "message": message,
        "recommendation": None,
        "evidence": {
            "passed_rules": passed_rules,
            "failed_rules": failed_rules,
            "total_rules": total_rules,
            "env": (context or {}).get("env"),
        },
    }
