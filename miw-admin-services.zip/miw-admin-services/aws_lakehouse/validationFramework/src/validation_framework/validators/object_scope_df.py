import json
import yaml


# ✅ -----------------------------
# Result Builders
# ✅ -----------------------------
def build_result(rule_id, rule_name, status, severity, file_path, message, recommendation=None, evidence=None):
    return {
        "rule_id": rule_id,
        "rule_name": rule_name,
        "status": status,
        "severity": severity,
        "file_path": file_path,
        "message": message,
        "recommendation": recommendation,
        "evidence": evidence or {}
    }

def build_file_summary_result(file_path, status, message, passed_rules, failed_rules, skipped_rules, total_rules, context=None):
    return {
        "rule_id": "FILE_SUMMARY",
        "rule_name": "file_summary",
        "status": status,
        "severity": "INFO" if status == "PASSED" else "ERROR",
        "file_path": file_path,
        "message": message,
        "recommendation": None,
        "evidence": {
            "passed_rules": passed_rules,
            "failed_rules": failed_rules,
            "skipped_rules": skipped_rules,            
            "total_rules": total_rules,
            "env": (context or {}).get("env")
        }
    }


# ✅ -----------------------------
# Main Validate Function
# ✅ -----------------------------
def validate(file_paths, rules, context=None):

    results = []

    for file_path in file_paths:
        payload = load_yaml_or_json(file_path)
        file_rule_results = []

        if payload is None:
            results.append(build_result(
                "FILE_LOAD_ERROR",
                "file_load_error",
                "FAILED",
                "ERROR",
                file_path,
                f"Unable to load file: {file_path}"
            ))
            continue

        for rule_id, rule in rules.items():

            if not rule.get("enabled", True):
                continue

            rule_type = rule.get("type")

            if rule_type == "conditional_list_pattern":
                result =  _conditional_list_pattern(rule_id, rule, payload, file_path)

            elif rule_type == "conditional_list_pattern_not_allowed":
                result =  _conditional_list_pattern_not_allowed(rule_id, rule, payload, file_path)

            elif rule_type == "conditional_field_required":
                result =  _conditional_field_required(rule_id, rule, payload, file_path)

            else:
                result = build_result(
                    rule_id,
                    rule.get("name"),
                    "FAILED",
                    rule.get("severity", "ERROR"),
                    file_path,
                    f"Unsupported rule type: {rule_type}"
                )

            file_rule_results.append(result)
            results.append(result)

        # ✅ Summary calculation
        passed_rules = sum(1 for r in file_rule_results if r["status"] == "PASSED")
        failed_rules = sum(1 for r in file_rule_results if r["status"] == "FAILED")
        skipped_rules = sum(1 for r in file_rule_results if r["status"] == "SKIPPED")

        summary_status = "PASSED" if failed_rules == 0 else "FAILED"
        summary_message = (
            "All validations passed for file"
            if summary_status == "PASSED"
            else "One or more validations failed for file"
        )

        results.append(build_file_summary_result(
            file_path,
            summary_status,
            summary_message,
            passed_rules,
            failed_rules,
            skipped_rules,
            len(file_rule_results),
            context
        ))

    return results



# ✅ -----------------------------
# DF_LH_001: Allowed Layers
# ✅ -----------------------------
def _conditional_list_pattern(rule_id, rule, resource, file_path):

    params = rule.get("params", {})
    condition = params.get("condition", {})

    if not _evaluate_condition(condition, resource):
        return _skip(rule_id, rule, file_path)

    field = rule.get("target_field")
    values = resource.get(field, [])

    allowed_patterns = params.get("allowed_patterns", [])

    invalid_items = []

    for item in values:
        if not any(p in item for p in allowed_patterns):
            invalid_items.append(item)

    if not invalid_items:
        return build_result(
            rule_id,
            rule["name"],
            "PASSED",
            rule["severity"],
            file_path,
            rule["message"],
            evidence={field: values}
        )

    return build_result(
        rule_id,
        rule["name"],
        "FAILED",
        rule["severity"],
        file_path,
        f"Invalid DBs: {invalid_items}",
        rule.get("recommendation"),
        evidence={field: invalid_items}
    )


# ✅ -----------------------------
# DF_LH_002: Block Invalid Layers
# ✅ -----------------------------
def _conditional_list_pattern_not_allowed(rule_id, rule, resource, file_path):

    params = rule.get("params", {})
    condition = params.get("condition", {})

    if not _evaluate_condition(condition, resource):
        return _skip(rule_id, rule, file_path)

    field = rule.get("target_field")
    values = resource.get(field, [])

    disallowed_patterns = params.get("disallowed_patterns", [])
    exclude_patterns = params.get("exclude_patterns", [])

    violations = []

    for item in values:

        if any(ex in item for ex in exclude_patterns):
            continue

        if any(p in item for p in disallowed_patterns):
            violations.append(item)

    if not violations:
        return build_result(
            rule_id,
            rule["name"],
            "PASSED",
            rule["severity"],
            file_path,
            rule["message"],
            evidence={field: values}
        )

    return build_result(
        rule_id,
        rule["name"],
        "FAILED",
        rule["severity"],
        file_path,
        f"Restricted DBs found: {violations}",
        rule.get("recommendation"),
        evidence={field: violations}
    )


# ✅ -----------------------------
# DF_LH_003: Required Field
# ✅ -----------------------------
def _conditional_field_required(rule_id, rule, resource, file_path):

    params = rule.get("params", {})
    condition = params.get("condition", {})

    if not _evaluate_condition(condition, resource):
        return _skip(rule_id, rule, file_path)

    required_field = params.get("required_field")
    value = resource.get(required_field)

    if value:
        return build_result(
            rule_id,
            rule["name"],
            "PASSED",
            rule["severity"],
            file_path,
            rule["message"],
            evidence={required_field: value}
        )

    return build_result(
        rule_id,
        rule["name"],
        "FAILED",
        rule["severity"],
        file_path,
        rule["message"],
        rule.get("recommendation"),
        evidence={required_field: value}
    )


# ✅ -----------------------------
# Condition Evaluator
# ✅ -----------------------------
def _evaluate_condition(condition, resource):

    field = condition.get("field")
    operator = condition.get("operator")
    value = condition.get("value")

    actual = resource.get(field)

    if operator == "equals":
        return actual == value

    return False


# ✅ -----------------------------
# Skip Rule
# ✅ -----------------------------
def _skip(rule_id, rule, file_path):
    return build_result(
        rule_id,
        rule.get("name"),
        "SKIPPED",
        rule.get("severity"),
        file_path,
        "Rule skipped (condition not met)"
    )


# ✅ -----------------------------
# File Loader
# ✅ -----------------------------
def load_yaml_or_json(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            if file_path.endswith(".json"):
                return json.load(f)
            return yaml.safe_load(f)
    except Exception:
        return None