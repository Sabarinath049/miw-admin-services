import json
import os
import re
from typing import Any, Dict

import yaml


# =========================
# MAIN VALIDATION ENTRY
# =========================
def validate(file_paths, rules, context=None):
    results = []

    for file_path in file_paths:
        payload = load_yaml_or_json(file_path)
        file_rule_results = []

        if payload is None:
            results.append(build_result(
                "FILE_LOAD_ERROR",
                "file_load_error",
                "FAILED",
                "ERROR",
                file_path,
                f"Unable to load file: {file_path}",
                "Check YAML/JSON format"
            ))
            continue

        for rule_id, rule in rules.items():
            # Default to enabled so a rule missing the "enabled" key is still
            # executed (matches the behavior of the other validators, e.g.
            # object_scope_df.py). Only an explicit `enabled: false` skips a rule.
            if not rule.get("enabled", True):
                continue

            rule_type = rule.get("type")

            if rule_type == "regex_match":
                result = apply_regex_rule(file_path, payload, rule_id, rule)

            elif rule_type == "allowed_values_in_name":
                result = apply_allowed_values_rule(file_path, payload, rule_id, rule)

            elif rule_type == "allowed_values":
                result = apply_allowed_values_exact(file_path, payload, rule_id, rule)

            elif rule_type == "equality_check":
                result = apply_equality_check(
                    file_path,
                    payload,
                    rule_id,
                    rule
                )

            elif rule_type == "account_id_by_env":
                result = apply_account_id_by_env_rule(
                    file_path,
                    payload,
                    rule_id,
                    rule,
                    context
                )

            else:
                result = build_result(
                    rule_id,
                    rule.get("name"),
                    "FAILED",
                    "ERROR",
                    file_path,
                    f"Unsupported rule type: {rule_type}",
                    "Update validator"
                )

            file_rule_results.append(result)
            results.append(result)

        results.append(build_summary(file_path, file_rule_results))

    return results


# =========================
# FILE LOADER
# =========================
def load_yaml_or_json(file_path):
    try:
        with open(file_path, "r") as f:
            if file_path.endswith(".json"):
                return json.load(f)
            return yaml.safe_load(f)
    except Exception:
        return None


# =========================
# REGEX RULE (supports file_path)
# =========================
def apply_regex_rule(file_path, payload, rule_id, rule):
    target = rule.get("target_field")
    pattern = rule.get("params", {}).get("pattern")

    value = file_path if target == "file_path" else get_value(payload, target)

    if not isinstance(value, str):
        return fail(rule_id, rule, file_path, "Invalid target field")

    # ✅ ADD THIS BACK
    if target == "file_path":
        value = os.path.normpath(value).replace("\\", "/")

    if not re.match(pattern, value):
        return fail(rule_id, rule, file_path, rule.get("message"),
                    {"value": value, "pattern": pattern})

    return success(rule_id, rule, file_path)



# =========================
# ALLOWED VALUES IN NAME (list supported)
# =========================
def apply_allowed_values_rule(file_path, payload, rule_id, rule):
    target = rule.get("target_field")
    allowed = [v.lower() for v in rule.get("params", {}).get("allowed_values", [])]

    values = get_value(payload, target)
    values = values if isinstance(values, list) else [values]

    invalid = []
    for val in values:
        if not isinstance(val, str):
            continue

        tokens = re.split(r"[_/\-]+", val.lower())
        if not any(t in allowed for t in tokens):
            invalid.append(val)

    if invalid:
        return fail(rule_id, rule, file_path, rule.get("message"),
                    {"invalid": invalid})

    return success(rule_id, rule, file_path)


# =========================
# EXACT ALLOWED VALUES
# =========================
def apply_allowed_values_exact(file_path, payload, rule_id, rule):
    value = get_value(payload, rule.get("target_field"))
    allowed = rule.get("params", {}).get("allowed_values", [])

    if value not in allowed:
        return fail(rule_id, rule, file_path, rule.get("message"),
                    {"value": value, "allowed": allowed})

    return success(rule_id, rule, file_path)


# =========================
# EQUALITY CHECK
# =========================
def apply_equality_check(file_path, payload, rule_id, rule):
    expressions = rule.get("params", {}).get("python_expression", [])

    if isinstance(expressions, str):
        expressions = [expressions]

    # Normalize to forward slashes so path-suffix expressions (e.g. DF_002's
    # file_path.split('/')[-1]...) behave consistently on Windows and Linux.
    normalized_file_path = os.path.normpath(file_path).replace("\\", "/")

    safe_locals = {
        **payload,

        # ✅ REQUIRED FIXES
        "payload": payload,
        "file_path": normalized_file_path,
        "file_name": os.path.basename(normalized_file_path),

        # Optional but useful if your rules expect it
        "account_type": payload.get("account_type"),

        # utilities
        "lower": lambda x: str(x).lower(),
        "len": len,
        "any": any,
        "all": all
    }

    failed = []

    for expr in expressions:
        try:
            if not eval(expr, {"__builtins__": {}}, safe_locals):
                failed.append(expr)
        except Exception as e:
            failed.append(f"{expr} -> {str(e)}")

    if failed:
        return fail(rule_id, rule, file_path, rule.get("message"),
                    {"failed_expressions": failed})

    return success(rule_id, rule, file_path)


# =========================
# HELPERS
# =========================
def get_value(payload: Dict[str, Any], path: str):
    if not path:
        return payload

    cur = payload
    for p in path.split("."):
        if not isinstance(cur, dict) or p not in cur:
            return None
        cur = cur[p]
    return cur


def success(rule_id, rule, file_path):
    return build_result(rule_id, rule.get("name"), "PASSED",
                        rule.get("severity", "ERROR"),
                        file_path, "Validation passed")


def fail(rule_id, rule, file_path, message, evidence=None):
    return build_result(rule_id, rule.get("name"), "FAILED",
                        rule.get("severity", "ERROR"),
                        file_path,
                        message or "Validation failed",
                        rule.get("recommendation"),
                        evidence)


def build_result(rule_id, name, status, severity, file_path, message, recommendation=None, evidence=None):
    return {
        "rule_id": rule_id,
        "rule_name": name,
        "status": status,
        "severity": severity,
        "file_path": file_path,
        "message": message,
        "recommendation": recommendation,
        "evidence": evidence or {}
    }


def build_summary(file_path, results):
    passed = sum(1 for r in results if r["status"] == "PASSED")
    failed = sum(1 for r in results if r["status"] == "FAILED")

    return {
        "rule_id": "SUMMARY",
        "rule_name": "file_summary",
        "status": "PASSED" if failed == 0 else "FAILED",
        "severity": "INFO",
        "file_path": file_path,
        "message": "Validation complete",
        "evidence": {
            "passed": passed,
            "failed": failed,
            "total": len(results)
        }
    }


# =========================
# ACCOUNT ID VALIDATION
# =========================
def apply_account_id_by_env_rule(
        file_path,
        payload,
        rule_id,
        rule,
        context=None):

    normalized_file_path = os.path.normpath(
        file_path
    ).replace("\\", "/")

    actual_account_id = str(
        payload.get("aws_account_id", "")
    ).strip()

    # Use actual environment from framework context
    env = str(
        (context or {}).get("env", "")
    ).strip().lower()

    account_mapping = rule.get(
        "params",
        {}
    ).get(
        "account_mapping",
        {}
    )

    matched_folder = next(
    (
        folder_name
        for folder_name in account_mapping
        if folder_name.lower() in normalized_file_path.lower()
    ),
    None)

    print("DEBUG PATH:", normalized_file_path)
    print("DEBUG FOLDERS:", list(account_mapping.keys()))
    print("DEBUG MATCHED_FOLDER:", matched_folder)

    if not matched_folder:
        return fail(
            rule_id,
            rule,
            file_path,
            "Unable to identify account folder from file path",
            {
                "file_path": normalized_file_path
            }
        )

    if env not in ["dev", "prd"]:
        return fail(
            rule_id,
            rule,
            file_path,
            "Unable to identify deployment environment from validation context",
            {
                "env": env
            }
        )

    expected_account_id = str(
        account_mapping.get(
            matched_folder,
            {}
        ).get(
            env,
            ""
        )
    )

    if not expected_account_id:
        return fail(
            rule_id,
            rule,
            file_path,
            "No account mapping found for folder/environment combination",
            {
                "folder": matched_folder,
                "env": env
            }
        )

    if actual_account_id != expected_account_id:
        return fail(
            rule_id,
            rule,
            file_path,
            rule.get("message"),
            {
                "folder": matched_folder,
                "env": env,
                "actual_account_id": actual_account_id,
                "expected_account_id": expected_account_id
            }
        )

    return success(
        rule_id,
        rule,
        file_path
    )