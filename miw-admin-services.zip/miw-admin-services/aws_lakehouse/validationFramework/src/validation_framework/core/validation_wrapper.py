import argparse
import sys, os
from collections import defaultdict
from importlib import import_module, util
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

import yaml

# Ensure src/ is in path for direct execution
PROJECT_ROOT = Path(__file__).resolve().parents[3]
WORKSPACE_ROOT = Path(__file__).resolve().parents[4]
WORKSPACE_PYTHON_ROOT = WORKSPACE_ROOT / "python"
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(WORKSPACE_ROOT) not in sys.path:
    sys.path.insert(0, str(WORKSPACE_ROOT))
if WORKSPACE_PYTHON_ROOT.exists() and str(WORKSPACE_PYTHON_ROOT) not in sys.path:
    sys.path.insert(0, str(WORKSPACE_PYTHON_ROOT))

try:
    from helpers.config_log import logger

    is_logger_available = True
except ImportError as e:
    try:
        from python.helpers.config_log import logger

        is_logger_available = True
    except ImportError as fallback_error:
        logger = None
        is_logger_available = False
        print(
            "Logger not available. Falling back to standard output for logging. "
            f"Errors: {e}; {fallback_error}"
        )

from src.validation_framework.reporting.result_reporting import (
    build_detailed_csv_rows,
    build_file_summary_rows,
    build_validation_results_text,
    format_results_by_status,
    summarize_results,
    write_csv_report,
    write_summary_table_file,
    write_txt_report,
)


RULEPACK_ROOT = PROJECT_ROOT / "metadata" / "rulepacks"


def _make_logger_safe(message: str) -> str:
    encodings: List[str] = []

    stdout_encoding = getattr(sys.stdout, "encoding", None)
    stderr_encoding = getattr(sys.stderr, "encoding", None)
    if stdout_encoding:
        encodings.append(stdout_encoding)
    if stderr_encoding:
        encodings.append(stderr_encoding)

    if logger is not None:
        for handler in getattr(logger, "handlers", []):
            stream = getattr(handler, "stream", None)
            stream_encoding = getattr(stream, "encoding", None)
            if stream_encoding:
                encodings.append(stream_encoding)

    if not encodings:
        encodings.append("utf-8")

    for encoding in encodings:
        try:
            message.encode(encoding)
        except UnicodeEncodeError:
            return message.encode(encoding, errors="replace").decode(encoding)

    return message


def log_debug(message: str) -> None:
    if is_logger_available and logger is not None:
        logger.debug(_make_logger_safe(message))
        return
    print(message)


def log_info(message: str) -> None:
    if is_logger_available and logger is not None:
        logger.info(_make_logger_safe(message))
        return
    print(message)


def log_warning(message: str) -> None:
    if is_logger_available and logger is not None:
        logger.warning(_make_logger_safe(message))
        return
    print(message)


def log_error(message: str) -> None:
    if is_logger_available and logger is not None:
        logger.error(_make_logger_safe(message))
        return
    print(message, file=sys.stderr)


def log_rendered_output(output_text: str, summary: Dict[str, int]) -> None:
    if is_logger_available and logger is not None:
        active_failure_lines: List[str] = []
        active_failure_severity: str = ""
        active_failure_file: str = ""
        current_file_context: str = ""

        def flush_active_failure() -> None:
            nonlocal active_failure_lines, active_failure_severity, active_failure_file
            if not active_failure_lines:
                return

            combined_parts: List[str] = []
            if active_failure_file:
                combined_parts.append(active_failure_file)
            combined_parts.extend(part.strip() for part in active_failure_lines if part.strip())
            combined_message = " | ".join(combined_parts)
            safe_combined_message = _make_logger_safe(combined_message)

            if active_failure_severity == "ERROR":
                logger.error(safe_combined_message)
            elif active_failure_severity == "WARNING":
                logger.warning(safe_combined_message)
            else:
                logger.info(safe_combined_message)

            active_failure_lines = []
            active_failure_severity = ""
            active_failure_file = ""

        for line in output_text.splitlines():
            safe_line = _make_logger_safe(line)
            normalized_line = line.upper()
            stripped_line = line.strip()

            if stripped_line.startswith("File:"):
                current_file_context = stripped_line

            is_failure_line = "SEVERITY:" in normalized_line and "[" in line and "]" in line
            if is_failure_line:
                flush_active_failure()
                if "SEVERITY: ERROR" in normalized_line:
                    active_failure_severity = "ERROR"
                elif "SEVERITY: WARNING" in normalized_line:
                    active_failure_severity = "WARNING"
                else:
                    active_failure_severity = ""

                active_failure_lines = [line]
                active_failure_file = current_file_context
                continue

            if active_failure_lines and (
                stripped_line.startswith("Recommendation:")
                or stripped_line.startswith("Evidence:")
            ):
                active_failure_lines.append(line)
                continue

            if active_failure_lines and not stripped_line:
                continue

            if active_failure_lines:
                flush_active_failure()

            if "SEVERITY: ERROR" in normalized_line:
                logger.error(safe_line)
            elif "SEVERITY: WARNING" in normalized_line:
                logger.warning(safe_line)
            elif "FAILED VALIDATIONS" in normalized_line:
                if summary.get("failed_errors", 0) > 0:
                    logger.error(safe_line)
                elif summary.get("failed_warnings", 0) > 0:
                    logger.warning(safe_line)
                else:
                    logger.info(safe_line)
            elif normalized_line.strip().startswith("SUMMARY:"):
                if summary.get("failed_errors", 0) > 0:
                    logger.info(safe_line)
                elif summary.get("failed_warnings", 0) > 0:
                    logger.info(safe_line)
                else:
                    logger.info(safe_line)
            else:
                logger.info(safe_line)

        if active_failure_lines:
            flush_active_failure()
        return
    print(output_text)


def parse_args(cli_args: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Validation Framework Wrapper",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--rulepack",
        "-r",
    )
    parser.add_argument(
        "--input-dir",
        "-i",
        help="Directory containing YAML/JSON files to validate",
    )
    parser.add_argument(
        "--files",
        "-f",
        nargs="+",
        default=[],
        help="One or more YAML/JSON files to validate",
    )
    parser.add_argument(
        "--env",
        "-e",
        required=True,
        help="Environment value injected into rule context (for example: dev/prd)",
    )
    parser.add_argument(
        "--resource-type",
        help="Optional file path filter (for example: database or s3)",
    )
    parser.add_argument(
        "--enable-pr-checks",
        action="store_true",
        help="Include PR metadata JSON file from environment variables for PR-specific rulepacks",
    )
    parser.add_argument(
        "--output-format",
        choices=["txt", "csv"],
        default="txt",
        help="Report output format",
    )
    parser.add_argument(
        "--output-dir",
        help="Optional output dir path for report files. Defaults to root of the project if not specified.",
    )
    parser.add_argument(
        "--store-txt",
        action="store_true",
        help="Store TXT report output",
    )
    parser.add_argument(
        "--store-csv",
        action="store_true",
        help="Store CSV report output",
    )
    parser.add_argument(
        "--txt-output-file",
        help="Optional TXT report path (used with --store-txt)",
    )
    parser.add_argument(
        "--csv-output-file",
        help="Optional CSV report path (used with --store-csv)",
    )
    parser.add_argument(
        "--store-summary-table",
        action="store_true",
        help="Store file summary table in a separate text file",
    )
    parser.add_argument(
        "--summary-file",
        help="Optional summary table file path (used with --store-summary-table)",
    )
    parser.add_argument(
        "--fail-on-warning",
        action="store_true",
        help="Return non-zero exit code when WARN failures exist",
    )
    parser.add_argument(
        "--show-passed",
        action="store_true",
        help="Print passed rule messages in detail output",
    )
    parser.add_argument(
        "--show-skipped",
        action="store_true",
        help="Print skipped rule messages in detail output",
    )
    return parser.parse_args(cli_args)


def resolve_rulepack_path(rulepack_arg: str) -> Path:
    candidate = Path(rulepack_arg)
    if candidate.exists():
        return candidate.resolve()

    if not candidate.suffix:
        with_suffix = candidate.with_suffix(".yml")
        if with_suffix.exists():
            return with_suffix.resolve()

    checks = [
        RULEPACK_ROOT / candidate,
        RULEPACK_ROOT / candidate.with_suffix(".yml"),
        RULEPACK_ROOT / candidate.with_suffix(".yaml"),
    ]
    for check in checks:
        if check.exists():
            return check.resolve()

    normalized = candidate.as_posix().replace("\\", "/")
    for match in RULEPACK_ROOT.rglob("*.yml"):
        rel = match.relative_to(RULEPACK_ROOT).as_posix()
        if rel == normalized or match.stem == candidate.stem:
            return match.resolve()
    for match in RULEPACK_ROOT.rglob("*.yaml"):
        rel = match.relative_to(RULEPACK_ROOT).as_posix()
        if rel == normalized or match.stem == candidate.stem:
            return match.resolve()

    raise FileNotFoundError(f"Rulepack not found: {rulepack_arg}")


def load_rulepack(rulepack_path: Path) -> Tuple[Dict, Dict]:
    with rulepack_path.open("r", encoding="utf-8") as handle:
        content = yaml.safe_load(handle) or {}

    rulepack = content.get("rulepack", {}) or {}
    rules = content.get("rules", {}) or {}

    if not rulepack:
        raise ValueError(f"Invalid rulepack format in {rulepack_path}: missing 'rulepack' section")
    if not rules:
        raise ValueError(f"Invalid rulepack format in {rulepack_path}: missing or empty 'rules' section")

    return rulepack, rules


def discover_rulepack_paths() -> List[Path]:
    discovered = list(RULEPACK_ROOT.rglob("*.yml")) + list(RULEPACK_ROOT.rglob("*.yaml"))
    return sorted(path.resolve() for path in discovered)


def build_rulepack_index() -> Tuple[Dict[str, Dict[str, List[str]]], Dict[str, Dict[str, Any]]]:
    index: Dict[str, Dict[str, List[str]]] = defaultdict(lambda: defaultdict(list))
    configs: Dict[str, Dict[str, Any]] = {}

    for rulepack_path in discover_rulepack_paths():
        rulepack, rules = load_rulepack(rulepack_path)

        enabled = rulepack.get("rulepack_enabled", rulepack.get("enabled", True))
        if not enabled:
            continue

        account_type = str(rulepack.get("account_type", "")).strip().lower()
        resource_type = str(rulepack.get("resource_type", "")).strip().lower()

        if not account_type or not resource_type:
            continue

        key = str(rulepack_path)
        configs[key] = {
            "path": rulepack_path,
            "rulepack": rulepack,
            "rules": rules,
        }
        index[account_type][resource_type].append(key)

    return index, configs


def extract_account_dimensions(file_path: str) -> Tuple[str, str, str]:
    parts = Path(file_path).parts
    if len(parts) < 3:
        raise ValueError(f"Unable to derive account/resource from path: {file_path}")

    resource_type = parts[-2].lower()
    account_exact = parts[-3].lower()
    account_family = account_exact.split("-")[0]

    return account_exact, account_family, resource_type


def get_matching_rulepacks_for_file(
    file_path: str,
    index: Dict[str, Dict[str, List[str]]],
) -> List[str]:
    account_exact, account_family, resource_type = extract_account_dimensions(file_path)
    matched: List[str] = []

    matched.extend(index.get(account_exact, {}).get(resource_type, []))
    matched.extend(index.get(account_family, {}).get(resource_type, []))
    matched.extend(index.get("all", {}).get(resource_type, []))

    if account_exact != "global":
        matched.extend(index.get(account_exact, {}).get("global", []))
        matched.extend(index.get(account_family, {}).get("global", []))
        matched.extend(index.get("all", {}).get("global", []))

    deduped: List[str] = []
    seen: Set[str] = set()
    for item in matched:
        if item in seen:
            continue
        deduped.append(item)
        seen.add(item)

    return deduped


def build_rulepack_file_map(
    file_paths: List[str],
    index: Dict[str, Dict[str, List[str]]],
) -> Tuple[Dict[str, List[str]], List[str]]:
    file_map: Dict[str, List[str]] = defaultdict(list)
    unmatched_files: List[str] = []

    for file_path in file_paths:
        matches = get_matching_rulepacks_for_file(file_path, index)
        if not matches:
            unmatched_files.append(file_path)
            continue
        for rulepack_key in matches:
            file_map[rulepack_key].append(file_path)

    for rulepack_key in list(file_map.keys()):
        file_map[rulepack_key] = sorted(set(file_map[rulepack_key]))

    return dict(file_map), sorted(unmatched_files)


def build_file_path_context(file_paths: List[str]) -> Dict[str, Dict[str, str]]:
    file_resource_types: Dict[str, str] = {}
    file_account_types: Dict[str, str] = {}

    for file_path in file_paths:
        try:
            account_exact, _account_family, resource_type = extract_account_dimensions(file_path)
        except ValueError:
            file_resource_types[file_path] = "unknown"
            file_account_types[file_path] = "unknown"
            continue
        file_resource_types[file_path] = resource_type
        file_account_types[file_path] = account_exact

    return {
        "file_resource_types": file_resource_types,
        "file_account_types": file_account_types,
    }


def collect_input_files(
    input_dir: str,
    files: Iterable[str],
    resource_type: str,
) -> List[str]:
    collected: List[Path] = []

    if input_dir:
        base = Path(input_dir)
        if not base.exists() or not base.is_dir():
            raise FileNotFoundError(f"Input directory not found: {input_dir}")
        collected.extend(path for path in base.rglob("*") if path.is_file())

    for file_arg in files:
        file_path = Path(file_arg)
        if not file_path.exists() or not file_path.is_file():
            raise FileNotFoundError(f"Input file not found: {file_arg}")
        collected.append(file_path)

    if not collected:
        raise ValueError("No input files were provided. Use --input-dir and/or --files.")

    collected = [p.resolve() for p in collected if p.suffix.lower() in {".yaml", ".yml", ".json"}]
    log_debug(f"Collected {len(collected)} YAML/JSON files from inputs before filtering by resource type.")
    if resource_type and resource_type.lower() != "global":
        filter_token = resource_type.lower()
        collected = [path for path in collected if filter_token in str(path).lower()]

    deduped = sorted({str(path) for path in collected})
    if not deduped:
        raise ValueError("No YAML/JSON files matched the provided inputs and filters.")

    return deduped


def load_validator_module(python_reference_file: str):
    if not python_reference_file:
        raise ValueError("No python_file_reference found in the rulepack")

    module_name = python_reference_file.replace(".py", "").replace("/", ".").replace("\\", ".")

    try:
        return import_module(module_name)
    except ModuleNotFoundError:
        pass

    path_candidate = Path(python_reference_file)
    if not path_candidate.is_absolute():
        path_candidate = PROJECT_ROOT / path_candidate

    if not path_candidate.exists():
        fallback = PROJECT_ROOT / "src" / "validation_framework" / "validators" / path_candidate.name
        if fallback.exists():
            path_candidate = fallback

    if not path_candidate.exists():
        raise FileNotFoundError(
            f"Validator module not found from python_file_reference: {python_reference_file}"
        )

    spec = util.spec_from_file_location(path_candidate.stem, path_candidate)
    if spec is None or spec.loader is None:
        raise ImportError(f"Unable to load validator module from {path_candidate}")

    validator_module = util.module_from_spec(spec)
    spec.loader.exec_module(validator_module)
    return validator_module


def resolve_output_path(
    output_format: str,
    output_file: str = None,
    output_dir: str = None,
) -> Path:
    if output_file:
        return Path(output_file).resolve()
    if output_dir:
        resolved_output_dir = Path(output_dir).resolve()
        resolved_output_dir.mkdir(parents=True, exist_ok=True)
        if output_format == "csv":
            return resolved_output_dir / "validation_results.csv"
        return resolved_output_dir / "validation_results.txt"
    if output_format == "csv":
        return PROJECT_ROOT / "validation_results.csv"
    return PROJECT_ROOT / "validation_results.txt"


def resolve_summary_path(summary_file: str = None, output_dir: str = None) -> Path:
    if summary_file:
        return Path(summary_file).resolve()
    if output_dir:
        resolved_output_dir = Path(output_dir).resolve()
        resolved_output_dir.mkdir(parents=True, exist_ok=True)
        return resolved_output_dir / "validation_summary_table.txt"
    return PROJECT_ROOT / "validation_summary_table.txt"


def enrich_results(
    batch_results: List[Dict[str, Any]],
    rulepack_name: str,
    rulepack_resource_type: str,
    file_resource_types: Dict[str, str],
    file_account_types: Dict[str, str] = None,
) -> List[Dict[str, Any]]:
    enriched: List[Dict[str, Any]] = []
    normalized_rulepack_name = rulepack_name or "unknown_rulepack"
    normalized_rulepack_resource = (rulepack_resource_type or "unknown").lower()

    for item in batch_results:
        updated = dict(item)
        file_path = str(updated.get("file_path", ""))
        file_resource = file_resource_types.get(file_path, normalized_rulepack_resource)
        updated["rulepack_name"] = normalized_rulepack_name
        updated["resource_type"] = file_resource
        if file_account_types is not None:
            updated["account_name"] = file_account_types.get(file_path, "")
        enriched.append(updated)

    return enriched


def run(cli_args: Optional[List[str]] = None) -> int:
    args = parse_args(cli_args)

    files_to_validate = collect_input_files(args.input_dir, args.files, args.resource_type)
    # Adding dummy file to enable pr descripiton check and pr label check for the validation framework
    if args.enable_pr_checks:
        input_dir = os.getenv("lakehouse_output_dir")
        pr_number = os.getenv("PR_NUMBER")
        if input_dir and pr_number:
            pr_description_file = Path(input_dir) / "global" / "pr" / f"{pr_number}.json"
            files_to_validate.append(str(pr_description_file.resolve()))
            log_debug(f"PR metadata file added for validation: {pr_description_file.resolve()}, files_to_validate: {files_to_validate}")

    path_context = build_file_path_context(files_to_validate)
    context = {
        "env": args.env,
        "file_resource_types": path_context["file_resource_types"],
        "file_account_types": path_context["file_account_types"],
    }

    results: List[Dict[str, Any]] = []

    if args.rulepack:
        rulepack_path = resolve_rulepack_path(args.rulepack)
        rulepack, rules = load_rulepack(rulepack_path)

        validator_module = load_validator_module(rulepack.get("python_file_reference"))

        if not hasattr(validator_module, "validate"):
            raise AttributeError(
                f"Validator module '{validator_module.__name__}' does not define a validate() function"
            )

        batch_results = validator_module.validate(files_to_validate, rules=rules, context=context)
        if not isinstance(batch_results, list):
            raise TypeError("Validator validate() must return a list of result dictionaries")
        results = enrich_results(
            batch_results,
            str(rulepack.get("id", rulepack_path.stem)),
            str(rulepack.get("resource_type", "unknown")),
            context["file_resource_types"],
            context["file_account_types"],
        )
    else:
        rulepack_index, rulepack_configs = build_rulepack_index()
        rulepack_file_map, unmatched_files = build_rulepack_file_map(files_to_validate, rulepack_index)

        if unmatched_files:
            log_warning(
                "Warning: No rulepack mapping found for "
                f"{len(unmatched_files)} files based on path-derived account/resource."
            )
            for file_path in unmatched_files:
                log_warning(f"  Skipped: {file_path}")

        if not rulepack_file_map:
            raise ValueError(
                "No matching rulepacks found for input files. "
                "Ensure rulepacks have account_type/resource_type and input paths follow .../<account>-<id>/<resource>/<file>."
            )

        log_info(f"Auto-selected {len(rulepack_file_map)} rulepack(s) from metadata index.")
        for rulepack_key in sorted(rulepack_file_map.keys()):
            config = rulepack_configs.get(rulepack_key)
            if not config:
                continue

            assigned_files = rulepack_file_map[rulepack_key]
            rulepack = config["rulepack"]
            rules = config["rules"]

            log_info(
                f"Running rulepack '{rulepack.get('id', Path(rulepack_key).name)}' "
                f"for {len(assigned_files)} file(s)."
            )

            validator_module = load_validator_module(rulepack.get("python_file_reference"))
            if not hasattr(validator_module, "validate"):
                raise AttributeError(
                    f"Validator module '{validator_module.__name__}' does not define a validate() function"
                )

            batch_results = validator_module.validate(assigned_files, rules=rules, context=context)
            if not isinstance(batch_results, list):
                raise TypeError(
                    f"Validator validate() must return a list of result dictionaries for rulepack {rulepack.get('id')}"
                )
            enriched_batch_results = enrich_results(
                batch_results,
                str(rulepack.get("id", Path(rulepack_key).stem)),
                str(rulepack.get("resource_type", "unknown")),
                context["file_resource_types"],
                context["file_account_types"],
            )
            results.extend(enriched_batch_results)

    grouped = format_results_by_status(results)
    summary = summarize_results(results)
    file_rows = build_file_summary_rows(results)
    detailed_csv_rows = build_detailed_csv_rows(results)

    should_store_txt = args.store_txt
    should_store_csv = args.store_csv

    if not should_store_txt and not should_store_csv:
        should_store_txt = args.output_format == "txt"
        should_store_csv = args.output_format == "csv"

    txt_output_path = (
        Path(args.txt_output_file).resolve()
        if args.txt_output_file
        else resolve_output_path("txt", output_dir=args.output_dir)
    )
    csv_output_path = (
        Path(args.csv_output_file).resolve()
        if args.csv_output_file
        else resolve_output_path("csv", output_dir=args.output_dir)
    )

    if should_store_txt:
        write_txt_report(txt_output_path, grouped, summary, file_rows, args.show_passed, args.show_skipped)
        log_info(f"Saved TXT report to: {txt_output_path}")

    if should_store_csv:
        write_csv_report(csv_output_path, detailed_csv_rows)
        log_info(f"Saved CSV report to: {csv_output_path}")

    if args.store_summary_table:
        summary_path = resolve_summary_path(args.summary_file, args.output_dir)
        write_summary_table_file(summary_path, file_rows, summary, args.show_skipped)
        log_info(f"Saved summary table to: {summary_path}")
    rendered_output = build_validation_results_text(grouped, summary, file_rows, args.show_passed, args.show_skipped)
    log_rendered_output(rendered_output, summary)

    if summary["failed_errors"] > 0:
        return 1
    if args.fail_on_warning and summary["failed_warnings"] > 0:
        return 1
    return 0


def main(cli_args: Optional[List[str]] = None, exit_process: bool = True) -> int:
    try:
        exit_code = run(cli_args)
    except (FileNotFoundError, ValueError, ImportError, AttributeError, TypeError) as known_error:
        log_error(f"ERROR: {known_error}")
        if exit_process:
            raise SystemExit(2) from known_error
        return 2
    except Exception as unexpected_error:
        log_error(f"UNEXPECTED ERROR: {unexpected_error}")
        if exit_process:
            raise SystemExit(3) from unexpected_error
        return 3

    if exit_process:
        raise SystemExit(exit_code)
    return exit_code


if __name__ == "__main__":
    main()
