import unittest
from unittest.mock import patch, mock_open
import os
import sys
import importlib

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(BASE_DIR, "src"))

# ✅ Update module path if needed
MODULE_NAME = "validation_framework.validators.object_scope_s3"
validator = importlib.import_module(MODULE_NAME)


class TestObjectScopeS3(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.file_path = "test.yaml"

        cls.sample_payload = {
            "bucket_name": "my-bucket",
            "env": "dev",
            "region": "ap-south-1"
        }

        cls.rules = {
            "S3_001": {
                "name": "validate_env",
                "enabled": True,
                "severity": "ERROR",
                "type": "multi_field_condition",
                "params": {
                    "match_logic": "AND",
                    "conditions": [
                        {"field": "env", "operator": "equals", "value": "dev"},
                        {"field": "region", "operator": "starts_with", "value": "ap"}
                    ]
                },
                "message": "Valid S3 config"
            },
            "S3_002": {
                "name": "validate_bucket",
                "enabled": True,
                "severity": "ERROR",
                "type": "multi_field_condition",
                "params": {
                    "match_logic": "OR",
                    "conditions": [
                        {"field": "bucket_name", "operator": "contains", "value": "prod"},
                        {"field": "env", "operator": "equals", "value": "prod"}
                    ]
                },
                "message": "Prod bucket validation"
            }
        }

    # ============================================================
    # RESULT BUILDERS
    # ============================================================

    def test_build_result(self):
        res = validator.build_result("R1", "rule", "PASSED", "ERROR", "file", "msg")
        self.assertEqual(res["status"], "PASSED")
        self.assertEqual(res["rule_id"], "R1")

    def test_build_summary(self):
        res = validator.build_file_summary_result(
            "file.yaml", "PASSED", "msg", 1, 0, 0, 1, {"env": "dev"}
        )
        self.assertEqual(res["status"], "PASSED")
        self.assertEqual(res["evidence"]["env"], "dev")

    # ============================================================
    # FILE LOADER
    # ============================================================

    @patch("builtins.open", new_callable=mock_open, read_data='{"env":"dev"}')
    def test_load_json(self, mock_file):
        res = validator.load_yaml_or_json("file.json")
        self.assertEqual(res, {"env": "dev"})

    @patch("builtins.open", new_callable=mock_open, read_data="env: dev")
    def test_load_yaml(self, mock_file):
        res = validator.load_yaml_or_json("file.yaml")
        self.assertEqual(res, {"env": "dev"})

    @patch("builtins.open", side_effect=Exception("error"))
    def test_load_fail(self, mock_file):
        res = validator.load_yaml_or_json("file.yaml")
        self.assertIsNone(res)

    # ============================================================
    # MULTI FIELD CONDITION
    # ============================================================

    def test_multi_field_condition_and_pass(self):
        rule = self.rules["S3_001"]

        res = validator._multi_field_condition(
            "S3_001", rule, self.sample_payload, self.file_path
        )
        self.assertEqual(res["status"], "PASSED")

    def test_multi_field_condition_and_skip(self):
        payload = {
            "env": "prod",
            "region": "us-east-1"
        }

        rule = self.rules["S3_001"]

        res = validator._multi_field_condition(
            "S3_001", rule, payload, self.file_path
        )
        self.assertEqual(res["status"], "SKIPPED")

    def test_multi_field_condition_or_pass(self):
        rule = self.rules["S3_002"]

        res = validator._multi_field_condition(
            "S3_002", rule, self.sample_payload, self.file_path
        )
        self.assertEqual(res["status"], "SKIPPED")  # no prod match

        payload = {
            "bucket_name": "prod-bucket"
        }

        res = validator._multi_field_condition(
            "S3_002", rule, payload, self.file_path
        )
        self.assertEqual(res["status"], "PASSED")

    def test_multi_field_condition_unknown_operator(self):
        rule = {
            "name": "bad_rule",
            "severity": "ERROR",
            "params": {
                "conditions": [
                    {"field": "env", "operator": "invalid_op", "value": "dev"}
                ]
            }
        }

        res = validator._multi_field_condition(
            "S3_003", rule, self.sample_payload, self.file_path
        )
        self.assertEqual(res["status"], "SKIPPED")

    # ============================================================
    # VALIDATE FUNCTION
    # ============================================================

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_success(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        results = validator.validate(["file.yaml"], self.rules)

        statuses = [r["status"] for r in results]
        self.assertIn("PASSED", statuses)

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_all_skipped_becomes_failed(self, mock_loader):
        payload = {
            "env": "test",
            "region": "us-east-1"
        }
        mock_loader.return_value = payload

        results = validator.validate(["file.yaml"], self.rules)

        # all should become FAILED because no rule passed
        non_summary = [r for r in results if r["rule_id"] != "FILE_SUMMARY"]

        for r in non_summary:
            self.assertEqual(r["status"], "FAILED")
            self.assertEqual(r["message"], "No matching rule found")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_file_error(self, mock_loader):
        mock_loader.return_value = None

        res = validator.validate(["file.yaml"], self.rules)
        self.assertEqual(res[0]["rule_id"], "FILE_LOAD_ERROR")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_summary_pass(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        results = validator.validate(["file.yaml"], self.rules)

        summary = [r for r in results if r["rule_id"] == "FILE_SUMMARY"][0]
        self.assertEqual(summary["status"], "PASSED")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_summary_fail(self, mock_loader):
        payload = {
            "env": "unknown"
        }
        mock_loader.return_value = payload

        results = validator.validate(["file.yaml"], self.rules)

        summary = [r for r in results if r["rule_id"] == "FILE_SUMMARY"][0]
        self.assertEqual(summary["status"], "FAILED")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_unsupported_rule(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        rules = {
            "BAD": {
                "name": "bad_rule",
                "type": "unknown",
                "severity": "ERROR"
            }
        }

        results = validator.validate(["file.yaml"], rules)

        self.assertEqual(results[0]["status"], "FAILED")
        self.assertIn("Unsupported", results[0]["message"])


if __name__ == "__main__":
    unittest.main()