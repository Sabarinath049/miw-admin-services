import unittest
from unittest.mock import patch, mock_open
import os
import sys
import importlib

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(BASE_DIR, "src"))

# ✅ Update this to your actual validator module path
MODULE_NAME = "validation_framework.validators.object_scope_db"
validator = importlib.import_module(MODULE_NAME)


class TestObjectScopeValidator(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.file_path = "test.yaml"

        cls.sample_payload = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "db_name": "438465132548:minerva_dev_dp_agtr_cdp_apac_ekaaus_dev_fdp_db_rl",
            "environment": "dev",
            "access_type": "rl"
        }

        cls.rules = {
            "RULE_001": {
                "name": "allow_proc_roles",
                "enabled": True,
                "severity": "ERROR",
                "type": "pattern_allowed",
                "target_field": "role_name",
                "params": {
                    "include_patterns": ["_procdataengineer"],
                    "exclude_patterns": ["_ignore"]
                },
                "message": "Allowed role"
            },
            "RULE_002": {
                "name": "block_ingestion_roles",
                "enabled": True,
                "severity": "ERROR",
                "type": "pattern_not_allowed",
                "target_field": "role_name",
                "params": {
                    "include_patterns": ["_procingestionengineer"],
                    "exclude_patterns": ["_approved_exception"]
                },
                "message": "Restricted role",
                "recommendation": "Use approved role"
            },
            "RULE_003": {
                "name": "multi_condition_rule",
                "enabled": True,
                "severity": "ERROR",
                "type": "multi_field_condition",
                "params": {
                    "match_logic": "AND",
                    "conditions": [
                        {"field": "environment", "operator": "equals", "value": "dev"},
                        {"field": "access_type", "operator": "equals", "value": "rl"}
                    ]
                }
            },
            "RULE_004": {
                "name": "rl_db_rule",
                "enabled": True,
                "severity": "ERROR",
                "type": "list_conditional_pattern",
                "target_field": "db_name",
                "params": {
                    "restricted_patterns": ["_fdp_", "_raw_"],
                    "allow_if_all": {
                        "contains": ["_rl"],
                        "starts_with": "${account_id}"
                    }
                },
                "message": "Invalid restricted db access",
                "recommendation": "Use valid RL DB"
            }
        }

    # ============================================================
    # RESULT BUILDER TESTS
    # ============================================================

    def test_build_result(self):
        result = validator.build_result(
            "R1", "test_rule", "PASSED", "ERROR", "file.yaml", "ok"
        )
        self.assertEqual(result["rule_id"], "R1")
        self.assertEqual(result["status"], "PASSED")
        self.assertEqual(result["file_path"], "file.yaml")

    def test_build_file_summary_result(self):
        result = validator.build_file_summary_result(
            "file.yaml", "PASSED", "done", 1, 0, 0, 1, {"env": "dev"}
        )
        self.assertEqual(result["rule_id"], "FILE_SUMMARY")
        self.assertEqual(result["status"], "PASSED")
        self.assertEqual(result["evidence"]["env"], "dev")

    # ============================================================
    # FILE LOADER TESTS
    # ============================================================

    @patch("builtins.open", new_callable=mock_open, read_data='{"role_name": "abc"}')
    def test_load_yaml_or_json_json_success(self, mock_file):
        result = validator.load_yaml_or_json("dummy.json")
        self.assertEqual(result, {"role_name": "abc"})

    @patch("builtins.open", new_callable=mock_open, read_data="role_name: abc")
    def test_load_yaml_or_json_yaml_success(self, mock_file):
        result = validator.load_yaml_or_json("dummy.yaml")
        self.assertEqual(result, {"role_name": "abc"})

    @patch("builtins.open", side_effect=Exception("read error"))
    def test_load_yaml_or_json_failure(self, mock_file):
        result = validator.load_yaml_or_json("dummy.yaml")
        self.assertIsNone(result)

    # ============================================================
    # PATTERN ALLOWED TESTS
    # ============================================================

    def test_pattern_allowed_pass(self):
        rule = {
            "name": "allow_proc_roles",
            "severity": "ERROR",
            "target_field": "role_name",
            "params": {
                "include_patterns": ["_procdataengineer"],
                "exclude_patterns": []
            }
        }
        resource = {"role_name": "agtr_apac_dev_procdataengineer"}

        result = validator._pattern_allowed("R1", rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_pattern_allowed_skipped_if_not_applicable(self):
        rule = {
            "name": "allow_proc_roles",
            "severity": "ERROR",
            "target_field": "role_name",
            "params": {
                "include_patterns": ["_procdataengineer"],
                "exclude_patterns": []
            }
        }
        resource = {"role_name": "some_other_role"}

        result = validator._pattern_allowed("R1", rule, resource, self.file_path)
        self.assertEqual(result["status"], "SKIPPED")

    def test_pattern_allowed_skipped_if_excluded(self):
        rule = {
            "name": "allow_proc_roles",
            "severity": "ERROR",
            "target_field": "role_name",
            "params": {
                "include_patterns": ["_procdataengineer"],
                "exclude_patterns": ["_ignore"]
            }
        }
        resource = {"role_name": "agtr_apac_dev_ignore"}

        result = validator._pattern_allowed("R1", rule, resource, self.file_path)
        self.assertEqual(result["status"], "SKIPPED")

    # ============================================================
    # PATTERN NOT ALLOWED TESTS
    # ============================================================

    def test_pattern_not_allowed_fail(self):
        rule = {
            "name": "block_ingestion_roles",
            "severity": "ERROR",
            "target_field": "role_name",
            "params": {
                "include_patterns": ["_procingestionengineer"],
                "exclude_patterns": []
            },
            "message": "Restricted role",
            "recommendation": "Use approved role"
        }
        resource = {"role_name": "agtr_apac_dev_procingestionengineer"}

        result = validator._pattern_not_allowed("R2", rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")

    def test_pattern_not_allowed_pass(self):
        rule = {
            "name": "block_ingestion_roles",
            "severity": "ERROR",
            "target_field": "role_name",
            "params": {
                "include_patterns": ["_procingestionengineer"],
                "exclude_patterns": []
            },
            "message": "Restricted role"
        }
        resource = {"role_name": "agtr_apac_dev_procdataengineer"}

        result = validator._pattern_not_allowed("R2", rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_pattern_not_allowed_pass_if_excluded(self):
        rule = {
            "name": "block_ingestion_roles",
            "severity": "ERROR",
            "target_field": "role_name",
            "params": {
                "include_patterns": ["_procingestionengineer"],
                "exclude_patterns": ["_approved_exception"]
            },
            "message": "Restricted role"
        }
        resource = {"role_name": "agtr_apac_dev_approved_exception_procingestionengineer"}

        result = validator._pattern_not_allowed("R2", rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    # ============================================================
    # MULTI FIELD CONDITION TESTS
    # ============================================================

    def test_multi_field_condition_pass(self):
        rule = {
            "name": "multi_condition_rule",
            "severity": "ERROR",
            "params": {
                "match_logic": "AND",
                "conditions": [
                    {"field": "environment", "operator": "equals", "value": "dev"},
                    {"field": "access_type", "operator": "equals", "value": "rl"}
                ]
            }
        }
        resource = {"environment": "dev", "access_type": "rl"}

        result = validator._multi_field_condition("R3", rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_multi_field_condition_skipped(self):
        rule = {
            "name": "multi_condition_rule",
            "severity": "ERROR",
            "params": {
                "match_logic": "AND",
                "conditions": [
                    {"field": "environment", "operator": "equals", "value": "dev"},
                    {"field": "access_type", "operator": "equals", "value": "rl"}
                ]
            }
        }
        resource = {"environment": "prod", "access_type": "rl"}

        result = validator._multi_field_condition("R3", rule, resource, self.file_path)
        self.assertEqual(result["status"], "SKIPPED")

    def test_multi_field_condition_or_logic_pass(self):
        rule = {
            "name": "multi_condition_rule",
            "severity": "ERROR",
            "params": {
                "match_logic": "OR",
                "conditions": [
                    {"field": "environment", "operator": "equals", "value": "dev"},
                    {"field": "access_type", "operator": "equals", "value": "read"}
                ]
            }
        }
        resource = {"environment": "dev", "access_type": "write"}

        result = validator._multi_field_condition("R3", rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    # ============================================================
    # LIST CONDITIONAL PATTERN TESTS
    # ============================================================

    def test_list_conditional_pattern_skipped_if_not_restricted(self):
        rule = {
            "name": "rl_db_rule",
            "severity": "ERROR",
            "target_field": "db_name",
            "params": {
                "restricted_patterns": ["_fdp_", "_raw_"],
                "allow_if_all": {
                    "contains": ["_rl"],
                    "starts_with": "${account_id}"
                }
            },
            "message": "Invalid restricted db access"
        }
        resource = {"db_name": "normal_curated_db"}

        result = validator._list_conditional_pattern(
            "R4", rule, resource, self.file_path, {"account_id": "438465132548"}
        )
        self.assertEqual(result["status"], "SKIPPED")

    def test_list_conditional_pattern_pass(self):
        rule = {
            "name": "rl_db_rule",
            "severity": "ERROR",
            "target_field": "db_name",
            "params": {
                "restricted_patterns": ["_fdp_", "_raw_"],
                "allow_if_all": {
                    "contains": ["_rl"],
                    "starts_with": "${account_id}"
                }
            },
            "message": "Invalid restricted db access"
        }
        resource = {
            "db_name": "438465132548:minerva_dev_dp_agtr_cdp_apac_ekaaus_dev_fdp_db_rl"
        }

        result = validator._list_conditional_pattern(
            "R4", rule, resource, self.file_path, {"account_id": "438465132548"}
        )
        self.assertEqual(result["status"], "PASSED")

    def test_list_conditional_pattern_skipped_if_invalid_rl(self):
        rule = {
            "name": "rl_db_rule",
            "severity": "ERROR",
            "target_field": "db_name",
            "params": {
                "restricted_patterns": ["_fdp_", "_raw_"],
                "allow_if_all": {
                    "contains": ["_rl"],
                    "starts_with": "${account_id}"
                }
            },
            "message": "Invalid restricted db access"
        }
        resource = {
            "db_name": "999999999999:minerva_dev_dp_agtr_cdp_apac_ekaaus_dev_fdp_db_rl"
        }

        result = validator._list_conditional_pattern(
            "R4", rule, resource, self.file_path, {"account_id": "438465132548"}
        )
        self.assertEqual(result["status"], "SKIPPED")

    # ============================================================
    # VALIDATE TESTS
    # ============================================================

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_success(self, mock_loader):
        mock_loader.return_value = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "environment": "dev",
            "access_type": "rl",
            "db_name": "438465132548:minerva_dev_dp_agtr_cdp_apac_ekaaus_dev_fdp_db_rl"
        }

        results = validator.validate(
            ["file.yaml"],
            self.rules,
            context={"account_id": "438465132548", "env": "dev"}
        )

        self.assertTrue(len(results) > 0)
        statuses = [r["status"] for r in results]
        self.assertIn("PASSED", statuses)

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_file_load_error(self, mock_loader):
        mock_loader.return_value = None

        results = validator.validate(["bad.yaml"], self.rules)

        self.assertEqual(results[0]["rule_id"], "FILE_LOAD_ERROR")
        self.assertEqual(results[0]["status"], "FAILED")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_unsupported_rule_type(self, mock_loader):
        mock_loader.return_value = {"role_name": "abc"}

        rules = {
            "BAD_RULE": {
                "name": "bad_rule",
                "enabled": True,
                "severity": "ERROR",
                "type": "unknown_type"
            }
        }

        results = validator.validate(["file.yaml"], rules)
        non_summary = [r for r in results if r["rule_id"] != "FILE_SUMMARY"]

        self.assertEqual(non_summary[0]["status"], "FAILED")
        self.assertIn("Unsupported rule type", non_summary[0]["message"])

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_summary_present(self, mock_loader):
        mock_loader.return_value = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "environment": "dev",
            "access_type": "rl",
            "db_name": "438465132548:minerva_dev_dp_agtr_cdp_apac_ekaaus_dev_fdp_db_rl"
        }

        results = validator.validate(
            ["file.yaml"],
            self.rules,
            context={"account_id": "438465132548", "env": "dev"}
        )

        summary = [r for r in results if r["rule_id"] == "FILE_SUMMARY"]
        self.assertEqual(len(summary), 1)
        self.assertIn(summary[0]["status"], ["PASSED", "FAILED", "SKIPPED"])


if __name__ == "__main__":
    unittest.main()
