import unittest
from unittest.mock import patch, mock_open
import os
import sys
import importlib

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(BASE_DIR, "src"))

# ✅ UPDATE THIS PATH
MODULE_NAME = "validation_framework.validators.object_scope_df"
validator = importlib.import_module(MODULE_NAME)


class TestConditionalValidator(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.file_path = "test.yaml"

        cls.sample_payload = {
            "env": "lakehouse",
            "glue_databases": [
                "curated_db",
                "serving_db",
                "invalid_db"
            ],
            "mandatory_field": "value"
        }

        cls.rules = {
            "RULE_001": {
                "name": "allowed_layers",
                "type": "conditional_list_pattern",
                "severity": "ERROR",
                "target_field": "glue_databases",
                "params": {
                    "condition": {
                        "field": "env",
                        "operator": "equals",
                        "value": "lakehouse"
                    },
                    "allowed_patterns": ["curated", "serving"]
                },
                "message": "Invalid layer",
                "recommendation": "Use valid DB"
            },
            "RULE_002": {
                "name": "block_invalid_layers",
                "type": "conditional_list_pattern_not_allowed",
                "severity": "ERROR",
                "target_field": "glue_databases",
                "params": {
                    "condition": {
                        "field": "env",
                        "operator": "equals",
                        "value": "lakehouse"
                    },
                    "disallowed_patterns": ["invalid"],
                    "exclude_patterns": ["ignore"]
                },
                "message": "Invalid DB",
                "recommendation": "Remove restricted DB"
            },
            "RULE_003": {
                "name": "required_field_check",
                "type": "conditional_field_required",
                "severity": "ERROR",
                "params": {
                    "condition": {
                        "field": "env",
                        "operator": "equals",
                        "value": "lakehouse"
                    },
                    "required_field": "mandatory_field"
                },
                "message": "Field required"
            }
        }

    # ============================================================
    # RESULT BUILDERS
    # ============================================================

    def test_build_result(self):
        result = validator.build_result(
            "R1", "rule", "PASSED", "ERROR", "file.yaml", "msg"
        )
        self.assertEqual(result["status"], "PASSED")
        self.assertEqual(result["rule_id"], "R1")

    def test_file_summary(self):
        res = validator.build_file_summary_result(
            "file", "PASSED", "msg", 1, 0, 0, 1, {"env": "lakehouse"}
        )
        self.assertEqual(res["status"], "PASSED")
        self.assertEqual(res["evidence"]["env"], "lakehouse")

    # ============================================================
    # FILE LOADER
    # ============================================================

    @patch("builtins.open", new_callable=mock_open, read_data='{"a":1}')
    def test_load_json(self, mock_file):
        res = validator.load_yaml_or_json("file.json")
        self.assertEqual(res, {"a": 1})

    @patch("builtins.open", new_callable=mock_open, read_data="a: 1")
    def test_load_yaml(self, mock_file):
        res = validator.load_yaml_or_json("file.yaml")
        self.assertEqual(res, {"a": 1})

    @patch("builtins.open", side_effect=Exception("err"))
    def test_load_fail(self, mock_file):
        res = validator.load_yaml_or_json("file.yaml")
        self.assertIsNone(res)

    # ============================================================
    # CONDITION EVALUATOR
    # ============================================================

    def test_evaluate_condition_true(self):
        cond = {"field": "env", "operator": "equals", "value": "lakehouse"}
        res = validator._evaluate_condition(cond, self.sample_payload)
        self.assertTrue(res)

    def test_evaluate_condition_false(self):
        cond = {"field": "env", "operator": "equals", "value": "compute"}
        res = validator._evaluate_condition(cond, self.sample_payload)
        self.assertFalse(res)

    # ============================================================
    # CONDITIONAL LIST PATTERN
    # ============================================================

    def test_conditional_list_pattern_pass(self):
        payload = {
            "env": "lakehouse",
            "glue_databases": ["curated_db", "serving_db"]
        }

        rule = self.rules["RULE_001"]

        res = validator._conditional_list_pattern(
            "R1", rule, payload, self.file_path
        )
        self.assertEqual(res["status"], "PASSED")

    def test_conditional_list_pattern_fail(self):
        rule = self.rules["RULE_001"]

        res = validator._conditional_list_pattern(
            "R1", rule, self.sample_payload, self.file_path
        )
        self.assertEqual(res["status"], "FAILED")

    def test_conditional_list_pattern_skip(self):
        payload = {"env": "compute"}

        rule = self.rules["RULE_001"]

        res = validator._conditional_list_pattern(
            "R1", rule, payload, self.file_path
        )
        self.assertEqual(res["status"], "SKIPPED")

    # ============================================================
    # CONDITIONAL LIST NOT ALLOWED
    # ============================================================

    def test_list_pattern_not_allowed_fail(self):
        rule = self.rules["RULE_002"]

        res = validator._conditional_list_pattern_not_allowed(
            "R2", rule, self.sample_payload, self.file_path
        )
        self.assertEqual(res["status"], "FAILED")

    def test_list_pattern_not_allowed_pass(self):
        payload = {
            "env": "lakehouse",
            "glue_databases": ["curated_db"]
        }

        rule = self.rules["RULE_002"]

        res = validator._conditional_list_pattern_not_allowed(
            "R2", rule, payload, self.file_path
        )
        self.assertEqual(res["status"], "PASSED")

    def test_list_pattern_not_allowed_skip(self):
        payload = {"env": "compute"}

        rule = self.rules["RULE_002"]

        res = validator._conditional_list_pattern_not_allowed(
            "R2", rule, payload, self.file_path
        )
        self.assertEqual(res["status"], "SKIPPED")

    # ============================================================
    # CONDITIONAL REQUIRED FIELD
    # ============================================================

    def test_required_field_pass(self):
        rule = self.rules["RULE_003"]

        res = validator._conditional_field_required(
            "R3", rule, self.sample_payload, self.file_path
        )
        self.assertEqual(res["status"], "PASSED")

    def test_required_field_fail(self):
        payload = {"env": "lakehouse"}

        rule = self.rules["RULE_003"]

        res = validator._conditional_field_required(
            "R3", rule, payload, self.file_path
        )
        self.assertEqual(res["status"], "FAILED")

    def test_required_field_skip(self):
        payload = {"env": "compute"}

        rule = self.rules["RULE_003"]

        res = validator._conditional_field_required(
            "R3", rule, payload, self.file_path
        )
        self.assertEqual(res["status"], "SKIPPED")

    # ============================================================
    # SKIP FUNCTION
    # ============================================================

    def test_skip_function(self):
        rule = {"name": "test", "severity": "ERROR"}

        res = validator._skip("R1", rule, self.file_path)
        self.assertEqual(res["status"], "SKIPPED")

    # ============================================================
    # VALIDATE FUNCTION
    # ============================================================

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_success(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        results = validator.validate(
            ["file.yaml"], self.rules, context={"env": "lakehouse"}
        )

        self.assertTrue(len(results) > 0)
        statuses = [r["status"] for r in results]
        self.assertIn("PASSED", statuses)

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_file_error(self, mock_loader):
        mock_loader.return_value = None

        res = validator.validate(["file.yaml"], self.rules)
        self.assertEqual(res[0]["rule_id"], "FILE_LOAD_ERROR")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_unsupported_rule(self, mock_loader):
        mock_loader.return_value = {"env": "lakehouse"}

        rules = {
            "BAD": {
                "type": "unknown",
                "severity": "ERROR"
            }
        }

        res = validator.validate(["file.yaml"], rules)
        self.assertEqual(res[0]["status"], "FAILED")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_summary(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        results = validator.validate(
            ["file.yaml"], self.rules, context={"env": "lakehouse"}
        )

        summary = [r for r in results if r["rule_id"] == "FILE_SUMMARY"]
        self.assertEqual(len(summary), 1)


if __name__ == "__main__":
    unittest.main()