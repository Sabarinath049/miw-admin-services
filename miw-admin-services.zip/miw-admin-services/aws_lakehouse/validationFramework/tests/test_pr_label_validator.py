import unittest
from unittest.mock import patch, MagicMock
import importlib
import os
import sys

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(BASE_DIR, "src"))

MODULE_NAME = "validation_framework.validators.global.pr_label_validator"
validator = importlib.import_module(MODULE_NAME)


class TestPRLabelValidator(unittest.TestCase):

    # =====================================
    # extract_pr_number
    # =====================================

    @patch.dict(os.environ, {"PR_NUMBER": "12345"})
    def test_extract_pr_number_from_env(self):
        result = validator.extract_pr_number("anything.yaml")
        self.assertEqual(result, "12345")

    @patch.dict(os.environ, {}, clear=True)
    def test_extract_pr_number_from_filename(self):
        result = validator.extract_pr_number("pr_67890.json")
        self.assertEqual(result, "67890")

    @patch.dict(os.environ, {}, clear=True)
    def test_extract_pr_number_failure(self):
        with self.assertRaises(ValueError):
            validator.extract_pr_number("sample.json")

    # =====================================
    # create_session
    # =====================================

    def test_create_session_success(self):
        session = validator.create_session("test_token")

        self.assertEqual(
            session.headers["Authorization"],
            "token test_token"
        )

    def test_create_session_no_token(self):
        with self.assertRaises(ValueError):
            validator.create_session(None)

    # =====================================
    # mandatory_label_regex
    # =====================================

    @patch.object(validator.PV, "build_result")
    def test_mandatory_label_regex_pass(self, mock_build):

        mock_build.return_value = {"status": "PASSED"}

        rule = {
            "id": "R1",
            "name": "mandatory",
            "params": {
                "pattern": "^release:.*"
            }
        }

        result = validator.evaluate_mandatory_label_regex(
            rule,
            ["release:1.0"],
            "PR#123"
        )

        self.assertEqual(result["status"], "PASSED")

    @patch.object(validator.PV, "build_result")
    def test_mandatory_label_regex_fail(self, mock_build):

        mock_build.return_value = {"status": "FAILED"}

        rule = {
            "id": "R1",
            "name": "mandatory",
            "message": "label missing",
            "params": {
                "pattern": "^release:.*"
            }
        }

        result = validator.evaluate_mandatory_label_regex(
            rule,
            ["feature"],
            "PR#123"
        )

        self.assertEqual(result["status"], "FAILED")

    # =====================================
    # label_count_regex
    # =====================================

    @patch.object(validator.PV, "build_result")
    def test_label_count_regex_pass(self, mock_build):

        mock_build.return_value = {"status": "PASSED"}

        rule = {
            "id": "R2",
            "name": "count",
            "params": {
                "pattern": "^priority:",
                "min_count": 1,
                "max_count": 2
            }
        }

        result = validator.evaluate_label_count_regex(
            rule,
            ["priority:p1"],
            "PR#123"
        )

        self.assertEqual(result["status"], "PASSED")

    @patch.object(validator.PV, "build_result")
    def test_label_count_regex_fail(self, mock_build):

        mock_build.return_value = {"status": "FAILED"}

        rule = {
            "id": "R2",
            "name": "count",
            "message": "invalid count",
            "params": {
                "pattern": "^priority:",
                "min_count": 1,
                "max_count": 1
            }
        }

        result = validator.evaluate_label_count_regex(
            rule,
            [],
            "PR#123"
        )

        self.assertEqual(result["status"], "FAILED")

    # =====================================
    # optional_label_regex
    # =====================================

    @patch.object(validator.PV, "build_result")
    def test_optional_label_not_present(self, mock_build):

        mock_build.return_value = {"status": "PASSED"}

        rule = {
            "id": "R3",
            "name": "optional",
            "params": {
                "category_pattern": "^priority:",
                "allowed_pattern": "^priority:(p1|p2)$"
            }
        }

        result = validator.evaluate_optional_label_regex(
            rule,
            ["feature"],
            "PR#123"
        )

        self.assertEqual(result["status"], "PASSED")

    @patch.object(validator.PV, "build_result")
    def test_optional_label_invalid(self, mock_build):

        mock_build.return_value = {"status": "FAILED"}

        rule = {
            "id": "R3",
            "name": "optional",
            "message": "bad priority",
            "params": {
                "category_pattern": "^priority:",
                "allowed_pattern": "^priority:(p1|p2)$"
            }
        }

        result = validator.evaluate_optional_label_regex(
            rule,
            ["priority:p9"],
            "PR#123"
        )

        self.assertEqual(result["status"], "FAILED")

    # =====================================
    # apply_rule
    # =====================================

    @patch.object(validator, "evaluate_mandatory_label_regex")
    def test_apply_rule_dispatch(self, mock_eval):

        mock_eval.return_value = {"status": "PASSED"}

        rule = {
            "id": "R1",
            "type": "mandatory_label_regex"
        }

        result = validator.apply_rule(
            rule,
            {"labels": ["release:1"]},
            "PR#123"
        )

        self.assertEqual(len(result), 1)

    # =====================================
    # fetch_pr_labels
    # =====================================

    def test_fetch_pr_labels_success(self):

        response = MagicMock()
        response.status_code = 200
        response.json.return_value = {
            "labels": [
                {"name": "priority:p1"},
                {"name": "release"}
            ]
        }

        session = MagicMock()
        session.get.return_value = response

        result = validator.fetch_pr_labels(
            session,
            "123"
        )

        self.assertEqual(
            result,
            ["priority:p1", "release"]
        )

    # =====================================
    # validate()
    # =====================================

    @patch.dict(os.environ, {"secret": "token123"})
    @patch(f"{MODULE_NAME}.fetch_pr_labels")
    @patch(f"{MODULE_NAME}.create_session")
    @patch.object(validator.PV, "build_result")
    def test_validate_success(
        self,
        mock_build,
        mock_create_session,
        mock_fetch
    ):

        mock_create_session.return_value = MagicMock()

        mock_fetch.return_value = [
            "release:1.0"
        ]

        mock_build.return_value = {
            "status": "PASSED"
        }

        rules = {
            "RULE1": {
                "enabled": True,
                "type": "mandatory_label_regex",
                "params": {
                    "pattern": "^release:"
                }
            }
        }

        results = validator.validate(
            ["123.json"],
            rules
        )

        self.assertTrue(len(results) > 0)

    @patch.dict(os.environ, {"secret": "token123"})
    @patch(f"{MODULE_NAME}.fetch_pr_labels")
    @patch(f"{MODULE_NAME}.create_session")
    @patch.object(validator.PV, "build_result")
    def test_validate_exception(
        self,
        mock_build,
        mock_create_session,
        mock_fetch
    ):

        mock_create_session.return_value = MagicMock()

        mock_fetch.side_effect = Exception(
            "API failure"
        )

        mock_build.return_value = {
            "status": "FAILED",
            "rule_id": "PR_LABEL_ERROR"
        }

        results = validator.validate(
            ["123.json"],
            {}
        )

        self.assertEqual(
            results[0]["rule_id"],
            "PR_LABEL_ERROR"
        )


if __name__ == "__main__":
    unittest.main()