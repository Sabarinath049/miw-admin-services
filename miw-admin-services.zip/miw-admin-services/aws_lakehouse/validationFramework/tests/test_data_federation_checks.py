import unittest
from unittest.mock import patch, mock_open
import importlib
import os
import sys

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(BASE_DIR, "src"))

MODULE_NAME = "validation_framework.validators.data_federation_checks"
validator = importlib.import_module(MODULE_NAME)


class TestValidator(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.file_path = "file.yaml"

    # =========================
    # load_yaml_or_json
    # =========================

    @patch("builtins.open", new_callable=mock_open, read_data='{"key": "value"}')
    def test_load_json(self, mock_file):
        result = validator.load_yaml_or_json("test.json")
        self.assertEqual(result, {"key": "value"})

    @patch("builtins.open", new_callable=mock_open, read_data="key: value")
    def test_load_yaml(self, mock_file):
        result = validator.load_yaml_or_json("test.yaml")
        self.assertEqual(result, {"key": "value"})

    @patch("builtins.open", side_effect=Exception("read error"))
    def test_load_file_error(self, mock_file):
        result = validator.load_yaml_or_json("bad.yaml")
        self.assertIsNone(result)

    # =========================
    # apply_regex_rule
    # =========================

    def test_apply_regex_rule_pass(self):
        rule = {
            "name": "regex_test",
            "type": "regex_match",
            "target_field": "file_path",
            "params": {"pattern": r".*\.yaml$"}
        }

        result = validator.apply_regex_rule(
            self.file_path, {}, "R1", rule
        )

        self.assertEqual(result["status"], "PASSED")

    def test_apply_regex_rule_fail(self):
        rule = {
            "name": "regex_test",
            "type": "regex_match",
            "target_field": "file_path",
            "params": {"pattern": r".*\.json$"}
        }

        result = validator.apply_regex_rule(
            self.file_path, {}, "R1", rule
        )

        self.assertEqual(result["status"], "FAILED")

    def test_apply_regex_rule_payload_field(self):
        payload = {"env": "dev"}

        rule = {
            "name": "regex_test",
            "target_field": "env",
            "params": {"pattern": r"dev"}
        }

        result = validator.apply_regex_rule(
            self.file_path, payload, "R1", rule
        )

        self.assertEqual(result["status"], "PASSED")

    def test_apply_regex_rule_invalid_target(self):
        payload = {"env": 123}

        rule = {
            "name": "regex_test",
            "target_field": "env",
            "params": {"pattern": r".*"}
        }

        result = validator.apply_regex_rule(
            self.file_path, payload, "R1", rule
        )

        self.assertEqual(result["status"], "FAILED")
        self.assertEqual(result["message"], "Invalid target field")

    # =========================
    # apply_allowed_values_rule
    # =========================

    def test_allowed_values_in_name_pass(self):
        payload = {"env": "dev_env"}

        rule = {
            "name": "allowed_test",
            "type": "allowed_values_in_name",
            "target_field": "env",
            "params": {"allowed_values": ["dev", "prod"]}
        }

        result = validator.apply_allowed_values_rule(
            self.file_path, payload, "R2", rule
        )

        self.assertEqual(result["status"], "PASSED")

    def test_allowed_values_in_name_fail(self):
        payload = {"env": "unknown_env"}

        rule = {
            "name": "allowed_test",
            "type": "allowed_values_in_name",
            "target_field": "env",
            "params": {"allowed_values": ["dev", "prod"]}
        }

        result = validator.apply_allowed_values_rule(
            self.file_path, payload, "R2", rule
        )

        self.assertEqual(result["status"], "FAILED")

    def test_allowed_values_in_name_list_pass(self):
        payload = {
            "envs": ["dev_app", "prod_app"]
        }

        rule = {
            "target_field": "envs",
            "params": {
                "allowed_values": ["dev", "prod"]
            }
        }

        result = validator.apply_allowed_values_rule(
            self.file_path, payload, "R2", rule
        )

        self.assertEqual(result["status"], "PASSED")

    def test_allowed_values_non_string_ignored(self):
        payload = {
            "envs": [1, 2, "dev_app"]
        }

        rule = {
            "target_field": "envs",
            "params": {
                "allowed_values": ["dev"]
            }
        }

        result = validator.apply_allowed_values_rule(
            self.file_path, payload, "R2", rule
        )

        self.assertEqual(result["status"], "PASSED")

    # =========================
    # apply_allowed_values_exact
    # =========================

    def test_allowed_values_exact_pass(self):
        payload = {"env": "dev"}

        rule = {
            "name": "exact_test",
            "type": "allowed_values",
            "target_field": "env",
            "params": {"allowed_values": ["dev", "prod"]}
        }

        result = validator.apply_allowed_values_exact(
            self.file_path, payload, "R3", rule
        )

        self.assertEqual(result["status"], "PASSED")

    def test_allowed_values_exact_fail(self):
        payload = {"env": "qa"}

        rule = {
            "name": "exact_test",
            "type": "allowed_values",
            "target_field": "env",
            "params": {"allowed_values": ["dev", "prod"]}
        }

        result = validator.apply_allowed_values_exact(
            self.file_path, payload, "R3", rule
        )

        self.assertEqual(result["status"], "FAILED")

    # =========================
    # apply_equality_check
    # =========================

    def test_equality_check_pass(self):
        payload = {"a": 5}

        rule = {
            "params": {
                "python_expression": [
                    "a == 5"
                ]
            }
        }

        result = validator.apply_equality_check(
            self.file_path, payload, "R4", rule
        )

        self.assertEqual(result["status"], "PASSED")

    def test_equality_check_fail(self):
        payload = {"a": 3}

        rule = {
            "params": {
                "python_expression": [
                    "a == 5"
                ]
            }
        }

        result = validator.apply_equality_check(
            self.file_path, payload, "R4", rule
        )

        self.assertEqual(result["status"], "FAILED")

    def test_equality_check_single_string_expression(self):
        payload = {"a": 5}

        rule = {
            "params": {
                "python_expression": "a == 5"
            }
        }

        result = validator.apply_equality_check(
            self.file_path, payload, "R4", rule
        )

        self.assertEqual(result["status"], "PASSED")

    def test_equality_check_multiple_expressions(self):
        payload = {
            "a": 5,
            "b": 10
        }

        rule = {
            "params": {
                "python_expression": [
                    "a == 5",
                    "b == 10"
                ]
            }
        }

        result = validator.apply_equality_check(
            self.file_path, payload, "R4", rule
        )

        self.assertEqual(result["status"], "PASSED")

    def test_equality_check_eval_exception(self):
        payload = {"a": 5}

        rule = {
            "params": {
                "python_expression": [
                    "unknown_var == 1"
                ]
            }
        }

        result = validator.apply_equality_check(
            self.file_path, payload, "R4", rule
        )

        self.assertEqual(result["status"], "FAILED")

    def test_equality_check_utility_functions(self):
        payload = {
            "name": "DEV",
            "items": [1, 2]
        }

        rule = {
            "params": {
                "python_expression": [
                    "lower(name) == 'dev'",
                    "len(items) == 2",
                    "all([True, True])",
                    "any([False, True])"
                ]
            }
        }

        result = validator.apply_equality_check(
            self.file_path, payload, "R4", rule
        )

        self.assertEqual(result["status"], "PASSED")

    def test_equality_check_file_name(self):
        payload = {}

        rule = {
            "params": {
                "python_expression": [
                    "file_name == 'file.yaml'"
                ]
            }
        }

        result = validator.apply_equality_check(
            self.file_path, payload, "R4", rule
        )

        self.assertEqual(result["status"], "PASSED")

    # =========================
    # DF_001/DF_002 regression: missing '_df' suffix must FAIL
    # (Data Federation validation in Production was unable to detect this)
    # =========================

    def test_df001_regex_rule_fails_when_data_share_name_missing_df_suffix(self):
        payload = {"data_share_name": "sales_lakehouse_dev"}

        rule = {
            "name": "data_share_name_suffix_check",
            "type": "regex_match",
            "target_field": "data_share_name",
            "severity": "ERROR",
            "params": {"pattern": ".*_df$"},
            "message": "data_share_name must end with '_df'",
        }

        result = validator.apply_regex_rule(
            "account/data_federation/sales_lakehouse_dev.yml", payload, "DF_001", rule
        )

        self.assertEqual(result["status"], "FAILED")

    def test_df001_regex_rule_passes_when_data_share_name_has_df_suffix(self):
        payload = {"data_share_name": "sales_lakehouse_dev_df"}

        rule = {
            "name": "data_share_name_suffix_check",
            "type": "regex_match",
            "target_field": "data_share_name",
            "severity": "ERROR",
            "params": {"pattern": ".*_df$"},
            "message": "data_share_name must end with '_df'",
        }

        result = validator.apply_regex_rule(
            "account/data_federation/sales_lakehouse_dev_df.yml", payload, "DF_001", rule
        )

        self.assertEqual(result["status"], "PASSED")

    def test_df002_equality_check_fails_when_file_name_missing_df_suffix(self):
        rule = {
            "name": "file_name_suffix_check",
            "params": {
                "python_expression": [
                    "file_path.split('/')[-1].endswith('_df.yml') or "
                    "file_path.split('/')[-1].endswith('_df.yaml')"
                ]
            },
        }

        result = validator.apply_equality_check(
            "account/data_federation/sales_lakehouse_dev.yml", {}, "DF_002", rule
        )

        self.assertEqual(result["status"], "FAILED")

    def test_df002_equality_check_normalizes_windows_style_paths(self):
        # Even when the incoming file_path uses OS-specific (Windows) backslash
        # separators, the suffix check must still correctly evaluate.
        rule = {
            "name": "file_name_suffix_check",
            "params": {
                "python_expression": [
                    "file_path.split('/')[-1].endswith('_df.yml') or "
                    "file_path.split('/')[-1].endswith('_df.yaml')"
                ]
            },
        }

        failing = validator.apply_equality_check(
            r"account\data_federation\sales_lakehouse_dev.yml", {}, "DF_002", rule
        )
        self.assertEqual(failing["status"], "FAILED")

        passing = validator.apply_equality_check(
            r"account\data_federation\sales_lakehouse_dev_df.yml", {}, "DF_002", rule
        )
        self.assertEqual(passing["status"], "PASSED")

    # =========================
    # get_value
    # =========================

    def test_get_value_nested(self):
        payload = {
            "a": {
                "b": {
                    "c": 100
                }
            }
        }

        self.assertEqual(
            validator.get_value(payload, "a.b.c"),
            100
        )

    def test_get_value_missing(self):
        payload = {"a": {"b": 1}}

        self.assertIsNone(
            validator.get_value(payload, "a.c")
        )

    def test_get_value_no_path(self):
        payload = {"a": 1}

        self.assertEqual(
            validator.get_value(payload, None),
            payload
        )

    # =========================
    # helpers
    # =========================

    def test_success(self):
        result = validator.success(
            "R1",
            {"name": "rule1"},
            self.file_path
        )

        self.assertEqual(result["status"], "PASSED")

    def test_fail(self):
        result = validator.fail(
            "R1",
            {
                "name": "rule1",
                "recommendation": "Fix issue"
            },
            self.file_path,
            "Failed validation"
        )

        self.assertEqual(result["status"], "FAILED")
        self.assertEqual(result["recommendation"], "Fix issue")

    def test_build_result(self):
        result = validator.build_result(
            "R1",
            "rule",
            "PASSED",
            "INFO",
            self.file_path,
            "ok"
        )

        self.assertEqual(result["rule_id"], "R1")
        self.assertEqual(result["status"], "PASSED")
        self.assertEqual(result["severity"], "INFO")

    # =========================
    # validate
    # =========================

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_success(self, mock_loader):
        mock_loader.return_value = {"env": "dev"}

        rules = {
            "R1": {
                "name": "env_check",
                "type": "allowed_values",
                "enabled": True,
                "target_field": "env",
                "params": {
                    "allowed_values": ["dev", "prod"]
                }
            }
        }

        result = validator.validate(
            [self.file_path],
            rules
        )

        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]["status"], "PASSED")
        self.assertEqual(result[1]["rule_id"], "SUMMARY")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_file_load_failure(self, mock_loader):
        mock_loader.return_value = None

        result = validator.validate(
            ["bad.yaml"],
            {}
        )

        self.assertEqual(
            result[0]["rule_id"],
            "FILE_LOAD_ERROR"
        )

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_disabled_rule(self, mock_loader):
        mock_loader.return_value = {"env": "dev"}

        rules = {
            "R1": {
                "enabled": False,
                "type": "allowed_values"
            }
        }

        result = validator.validate(
            [self.file_path],
            rules
        )

        self.assertEqual(len(result), 1)
        self.assertEqual(
            result[0]["rule_id"],
            "SUMMARY"
        )

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_rule_runs_by_default_when_enabled_key_omitted(self, mock_loader):
        # A rule that omits "enabled" entirely must still execute (fail-safe
        # default), matching the behavior of the other validators.
        mock_loader.return_value = {"env": "qa"}

        rules = {
            "R1": {
                "name": "env_check",
                "type": "allowed_values",
                "target_field": "env",
                "params": {
                    "allowed_values": ["dev", "prod"]
                }
            }
        }

        result = validator.validate(
            [self.file_path],
            rules
        )

        self.assertEqual(result[0]["rule_id"], "R1")
        self.assertEqual(result[0]["status"], "FAILED")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_unsupported_rule(self, mock_loader):
        mock_loader.return_value = {"env": "dev"}

        rules = {
            "R1": {
                "enabled": True,
                "name": "bad_rule",
                "type": "unknown_rule"
            }
        }

        result = validator.validate(
            [self.file_path],
            rules
        )

        self.assertEqual(
            result[0]["status"],
            "FAILED"
        )

        self.assertIn(
            "Unsupported rule type",
            result[0]["message"]
        )

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_multiple_rules(self, mock_loader):
        mock_loader.return_value = {
            "env": "dev",
            "a": 5
        }

        rules = {
            "R1": {
                "enabled": True,
                "type": "allowed_values",
                "target_field": "env",
                "params": {
                    "allowed_values": ["dev"]
                }
            },
            "R2": {
                "enabled": True,
                "type": "equality_check",
                "params": {
                    "python_expression": [
                        "a == 5"
                    ]
                }
            }
        }

        result = validator.validate(
            [self.file_path],
            rules
        )

        summary = result[-1]

        self.assertEqual(
            summary["evidence"]["passed"],
            2
        )

    # =========================
    # ACCOUNT ID VALIDATION
    # =========================

    def test_account_id_validation_pass_compute_dev(self):

        payload = {
            "aws_account_id": "068887784423"
        }

        context = {
            "env": "dev"
        }

        rule = {
            "name": "aws_account_id_env_folder_validation",
            "recommendation": "Use correct account id",
            "params": {
                "account_mapping": {
                    "compute-001": {
                        "dev": "068887784423",
                        "prd": "367241115350"
                    }
                }
            }
        }

        result = validator.apply_account_id_by_env_rule(
            "metadata/samples/compute-001/data_federation/test_df.yaml",
            payload,
            "DF_014",
            rule,
            context
        )

        self.assertEqual(result["status"], "PASSED")

    def test_account_id_validation_fail_compute_dev(self):

        payload = {
            "aws_account_id": "367241115350"
        }

        context = {
            "env": "dev"
        }

        rule = {
            "name": "aws_account_id_env_folder_validation",
            "recommendation": "Use correct account id",
            "message": "aws_account_id mismatch",
            "params": {
                "account_mapping": {
                    "compute-001": {
                        "dev": "068887784423",
                        "prd": "367241115350"
                    }
                }
            }
        }

        result = validator.apply_account_id_by_env_rule(
            "metadata/samples/compute-001/data_federation/test_df.yaml",
            payload,
            "DF_014",
            rule,
            context
        )

        self.assertEqual(result["status"], "FAILED")
        self.assertEqual(
            result["evidence"]["expected_account_id"],
            "068887784423"
        )

    def test_account_id_validation_pass_compute_prd(self):

        payload = {
            "aws_account_id": "367241115350"
        }

        context = {
            "env": "prd"
        }

        rule = {
            "params": {
                "account_mapping": {
                    "compute-001": {
                        "dev": "068887784423",
                        "prd": "367241115350"
                    }
                }
            }
        }

        result = validator.apply_account_id_by_env_rule(
            "metadata/samples/compute-001/data_federation/test_df.yaml",
            payload,
            "DF_014",
            rule,
            context
        )

        self.assertEqual(result["status"], "PASSED")

    def test_account_id_validation_pass_lakehouse_dev(self):

        payload = {
            "aws_account_id": "438465132548"
        }

        context = {
            "env": "dev"
        }

        rule = {
            "params": {
                "account_mapping": {
                    "lakehouse-001": {
                        "dev": "438465132548",
                        "prd": "578647603827"
                    }
                }
            }
        }

        result = validator.apply_account_id_by_env_rule(
            "metadata/samples/lakehouse-001/data_federation/test_df.yaml",
            payload,
            "DF_014",
            rule,
            context
        )

        self.assertEqual(result["status"], "PASSED")

    def test_account_id_validation_unknown_folder(self):

        payload = {
            "aws_account_id": "123456789012"
        }

        context = {
            "env": "dev"
        }

        rule = {
            "params": {
                "account_mapping": {
                    "compute-001": {
                        "dev": "068887784423",
                        "prd": "367241115350"
                    }
                }
            }
        }

        result = validator.apply_account_id_by_env_rule(
            "metadata/samples/unknown-account/data_federation/test_df.yaml",
            payload,
            "DF_014",
            rule,
            context
        )

        self.assertEqual(result["status"], "FAILED")

        self.assertIn(
            "Unable to identify account folder",
            result["message"]
        )

    def test_account_id_validation_invalid_env(self):

        payload = {
            "aws_account_id": "068887784423"
        }

        context = {
            "env": "qa"
        }

        rule = {
            "params": {
                "account_mapping": {
                    "compute-001": {
                        "dev": "068887784423",
                        "prd": "367241115350"
                    }
                }
            }
        }

        result = validator.apply_account_id_by_env_rule(
            "metadata/samples/compute-001/data_federation/test_df.yaml",
            payload,
            "DF_014",
            rule,
            context
        )

        self.assertEqual(result["status"], "FAILED")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_account_id_rule(self, mock_loader):

        mock_loader.return_value

    # =========================
    # build_summary
    # =========================

    def test_summary_pass(self):
        results = [
            {"status": "PASSED"},
            {"status": "PASSED"}
        ]

        summary = validator.build_summary(
            self.file_path,
            results
        )

        self.assertEqual(summary["status"], "PASSED")
        self.assertEqual(summary["evidence"]["passed"], 2)

    def test_summary_fail(self):
        results = [
            {"status": "PASSED"},
            {"status": "FAILED"}
        ]

        summary = validator.build_summary(
            self.file_path,
            results
        )

        self.assertEqual(summary["status"], "FAILED")
        self.assertEqual(summary["evidence"]["failed"], 1)


if __name__ == "__main__":
    unittest.main()