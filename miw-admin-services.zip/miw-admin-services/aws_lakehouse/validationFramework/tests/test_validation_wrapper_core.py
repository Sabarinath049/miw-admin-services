import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from validation_framework.core import validation_wrapper as wrapper


def test_extract_account_dimensions_success():
    account_exact, account_family, resource_type = wrapper.extract_account_dimensions(
        "dummy_files/lakehouse-001/s3/dev-lh1-agtr-eng-assets.yaml"
    )

    assert account_exact == "lakehouse-001"
    assert account_family == "lakehouse"
    assert resource_type == "s3"


def test_extract_account_dimensions_invalid_path():
    with pytest.raises(ValueError):
        wrapper.extract_account_dimensions("only_one_part.yaml")


def test_get_matching_rulepacks_for_file_order_and_dedup():
    index = {
        "lakehouse-001": {
            "s3": ["exact_s3", "dup_item"],
            "global": ["exact_global", "dup_item"],
        },
        "lakehouse": {
            "s3": ["family_s3"],
            "global": ["family_global"],
        },
        "all": {
            "s3": ["all_s3"],
            "global": ["all_global"],
        },
    }

    matches = wrapper.get_matching_rulepacks_for_file(
        "dummy_files/lakehouse-001/s3/dev-lh1-agtr-eng-assets.yaml", index
    )

    assert matches == [
        "exact_s3",
        "dup_item",
        "family_s3",
        "all_s3",
        "exact_global",
        "family_global",
        "all_global",
    ]


def test_build_rulepack_file_map_with_unmatched():
    index = {
        "lakehouse": {
            "s3": ["rp_s3"],
            "global": ["rp_global"],
        }
    }

    files = [
        "dummy_files/lakehouse-001/s3/a.yaml",
        "dummy_files/unknown/x/y.yaml",
    ]

    file_map, unmatched = wrapper.build_rulepack_file_map(files, index)

    assert sorted(file_map.keys()) == ["rp_global", "rp_s3"]
    assert "dummy_files/lakehouse-001/s3/a.yaml" in file_map["rp_s3"]
    assert unmatched == ["dummy_files/unknown/x/y.yaml"]


def test_build_file_path_context_unknown_handling():
    context = wrapper.build_file_path_context([
        "dummy_files/lakehouse-001/s3/a.yaml",
        "badpath",
    ])

    assert context["file_resource_types"]["dummy_files/lakehouse-001/s3/a.yaml"] == "s3"
    assert context["file_account_types"]["dummy_files/lakehouse-001/s3/a.yaml"] == "lakehouse-001"
    assert context["file_resource_types"]["badpath"] == "unknown"
    assert context["file_account_types"]["badpath"] == "unknown"


def test_resolve_output_and_summary_paths(tmp_path):
    custom_txt = tmp_path / "my.txt"
    custom_summary = tmp_path / "my_summary.txt"

    assert wrapper.resolve_output_path("txt", str(custom_txt)) == custom_txt.resolve()
    assert wrapper.resolve_output_path("csv").name == "validation_results.csv"
    assert wrapper.resolve_summary_path(str(custom_summary)) == custom_summary.resolve()
    assert wrapper.resolve_summary_path().name == "validation_summary_table.txt"


def test_enrich_results_uses_file_resource_map_and_fallback():
    batch_results = [
        {"file_path": "dummy_files/lakehouse-001/s3/a.yaml", "status": "PASSED"},
        {"file_path": "dummy_files/lakehouse-001/unknown/b.yaml", "status": "FAILED"},
    ]
    file_resource_types = {"dummy_files/lakehouse-001/s3/a.yaml": "s3"}

    enriched = wrapper.enrich_results(
        batch_results,
        rulepack_name="global_allowed_values",
        rulepack_resource_type="global",
        file_resource_types=file_resource_types,
    )

    assert enriched[0]["rulepack_name"] == "global_allowed_values"
    assert enriched[0]["resource_type"] == "s3"
    assert enriched[1]["resource_type"] == "global"


def test_log_rendered_output_fallback_print(capsys, monkeypatch):
    monkeypatch.setattr(wrapper, "is_logger_available", False)
    monkeypatch.setattr(wrapper, "logger", None)

    wrapper.log_rendered_output("line1\nline2", {"failed_errors": 0, "failed_warnings": 0})

    captured = capsys.readouterr()
    assert "line1" in captured.out
    assert "line2" in captured.out
