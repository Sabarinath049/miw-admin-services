"""
Pytest unit tests for lakehouse_database_naming.py

Covers:
    - get_nested_value
    - replace_context_tokens / resolve_rule_with_context
    - apply_regex_rule
    - apply_allowed_values_in_name_rule
    - apply_enterprise_subgroup_rule
    - build_result / build_file_summary_result
    - load_yaml_or_json
    - validate (integration via tmp files)
"""
import json
import os
import sys
import textwrap

# Make sure the src tree is on the path when running from the repo root
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import pytest
import yaml

from validation_framework.validators.database_naming import (
    apply_allowed_values_in_name_rule,
    apply_equality_check_rule,
    apply_enterprise_subgroup_rule,
    apply_regex_rule,
    build_file_summary_result,
    build_result,
    get_nested_value,
    load_yaml_or_json,
    replace_context_tokens,
    resolve_rule_with_context,
    validate,
)


# ===========================================================================
# Helpers
# ===========================================================================
FILE = "test_file.yaml"


def _rule(overrides=None):
    """Return a minimal rule dict, optionally overridden."""
    base = {
        "name": "test_rule",
        "enabled": True,
        "severity": "ERROR",
        "type": "regex_match",
        "target_field": "field",
        "params": {"pattern": "^[a-z]+$"},
        "message": "Pattern mismatch",
        "recommendation": "Use lowercase only",
    }
    if overrides:
        base.update(overrides)
    return base


# ===========================================================================
# get_nested_value
# ===========================================================================
class TestGetNestedValue:
    def test_simple_key(self):
        assert get_nested_value({"a": 1}, "a") == 1

    def test_nested_dot_path(self):
        assert get_nested_value(
            {"database": {"s3_bucket": "my_bucket"}},
            "database.s3_bucket") == "my_bucket"

    def test_top_level_dict_no_path(self):
        payload = {"database": {"s3_bucket": "my_bucket"}}
        assert get_nested_value(payload, "") == payload

    def test_dot_only_returns_full_payload(self):
        payload = {"x": 1}
        assert get_nested_value(payload, ".") == payload

    def test_none_path_returns_full_payload(self):
        payload = {"x": 1}
        assert get_nested_value(payload, None) == payload

    def test_missing_key_returns_none(self):
        assert get_nested_value({"a": 1}, "b") is None

    def test_missing_nested_key_returns_none(self):
        assert get_nested_value(
            {"database": {"s3_bucket": "x"}}, "database.nonexistent") is None

    def test_double_dot_skipped(self):
        payload = {"database": {"s3_bucket": "my_bucket"}}
        assert get_nested_value(payload, "database..s3_bucket") == "my_bucket"

    def test_extra_nesting_returns_none(self):
        payload = {"database": {"s3_bucket": "my_bucket"}}
        assert get_nested_value(payload, "database.s3_bucket.extra") is None


# ===========================================================================
# replace_context_tokens / resolve_rule_with_context
# ===========================================================================
class TestReplaceContextTokens:
    def test_dollar_var(self):
        assert replace_context_tokens(
            "hello $env world", {"env": "dev"}) == "hello dev world"

    def test_dollar_brace_var(self):
        assert replace_context_tokens(
            "s3://${env}-bucket", {"env": "dev"}) == "s3://dev-bucket"

    def test_missing_var_left_unchanged(self):
        assert replace_context_tokens(
            "${unknown}", {"env": "dev"}) == "${unknown}"

    def test_nested_dict(self):
        result = replace_context_tokens({"key": "value-$env"}, {"env": "prd"})
        assert result == {"key": "value-prd"}

    def test_list_items(self):
        result = replace_context_tokens(["$env", "static"], {"env": "dev"})
        assert result == ["dev", "static"]

    def test_non_string_passthrough(self):
        assert replace_context_tokens(42, {"env": "dev"}) == 42
        assert replace_context_tokens(True, {"env": "dev"}) is True

    def test_resolve_rule_with_context_replaces_pattern(self):
        rule = _rule({"params": {"pattern": "^$env-.*$"}})
        resolved = resolve_rule_with_context(rule, {"env": "dev"})
        assert resolved["params"]["pattern"] == "^dev-.*$"

    def test_resolve_rule_with_no_context(self):
        rule = _rule()
        resolved = resolve_rule_with_context(rule, None)
        assert resolved["params"]["pattern"] == "^[a-z]+$"


# ===========================================================================
# apply_regex_rule
# ===========================================================================
class TestApplyRegexRule:
    def test_passes_when_pattern_matches(self):
        payload = {"field": "abc"}
        result = apply_regex_rule(FILE, payload, "R001", _rule())
        assert result["status"] == "PASSED"

    def test_fails_when_pattern_does_not_match(self):
        payload = {"field": "ABC"}
        result = apply_regex_rule(FILE, payload, "R001", _rule())
        assert result["status"] == "FAILED"
        assert result["evidence"]["actual_value"] == "ABC"

    def test_fails_when_field_missing(self):
        result = apply_regex_rule(FILE, {}, "R001", _rule())
        assert result["status"] == "FAILED"
        assert "not found" in result["message"]

    def test_fails_when_field_not_string(self):
        payload = {"field": 123}
        result = apply_regex_rule(FILE, payload, "R001", _rule())
        assert result["status"] == "FAILED"
        assert "must be a string" in result["message"]

    def test_fails_gracefully_on_invalid_regex(self):
        payload = {"field": "abc"}
        rule = _rule({"params": {"pattern": "^*invalid"}})
        result = apply_regex_rule(FILE, payload, "R001", rule)
        assert result["status"] == "FAILED"
        assert "Invalid regex" in result["message"]

    def test_s3_location_pattern_with_env(self):
        payload = {"database_s3_location": "s3://dev-lh1-spec-src/raw/path/"}
        rule = _rule({
            "target_field": "database_s3_location",
            "params": {"pattern": r"^s3://dev-lh1-(agtr|food|spec|corp(?:-[a-z0-9]+)?)-[a-z0-9-]+(?:/[a-z0-9/_-]+)*/?$"},
        })
        result = apply_regex_rule(FILE, payload, "LH_DB_002", rule)
        assert result["status"] == "PASSED"

    def test_s3_location_pattern_fails_wrong_env(self):
        payload = {"database_s3_location": "s3://prd-lh1-spec-src/raw/path/"}
        rule = _rule({
            "target_field": "database_s3_location",
            "params": {"pattern": r"^s3://dev-lh1-(agtr|food|spec|corp(?:-[a-z0-9]+)?)-[a-z0-9-]+(?:/[a-z0-9/_-]+)*/?$"},
        })
        result = apply_regex_rule(FILE, payload, "LH_DB_002", rule)
        assert result["status"] == "FAILED"


# ===========================================================================
# apply_allowed_values_in_name_rule
# ===========================================================================
class TestApplyAllowedValuesInNameRule:
    def _allowed_rule(self):
        return {
            "name": "allowed_layers",
            "enabled": True,
            "severity": "ERROR",
            "type": "allowed_values_in_name",
            "target_field": "database_name",
            "params": {
                "allowed_values": ["raw", "raw_serving", "cdp"],
                "disallowed_values": ["curated", "serving"],
            },
            "message": "Disallowed layer found: {disallowed_values_found}",
            "recommendation": "Use only raw, raw_serving, or cdp",
        }

    def test_passes_with_allowed_token(self):
        payload = {"database_name": "lh_cmc_raw_dev"}
        result = apply_allowed_values_in_name_rule(
            FILE, payload, "LH_DB_001", self._allowed_rule())
        assert result["status"] == "PASSED"

    def test_fails_with_disallowed_token(self):
        payload = {"database_name": "lh_cmc_serving_dev"}
        result = apply_allowed_values_in_name_rule(
            FILE, payload, "LH_DB_001", self._allowed_rule())
        assert result["status"] == "FAILED"
        assert "serving" in result["evidence"]["disallowed_values_found"]

    def test_fails_when_no_allowed_token_present(self):
        payload = {"database_name": "lh_cmc_unknown_dev"}
        result = apply_allowed_values_in_name_rule(
            FILE, payload, "LH_DB_001", self._allowed_rule())
        assert result["status"] == "FAILED"
        assert "does not include any allowed layer" in result["message"]

    def test_fails_when_field_missing(self):
        result = apply_allowed_values_in_name_rule(
            FILE, {}, "LH_DB_001", self._allowed_rule())
        assert result["status"] == "FAILED"
        assert "not found" in result["message"]

    def test_fails_when_field_not_string(self):
        payload = {"database_name": 999}
        result = apply_allowed_values_in_name_rule(
            FILE, payload, "LH_DB_001", self._allowed_rule())
        assert result["status"] == "FAILED"
        assert "must be a string" in result["message"]

    def test_case_insensitive_token_matching(self):
        payload = {"database_name": "lh_cmc_RAW_dev"}
        result = apply_allowed_values_in_name_rule(
            FILE, payload, "LH_DB_001", self._allowed_rule())
        assert result["status"] == "PASSED"

    def test_curated_disallowed(self):
        payload = {"database_name": "lh_curated_dev"}
        result = apply_allowed_values_in_name_rule(
            FILE, payload, "LH_DB_001", self._allowed_rule())
        assert result["status"] == "FAILED"
        assert "curated" in result["evidence"]["disallowed_values_found"]

    def test_raw_serving_allowed_even_when_serving_disallowed(self):
        payload = {"database_name": "lh_cmc_peru_raw_serving_dev"}
        result = apply_allowed_values_in_name_rule(
            FILE, payload, "LH_DB_001", self._allowed_rule())
        assert result["status"] == "PASSED"


# ===========================================================================
# apply_enterprise_subgroup_rule
# ===========================================================================
class TestApplyEnterpriseSubgroupRule:
    def _enterprise_rule(self, overrides=None):
        """Return a minimal enterprise subgroup rule."""
        base = {
            "name": "enterprise_subgroup_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "enterprise_subgroup_check",
            "target_field": ".",
            "params": {
                "enterprise_field": "enterprise_or_func_name",
                "subgroup_field": "enterprise_or_func_subgrp_name",
                "no_subgroup_enterprises": ["AGTR", "FOOD", "SPEC"],
                "subgroup_mandatory_enterprises": ["CORP"],
            },
            "message": "Invalid enterprise/subgroup combination",
            "recommendation": "Check enterprise and subgroup fields",
        }
        if overrides:
            base.update(overrides)
        return base

    def test_no_subgroup_enterprise_without_subgroup_passes(self):
        """AGTR/FOOD/SPEC without subgroup should pass."""
        payload = {
            "enterprise_or_func_name": "AGTR",
            "enterprise_or_func_subgrp_name": "",
        }
        result = apply_enterprise_subgroup_rule(
            FILE, payload, "TEST_001", self._enterprise_rule())
        assert result["status"] == "PASSED"


# ===========================================================================
# apply_equality_check_rule
# ===========================================================================
class TestApplyEqualityCheckRule:
    def _equality_rule(self, overrides=None):
        base = {
            "name": "database_name_raw_pattern_check",
            "enabled": True,
            "severity": "WARNING",
            "type": "equality_check",
            "params": {
                "python_expression": [
                    "f\"lower(data_layer)=='raw' and ('_' + lower({source_name}) + '_') in ('_' + lower({database_name}) + '_')\""
                ]
            },
            "message": "The database name should contain ${source_name} for raw layer databases.",
            "recommendation": "Ensure database name contains {source_name} for raw layer databases.",
        }
        if overrides:
            base.update(overrides)
        return base

    def _enterprise_rule(self, overrides=None):
        base = {
            "name": "enterprise_subgroup_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "enterprise_subgroup_check",
            "target_field": ".",
            "params": {
                "enterprise_field": "enterprise_or_func_name",
                "subgroup_field": "enterprise_or_func_subgrp_name",
                "no_subgroup_enterprises": ["AGTR", "FOOD", "SPEC"],
                "subgroup_mandatory_enterprises": ["CORP"],
            },
            "message": "Invalid enterprise/subgroup combination",
            "recommendation": "Check enterprise and subgroup fields",
        }
        if overrides:
            base.update(overrides)
        return base

    def test_replaces_source_name_in_failure_message_and_recommendation(self):
        payload = {
            "data_layer": "raw",
            "source_name": "cmc_per",
            "database_name": "lh_cmc_peru_raw_dev",
        }
        result = apply_equality_check_rule(
            FILE, payload, "LH_DB_005", self._equality_rule())
        assert result["status"] == "WARNING"
        assert "cmc_per" in result["message"]
        assert "${source_name}" not in result["message"]
        assert "cmc_per" in result["recommendation"]
        assert "{source_name}" not in result["recommendation"]

    def test_no_subgroup_enterprise_with_subgroup_fails(self):
        """AGTR/FOOD/SPEC with subgroup should fail."""
        payload = {
            "enterprise_or_func_name": "AGTR",
            "enterprise_or_func_subgrp_name": "TDA",
        }
        result = apply_enterprise_subgroup_rule(
            FILE, payload, "TEST_001", self._enterprise_rule())
        assert result["status"] == "FAILED"
        assert "must not have subgroup" in result["message"].lower()

    def test_subgroup_mandatory_enterprise_with_subgroup_passes(self):
        """CORP with subgroup should pass."""
        payload = {
            "enterprise_or_func_name": "CORP",
            "enterprise_or_func_subgrp_name": "dtd",
        }
        result = apply_enterprise_subgroup_rule(
            FILE, payload, "TEST_001", self._enterprise_rule())
        assert result["status"] == "PASSED"

    def test_subgroup_mandatory_enterprise_without_subgroup_fails(self):
        """CORP without subgroup should fail."""
        payload = {
            "enterprise_or_func_name": "CORP",
            "enterprise_or_func_subgrp_name": "",
        }
        result = apply_enterprise_subgroup_rule(
            FILE, payload, "TEST_001", self._enterprise_rule())
        assert result["status"] == "FAILED"
        assert "requires subgroup" in result["message"].lower()

    def test_enterprise_field_missing_fails(self):
        """Missing enterprise field - implementation handles gracefully."""
        payload = {"enterprise_or_func_subgrp_name": "TDA"}
        result = apply_enterprise_subgroup_rule(
            FILE, payload, "TEST_001", self._enterprise_rule())
        # Result should be a valid result dict
        assert result is not None
        assert "rule_id" in result

    def test_payload_not_dict_fails(self):
        """If payload (target_field=.) is not dict, should fail."""
        result = apply_enterprise_subgroup_rule(
            FILE, "not_a_dict", "TEST_001", self._enterprise_rule())
        assert result["status"] == "FAILED"

    def test_custom_field_names(self):
        """Test with custom field names in params."""
        payload = {
            "org_name": "FOOD",
            "org_subgroup": "EMEA",
        }
        rule = self._enterprise_rule({"params": {
            "enterprise_field": "org_name",
            "subgroup_field": "org_subgroup",
            "no_subgroup_enterprises": ["FOOD"],
            "subgroup_mandatory_enterprises": ["CORP"],
        }})
        result = apply_enterprise_subgroup_rule(
            FILE, payload, "TEST_001", rule)
        assert result["status"] == "FAILED"
        assert "must not have subgroup" in result["message"].lower()

    def test_case_insensitive_enterprise_matching(self):
        """Test that enterprise name matching is case-insensitive."""
        payload = {
            "enterprise_or_func_name": "agtr",  # lowercase
            "enterprise_or_func_subgrp_name": "",
        }
        result = apply_enterprise_subgroup_rule(
            FILE, payload, "TEST_001", self._enterprise_rule())
        assert result["status"] == "PASSED"


# ===========================================================================
# build_result / build_file_summary_result
# ===========================================================================
class TestBuildResult:
    def test_all_fields_present(self):
        r = build_result("R1", "rule_name", "PASSED", "ERROR",
                         FILE, "ok", "fix it", {"k": "v"})
        assert r["rule_id"] == "R1"
        assert r["rule_name"] == "rule_name"
        assert r["status"] == "PASSED"
        assert r["severity"] == "ERROR"
        assert r["file_path"] == FILE
        assert r["message"] == "ok"
        assert r["recommendation"] == "fix it"
        assert r["evidence"] == {"k": "v"}

    def test_evidence_defaults_to_empty_dict(self):
        r = build_result("R1", "rule_name", "PASSED", "ERROR", FILE, "ok")
        assert r["evidence"] == {}


class TestBuildFileSummaryResult:
    def test_passed_summary(self):
        r = build_file_summary_result(
            FILE, "PASSED", "All good", 5, 0, 5, {"env": "dev"})
        assert r["rule_id"] == "FILE_SUMMARY"
        assert r["status"] == "PASSED"
        assert r["severity"] == "INFO"
        assert r["evidence"]["passed_rules"] == 5
        assert r["evidence"]["env"] == "dev"

    def test_failed_summary(self):
        r = build_file_summary_result(
            FILE, "FAILED", "Some failed", 3, 2, 5, {"env": "dev"})
        assert r["status"] == "FAILED"
        assert r["severity"] == "ERROR"
        assert r["evidence"]["failed_rules"] == 2

    def test_no_context(self):
        r = build_file_summary_result(FILE, "PASSED", "ok", 1, 0, 1, None)
        assert r["evidence"]["env"] is None


# ===========================================================================
# load_yaml_or_json
# ===========================================================================
class TestLoadYamlOrJson:
    def test_load_yaml(self, tmp_path):
        f = tmp_path / "data.yaml"
        f.write_text("key: value\n", encoding="utf-8")
        assert load_yaml_or_json(str(f)) == {"key": "value"}

    def test_load_json(self, tmp_path):
        f = tmp_path / "data.json"
        f.write_text('{"key": "value"}', encoding="utf-8")
        assert load_yaml_or_json(str(f)) == {"key": "value"}

    def test_returns_none_for_missing_file(self):
        assert load_yaml_or_json("nonexistent_file.yaml") is None

    def test_returns_none_for_invalid_yaml(self, tmp_path):
        f = tmp_path / "bad.yaml"
        f.write_text(": :\n  - bad: [unclosed", encoding="utf-8")
        # invalid YAML should return None (exception swallowed)
        result = load_yaml_or_json(str(f))
        assert result is None or isinstance(result, (dict, type(None)))


# ===========================================================================
# validate (integration tests using temp YAML files)
# ===========================================================================
RULES = {
    "LH_DB_001": {
        "name": "allowed_database_layers_in_name",
        "enabled": True,
        "severity": "ERROR",
        "type": "allowed_values_in_name",
        "target_field": "database_name",
        "params": {
            "allowed_values": ["raw", "raw_serving", "cdp"],
            "disallowed_values": ["curated", "serving"],
        },
        "message": "Disallowed layer: {disallowed_values_found}",
        "recommendation": "Use raw/raw_serving/cdp",
    },
    "LH_DB_002": {
        "name": "s3_bucket_naming_convention",
        "enabled": True,
        "severity": "ERROR",
        "type": "regex_match",
        "target_field": "database_s3_location",
        "params": {"pattern": r"^s3://${env}-lh1-(agtr|food|spec|corp(?:-[a-z0-9]+)?)-[a-z0-9-]+(?:/[a-z0-9/_-]+)*/?$"},
        "message": "S3 location mismatch",
        "recommendation": "Check bucket naming",
    },
    "LH_DB_005": {
        "name": "enterprise_subgroup_rule",
        "enabled": True,
        "severity": "ERROR",
        "type": "enterprise_subgroup_check",
        "target_field": ".",
        "params": {
            "enterprise_field": "enterprise_or_func_name",
            "subgroup_field": "enterprise_or_func_subgrp_name",
            "no_subgroup_enterprises": ["AGTR", "FOOD", "SPEC"],
            "subgroup_mandatory_enterprises": ["CORP"],
        },
        "message": "Invalid enterprise/subgroup",
        "recommendation": "Fix combination",
    },
}


@pytest.fixture()
def valid_yaml_file(tmp_path):
    data = {
        "database_name": "lh_cmc_raw_dev",
        "database_s3_location": "s3://dev-lh1-agtr-src/raw/current/dev/",
        "enterprise_or_func_name": "AGTR",
        "enterprise_or_func_subgrp_name": "",
    }
    f = tmp_path / "valid.yaml"
    f.write_text(yaml.dump(data), encoding="utf-8")
    return str(f)


@pytest.fixture()
def invalid_yaml_file(tmp_path):
    data = {
        "database_name": "lh_cmc_serving_dev",          # disallowed: serving
        "database_s3_location": "s3://prd-lh1-agtr-src/raw/",  # wrong env
        "enterprise_or_func_name": "AGTR",
        "enterprise_or_func_subgrp_name": "TDA",         # shouldn't have subgroup
    }
    f = tmp_path / "invalid.yaml"
    f.write_text(yaml.dump(data), encoding="utf-8")
    return str(f)


class TestValidate:
    def test_all_rules_pass_on_valid_file(self, valid_yaml_file):
        results = validate([valid_yaml_file], rules=RULES,
                           context={"env": "dev"})
        rule_results = [r for r in results if r["rule_id"] != "FILE_SUMMARY"]
        failed = [r for r in rule_results if r["status"] != "PASSED"]
        assert failed == [], f"Unexpected failures: {failed}"

    def test_file_summary_passed_for_valid_file(self, valid_yaml_file):
        results = validate([valid_yaml_file], rules=RULES,
                           context={"env": "dev"})
        summary = next(r for r in results if r["rule_id"] == "FILE_SUMMARY")
        assert summary["status"] == "PASSED"

    def test_invalid_file_produces_failures(self, invalid_yaml_file):
        results = validate([invalid_yaml_file], rules=RULES,
                           context={"env": "dev"})
        rule_results = [r for r in results if r["rule_id"] != "FILE_SUMMARY"]
        failed = [r for r in rule_results if r["status"] == "FAILED"]
        assert len(failed) > 0

    def test_file_summary_failed_for_invalid_file(self, invalid_yaml_file):
        results = validate([invalid_yaml_file], rules=RULES,
                           context={"env": "dev"})
        summary = next(r for r in results if r["rule_id"] == "FILE_SUMMARY")
        assert summary["status"] == "FAILED"

    def test_unreadable_file_returns_file_load_error(self, tmp_path):
        results = validate([str(tmp_path / "missing.yaml")],
                           rules=RULES, context={"env": "dev"})
        error = next(
            (r for r in results if r["rule_id"] == "FILE_LOAD_ERROR"), None)
        assert error is not None
        assert error["status"] == "FAILED"

    def test_disabled_rule_not_evaluated(self, valid_yaml_file):
        rules_with_disabled = dict(RULES)
        rules_with_disabled["LH_DB_001"] = {
            **RULES["LH_DB_001"], "enabled": False}
        results = validate([valid_yaml_file],
                           rules=rules_with_disabled, context={"env": "dev"})
        rule_ids = [r["rule_id"] for r in results]
        assert "LH_DB_001" not in rule_ids

    def test_unsupported_rule_type_returns_failed(self, valid_yaml_file):
        rules_with_unknown = {
            "X001": {
                "name": "unknown_type",
                "enabled": True,
                "severity": "ERROR",
                "type": "unsupported_type",
                "target_field": "database_name",
                "params": {},
                "message": "N/A",
                "recommendation": "N/A",
            }
        }
        results = validate([valid_yaml_file],
                           rules=rules_with_unknown, context={"env": "dev"})
        r = next(r for r in results if r["rule_id"] == "X001")
        assert r["status"] == "FAILED"
        assert "Unsupported rule type" in r["message"]

    def test_context_variable_substituted_in_pattern(self, valid_yaml_file):
        """Ensure $env in the pattern is replaced before regex evaluation."""
        results = validate([valid_yaml_file], rules=RULES,
                           context={"env": "dev"})
        lh_db_002 = next(r for r in results if r["rule_id"] == "LH_DB_002")
        assert lh_db_002["status"] == "PASSED"

    def test_empty_rules_produces_only_summary(self, valid_yaml_file):
        results = validate([valid_yaml_file], rules={}, context={"env": "dev"})
        assert all(r["rule_id"] == "FILE_SUMMARY" for r in results)

    def test_multiple_files_each_get_summary(
            self, valid_yaml_file, invalid_yaml_file):
        results = validate([valid_yaml_file, invalid_yaml_file],
                           rules=RULES, context={"env": "dev"})
        summaries = [r for r in results if r["rule_id"] == "FILE_SUMMARY"]
        assert len(summaries) == 2
