import unittest
from unittest.mock import patch, mock_open
import os
import sys
import importlib

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(BASE_DIR, "src"))

# ✅ Update module path if needed
MODULE_NAME = "validation_framework.validators.object_scope_rp"
validator = importlib.import_module(MODULE_NAME)


class TestObjectScopeRP(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.file_path = "test.yaml"

        cls.sample_payload = {
            "intake_id": "M1234567"
        }

        cls.rules = {
            "RP_001": {
                "name": "validate_intake_id",
                "enabled": True,
                "severity": "ERROR",
                "type": "regex_match",
                "target_field": "intake_id",
                "params": {
                    "pattern": "^M[0-9]{7}$"
                },
                "message": "Invalid intake_id format",
                "recommendation": "Use format M#######"
            }
        }

    # ============================================================
    # RESULT BUILDERS
    # ============================================================

    def test_build_result(self):
        res = validator.build_result("R1", "rule", "PASSED", "ERROR", "file", "msg")
        self.assertEqual(res["status"], "PASSED")
        self.assertEqual(res["rule_id"], "R1")

    def test_build_summary(self):
        res = validator.build_file_summary_result(
            "file.yaml", "PASSED", "msg", 1, 0, 0, 1, {"env": "dev"}
        )
        self.assertEqual(res["status"], "PASSED")
        self.assertEqual(res["evidence"]["env"], "dev")

    # ============================================================
    # FILE LOADER
    # ============================================================

    @patch("builtins.open", new_callable=mock_open, read_data='{"intake_id":"M1234567"}')
    def test_load_json(self, mock_file):
        res = validator.load_yaml_or_json("file.json")
        self.assertEqual(res, {"intake_id": "M1234567"})

    @patch("builtins.open", new_callable=mock_open, read_data="intake_id: M1234567")
    def test_load_yaml(self, mock_file):
        res = validator.load_yaml_or_json("file.yaml")
        self.assertEqual(res, {"intake_id": "M1234567"})

    @patch("builtins.open", side_effect=Exception("error"))
    def test_load_fail(self, mock_file):
        res = validator.load_yaml_or_json("file.yaml")
        self.assertIsNone(res)

    # ============================================================
    # REGEX MATCH
    # ============================================================

    def test_regex_match_pass(self):
        rule = self.rules["RP_001"]

        res = validator._regex_match(
            "RP_001", rule, self.sample_payload, self.file_path
        )

        self.assertEqual(res["status"], "PASSED")

    def test_regex_match_fail(self):
        payload = {"intake_id": "INVALID"}
        rule = self.rules["RP_001"]

        res = validator._regex_match(
            "RP_001", rule, payload, self.file_path
        )

        self.assertEqual(res["status"], "FAILED")

    def test_regex_missing_pattern(self):
        rule = {
            "name": "bad_rule",
            "severity": "ERROR",
            "target_field": "intake_id",
            "params": {}
        }

        res = validator._regex_match(
            "RP_002", rule, self.sample_payload, self.file_path
        )

        self.assertEqual(res["status"], "FAILED")
        self.assertIn("pattern", res["message"].lower())

    # ============================================================
    # VALIDATE FUNCTION
    # ============================================================

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_pass(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        results = validator.validate(["file.yaml"], self.rules)

        statuses = [r["status"] for r in results]
        self.assertIn("PASSED", statuses)

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_fail(self, mock_loader):
        mock_loader.return_value = {"intake_id": "BAD"}

        results = validator.validate(["file.yaml"], self.rules)

        statuses = [r["status"] for r in results]
        self.assertIn("FAILED", statuses)

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_file_error(self, mock_loader):
        mock_loader.return_value = None

        results = validator.validate(["file.yaml"], self.rules)

        self.assertEqual(results[0]["rule_id"], "FILE_LOAD_ERROR")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_unsupported_rule(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        rules = {
            "BAD_RULE": {
                "name": "bad",
                "type": "unknown",
                "severity": "ERROR"
            }
        }

        results = validator.validate(["file.yaml"], rules)

        self.assertEqual(results[0]["status"], "FAILED")
        self.assertIn("Unsupported", results[0]["message"])

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_summary_present(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        results = validator.validate(["file.yaml"], self.rules)

        summary = [r for r in results if r["rule_id"] == "FILE_SUMMARY"]
        self.assertEqual(len(summary), 1)

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_summary_failed(self, mock_loader):
        mock_loader.return_value = {"intake_id": "bad"}

        results = validator.validate(["file.yaml"], self.rules)

        summary = [r for r in results if r["rule_id"] == "FILE_SUMMARY"][0]
        self.assertEqual(summary["status"], "FAILED")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_summary_passed(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        results = validator.validate(["file.yaml"], self.rules)

        summary = [r for r in results if r["rule_id"] == "FILE_SUMMARY"][0]
        self.assertEqual(summary["status"], "PASSED")


if __name__ == "__main__":
    unittest.main()