import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from validation_framework.reporting import result_reporting as reporting


@pytest.fixture
def sample_results():
    return [
        {
            "rule_id": "R1",
            "rule_name": "rule_one",
            "status": "PASSED",
            "severity": "ERROR",
            "message": "ok",
            "file_path": "dummy_files/lakehouse-001/s3/dev-a.yaml",
            "rulepack_name": "rp_global",
            "resource_type": "s3",
        },
        {
            "rule_id": "R2",
            "rule_name": "rule_two",
            "status": "FAILED",
            "severity": "ERROR",
            "message": "failed",
            "recommendation": "fix it",
            "evidence": {"k": "v"},
            "file_path": "dummy_files/lakehouse-001/s3/dev-a.yaml",
            "rulepack_name": "rp_global",
            "resource_type": "s3",
        },
        {
            "rule_id": "R3",
            "rule_name": "rule_three",
            "status": "SKIPPED",
            "severity": "WARN",
            "message": "skip",
            "file_path": "dummy_files/lakehouse-001/glue_db/db-b.yaml",
            "rulepack_name": "rp_db",
            "resource_type": "glue_db",
        },
        {
            "rule_id": "FILE_SUMMARY",
            "status": "PASSED",
            "file_path": "dummy_files/lakehouse-001/s3/dev-a.yaml",
        },
    ]


def test_format_results_by_status(sample_results):
    grouped = reporting.format_results_by_status(sample_results)

    assert "dummy_files/lakehouse-001/s3/dev-a.yaml" in grouped["Passed"]
    assert "dummy_files/lakehouse-001/s3/dev-a.yaml" in grouped["Failed"]
    assert "dummy_files/lakehouse-001/glue_db/db-b.yaml" in grouped["Skipped"]


def test_summarize_results_counts(sample_results):
    summary = reporting.summarize_results(sample_results)

    assert summary["passed"] == 1
    assert summary["failed"] == 1
    assert summary["skipped"] == 1
    assert summary["failed_errors"] == 1
    assert summary["failed_warnings"] == 0
    assert summary["total_rules"] == 3


def test_build_file_summary_rows_excludes_skipped(sample_results):
    rows = reporting.build_file_summary_rows(sample_results)

    assert len(rows) == 1
    assert rows[0]["filename"] == "dev-a.yaml"
    assert rows[0]["passed"] == "1"
    assert rows[0]["failed_total"] == "1"
    assert rows[0]["verdict"] == "FAILED"


def test_build_detailed_csv_rows_shape(sample_results):
    rows = reporting.build_detailed_csv_rows(sample_results)

    assert len(rows) == 3
    failed_row = next(row for row in rows if row["status"] == "FAILED")
    parsed_error_info = json.loads(failed_row["error_info"])
    assert failed_row["resource_type"] == "s3"
    assert failed_row["file_name"] == "dev-a.yaml"
    assert failed_row["rulepack_name"] == "rp_global"
    assert parsed_error_info["rule_id"] == "R2"


def test_build_validation_results_text_respects_show_skipped(sample_results):
    grouped = reporting.format_results_by_status(sample_results)
    summary = reporting.summarize_results(sample_results)
    rows = reporting.build_file_summary_rows(sample_results)

    text_without_skipped = reporting.build_validation_results_text(
        grouped,
        summary,
        rows,
        show_passed=False,
        show_skipped=False,
    )
    assert "SKIPPED VALIDATIONS" not in text_without_skipped
    assert "2 total" in text_without_skipped

    text_with_skipped = reporting.build_validation_results_text(
        grouped,
        summary,
        rows,
        show_passed=False,
        show_skipped=True,
    )
    assert "SKIPPED VALIDATIONS" in text_with_skipped
    assert "3 total" in text_with_skipped


def test_write_csv_report_and_summary_table_file(tmp_path, sample_results):
    detailed_rows = reporting.build_detailed_csv_rows(sample_results)
    summary = reporting.summarize_results(sample_results)
    file_rows = reporting.build_file_summary_rows(sample_results)

    csv_path = tmp_path / "out.csv"
    summary_path = tmp_path / "summary.txt"

    reporting.write_csv_report(csv_path, detailed_rows)
    reporting.write_summary_table_file(summary_path, file_rows, summary, show_skipped=False)

    csv_content = csv_path.read_text(encoding="utf-8")
    summary_content = summary_path.read_text(encoding="utf-8")

    assert "resource_type,file_name,rulepack_name,status,error_info" in csv_content
    assert "VALIDATION SUMMARY" in summary_content
    assert "Summary:" in summary_content


def test_write_txt_report(tmp_path, sample_results):
    grouped = reporting.format_results_by_status(sample_results)
    summary = reporting.summarize_results(sample_results)
    file_rows = reporting.build_file_summary_rows(sample_results)

    txt_path = tmp_path / "report.txt"
    reporting.write_txt_report(
        txt_path,
        grouped,
        summary,
        file_rows,
        show_passed=True,
        show_skipped=False,
    )

    content = txt_path.read_text(encoding="utf-8")
    assert "VALIDATION RESULTS" in content
    assert "VALIDATION SUMMARY" in content
    assert "FAILED VALIDATIONS" in content
    assert "SKIPPED VALIDATIONS" not in content
