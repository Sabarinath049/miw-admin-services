import unittest
from unittest.mock import patch, mock_open
import os
import sys
import importlib

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(BASE_DIR, "src"))

# ✅ Update module path
MODULE_NAME = "validation_framework.validators.object_scope_smus_db"
validator = importlib.import_module(MODULE_NAME)


class TestObjectScopeSMUSDB(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.file_path = "test.yaml"

        cls.sample_payload = {
            "access_to_resources": {
                "glue_databases": [
                    "minerva_curated_db",
                    "minerva_serving_db",
                    "438465132548:minerva_dev_fdp_db_rl"
                ]
            }
        }

        cls.rules = {
            "DB_001": {
                "name": "allow_core_layers",
                "enabled": True,
                "severity": "ERROR",
                "type": "list_pattern_allowed",
                "target_field": "access_to_resources.glue_databases",
                "params": {
                    "allowed_patterns": ["_curated_", "_serving_"]
                },
                "message": "Only curated/serving allowed"
            },
            "DB_002": {
                "name": "block_raw_layers",
                "enabled": True,
                "severity": "ERROR",
                "type": "list_pattern_not_allowed",
                "target_field": "access_to_resources.glue_databases",
                "params": {
                    "disallowed_patterns": ["_raw_", "_fdp_"]
                },
                "message": "Raw/fdp not allowed"
            },
            "DB_003": {
                "name": "rl_validation",
                "enabled": True,
                "severity": "ERROR",
                "type": "list_conditional_pattern",
                "target_field": "access_to_resources.glue_databases",
                "params": {
                    "restricted_patterns": ["_fdp_"],
                    "exclude_patterns": [],
                    "allow_if_all": {
                        "contains": ["_rl"]
                    }
                },
                "message": "Invalid RL db"
            }
        }

    # ============================================================
    # HELPERS
    # ============================================================

    def test_get_nested_value(self):
        result = validator.get_nested_value(
            self.sample_payload, 
            "access_to_resources.glue_databases"
        )
        self.assertEqual(len(result), 3)

    def test_get_nested_value_missing(self):
        result = validator.get_nested_value(self.sample_payload, "invalid.path")
        self.assertEqual(result, [])

    # ============================================================
    # FILE LOADER
    # ============================================================

    @patch("builtins.open", new_callable=mock_open, read_data='{"a":1}')
    def test_load_json(self, mock_file):
        res = validator.load_yaml_or_json("file.json")
        self.assertEqual(res, {"a": 1})

    @patch("builtins.open", new_callable=mock_open, read_data="a: 1")
    def test_load_yaml(self, mock_file):
        res = validator.load_yaml_or_json("file.yaml")
        self.assertEqual(res, {"a": 1})

    @patch("builtins.open", side_effect=Exception("error"))
    def test_load_fail(self, mock_file):
        res = validator.load_yaml_or_json("file.yaml")
        self.assertIsNone(res)

    # ============================================================
    # LIST PATTERN ALLOWED
    # ============================================================

    def test_list_pattern_allowed_pass(self):
        payload = {
            "access_to_resources": {
                "glue_databases": ["abc_curated_db", "xyz_serving_db"]
            }
        }
        rule = self.rules["DB_001"]

        res = validator._list_pattern_allowed("DB_001", rule, payload, self.file_path)
        self.assertEqual(res["status"], "PASSED")

    def test_list_pattern_allowed_skip_invalid(self):
        rule = self.rules["DB_001"]

        res = validator._list_pattern_allowed("DB_001", rule, self.sample_payload, self.file_path)
        self.assertEqual(res["status"], "SKIPPED")

    # ============================================================
    # LIST PATTERN NOT ALLOWED
    # ============================================================

    def test_list_pattern_not_allowed_fail(self):
        payload = {
            "access_to_resources": {
                "glue_databases": ["abc_fdp_db"]
            }
        }
        rule = self.rules["DB_002"]

        res = validator._list_pattern_not_allowed("DB_002", rule, payload, self.file_path)
        self.assertEqual(res["status"], "FAILED")

    def test_list_pattern_not_allowed_pass(self):
        payload = {
            "access_to_resources": {
                "glue_databases": ["abc_curated_db"]
            }
        }
        rule = self.rules["DB_002"]

        res = validator._list_pattern_not_allowed("DB_002", rule, payload, self.file_path)
        self.assertEqual(res["status"], "PASSED")

    def test_rl_exception_allowed(self):
        # ✅ RL exception case
        payload = {
            "access_to_resources": {
                "glue_databases": ["438465132548:minerva_dev_fdp_db_rl"]
            }
        }
        rule = self.rules["DB_002"]

        res = validator._list_pattern_not_allowed("DB_002", rule, payload, self.file_path)
        self.assertEqual(res["status"], "PASSED")

    # ============================================================
    # LIST CONDITIONAL PATTERN
    # ============================================================

    def test_list_conditional_pattern_pass(self):
        payload = {
            "access_to_resources": {
                "glue_databases": [
                    "438465132548:minerva_dev_fdp_db_rl"
                ]
            }
        }
        rule = self.rules["DB_003"]

        res = validator._list_conditional_pattern(
            "DB_003", rule, payload, self.file_path, context={}
        )
        self.assertEqual(res["status"], "PASSED")

    def test_list_conditional_pattern_skip(self):
        payload = {
            "access_to_resources": {
                "glue_databases": ["abc_fdp_db"]
            }
        }
        rule = self.rules["DB_003"]

        res = validator._list_conditional_pattern(
            "DB_003", rule, payload, self.file_path, context={}
        )
        self.assertEqual(res["status"], "SKIPPED")

    def test_list_conditional_pattern_excluded(self):
        payload = {
            "access_to_resources": {
                "glue_databases": ["abc_ignore_fdp_db"]
            }
        }

        rule = {
            **self.rules["DB_003"],
            "params": {
                "restricted_patterns": ["_fdp_"],
                "exclude_patterns": ["ignore"],
                "allow_if_all": {"contains": ["_rl"]}
            }
        }

        res = validator._list_conditional_pattern(
            "DB_003", rule, payload, self.file_path, context={}
        )
        self.assertEqual(res["status"], "PASSED")

    # ============================================================
    # VALIDATE FUNCTION
    # ============================================================

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_success(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        results = validator.validate(["file.yaml"], self.rules)

        statuses = [r["status"] for r in results]
        self.assertIn("PASSED", statuses)

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_fail(self, mock_loader):
        payload = {
            "access_to_resources": {
                "glue_databases": ["abc_fdp_db"]
            }
        }
        mock_loader.return_value = payload

        results = validator.validate(["file.yaml"], self.rules)

        statuses = [r["status"] for r in results]
        self.assertIn("FAILED", statuses)

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_file_error(self, mock_loader):
        mock_loader.return_value = None

        results = validator.validate(["file.yaml"], self.rules)

        self.assertEqual(results[0]["rule_id"], "FILE_LOAD_ERROR")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_summary(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        results = validator.validate(["file.yaml"], self.rules)

        summary = [r for r in results if r["rule_id"] == "FILE_SUMMARY"]
        self.assertEqual(len(summary), 1)


if __name__ == "__main__":
    unittest.main()