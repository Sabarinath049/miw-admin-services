"""
Comprehensive pytest tests for IAM Validation Rules

Tests cover:
- LH_IAM_001 / CMP_IAM_001: IAM role naming convention checks
- LH_IAM_002 / CMP_IAM_002: IAM Glue DB access matrix validation
- LH_IAM_003 / CMP_IAM_003: Resource Link write permission checks
- LH_IAM_004 / CMP_IAM_004: IAM data_prefix naming convention checks
"""

import unittest
from unittest.mock import patch, mock_open
import importlib
import os
import sys
import tempfile
import json
import yaml

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(BASE_DIR, "src"))

MODULE_NAME = "validation_framework.validators.iam_check"
validator = importlib.import_module(MODULE_NAME)


class TestIAMHelpers(unittest.TestCase):
    """Test helper functions used by IAM validators."""

    def test_load_yaml_or_json_yaml(self):
        """Test loading a valid YAML file."""
        yaml_content = "role_name: test_role\naws_account_id: 123456789"
        with patch("builtins.open", mock_open(read_data=yaml_content)):
            result = validator.load_yaml_or_json("test.yaml")
            self.assertIsNotNone(result)
            self.assertEqual(result["role_name"], "test_role")

    def test_load_yaml_or_json_json(self):
        """Test loading a valid JSON file."""
        json_content = '{"role_name": "test_role", "aws_account_id": 123456789}'
        with patch("builtins.open", mock_open(read_data=json_content)):
            result = validator.load_yaml_or_json("test.json")
            self.assertIsNotNone(result)
            self.assertEqual(result["role_name"], "test_role")

    def test_load_yaml_or_json_invalid_file(self):
        """Test loading an invalid file."""
        with patch("builtins.open", side_effect=Exception("File not found")):
            result = validator.load_yaml_or_json("nonexistent.yaml")
            self.assertIsNone(result)

    def test_extract_role_type_procdataengineer(self):
        """Test extracting role type from procdataengineer role."""
        role_name = "agtr_apac_dev_procdataengineer"
        role_type = validator.extract_role_type(role_name)
        self.assertEqual(role_type, "procdataengineer")

    def test_extract_role_type_procingestionengineer(self):
        """Test extracting role type from procingestionengineer role."""
        role_name = "corp_dtd_dev_procingestionengineer"
        role_type = validator.extract_role_type(role_name)
        self.assertEqual(role_type, "procingestionengineer")

    def test_extract_role_type_snfcatalogfed(self):
        """Test extracting role type from snfcatalogfed role."""
        role_name = "minerva_corp_dev_snfcatalogfed"
        role_type = validator.extract_role_type(role_name)
        self.assertEqual(role_type, "snfcatalogfed")

    def test_extract_role_type_prd_environment(self):
        """Test extracting role type from production environment."""
        role_name = "minerva_data_prd_procegressengineer"
        role_type = validator.extract_role_type(role_name)
        self.assertEqual(role_type, "procegressengineer")

    def test_extract_role_type_empty(self):
        """Test extracting role type from empty role name."""
        role_type = validator.extract_role_type("")
        self.assertEqual(role_type, "")

    def test_extract_role_type_no_env(self):
        """Test extracting role type when no env marker present."""
        role_name = "role_without_env"
        role_type = validator.extract_role_type(role_name)
        self.assertEqual(role_type, "")

    def test_check_layer_type_match_suffix(self):
        """Test suffix matching for layer types."""
        layer_type_patterns = {
            "resource_link": {"match_type": "suffix", "pattern": "_rl"}
        }
        # Should match suffix
        self.assertTrue(validator.check_layer_type_match(
            "lkc-myrp67_rl", "resource_link", layer_type_patterns
        ))
        # Should not match
        self.assertFalse(validator.check_layer_type_match(
            "raw", "resource_link", layer_type_patterns
        ))

    def test_check_layer_type_match_prefix(self):
        """Test prefix matching for layer types."""
        layer_type_patterns = {
            "tableflow": {"match_type": "prefix", "pattern": "lkc-"}
        }
        # Should match prefix
        self.assertTrue(validator.check_layer_type_match(
            "lkc-myrp67", "tableflow", layer_type_patterns
        ))
        # Should not match
        self.assertFalse(validator.check_layer_type_match(
            "raw", "tableflow", layer_type_patterns
        ))

    def test_check_layer_type_match_substring_fallback(self):
        """Test substring matching as fallback."""
        layer_type_patterns = {}
        # Substring fallback matching
        self.assertTrue(validator.check_layer_type_match(
            "raw", "raw", layer_type_patterns
        ))
        self.assertTrue(validator.check_layer_type_match(
            "raw_serving", "raw", layer_type_patterns
        ))


class TestIAMRoleNamingConvention(unittest.TestCase):
    """Test LH_IAM_001 / CMP_IAM_001: IAM role naming convention checks."""

    def setUp(self):
        """Set up common test data."""
        self.file_path = "test_iam.yaml"
        self.rule = {
            "name": "lakehouse_iam_role_naming_convention_check",
            "severity": "ERROR",
            "params": {
                "role_patterns": {
                    "procdataengineer": "^[a-z0-9]+_[a-z0-9_]+_(dev|prd|sbx)_procdataengineer$",
                    "procingestionengineer": "^corp_dtd_(dev|prd|sbx)_procingestionengineer$",
                    "procintegratedingestionengineer": "^[a-z0-9]+_[a-z0-9_]+_(dev|prd|sbx)_procintegratedingestionengineer$",
                    "procegressengineer": "^[a-z0-9]+_[a-z0-9_]+_(dev|prd|sbx)_procegressengineer$",
                    "snfcatalogfed": "^[a-z0-9]+(?:_[a-z0-9_]+)*_(dev|prd|sbx)_snfcatalogfed$",
                    "crwlrole": "^[a-z0-9]+_[a-z0-9_]+(?:_[a-z0-9_]+)?_(raw|raw_serving|cdp)_(dev|prd|sbx)_crwlrole$"
                },
                "deprecated_roles": ["snfcatalogfed"]
            },
            "message": "IAM role name does not follow the approved naming convention",
            "recommendation": "Use approved naming pattern for the account and role type"
        }

    def test_procdataengineer_naming_pass(self):
        """Test valid procdataengineer role name."""
        resource = {"role_name": "agtr_apac_dev_procdataengineer"}
        result = validator.check_iam_role_naming("LH_IAM_001", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")
        self.assertEqual(result["evidence"]["matched_type"], "procdataengineer")

    def test_procdataengineer_naming_pass_with_underscores(self):
        """Test procdataengineer role name with underscores in domain."""
        resource = {"role_name": "corp_fin_jarvis_prd_procdataengineer"}
        result = validator.check_iam_role_naming("LH_IAM_001", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_procingestionengineer_naming_pass(self):
        """Test valid procingestionengineer role name."""
        resource = {"role_name": "corp_dtd_dev_procingestionengineer"}
        result = validator.check_iam_role_naming("LH_IAM_001", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")
        self.assertEqual(result["evidence"]["matched_type"], "procingestionengineer")

    def test_procintegratedingestionengineer_naming_pass(self):
        """Test valid procintegratedingestionengineer role name."""
        resource = {"role_name": "agtr_apac_sbx_procintegratedingestionengineer"}
        result = validator.check_iam_role_naming("LH_IAM_001", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_procegressengineer_naming_pass(self):
        """Test valid procegressengineer role name."""
        resource = {"role_name": "minerva_data_prd_procegressengineer"}
        result = validator.check_iam_role_naming("LH_IAM_001", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_crwlrole_naming_pass(self):
        """Test valid crwlrole name."""
        resource = {"role_name": "minerva_data_scripts_raw_dev_crwlrole"}
        result = validator.check_iam_role_naming("LH_IAM_001", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_deprecated_role_snfcatalogfed_fail(self):
        """Test that deprecated snfcatalogfed role is rejected."""
        resource = {"role_name": "minerva_corp_dev_snfcatalogfed"}
        result = validator.check_iam_role_naming("LH_IAM_001", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("deprecated", result["message"].lower())
        self.assertEqual(result["evidence"]["deprecated_role"], "snfcatalogfed")

    def test_empty_role_name_fail(self):
        """Test that empty role name fails."""
        resource = {"role_name": ""}
        result = validator.check_iam_role_naming("LH_IAM_001", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("cannot be empty", result["message"])

    def test_invalid_naming_pattern_fail(self):
        """Test that invalid role name fails."""
        resource = {"role_name": "invalid_role_name_xyz"}
        result = validator.check_iam_role_naming("LH_IAM_001", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("does not follow approved naming convention", result["message"])

    def test_missing_environment_marker_fail(self):
        """Test role name without environment marker fails."""
        resource = {"role_name": "agtr_apac_procdataengineer"}  # Missing dev/prd/sbx
        result = validator.check_iam_role_naming("LH_IAM_001", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")

    def test_invalid_environment_marker_fail(self):
        """Test role name with invalid environment marker fails."""
        resource = {"role_name": "agtr_apac_staging_procdataengineer"}  # 'staging' not allowed
        result = validator.check_iam_role_naming("LH_IAM_001", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")


class TestGlueDBAccess(unittest.TestCase):
    """Test LH_IAM_002 / CMP_IAM_002: IAM Glue DB access matrix validation."""

    def setUp(self):
        """Set up common test data."""
        self.file_path = "test_iam_access.yaml"
        self.rule = {
            "name": "lakehouse_iam_glue_db_access_matrix_check",
            "severity": "ERROR",
            "params": {
                "layer_type_patterns": {
                    "resource_link": {"match_type": "suffix", "pattern": "_rl"},
                    "tableflow": {"match_type": "prefix", "pattern": "lkc-"}
                },
                "access_rules": {
                    "procdataengineer": {
                        "require_read": True,
                        "require_write": True,
                        "allowed_read_layers": ["raw", "raw_cdp", "internal", "tableflow", "resource_link"],
                        "allowed_write_layers": ["raw_serving", "internal"]
                    },
                    "procintegratedingestionengineer": {
                        "require_write": True,
                        "allowed_write_layers": ["raw"]
                    },
                    "procingestionengineer": {
                        "require_write": True,
                        "disallowed_write_layers": ["raw", "raw_cdp", "raw_serving"]
                    },
                    "procegressengineer": {
                        "require_read": True,
                        "allowed_read_layers": ["raw", "raw_cdp", "raw_serving"]
                    }
                }
            },
            "message": "IAM Glue DB access is not aligned with Lakehouse role policy",
            "recommendation": "Align Glue DB read/write permissions to approved role access matrix"
        }

    def test_procdataengineer_read_write_pass(self):
        """Test procdataengineer with read and write access passes."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "glue_databases": {
                    "read": ["raw", "raw_cdp"],
                    "write": ["raw_serving"]
                }
            }
        }
        result = validator.check_glue_db_access("LH_IAM_002", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_procdataengineer_tableflow_read_pass(self):
        """Test procdataengineer can read tableflow (prefix lkc-)."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "glue_databases": {
                    "read": ["lkc-myrp67"],
                    "write": ["raw_serving"]
                }
            }
        }
        result = validator.check_glue_db_access("LH_IAM_002", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_procdataengineer_resource_link_read_pass(self):
        """Test procdataengineer can read resource links (suffix _rl)."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "glue_databases": {
                    "read": ["578647603827:lkc-myrp67_rl"],
                    "write": ["raw_serving"]
                }
            }
        }
        result = validator.check_glue_db_access("LH_IAM_002", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_procdataengineer_missing_required_read_fail(self):
        """Test procdataengineer without required read access fails."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "glue_databases": {
                    "write": ["raw_serving"]
                }
            }
        }
        result = validator.check_glue_db_access("LH_IAM_002", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("requires read access", result["message"])

    def test_procdataengineer_missing_required_write_fail(self):
        """Test procdataengineer without required write access fails."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "glue_databases": {
                    "read": ["raw"]
                }
            }
        }
        result = validator.check_glue_db_access("LH_IAM_002", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("requires write access", result["message"])

    def test_procdataengineer_disallowed_write_layer_fail(self):
        """Test procdataengineer with disallowed write layer fails."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "glue_databases": {
                    "read": ["raw"],
                    "write": ["cdp"]  # cdp is not in allowed_write_layers
                }
            }
        }
        result = validator.check_glue_db_access("LH_IAM_002", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("not allowed", result["message"])

    def test_procingestionengineer_disallowed_write_fail(self):
        """Test procingestionengineer cannot write to disallowed layers."""
        resource = {
            "role_name": "corp_dtd_dev_procingestionengineer",
            "access_to_resources": {
                "glue_databases": {
                    "write": ["raw"]  # raw is in disallowed_write_layers
                }
            }
        }
        result = validator.check_glue_db_access("LH_IAM_002", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("disallowed", result["message"])

    def test_procegressengineer_read_only_pass(self):
        """Test procegressengineer with read-only access passes."""
        resource = {
            "role_name": "minerva_data_dev_procegressengineer",
            "access_to_resources": {
                "glue_databases": {
                    "read": ["raw", "raw_cdp"]
                }
            }
        }
        result = validator.check_glue_db_access("LH_IAM_002", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_no_glue_database_access_pass(self):
        """Test role with no Glue database access defined passes."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {}
        }
        result = validator.check_glue_db_access("LH_IAM_002", self.rule, resource, self.file_path)
        # Should pass since no access rules defined for this role type triggers "no specific rules"
        self.assertIn(result["status"], ["PASSED", "FAILED"])

    def test_single_layer_as_string_not_list(self):
        """Test handling of single layer as string instead of list."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "glue_databases": {
                    "read": "raw",  # String instead of list
                    "write": "raw_serving"
                }
            }
        }
        result = validator.check_glue_db_access("LH_IAM_002", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")


class TestNoResourceLinkWrite(unittest.TestCase):
    """Test LH_IAM_003 / CMP_IAM_003: Resource Link write permission checks."""

    def setUp(self):
        """Set up common test data."""
        self.file_path = "test_iam_rl.yaml"
        self.rule = {
            "name": "lakehouse_iam_no_resource_link_write_check",
            "severity": "ERROR",
            "message": "Resource Links write permission is not allowed",
            "recommendation": "Remove write grants on Resource Links"
        }

    def test_no_resource_link_write_pass(self):
        """Test role with no resource link write permissions passes."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "glue_databases": {
                    "read": ["raw"],
                    "write": ["raw_serving"]
                }
            }
        }
        result = validator.check_no_resource_link_write("LH_IAM_003", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_resource_link_write_fail(self):
        """Test that resource link write permission is rejected."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "glue_databases": {
                    "read": ["raw"],
                    "write": ["578647603827:lkc-myrp67_rl"]  # Resource link with _rl suffix
                }
            }
        }
        result = validator.check_no_resource_link_write("LH_IAM_003", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")
        self.assertEqual(result["evidence"]["layer_with_rl_write"], "578647603827:lkc-myrp67_rl")

    def test_resource_link_write_without_prefix_fail(self):
        """Test that resource link write without account prefix is rejected."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "glue_databases": {
                    "read": ["raw"],
                    "write": ["lkc-myrp67_rl"]  # Resource link with _rl suffix
                }
            }
        }
        result = validator.check_no_resource_link_write("LH_IAM_003", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")

    def test_resource_link_keyword_write_fail(self):
        """Test that write permission with 'resource_link' keyword is rejected."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "glue_databases": {
                    "write": ["resource_link"]
                }
            }
        }
        result = validator.check_no_resource_link_write("LH_IAM_003", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")

    def test_empty_write_layers_pass(self):
        """Test role with empty write layers passes."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "glue_databases": {
                    "read": ["raw"],
                    "write": []
                }
            }
        }
        result = validator.check_no_resource_link_write("LH_IAM_003", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_no_glue_database_access_pass(self):
        """Test role with no Glue database access passes."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {}
        }
        result = validator.check_no_resource_link_write("LH_IAM_003", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")


class TestDataPrefixNaming(unittest.TestCase):
    """Test LH_IAM_004 / CMP_IAM_004: IAM data_prefix naming convention checks."""

    def setUp(self):
        """Set up common test data."""
        self.file_path = "test_iam_s3.yaml"
        self.rule = {
            "name": "lakehouse_iam_data_prefix_naming_check",
            "severity": "ERROR",
            "params": {
                "nc1_bucket_pattern": "^minerva-(dev|prd|sbx)-(src|dp|scripts|eng-assets|ops)-[a-z0-9-]+$",
                "nc2_bucket_pattern": "^(dev|prd|sbx)-lh[0-9]+-[a-z0-9-]+-(src|dp|scripts|eng-assets|ops)$"
            },
            "message": "IAM data_prefixes do not follow approved naming conventions",
            "recommendation": "Each data_prefix must follow either NC1 (minerva-*) or NC2 (lh*-*) naming convention"
        }

    def test_nc1_bucket_naming_pass(self):
        """Test valid NC1 bucket naming passes."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "s3_prefixes": ["minerva-dev-src-agtr-apac"]
            }
        }
        result = validator.check_data_prefix_naming("LH_IAM_004", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_nc1_bucket_naming_ops_pass(self):
        """Test valid NC1 ops bucket naming passes."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "s3_prefixes": ["minerva-prd-ops-agtr-apac"]
            }
        }
        result = validator.check_data_prefix_naming("LH_IAM_004", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_nc2_bucket_naming_pass(self):
        """Test valid NC2 bucket naming passes."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "s3_prefixes": ["dev-lh1-agtr-apac-src"]
            }
        }
        result = validator.check_data_prefix_naming("LH_IAM_004", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_nc2_bucket_naming_dp_pass(self):
        """Test valid NC2 dp bucket naming passes."""
        resource = {
            "role_name": "agtr_apac_prd_procdataengineer",
            "access_to_resources": {
                "s3_prefixes": ["prd-lh2-agtr-apac-dp"]
            }
        }
        result = validator.check_data_prefix_naming("LH_IAM_004", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_multiple_buckets_all_valid_pass(self):
        """Test multiple valid buckets pass."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "s3_prefixes": [
                    "minerva-dev-src-agtr-apac",
                    "dev-lh1-agtr-apac-src",
                    "minerva-prd-ops-agtr-apac"
                ]
            }
        }
        result = validator.check_data_prefix_naming("LH_IAM_004", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_invalid_bucket_naming_fail(self):
        """Test invalid bucket naming fails."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "s3_prefixes": ["invalid-bucket-name"]
            }
        }
        result = validator.check_data_prefix_naming("LH_IAM_004", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")
        self.assertIn("invalid-bucket-name", result["evidence"]["invalid_prefixes"])

    def test_missing_environment_marker_fail(self):
        """Test bucket without environment marker fails."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "s3_prefixes": ["minerva-src-agtr-apac"]  # Missing dev/prd/sbx
            }
        }
        result = validator.check_data_prefix_naming("LH_IAM_004", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")

    def test_missing_purpose_marker_fail(self):
        """Test bucket without purpose marker fails."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "s3_prefixes": ["minerva-dev-agtr-apac"]  # Missing src/dp/scripts/eng-assets/ops
            }
        }
        result = validator.check_data_prefix_naming("LH_IAM_004", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")

    def test_nc2_invalid_lh_number_fail(self):
        """Test NC2 bucket with invalid lh number fails."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "s3_prefixes": ["dev-lha-agtr-apac-src"]  # lha instead of lh[0-9]
            }
        }
        result = validator.check_data_prefix_naming("LH_IAM_004", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")

    def test_empty_s3_prefixes_pass(self):
        """Test role with no S3 prefixes passes."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "s3_prefixes": []
            }
        }
        result = validator.check_data_prefix_naming("LH_IAM_004", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_no_s3_prefixes_field_pass(self):
        """Test role without s3_prefixes field passes."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {}
        }
        result = validator.check_data_prefix_naming("LH_IAM_004", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "PASSED")

    def test_mixed_valid_invalid_buckets_fail(self):
        """Test that one invalid bucket among valid ones fails."""
        resource = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "access_to_resources": {
                "s3_prefixes": [
                    "minerva-dev-src-agtr-apac",
                    "invalid-bucket",
                    "dev-lh1-agtr-apac-src"
                ]
            }
        }
        result = validator.check_data_prefix_naming("LH_IAM_004", self.rule, resource, self.file_path)
        self.assertEqual(result["status"], "FAILED")
        self.assertEqual(len(result["evidence"]["invalid_prefixes"]), 1)


class TestMainValidator(unittest.TestCase):
    """Test the main validate function."""

    def setUp(self):
        """Set up common test data."""
        self.rules = {
            "LH_IAM_001": {
                "enabled": True,
                "name": "lakehouse_iam_role_naming_convention_check",
                "type": "iam_role_name_check",
                "severity": "ERROR",
                "params": {
                    "role_patterns": {
                        "procdataengineer": "^[a-z0-9]+_[a-z0-9_]+_(dev|prd|sbx)_procdataengineer$"
                    },
                    "deprecated_roles": ["snfcatalogfed"]
                },
                "message": "IAM role name does not follow the approved naming convention",
                "recommendation": "Use approved naming pattern"
            }
        }

    @patch("validation_framework.validators.iam_check.load_yaml_or_json")
    def test_validate_passes_all_rules(self, mock_load):
        """Test validate function when all rules pass."""
        mock_load.return_value = {"role_name": "agtr_apac_dev_procdataengineer"}
        
        results = validator.validate(["test.yaml"], self.rules, context={"env": "dev"})
        
        # Results include actual rule results + FILE_SUMMARY
        self.assertGreater(len(results), 0)
        # Check for FILE_SUMMARY
        file_summary = [r for r in results if r["rule_id"] == "FILE_SUMMARY"]
        self.assertEqual(len(file_summary), 1)
        self.assertEqual(file_summary[0]["status"], "PASSED")

    @patch("validation_framework.validators.iam_check.load_yaml_or_json")
    def test_validate_fails_rule(self, mock_load):
        """Test validate function when a rule fails."""
        mock_load.return_value = {"role_name": "invalid_role"}
        
        results = validator.validate(["test.yaml"], self.rules, context={"env": "dev"})
        
        file_summary = [r for r in results if r["rule_id"] == "FILE_SUMMARY"]
        self.assertEqual(len(file_summary), 1)
        self.assertEqual(file_summary[0]["status"], "FAILED")
        self.assertEqual(file_summary[0]["evidence"]["failed_rules"], 1)

    @patch("validation_framework.validators.iam_check.load_yaml_or_json")
    def test_validate_file_load_error(self, mock_load):
        """Test validate function when file cannot be loaded."""
        mock_load.return_value = None
        
        results = validator.validate(["nonexistent.yaml"], self.rules)
        
        error_result = [r for r in results if r["rule_id"] == "FILE_LOAD_ERROR"]
        self.assertEqual(len(error_result), 1)
        self.assertEqual(error_result[0]["status"], "FAILED")

    def test_validate_skips_disabled_rules(self):
        """Test that validate skips disabled rules."""
        disabled_rules = self.rules.copy()
        disabled_rules["LH_IAM_001"]["enabled"] = False
        
        with patch("validation_framework.validators.iam_check.load_yaml_or_json") as mock_load:
            mock_load.return_value = {"role_name": "agtr_apac_dev_procdataengineer"}
            
            results = validator.validate(["test.yaml"], disabled_rules)
            
            file_summary = [r for r in results if r["rule_id"] == "FILE_SUMMARY"]
            # No rules should be applied since the only rule is disabled
            self.assertEqual(file_summary[0]["evidence"]["passed_rules"], 0)


if __name__ == "__main__":
    unittest.main()
