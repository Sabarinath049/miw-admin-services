"""
Pytest unit tests for resource_policy_check.py
"""

from validation_framework.validators.resource_policy_check import (
    apply_allowed_values_in_name_rule,
    apply_non_empty_check_rule,
    apply_regex_rule,
    build_file_summary_result,
    build_result,
    get_nested_value,
    load_yaml_or_json,
    replace_context_tokens,
    resolve_rule_with_context,
    validate,
)
import os
import sys

import pytest
import yaml

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


FILE = "resource_policy.yaml"


def _rule(overrides=None):
    base = {
        "name": "test_rule",
        "enabled": True,
        "severity": "ERROR",
        "type": "regex_match",
        "target_field": "field",
        "params": {"pattern": "^[a-z]+$"},
        "message": "Pattern mismatch",
        "recommendation": "Fix value",
    }
    if overrides:
        base.update(overrides)
    return base


class TestGetNestedValue:
    def test_simple_key(self):
        assert get_nested_value({"a": 1}, "a") == 1

    def test_nested_path(self):
        payload = {"access_to_resources": {"glue_databases": ["lake_cdp"]}}
        assert get_nested_value(
            payload, "access_to_resources.glue_databases") == ["lake_cdp"]

    def test_returns_payload_for_dot(self):
        payload = {"x": 1}
        assert get_nested_value(payload, ".") == payload

    def test_missing_key_returns_none(self):
        assert get_nested_value({"a": 1}, "b") is None


class TestContextReplacement:
    def test_replace_context_tokens_str(self):
        assert replace_context_tokens("$env", {"env": "dev"}) == "dev"

    def test_replace_context_tokens_nested(self):
        value = {"params": {"pattern": "^${env}-.*$"}}
        result = replace_context_tokens(value, {"env": "dev"})
        assert result["params"]["pattern"] == "^dev-.*$"

    def test_resolve_rule_with_context(self):
        rule = _rule({"params": {"pattern": "^${env}-.*$"}})
        resolved = resolve_rule_with_context(rule, {"env": "dev"})
        assert resolved["params"]["pattern"] == "^dev-.*$"


class TestAllowedValuesInName:
    def _allowed_rule(self):
        return {
            "name": "Resource_policy_db_name_pattern_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "allowed_values_in_name",
            "target_field": "access_to_resources.glue_databases",
            "params": {
                "allowed_values": ["cdp"],
                "disallowed_values": [
                    "raw_serving",
                    "raw",
                    "curated",
                    "serving"],
            },
            "message": "Disallowed layer found: {disallowed_values_found}",
            "recommendation": "Only cdp is allowed",
        }

    def test_passes_for_cdp_database_list(self):
        payload = {"access_to_resources": {
            "glue_databases": ["lh_fin_cdp_dev"]}}
        result = apply_allowed_values_in_name_rule(
            FILE, payload, "LH_RP_001", self._allowed_rule())
        assert result["status"] == "PASSED"

    def test_fails_for_disallowed_layer(self):
        payload = {"access_to_resources": {
            "glue_databases": ["lh_fin_raw_dev"]}}
        result = apply_allowed_values_in_name_rule(
            FILE, payload, "LH_RP_001", self._allowed_rule())
        assert result["status"] == "FAILED"
        assert "raw" in result["evidence"]["disallowed_values_found"]

    def test_fails_for_missing_allowed_token(self):
        payload = {"access_to_resources": {
            "glue_databases": ["lh_fin_unknown_dev"]}}
        result = apply_allowed_values_in_name_rule(
            FILE, payload, "LH_RP_001", self._allowed_rule())
        assert result["status"] == "FAILED"
        assert "values_missing_allowed" in result["evidence"]

    def test_fails_if_target_missing(self):
        payload = {"access_to_resources": {}}
        result = apply_allowed_values_in_name_rule(
            FILE, payload, "LH_RP_001", self._allowed_rule())
        assert result["status"] == "FAILED"
        assert "not found" in result["message"]

    def test_fails_if_not_string_or_list(self):
        payload = {"access_to_resources": {"glue_databases": 123}}
        result = apply_allowed_values_in_name_rule(
            FILE, payload, "LH_RP_001", self._allowed_rule())
        assert result["status"] == "FAILED"

    def test_lh_rp_001_fails_when_any_allowed_value_is_missing(self):
        payload = {"access_to_resources": {"glue_databases": ["lh_fin_cdp_dev"]}}
        rule = self._allowed_rule()
        rule["params"]["allowed_values"] = ["cdp", "raw"]
        rule["params"]["disallowed_values"] = ["raw_serving", "curated", "serving"]

        result = apply_allowed_values_in_name_rule(
            FILE, payload, "LH_RP_001", rule)

        assert result["status"] == "FAILED"
        assert result["evidence"]["missing_allowed_values"] == ["raw"]

    def test_lh_rp_001_passes_when_all_allowed_values_are_present(self):
        payload = {
            "access_to_resources": {
                "glue_databases": ["lh_fin_cdp_dev", "lh_fin_raw_dev"]
            }
        }
        rule = self._allowed_rule()
        rule["params"]["allowed_values"] = ["cdp", "raw"]
        rule["params"]["disallowed_values"] = ["raw_serving", "curated", "serving"]

        result = apply_allowed_values_in_name_rule(
            FILE, payload, "LH_RP_001", rule)

        assert result["status"] == "PASSED"


class TestRegexMatch:
    def _regex_rule(self):
        return {
            "name": "resource_policy_s3_prefix_naming_convention",
            "enabled": True,
            "severity": "ERROR",
            "type": "regex_match",
            "target_field": "access_to_resources.s3_prefixes",
            "params": {"pattern": r"^s3://[a-z0-9-]+/(cdp)/[a-z0-9/_-]+/?$"},
            "message": "S3 prefix should contain only cdp paths",
            "recommendation": "Use cdp paths",
        }

    def test_passes_for_valid_list(self):
        payload = {"access_to_resources": {
            "s3_prefixes": ["s3://dev-lh1-spec-src/cdp/path/"]}}
        result = apply_regex_rule(
            FILE, payload, "LH_RP_002", self._regex_rule())
        assert result["status"] == "PASSED"

    def test_fails_for_invalid_value_in_list(self):
        payload = {"access_to_resources": {
            "s3_prefixes": ["s3://dev-lh1-spec-src/raw/path/"]}}
        result = apply_regex_rule(
            FILE, payload, "LH_RP_002", self._regex_rule())
        assert result["status"] == "FAILED"
        assert "mismatched_values" in result["evidence"]

    def test_fails_for_missing_target(self):
        payload = {"access_to_resources": {}}
        result = apply_regex_rule(
            FILE, payload, "LH_RP_002", self._regex_rule())
        assert result["status"] == "FAILED"

    def test_fails_for_invalid_regex(self):
        payload = {"access_to_resources": {
            "s3_prefixes": ["s3://dev-lh1-spec-src/cdp/path/"]}}
        rule = self._regex_rule()
        rule["params"]["pattern"] = "^*invalid"
        result = apply_regex_rule(FILE, payload, "LH_RP_002", rule)
        assert result["status"] == "FAILED"
        assert "Invalid regex" in result["message"]

    def test_pattern_supports_payload_placeholders(self):
        payload = {"enterprise_or_func_name": "food", "access_to_resources": {
            "s3_prefixes": ["s3://dev-lh1-food-src/cdp/path/"]}, }
        rule = {
            "name": "resource_policy_s3_prefix_naming_convention",
            "enabled": True,
            "severity": "ERROR",
            "type": "regex_match",
            "target_field": "access_to_resources.s3_prefixes",
            "params": {
                "pattern": r"^s3://[a-z0-9-]+-${enterprise_or_func_name}-[a-z0-9-]+/cdp/[a-z0-9/_-]+/?$"},
            "message": "S3 prefix mismatch",
            "recommendation": "Fix path",
        }
        result = apply_regex_rule(FILE, payload, "LH_RP_002", rule)
        assert result["status"] == "PASSED"

    def test_pattern_placeholder_rendered_as_lowercase(self):
        payload = {"enterprise_or_func_name": "FOOD", "access_to_resources": {
            "s3_prefixes": ["s3://dev-lh1-food-src/cdp/path/"]}, }
        rule = {
            "name": "resource_policy_s3_prefix_naming_convention",
            "enabled": True,
            "severity": "ERROR",
            "type": "regex_match",
            "target_field": "access_to_resources.s3_prefixes",
            "params": {
                "pattern": r"^s3://[a-z0-9-]+-${enterprise_or_func_name}-[a-z0-9-]+/cdp/[a-z0-9/_-]+/?$"},
            "message": "S3 prefix mismatch",
            "recommendation": "Fix path",
        }
        result = apply_regex_rule(FILE, payload, "LH_RP_002", rule)
        assert result["status"] == "PASSED"

    def test_regex_uses_default_message_when_none(self):
        payload = {"access_to_resources": {
            "s3_prefixes": ["s3://dev-lh1-spec-src/raw/path/"]}}
        rule = self._regex_rule()
        rule["message"] = None
        result = apply_regex_rule(FILE, payload, "LH_RP_002", rule)
        assert result["status"] == "FAILED"
        assert result["message"] == "Target value does not match required regex pattern"


class TestNonEmptyCheck:
    def _non_empty_rule(self):
        return {
            "name": "Glue_databases_S3_Resource_Policy_NonEmpty_Check",
            "enabled": True,
            "severity": "ERROR",
            "type": "non_empty_check",
            "target_field": [
                "access_to_resources.glue_databases",
                "access_to_resources.s3_prefixes",
            ],
            "params": {
                "python_expression": [
                    "f\"len({access_to_resources.s3_prefixes})>0 or len({access_to_resources.glue_databases})>0\""
                ]
            },
            "message": "The resource policy should contain non-empty Glue databases or S3 prefixes.",
            "recommendation": "Include at least one Glue database or S3 prefix.",
        }

    def test_passes_when_glue_databases_non_empty(self):
        payload = {"access_to_resources": {
            "glue_databases": ["lh_fin_cdp_dev"], "s3_prefixes": []}}
        result = apply_non_empty_check_rule(
            FILE, payload, "LH_RP_003", self._non_empty_rule())
        assert result["status"] == "PASSED"

    def test_passes_when_s3_prefixes_non_empty(self):
        payload = {"access_to_resources": {
            "glue_databases": [], "s3_prefixes": ["s3://dev/cdp/x/"]}}
        result = apply_non_empty_check_rule(
            FILE, payload, "LH_RP_003", self._non_empty_rule())
        assert result["status"] == "PASSED"

    def test_fails_when_both_empty(self):
        payload = {"access_to_resources": {
            "glue_databases": [], "s3_prefixes": []}}
        result = apply_non_empty_check_rule(
            FILE, payload, "LH_RP_003", self._non_empty_rule())
        assert result["status"] == "FAILED"

    def test_fails_when_field_missing(self):
        payload = {"access_to_resources": {"glue_databases": []}}
        result = apply_non_empty_check_rule(
            FILE, payload, "LH_RP_003", self._non_empty_rule())
        assert result["status"] == "FAILED"
        assert "missing_fields" in result["evidence"]

    def test_regex_pattern_in_non_empty_rule_passes(self):
        payload = {"principal_role_arn": [
            "arn:aws:iam::123456789012:role/demo"]}
        rule = {
            "name": "Cross_Account_Role_ARN_Check",
            "enabled": True,
            "severity": "ERROR",
            "type": "non_empty_check",
            "target_field": "principal_role_arn",
            "params": {
                "python_expression": ["f\"len({principal_role_arn})>0\""],
                "regex_pattern": [r"^arn:aws:iam::[0-9]{12}:role/.+$"],
            },
            "message": "Invalid ARN",
            "recommendation": "Fix ARN",
        }
        result = apply_non_empty_check_rule(FILE, payload, "LH_RP_005", rule)
        assert result["status"] == "PASSED"

    def test_regex_pattern_in_non_empty_rule_fails(self):
        payload = {"principal_role_arn": ["invalid-arn"]}
        rule = {
            "name": "Cross_Account_Role_ARN_Check",
            "enabled": True,
            "severity": "ERROR",
            "type": "non_empty_check",
            "target_field": "principal_role_arn",
            "params": {
                "python_expression": ["f\"len({principal_role_arn})>0\""],
                "regex_pattern": [r"^arn:aws:iam::[0-9]{12}:role/.+$"],
            },
            "message": "Invalid ARN",
            "recommendation": "Fix ARN",
        }
        result = apply_non_empty_check_rule(FILE, payload, "LH_RP_005", rule)
        assert result["status"] == "FAILED"

    def test_non_empty_check_treats_empty_string_as_empty(self):
        payload = {
            "aws_account_id": "",
            "cross_account_aws_id": "",
        }
        rule = {
            "name": "Cross_Account_ID_Check",
            "enabled": True,
            "severity": "ERROR",
            "type": "non_empty_check",
            "target_field": ["cross_account_aws_id", "aws_account_id"],
            "params": {
                "python_expression": [
                    "f\"len({cross_account_aws_id})>0 or len({aws_account_id})>0\""
                ]
            },
            "message": "IDs should not be empty",
            "recommendation": "Provide account IDs",
        }
        result = apply_non_empty_check_rule(FILE, payload, "LH_RP_004", rule)
        assert result["status"] == "FAILED"

    def test_non_empty_check_treats_list_of_empty_strings_as_empty(self):
        payload = {
            "aws_account_id": ["   "],
            "cross_account_aws_id": [""],
        }
        rule = {
            "name": "Cross_Account_ID_Check",
            "enabled": True,
            "severity": "ERROR",
            "type": "non_empty_check",
            "target_field": ["cross_account_aws_id", "aws_account_id"],
            "params": {
                "python_expression": [
                    "f\"len({cross_account_aws_id})>0 or len({aws_account_id})>0\""
                ]
            },
            "message": "IDs should not be empty",
            "recommendation": "Provide account IDs",
        }
        result = apply_non_empty_check_rule(FILE, payload, "LH_RP_004", rule)
        assert result["status"] == "FAILED"

    def test_requires_aws_account_id_even_if_cross_account_id_exists(self):
        payload = {
            "aws_account_id": "",
            "cross_account_aws_id": "139823407693",
        }
        rule = {
            "name": "Cross_Account_ID_Check",
            "enabled": True,
            "severity": "ERROR",
            "type": "non_empty_check",
            "target_field": [
                "cross_account_aws_id",
                "aws_account_id"],
            "params": {
                "python_expression": ["f\"len({aws_account_id})>0\""]},
            "message": "The resource policy must contain aws_account_id.",
            "recommendation": "Ensure that aws_account_id is provided with a non-empty value.",
        }
        result = apply_non_empty_check_rule(FILE, payload, "LH_RP_004", rule)
        assert result["status"] == "FAILED"


class TestResultBuilders:
    def test_build_result(self):
        result = build_result("RULE_1", "name", "PASSED", "INFO", FILE, "ok")
        assert result["rule_id"] == "RULE_1"
        assert result["status"] == "PASSED"

    def test_build_result_maps_warning_severity_to_warning_status(self):
        result = build_result(
            "RULE_2", "name", "FAILED", "Warning", FILE, "warn")
        assert result["status"] == "WARNING"

    def test_build_file_summary_result(self):
        result = build_file_summary_result(
            FILE, "PASSED", "all good", 2, 0, 2, {"env": "dev"})
        assert result["rule_id"] == "FILE_SUMMARY"
        assert result["evidence"]["env"] == "dev"


class TestLoadYamlOrJson:
    def test_load_yaml(self, tmp_path):
        f = tmp_path / "input.yaml"
        f.write_text("a: 1\n", encoding="utf-8")
        assert load_yaml_or_json(str(f)) == {"a": 1}

    def test_load_json(self, tmp_path):
        f = tmp_path / "input.json"
        f.write_text('{"a": 1}', encoding="utf-8")
        assert load_yaml_or_json(str(f)) == {"a": 1}

    def test_load_missing_returns_none(self):
        assert load_yaml_or_json("missing-file.yaml") is None


RULES = {
    "LH_RP_001": {
        "name": "Resource_policy_db_name_pattern_check",
        "enabled": True,
        "severity": "ERROR",
        "type": "allowed_values_in_name",
        "target_field": "access_to_resources.glue_databases",
        "params": {
            "allowed_values": ["cdp"],
            "disallowed_values": ["raw_serving", "raw", "curated", "serving"],
        },
        "message": "Disallowed layer found: {disallowed_values_found}",
        "recommendation": "Only cdp is allowed",
    },
    "LH_RP_002": {
        "name": "resource_policy_s3_prefix_naming_convention",
        "enabled": True,
        "severity": "ERROR",
        "type": "regex_match",
        "target_field": "access_to_resources.s3_prefixes",
        "params": {"pattern": r"^s3://[a-z0-9-]+/(cdp)/[a-z0-9/_-]+/?$"},
        "message": "S3 prefix should contain only cdp paths",
        "recommendation": "Use cdp paths",
    },
    "LH_RP_003": {
        "name": "Glue_databases_S3_Resource_Policy_NonEmpty_Check",
        "enabled": True,
        "severity": "ERROR",
        "type": "non_empty_check",
        "target_field": [
            "access_to_resources.glue_databases",
            "access_to_resources.s3_prefixes",
        ],
        "params": {
            "python_expression": [
                "f\"len({access_to_resources.s3_prefixes})>0 or len({access_to_resources.glue_databases})>0\""
            ]
        },
        "message": "The resource policy should contain non-empty Glue databases or S3 prefixes.",
        "recommendation": "Include at least one Glue database or S3 prefix.",
    },
}


@pytest.fixture()
def valid_resource_policy_file(tmp_path):
    data = {
        "resource_policy_name": "minerva_dev_spec_tda_example_rp",
        "access_to_resources": {
            "glue_databases": ["lh_fin_cdp_dev"],
            "s3_prefixes": ["s3://dev-lh1-spec-src/cdp/current/dev/"],
        },
    }
    f = tmp_path / "valid_resource_policy.yaml"
    f.write_text(yaml.dump(data), encoding="utf-8")
    return str(f)


@pytest.fixture()
def invalid_resource_policy_file(tmp_path):
    data = {
        "resource_policy_name": "minerva_dev_spec_tda_example_rp",
        "access_to_resources": {
            "glue_databases": ["lh_fin_raw_dev"],
            "s3_prefixes": ["s3://dev-lh1-spec-src/raw/current/dev/"],
        },
    }
    f = tmp_path / "invalid_resource_policy.yaml"
    f.write_text(yaml.dump(data), encoding="utf-8")
    return str(f)


class TestValidate:
    def test_validate_passes_for_valid_file(self, valid_resource_policy_file):
        results = validate([valid_resource_policy_file],
                           RULES, context={"env": "dev"})
        rule_results = [r for r in results if r["rule_id"] != "FILE_SUMMARY"]
        assert all(r["status"] == "PASSED" for r in rule_results)

    def test_validate_fails_for_invalid_file(
            self, invalid_resource_policy_file):
        results = validate([invalid_resource_policy_file],
                           RULES, context={"env": "dev"})
        rule_results = [r for r in results if r["rule_id"] != "FILE_SUMMARY"]
        assert any(r["status"] == "FAILED" for r in rule_results)

    def test_validate_file_summary_exists(self, valid_resource_policy_file):
        results = validate([valid_resource_policy_file],
                           RULES, context={"env": "dev"})
        summary = next(
            (r for r in results if r["rule_id"] == "FILE_SUMMARY"), None)
        assert summary is not None

    def test_validate_handles_missing_file(self, tmp_path):
        missing_file = str(tmp_path / "missing.yaml")
        results = validate([missing_file], RULES, context={"env": "dev"})
        assert any(r["rule_id"] == "FILE_LOAD_ERROR" for r in results)

    def test_validate_unsupported_rule_type(self, valid_resource_policy_file):
        rules = {
            "X": {
                "name": "unsupported",
                "enabled": True,
                "severity": "ERROR",
                "type": "unknown_type",
            }
        }
        results = validate([valid_resource_policy_file],
                           rules, context={"env": "dev"})
        row = next(r for r in results if r["rule_id"] == "X")
        assert row["status"] == "FAILED"
        assert "Unsupported rule type" in row["message"]
