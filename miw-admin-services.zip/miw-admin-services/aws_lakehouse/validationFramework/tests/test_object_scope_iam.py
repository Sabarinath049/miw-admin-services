import unittest
from unittest.mock import patch, mock_open
import os
import sys
import importlib

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(BASE_DIR, "src"))

# ✅ Update this path if needed
MODULE_NAME = "validation_framework.validators.object_scope_iam"
validator = importlib.import_module(MODULE_NAME)


class TestObjectScopeIAM(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.file_path = "test.yaml"

        cls.sample_payload = {
            "role_name": "agtr_apac_dev_procdataengineer",
            "athena_workgroup_name": "wg1",
            "enable_glue_jobs": True
        }

        cls.rules = {
            "CP_IAM_SCOPE_001": {
                "name": "allow_proc_roles",
                "enabled": True,
                "severity": "ERROR",
                "type": "pattern_allowed",
                "target_field": "role_name",
                "params": {
                    "include_patterns": ["_procdataengineer"]
                },
                "message": "Valid role"
            },
            "CP_IAM_SCOPE_002": {
                "name": "block_ingestion_roles",
                "enabled": True,
                "severity": "ERROR",
                "type": "pattern_not_allowed",
                "target_field": "role_name",
                "params": {
                    "disallowed_patterns": ["_procingestionengineer"]
                },
                "message": "Invalid role"
            },
            "CP_IAM_SCOPE_004": {
                "name": "require_workgroup",
                "enabled": True,
                "severity": "ERROR",
                "type": "conditional_field_required",
                "params": {
                    "condition": {
                        "field": "role_name",
                        "operator": "contains",
                        "value": "_procdataengineer"
                    },
                    "required_field": "athena_workgroup_name"
                },
                "message": "Workgroup required"
            },
            "CP_IAM_SCOPE_005": {
                "name": "require_glue_flag",
                "enabled": True,
                "severity": "ERROR",
                "type": "conditional_field_required",
                "params": {
                    "condition": {
                        "field": "role_name",
                        "operator": "contains",
                        "value": "_procdataengineer"
                    },
                    "required_field": "enable_glue_jobs"
                },
                "message": "Glue flag required"
            }
        }

    # ============================================================
    # BUILDERS
    # ============================================================

    def test_build_result(self):
        res = validator.build_result("R1", "rule", "PASSED", "ERROR", "file", "msg")
        self.assertEqual(res["status"], "PASSED")
        self.assertEqual(res["rule_id"], "R1")

    def test_build_file_summary(self):
        res = validator.build_file_summary_result(
            "file", "PASSED", "msg", 1, 0, 0, 1, {"env": "dev"}
        )
        self.assertEqual(res["status"], "PASSED")
        self.assertEqual(res["evidence"]["env"], "dev")

    # ============================================================
    # FILE LOADER
    # ============================================================

    @patch("builtins.open", new_callable=mock_open, read_data='{"role_name":"abc"}')
    def test_load_json(self, mock_file):
        res = validator.load_yaml_or_json("file.json")
        self.assertEqual(res, {"role_name": "abc"})

    @patch("builtins.open", new_callable=mock_open, read_data="role_name: abc")
    def test_load_yaml(self, mock_file):
        res = validator.load_yaml_or_json("file.yaml")
        self.assertEqual(res, {"role_name": "abc"})

    @patch("builtins.open", side_effect=Exception("error"))
    def test_load_fail(self, mock_file):
        res = validator.load_yaml_or_json("file.yaml")
        self.assertIsNone(res)

    # ============================================================
    # PATTERN ALLOWED
    # ============================================================

    def test_pattern_allowed_pass(self):
        rule = self.rules["CP_IAM_SCOPE_001"]
        res = validator._pattern_allowed("R1", rule, self.sample_payload, self.file_path)
        self.assertEqual(res["status"], "PASSED")

    def test_pattern_allowed_fail(self):
        payload = {"role_name": "invalid_role"}
        rule = self.rules["CP_IAM_SCOPE_001"]

        res = validator._pattern_allowed("R1", rule, payload, self.file_path)
        self.assertEqual(res["status"], "FAILED")

    # ============================================================
    # PATTERN NOT ALLOWED
    # ============================================================

    def test_pattern_not_allowed_pass(self):
        rule = self.rules["CP_IAM_SCOPE_002"]
        res = validator._pattern_not_allowed("R2", rule, self.sample_payload, self.file_path)
        self.assertEqual(res["status"], "PASSED")

    def test_pattern_not_allowed_fail(self):
        payload = {"role_name": "abc_procingestionengineer"}
        rule = self.rules["CP_IAM_SCOPE_002"]

        res = validator._pattern_not_allowed("R2", rule, payload, self.file_path)
        self.assertEqual(res["status"], "FAILED")

    # ============================================================
    # CONDITIONAL REQUIRED FIELD
    # ============================================================

    def test_required_field_pass(self):
        rule = self.rules["CP_IAM_SCOPE_004"]
        res = validator._conditional_field_required("R3", rule, self.sample_payload, self.file_path)
        self.assertEqual(res["status"], "PASSED")

    def test_required_field_fail(self):
        payload = {"role_name": "agtr_procdataengineer"}
        rule = self.rules["CP_IAM_SCOPE_004"]

        res = validator._conditional_field_required("R3", rule, payload, self.file_path)
        self.assertEqual(res["status"], "FAILED")

    def test_required_field_skipped(self):
        payload = {"role_name": "other_role"}
        rule = self.rules["CP_IAM_SCOPE_004"]

        res = validator._conditional_field_required("R3", rule, payload, self.file_path)
        self.assertEqual(res["status"], "SKIPPED")

    # ============================================================
    # CONDITION EVALUATOR
    # ============================================================

    def test_condition_contains(self):
        cond = {"field": "role_name", "operator": "contains", "value": "_proc"}
        res = validator._evaluate_condition(self.sample_payload, cond)
        self.assertTrue(res)

    def test_condition_equals(self):
        cond = {"field": "role_name", "operator": "equals", "value": "abc"}
        res = validator._evaluate_condition(self.sample_payload, cond)
        self.assertFalse(res)

    def test_condition_exists(self):
        cond = {"field": "role_name", "operator": "exists"}
        res = validator._evaluate_condition(self.sample_payload, cond)
        self.assertTrue(res)

    # ============================================================
    # VALIDATE FUNCTION
    # ============================================================

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_success(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        results = validator.validate(["file.yaml"], self.rules)

        self.assertTrue(len(results) > 0)
        statuses = [r["status"] for r in results]
        self.assertIn("PASSED", statuses)

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_file_error(self, mock_loader):
        mock_loader.return_value = None

        results = validator.validate(["file.yaml"], self.rules)

        self.assertEqual(results[0]["rule_id"], "FILE_LOAD_ERROR")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_dependency_skip(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        results = validator.validate(["file.yaml"], self.rules)

        rule4 = [r for r in results if r["rule_id"] == "CP_IAM_SCOPE_004"][0]
        rule5 = [r for r in results if r["rule_id"] == "CP_IAM_SCOPE_005"][0]

        self.assertEqual(rule4["status"], "SKIPPED")
        self.assertEqual(rule5["status"], "SKIPPED")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_summary_present(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        results = validator.validate(["file.yaml"], self.rules)

        summary = [r for r in results if r["rule_id"] == "FILE_SUMMARY"]
        self.assertEqual(len(summary), 1)
        self.assertIn(summary[0]["status"], ["PASSED", "FAILED", "SKIPPED"])


if __name__ == "__main__":
    unittest.main()