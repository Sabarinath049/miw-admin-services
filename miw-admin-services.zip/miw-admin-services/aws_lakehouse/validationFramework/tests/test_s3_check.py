"""
Comprehensive pytest tests for s3_check validator.

Tests cover:
- Bucket naming convention validation (length, pattern, enterprise/subgroup rules)
- Value check rule (equality, lists, regex, conditional applicability)
- Regex match validation
- Context variable substitution
- File loading (YAML/JSON)
- FILE_SUMMARY record generation
- Integration end-to-end validation
"""

from validation_framework.validators.s3_check import (
    validate,
    apply_bucket_naming_convention_check,
    apply_value_check_rule,
    apply_regex_rule,
    get_nested_value,
    replace_context_tokens,
    resolve_rule_with_context,
    build_result,
    build_file_summary_result,
    load_yaml_or_json,
    _resolve_expected_value_for_rule,
    _match_expected_value,
)
import json
import os
import tempfile
from pathlib import Path

import pytest
import yaml

# Add src to path for imports
import sys
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


# =====================================================================
# Fixtures
# =====================================================================

@pytest.fixture
def valid_s3_config():
    """Return a valid S3 configuration payload."""
    return {
        "bucket_name": "dev-cmp1-apac-dp",
        "enterprise_or_func_name": "AGTR",
        "enterprise_or_func_subgrp_name": "Asia Pacific",
        "versioning_enabled": True,
        "public_access_blocked": True,
        "encryption_enabled": True,
        "encryption_type": "SSE-S3",
        "encryption_key_arn": "arn:aws:kms:us-east-1:123456789012:key/12345678-1234-1234-1234-123456789012",
        "usage_type": "dp",
    }


@pytest.fixture
def temp_yaml_file(valid_s3_config):
    """Create a temporary YAML file with valid S3 config."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        yaml.dump(valid_s3_config, f)
        f.flush()
        yield f.name
    os.unlink(f.name)


@pytest.fixture
def temp_json_file(valid_s3_config):
    """Create a temporary JSON file with valid S3 config."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(valid_s3_config, f)
        f.flush()
        yield f.name
    os.unlink(f.name)


@pytest.fixture
def invalid_yaml_file():
    """Create a temporary invalid YAML file."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        f.write("{invalid: yaml: content:")
        f.flush()
        yield f.name
    os.unlink(f.name)


# =====================================================================
# Test: get_nested_value
# =====================================================================

class TestGetNestedValue:
    """Test nested field path resolution."""

    def test_simple_field(self):
        payload = {"bucket_name": "my-bucket"}
        assert get_nested_value(payload, "bucket_name") == "my-bucket"

    def test_nested_field(self):
        payload = {"config": {"encryption": "enabled"}}
        assert get_nested_value(payload, "config.encryption") == "enabled"

    def test_deep_nested_field(self):
        payload = {"a": {"b": {"c": "value"}}}
        assert get_nested_value(payload, "a.b.c") == "value"

    def test_none_path_returns_full_payload(self):
        payload = {"bucket": "test"}
        assert get_nested_value(payload, None) == payload

    def test_empty_path_returns_full_payload(self):
        payload = {"bucket": "test"}
        assert get_nested_value(payload, "") == payload

    def test_dot_only_returns_full_payload(self):
        payload = {"bucket": "test"}
        assert get_nested_value(payload, ".") == payload

    def test_none_string_returns_full_payload(self):
        payload = {"bucket": "test"}
        for null_string in ["none", "null", "None", "NULL"]:
            assert get_nested_value(payload, null_string) == payload

    def test_missing_key_returns_none(self):
        assert get_nested_value({"a": 1}, "b") is None

    def test_missing_nested_key_returns_none(self):
        assert get_nested_value({"config": {"a": 1}}, "config.missing") is None

    def test_non_dict_intermediate_returns_none(self):
        assert get_nested_value({"a": "string"}, "a.b") is None

    def test_double_dots_skipped(self):
        payload = {"a": {"b": "value"}}
        assert get_nested_value(payload, "a..b") == "value"


# =====================================================================
# Test: apply_bucket_naming_convention_check
# =====================================================================

class TestApplyBucketNamingConventionCheck:
    """Test S3 bucket naming convention validation."""

    def test_valid_bucket_name(self, valid_s3_config):
        """Test valid bucket name passes check."""
        rule = {
            "name": "s3_bucket_naming_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "bucket_naming_convention_check",
            "target_field": ".",
            "params": {
                "bucket_field": "bucket_name",
                "enterprise_field": "enterprise_or_func_name",
                "subgroup_field": "enterprise_or_func_subgrp_name",
                "min_length": 10,
                "max_length": 63,
                "allowed_pattern": r"^dev-cmp[1-4]-[a-z][a-z0-9.\-]*-dp$",
                "disallow_consecutive_dots": True,
                "no_subgroup_enterprises": ["AGTR", "FOOD", "SPEC"],
                "subgroup_mandatory_enterprises": ["CORP"],
            },
        }
        result = apply_bucket_naming_convention_check(
            "test.yaml", valid_s3_config, "TEST_001", rule
        )
        assert result["status"] == "PASSED"
        assert result["rule_id"] == "TEST_001"

    def test_bucket_name_too_short(self, valid_s3_config):
        """Test bucket name below minimum length fails."""
        rule = {
            "name": "s3_bucket_naming_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "bucket_naming_convention_check",
            "target_field": ".",
            "params": {
                "bucket_field": "bucket_name",
                "enterprise_field": "enterprise_or_func_name",
                "subgroup_field": "enterprise_or_func_subgrp_name",
                "min_length": 20,
                "max_length": 63,
                "allowed_pattern": r"^[a-z][a-z0-9.\-]*[a-z0-9]$",
            },
        }
        result = apply_bucket_naming_convention_check(
            "test.yaml", valid_s3_config, "TEST_001", rule
        )
        assert result["status"] == "FAILED"
        assert "outside allowed range" in result["message"]

    def test_bucket_name_too_long(self, valid_s3_config):
        """Test bucket name above maximum length fails."""
        rule = {
            "name": "s3_bucket_naming_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "bucket_naming_convention_check",
            "target_field": ".",
            "params": {
                "bucket_field": "bucket_name",
                "enterprise_field": "enterprise_or_func_name",
                "subgroup_field": "enterprise_or_func_subgrp_name",
                "min_length": 3,
                "max_length": 10,
                "allowed_pattern": r"^[a-z][a-z0-9.\-]*[a-z0-9]$",
            },
        }
        result = apply_bucket_naming_convention_check(
            "test.yaml", valid_s3_config, "TEST_001", rule
        )
        assert result["status"] == "FAILED"
        assert "outside allowed range" in result["message"]

    def test_bucket_name_invalid_characters(self, valid_s3_config):
        """Test bucket name with invalid characters fails."""
        config = valid_s3_config.copy()
        # Underscores and uppercase not allowed
        config["bucket_name"] = "dev_cmp1_APAC_dp"

        rule = {
            "name": "s3_bucket_naming_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "bucket_naming_convention_check",
            "target_field": ".",
            "params": {
                "bucket_field": "bucket_name",
                "enterprise_field": "enterprise_or_func_name",
                "subgroup_field": "enterprise_or_func_subgrp_name",
                "min_length": 10,
                "max_length": 63,
                "allowed_pattern": r"^[a-z][a-z0-9.\-]*[a-z0-9]$",
            },
        }
        result = apply_bucket_naming_convention_check(
            "test.yaml", config, "TEST_001", rule
        )
        assert result["status"] == "FAILED"
        assert "does not match allowed pattern" in result["message"]

    def test_consecutive_dots_not_allowed(self, valid_s3_config):
        """Test bucket name with consecutive dots fails."""
        config = valid_s3_config.copy()
        config["bucket_name"] = "dev-cmp1-apac..dp"

        rule = {
            "name": "s3_bucket_naming_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "bucket_naming_convention_check",
            "target_field": ".",
            "params": {
                "bucket_field": "bucket_name",
                "enterprise_field": "enterprise_or_func_name",
                "subgroup_field": "enterprise_or_func_subgrp_name",
                "min_length": 10,
                "max_length": 63,
                "allowed_pattern": r"^[a-z][a-z0-9.\-]*[a-z0-9]$",
                "disallow_consecutive_dots": True,
            },
        }
        result = apply_bucket_naming_convention_check(
            "test.yaml", config, "TEST_001", rule
        )
        assert result["status"] == "FAILED"
        assert "consecutive dots" in result["message"]

    def test_consecutive_dots_allowed(self, valid_s3_config):
        """Test bucket name with consecutive dots passes when allowed."""
        config = valid_s3_config.copy()
        config["bucket_name"] = "dev-cmp1..apac-dp"

        rule = {
            "name": "s3_bucket_naming_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "bucket_naming_convention_check",
            "target_field": ".",
            "params": {
                "bucket_field": "bucket_name",
                "enterprise_field": "enterprise_or_func_name",
                "subgroup_field": "enterprise_or_func_subgrp_name",
                "min_length": 10,
                "max_length": 63,
                "allowed_pattern": r"^[a-z][a-z0-9.\-]*[a-z0-9]$",
                "disallow_consecutive_dots": False,
            },
        }
        result = apply_bucket_naming_convention_check(
            "test.yaml", config, "TEST_001", rule
        )
        assert result["status"] == "PASSED"

    def test_no_subgroup_enterprise_constraint(self):
        """Test no_subgroup_enterprises constraint (subgroup must not appear)."""
        config = {
            "bucket_name": "dev-cmp1-apac-wtg-dp",  # Contains subgroup 'wtg'
            "enterprise_or_func_name": "AGTR",
            "enterprise_or_func_subgrp_name": "wtg",  # Must match lowercase in bucket
        }

        rule = {
            "name": "s3_bucket_naming_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "bucket_naming_convention_check",
            "target_field": ".",
            "params": {
                "bucket_field": "bucket_name",
                "enterprise_field": "enterprise_or_func_name",
                "subgroup_field": "enterprise_or_func_subgrp_name",
                "min_length": 10,
                "max_length": 63,
                "allowed_pattern": r"^[a-z][a-z0-9.\-]*[a-z0-9]$",
                "no_subgroup_enterprises": ["AGTR"],
            },
        }
        result = apply_bucket_naming_convention_check(
            "test.yaml", config, "TEST_001", rule
        )
        assert result["status"] == "FAILED"
        assert "should not include subgroup" in result["message"]

    def test_subgroup_mandatory_enterprise_present(self):
        """Test subgroup_mandatory_enterprises constraint (subgroup must appear)."""
        config = {
            "bucket_name": "dev-cmp1-corp-dtd-dp",  # Contains subgroup 'corp-dtd'
            "enterprise_or_func_name": "CORP",
            "enterprise_or_func_subgrp_name": "corp-dtd",
        }

        rule = {
            "name": "s3_bucket_naming_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "bucket_naming_convention_check",
            "target_field": ".",
            "params": {
                "bucket_field": "bucket_name",
                "enterprise_field": "enterprise_or_func_name",
                "subgroup_field": "enterprise_or_func_subgrp_name",
                "min_length": 10,
                "max_length": 63,
                "allowed_pattern": r"^[a-z][a-z0-9.\-]*[a-z0-9]$",
                "subgroup_mandatory_enterprises": ["CORP"],
            },
        }
        result = apply_bucket_naming_convention_check(
            "test.yaml", config, "TEST_001", rule
        )
        assert result["status"] == "PASSED"

    def test_subgroup_mandatory_enterprise_missing(self):
        """Test subgroup_mandatory_enterprises constraint fails when subgroup missing."""
        config = {
            "bucket_name": "dev-cmp1-apac-dp",  # No subgroup
            "enterprise_or_func_name": "CORP",
            "enterprise_or_func_subgrp_name": "",
        }

        rule = {
            "name": "s3_bucket_naming_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "bucket_naming_convention_check",
            "target_field": ".",
            "params": {
                "bucket_field": "bucket_name",
                "enterprise_field": "enterprise_or_func_name",
                "subgroup_field": "enterprise_or_func_subgrp_name",
                "min_length": 10,
                "max_length": 63,
                "allowed_pattern": r"^[a-z][a-z0-9.\-]*[a-z0-9]$",
                "subgroup_mandatory_enterprises": ["CORP"],
            },
        }
        result = apply_bucket_naming_convention_check(
            "test.yaml", config, "TEST_001", rule
        )
        assert result["status"] == "FAILED"
        assert "requires a subgroup" in result["message"]

    def test_missing_bucket_name_field(self, valid_s3_config):
        """Test missing bucket_name field fails."""
        config = valid_s3_config.copy()
        del config["bucket_name"]

        rule = {
            "name": "s3_bucket_naming_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "bucket_naming_convention_check",
            "target_field": ".",
            "params": {
                "bucket_field": "bucket_name",
                "enterprise_field": "enterprise_or_func_name",
                "subgroup_field": "enterprise_or_func_subgrp_name",
            },
        }
        result = apply_bucket_naming_convention_check(
            "test.yaml", config, "TEST_001", rule
        )
        assert result["status"] == "FAILED"
        assert "not found" in result["message"]

    def test_bucket_name_not_string(self, valid_s3_config):
        """Test non-string bucket_name fails."""
        config = valid_s3_config.copy()
        config["bucket_name"] = 12345  # Not a string

        rule = {
            "name": "s3_bucket_naming_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "bucket_naming_convention_check",
            "target_field": ".",
            "params": {
                "bucket_field": "bucket_name",
                "enterprise_field": "enterprise_or_func_name",
                "subgroup_field": "enterprise_or_func_subgrp_name",
            },
        }
        result = apply_bucket_naming_convention_check(
            "test.yaml", config, "TEST_001", rule
        )
        assert result["status"] == "FAILED"
        assert "must be a string" in result["message"]


# =====================================================================
# Test: apply_value_check_rule
# =====================================================================

class TestApplyValueCheckRule:
    """Test generic value check rule validation."""

    def test_equality_check_pass(self, valid_s3_config):
        """Test equality check with matching value passes."""
        rule = {
            "name": "s3_versioning_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "value_check",
            "target_field": "versioning_enabled",
            "params": {"target_value": True},
        }
        result = apply_value_check_rule(
            "test.yaml", valid_s3_config, "TEST_001", rule)
        assert result["status"] == "PASSED"

    def test_equality_check_fail(self, valid_s3_config):
        """Test equality check with mismatched value fails."""
        config = valid_s3_config.copy()
        config["versioning_enabled"] = False

        rule = {
            "name": "s3_versioning_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "value_check",
            "target_field": "versioning_enabled",
            "params": {"target_value": True},
        }
        result = apply_value_check_rule("test.yaml", config, "TEST_001", rule)
        assert result["status"] == "FAILED"

    def test_list_check_pass(self, valid_s3_config):
        """Test allowed values list check with valid value passes."""
        rule = {
            "name": "s3_encryption_type_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "value_check",
            "target_field": "encryption_type",
            "params": {"target_value": ["SSE-S3", "SSE-KMS"]},
        }
        result = apply_value_check_rule(
            "test.yaml", valid_s3_config, "TEST_001", rule)
        assert result["status"] == "PASSED"

    def test_list_check_fail(self, valid_s3_config):
        """Test allowed values list check with invalid value fails."""
        config = valid_s3_config.copy()
        config["encryption_type"] = "NO-ENCRYPTION"

        rule = {
            "name": "s3_encryption_type_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "value_check",
            "target_field": "encryption_type",
            "params": {"target_value": ["SSE-S3", "SSE-KMS"]},
        }
        result = apply_value_check_rule("test.yaml", config, "TEST_001", rule)
        assert result["status"] == "FAILED"

    def test_regex_check_pass(self, valid_s3_config):
        """Test regex check with matching value passes."""
        rule = {
            "name": "s3_encryption_key_arn_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "value_check",
            "target_field": "encryption_key_arn",
            "params": {
                "target_value": {
                    "regex": {
                        "pattern": r"^arn:aws:kms:[a-z0-9\-]+:\d+:key/[a-z0-9\-]+$"}}},
        }
        result = apply_value_check_rule(
            "test.yaml", valid_s3_config, "TEST_001", rule)
        assert result["status"] == "PASSED"

    def test_regex_check_fail(self, valid_s3_config):
        """Test regex check with non-matching value fails."""
        config = valid_s3_config.copy()
        config["encryption_key_arn"] = "invalid-arn"

        rule = {
            "name": "s3_encryption_key_arn_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "value_check",
            "target_field": "encryption_key_arn",
            "params": {
                "target_value": {
                    "regex": {
                        "pattern": r"^arn:aws:kms:[a-z0-9\-]+:\d+:key/[a-z0-9\-]+$"}}},
        }
        result = apply_value_check_rule("test.yaml", config, "TEST_001", rule)
        assert result["status"] == "FAILED"

    def test_missing_target_field_fails(self, valid_s3_config):
        """Test missing target field fails."""
        rule = {
            "name": "s3_versioning_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "value_check",
            "target_field": "missing_field",
            "params": {"target_value": True},
        }
        result = apply_value_check_rule(
            "test.yaml", valid_s3_config, "TEST_001", rule)
        assert result["status"] == "FAILED"
        assert "not found" in result["message"]

    def test_no_target_field_in_rule_fails(self, valid_s3_config):
        """Test missing target_field key in rule fails."""
        rule = {
            "name": "s3_versioning_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "value_check",
            "params": {"target_value": True},
        }
        result = apply_value_check_rule(
            "test.yaml", valid_s3_config, "TEST_001", rule)
        assert result["status"] == "FAILED"
        assert "requires a target_field" in result["message"]

    def test_conditional_applicability_skip(self):
        """Test conditional applicability skips rule when not applicable."""
        config = {
            "encryption_type": "SSE-S3",
            "encryption_key_arn": None,
        }

        rule = {
            "name": "s3_encryption_key_arn_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "value_check",
            "target_field": "encryption_key_arn",
            "params": {
                "target_value": "arn:aws:...",
                "encryption_type_field": "encryption_type",
                "required_encryption_type": "SSE-KMS",
            },
        }
        result = apply_value_check_rule("test.yaml", config, "TEST_001", rule)
        assert result["status"] == "PASSED"
        assert "not applicable" in result["message"]

    def test_conditional_applicability_apply(self, valid_s3_config):
        """Test conditional applicability applies rule when conditions match."""
        config = valid_s3_config.copy()
        config["encryption_type"] = "SSE-KMS"

        rule = {
            "name": "s3_encryption_key_arn_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "value_check",
            "target_field": "encryption_key_arn",
            "params": {
                "target_value": {
                    "regex": {
                        "pattern": r"^arn:aws:kms:[a-z0-9\-]+:\d+:key/[a-z0-9\-]+$"}},
                "encryption_type_field": "encryption_type",
                "required_encryption_type": "SSE-KMS",
            },
        }
        result = apply_value_check_rule("test.yaml", config, "TEST_001", rule)
        assert result["status"] == "PASSED"

    def test_versioning_category_with_versioning(self):
        """Test versioning category check with allowed_with_versioning."""
        config = {
            "bucket_name": "test-scripts-bucket",
            "usage_type": "scripts",
            "versioning_enabled": True,  # Scripts category expects versioning to be True
        }

        rule = {
            "name": "s3_versioning_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "value_check",
            "target_field": "versioning_enabled",
            "params": {
                "target_value": False,  # Default is False, but scripts overrides to True
                "s3_buckets_allowed_with_versioning": ["scripts"],
                "s3_buckets_allowed_without_versioning": ["dp", "src"],
            },
        }
        result = apply_value_check_rule("test.yaml", config, "TEST_001", rule)
        # Should pass because "scripts" is in allowed_with_versioning, and
        # actual value matches expected
        assert result["status"] == "PASSED"
        assert "Validation passed" in result["message"]

    def test_versioning_category_without_versioning(self):
        """Test versioning category check with allowed_without_versioning."""
        config = {
            "bucket_name": "test-dp-bucket",
            "usage_type": "dp",
            "versioning_enabled": False,  # DP category expects versioning to be False
        }

        rule = {
            "name": "s3_versioning_check",
            "enabled": True,
            "severity": "ERROR",
            "type": "value_check",
            "target_field": "versioning_enabled",
            "params": {
                "target_value": True,  # Default is True, but dp overrides to False
                "s3_buckets_allowed_with_versioning": ["scripts"],
                "s3_buckets_allowed_without_versioning": ["dp", "src"],
            },
        }
        result = apply_value_check_rule("test.yaml", config, "TEST_001", rule)
        assert result["status"] == "PASSED"
        assert "Validation passed" in result["message"]


# =====================================================================
# Test: apply_regex_rule
# =====================================================================

class TestApplyRegexRule:
    """Test regex pattern matching validation."""

    def test_regex_match_pass(self, valid_s3_config):
        """Test regex match with valid value passes."""
        rule = {
            "name": "bucket_naming_regex",
            "enabled": True,
            "severity": "ERROR",
            "type": "regex_match",
            "target_field": "bucket_name",
            "params": {"pattern": r"^dev-cmp[1-4]-[a-z]+-dp$"},
        }
        result = apply_regex_rule(
            "test.yaml", valid_s3_config, "TEST_001", rule)
        assert result["status"] == "PASSED"

    def test_regex_match_fail(self, valid_s3_config):
        """Test regex match with invalid value fails."""
        config = valid_s3_config.copy()
        config["bucket_name"] = "INVALID_BUCKET_NAME"

        rule = {
            "name": "bucket_naming_regex",
            "enabled": True,
            "severity": "ERROR",
            "type": "regex_match",
            "target_field": "bucket_name",
            "params": {"pattern": r"^dev-cmp[1-4]-[a-z]+-dp$"},
        }
        result = apply_regex_rule("test.yaml", config, "TEST_001", rule)
        assert result["status"] == "FAILED"

    def test_regex_match_target_not_found(self, valid_s3_config):
        """Test regex match fails when target not found."""
        rule = {
            "name": "bucket_naming_regex",
            "enabled": True,
            "severity": "ERROR",
            "type": "regex_match",
            "target_field": "missing_field",
            "params": {"pattern": r"^[a-z]+$"},
        }
        result = apply_regex_rule(
            "test.yaml", valid_s3_config, "TEST_001", rule)
        assert result["status"] == "FAILED"
        assert "not found" in result["message"]

    def test_regex_match_target_not_string(self, valid_s3_config):
        """Test regex match fails when target not string."""
        config = valid_s3_config.copy()
        config["bucket_name"] = 12345

        rule = {
            "name": "bucket_naming_regex",
            "enabled": True,
            "severity": "ERROR",
            "type": "regex_match",
            "target_field": "bucket_name",
            "params": {"pattern": r"^[a-z]+$"},
        }
        result = apply_regex_rule("test.yaml", config, "TEST_001", rule)
        assert result["status"] == "FAILED"
        assert "must be a string" in result["message"]

    def test_invalid_regex_pattern(self, valid_s3_config):
        """Test invalid regex pattern fails gracefully."""
        rule = {
            "name": "bucket_naming_regex",
            "enabled": True,
            "severity": "ERROR",
            "type": "regex_match",
            "target_field": "bucket_name",
            "params": {"pattern": r"(?P<invalid"},  # Invalid regex
        }
        result = apply_regex_rule(
            "test.yaml", valid_s3_config, "TEST_001", rule)
        assert result["status"] == "FAILED"
        assert "Invalid regex pattern" in result["message"]


# =====================================================================
# Test: _resolve_expected_value_for_rule
# =====================================================================

class TestResolveExpectedValue:
    """Test expected value resolution with category overrides."""

    def test_no_category_override_returns_default(self):
        """Test no category override returns default target_value."""
        params = {
            "target_value": True,
            "s3_buckets_allowed_with_versioning": [],
            "s3_buckets_allowed_without_versioning": [],
        }
        payload = {"bucket_name": "test-bucket"}
        result = _resolve_expected_value_for_rule(payload, params)
        assert result is True

    def test_category_with_versioning_returns_true(self):
        """Test bucket in with_versioning category returns True."""
        params = {
            "target_value": False,
            "s3_buckets_allowed_with_versioning": ["scripts"],
            "s3_buckets_allowed_without_versioning": [],
        }
        payload = {"bucket_name": "test-scripts-bucket",
                   "usage_type": "scripts"}
        result = _resolve_expected_value_for_rule(payload, params)
        assert result is True

    def test_category_without_versioning_returns_false(self):
        """Test bucket in without_versioning category returns False."""
        params = {
            "target_value": True,
            "s3_buckets_allowed_with_versioning": [],
            "s3_buckets_allowed_without_versioning": ["dp", "src"],
        }
        payload = {"bucket_name": "test-dp-bucket", "usage_type": "dp"}
        result = _resolve_expected_value_for_rule(payload, params)
        assert result is False


# =====================================================================
# Test: _match_expected_value
# =====================================================================

class TestMatchExpectedValue:
    """Test expected value matching logic."""

    def test_direct_equality_match(self):
        """Test direct equality matching."""
        is_valid, reason = _match_expected_value(True, True)
        assert is_valid is True

    def test_direct_equality_mismatch(self):
        """Test direct equality mismatch."""
        is_valid, reason = _match_expected_value(True, False)
        assert is_valid is False

    def test_list_match(self):
        """Test list value matching."""
        is_valid, reason = _match_expected_value(
            "SSE-S3", ["SSE-S3", "SSE-KMS"])
        assert is_valid is True

    def test_list_mismatch(self):
        """Test list value mismatch."""
        is_valid, reason = _match_expected_value(
            "NO-ENCRYPTION", ["SSE-S3", "SSE-KMS"])
        assert is_valid is False

    def test_regex_match(self):
        """Test regex pattern matching."""
        expected = {
            "regex": {
                "pattern": r"^arn:aws:kms:[a-z0-9\-]+:\d+:key/[a-z0-9\-]+$"
            }
        }
        is_valid, reason = _match_expected_value(
            "arn:aws:kms:us-east-1:123456789012:key/12345678-1234-1234-1234-123456789012",
            expected)
        assert is_valid is True

    def test_regex_mismatch(self):
        """Test regex pattern mismatch."""
        expected = {
            "regex": {
                "pattern": r"^arn:aws:kms:[a-z0-9\-]+:\d+:key/[a-z0-9\-]+$"
            }
        }
        is_valid, reason = _match_expected_value("invalid-arn", expected)
        assert is_valid is False

    def test_regex_non_string_value(self):
        """Test regex matching fails with non-string value."""
        expected = {"regex": {"pattern": r"^test$"}}
        is_valid, reason = _match_expected_value(12345, expected)
        assert is_valid is False
        assert "must be a string" in reason

    def test_invalid_regex_pattern(self):
        """Test invalid regex pattern fails gracefully."""
        expected = {"regex": {"pattern": r"(?P<invalid"}}
        is_valid, reason = _match_expected_value("test", expected)
        assert is_valid is False
        assert "Invalid regex pattern" in reason


# =====================================================================
# Test: File loading
# =====================================================================

class TestFileLoading:
    """Test YAML/JSON file loading."""

    def test_load_yaml_file_success(self, temp_yaml_file):
        """Test loading valid YAML file."""
        payload = load_yaml_or_json(temp_yaml_file)
        assert payload is not None
        assert "bucket_name" in payload

    def test_load_json_file_success(self, temp_json_file):
        """Test loading valid JSON file."""
        payload = load_yaml_or_json(temp_json_file)
        assert payload is not None
        assert "bucket_name" in payload

    def test_load_invalid_yaml_file(self, invalid_yaml_file):
        """Test loading invalid YAML file returns None."""
        payload = load_yaml_or_json(invalid_yaml_file)
        assert payload is None

    def test_load_nonexistent_file(self):
        """Test loading nonexistent file returns None."""
        payload = load_yaml_or_json("/nonexistent/file.yaml")
        assert payload is None


# =====================================================================
# Test: Result builders
# =====================================================================

class TestResultBuilders:
    """Test result dictionary builders."""

    def test_build_result(self):
        """Test build_result creates proper structure."""
        result = build_result(
            rule_id="TEST_001",
            rule_name="test_rule",
            status="PASSED",
            severity="ERROR",
            file_path="test.yaml",
            message="Test passed",
            recommendation="No action needed",
            evidence={"key": "value"},
        )
        assert result["rule_id"] == "TEST_001"
        assert result["status"] == "PASSED"
        assert result["evidence"]["key"] == "value"

    def test_build_file_summary_result(self):
        """Test build_file_summary_result creates proper structure."""
        result = build_file_summary_result(
            file_path="test.yaml",
            status="PASSED",
            message="All validations passed",
            passed_rules=5,
            failed_rules=0,
            total_rules=5,
            context={"env": "dev"},
        )
        assert result["rule_id"] == "FILE_SUMMARY"
        assert result["evidence"]["passed_rules"] == 5
        assert result["evidence"]["env"] == "dev"


# =====================================================================
# Test: Context variable substitution
# =====================================================================

class TestContextSubstitution:
    """Test context variable replacement."""

    def test_simple_token_replacement(self):
        """Test simple $key token replacement."""
        value = "env-$env-bucket"
        context = {"env": "dev"}
        result = replace_context_tokens(value, context)
        assert result == "env-dev-bucket"

    def test_braced_token_replacement(self):
        """Test ${key} token replacement."""
        value = "env-${env}-bucket"
        context = {"env": "prod"}
        result = replace_context_tokens(value, context)
        assert result == "env-prod-bucket"

    def test_multiple_token_replacement(self):
        """Test multiple token replacement."""
        value = "$account-$region-$env"
        context = {"account": "123", "region": "us-east-1", "env": "dev"}
        result = replace_context_tokens(value, context)
        assert result == "123-us-east-1-dev"

    def test_missing_token_unchanged(self):
        """Test missing token remains unchanged."""
        value = "env-$missing-bucket"
        context = {"env": "dev"}
        result = replace_context_tokens(value, context)
        assert result == "env-$missing-bucket"

    def test_dict_recursive_replacement(self):
        """Test recursive replacement in dict."""
        value = {"field": "env-$env", "nested": {"value": "$account"}}
        context = {"env": "dev", "account": "123"}
        result = replace_context_tokens(value, context)
        assert result["field"] == "env-dev"
        assert result["nested"]["value"] == "123"

    def test_list_recursive_replacement(self):
        """Test recursive replacement in list."""
        value = ["env-$env", "$account"]
        context = {"env": "dev", "account": "123"}
        result = replace_context_tokens(value, context)
        assert result[0] == "env-dev"
        assert result[1] == "123"


# =====================================================================
# Integration tests
# =====================================================================

class TestValidateIntegration:
    """Integration tests for full validation workflow."""

    def test_validate_valid_config(self, temp_yaml_file):
        """Test validate with valid configuration."""
        rules = {
            "TEST_001": {
                "name": "s3_versioning_check",
                "enabled": True,
                "severity": "ERROR",
                "type": "value_check",
                "target_field": "versioning_enabled",
                "params": {"target_value": True},
            }
        }
        results = validate([temp_yaml_file], rules)

        # Find non-FILE_SUMMARY results
        rule_results = [r for r in results if r["rule_id"] != "FILE_SUMMARY"]
        assert len(rule_results) > 0
        assert any(r["status"] == "PASSED" for r in rule_results)

    def test_validate_with_file_summary(self, temp_yaml_file):
        """Test validate includes FILE_SUMMARY record."""
        rules = {
            "TEST_001": {
                "name": "test_rule",
                "enabled": True,
                "severity": "ERROR",
                "type": "value_check",
                "target_field": "versioning_enabled",
                "params": {"target_value": True},
            }
        }
        results = validate([temp_yaml_file], rules)

        summaries = [r for r in results if r["rule_id"] == "FILE_SUMMARY"]
        assert len(summaries) == 1
        assert summaries[0]["evidence"]["env"] is None

    def test_validate_with_context(self, temp_yaml_file):
        """Test validate passes context through."""
        rules = {
            "TEST_001": {
                "name": "test_rule",
                "enabled": True,
                "severity": "ERROR",
                "type": "value_check",
                "target_field": "versioning_enabled",
                "params": {"target_value": True},
            }
        }
        context = {"env": "dev"}
        results = validate([temp_yaml_file], rules, context)

        summaries = [r for r in results if r["rule_id"] == "FILE_SUMMARY"]
        assert summaries[0]["evidence"]["env"] == "dev"

    def test_validate_invalid_file(self, invalid_yaml_file):
        """Test validate handles invalid file."""
        rules = {
            "TEST_001": {
                "name": "test_rule",
                "enabled": True,
                "severity": "ERROR",
                "type": "value_check",
                "target_field": "versioning_enabled",
                "params": {"target_value": True},
            }
        }
        results = validate([invalid_yaml_file], rules)

        # Should have FILE_LOAD_ERROR and FILE_SUMMARY
        errors = [r for r in results if r["rule_id"] == "FILE_LOAD_ERROR"]
        assert len(errors) == 1

    def test_validate_disabled_rule_skipped(self, temp_yaml_file):
        """Test disabled rules are skipped."""
        rules = {
            "TEST_001": {
                "name": "test_rule",
                "enabled": False,
                "severity": "ERROR",
                "type": "value_check",
                "target_field": "versioning_enabled",
                "params": {"target_value": True},
            }
        }
        results = validate([temp_yaml_file], rules)

        # Should only have FILE_SUMMARY, no rule results
        rule_results = [r for r in results if r["rule_id"] != "FILE_SUMMARY"]
        assert len(rule_results) == 0
