import unittest
from unittest.mock import patch, Mock
import importlib
import sys
import os

# ============================================================
# PATH SETUP
# ============================================================

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC_PATH = os.path.join(BASE_DIR, "src")

if SRC_PATH not in sys.path:
    sys.path.insert(0, SRC_PATH)

MODULE_NAME = (
    "validation_framework.validators.global.pr_description_validator"
)

engine = importlib.import_module(MODULE_NAME)


class TestValidatorEngine(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        cls.sample_pr_body = """
### 1. Objective
> Build new pipeline

### 2. Data Flow
> Source -> Target

### 3. Priority
> High

### 4. Approval
> Approved

### 5. Compute
> Medium

### 6. Dependencies
> Vendor feed
"""

        cls.rules = {
            "RULE_1": {
                "type": "string_not_empty_and_not_in",
                "target_field": "q1_objective",
                "severity": "ERROR",
                "message": "Invalid: {actual_value}",
                "params": {
                    "disallowed_values": ["na", "none"]
                }
            }
        }

    # ============================================================
    # FILE HANDLING TESTS
    # ============================================================

    def test_extract_pr_number_from_filename(self):
        result = engine.extract_pr_number("3714.txt")
        self.assertEqual(result, "3714")

    @patch.dict(os.environ, {"PR_NUMBER": "9876"})
    def test_extract_pr_number_from_env(self):
        result = engine.extract_pr_number("3714.txt")
        self.assertEqual(result, "9876")

    @patch.dict(os.environ, {}, clear=True)
    def test_extract_pr_number_failure(self):
        with self.assertRaises(ValueError):
            engine.extract_pr_number("file.txt")

    def test_extract_digits(self):
        result = engine._extract_digits("abc12345.txt")
        self.assertEqual(result, "12345")

    def test_extract_digits_none(self):
        result = engine._extract_digits("abcdef")
        self.assertIsNone(result)

    # ============================================================
    # SESSION & API TESTS
    # ============================================================

    def test_create_session_success(self):
        session = engine.create_session("dummy_token")

        self.assertEqual(
            session.headers["Authorization"],
            "token dummy_token"
        )

    def test_create_session_failure(self):
        with self.assertRaises(ValueError):
            engine.create_session(None)

    @patch("requests.Session.get")
    def test_fetch_pr_body_success(self, mock_get):
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "body": "test body"
        }

        mock_get.return_value = mock_response

        session = Mock()
        session.get = mock_get

        result = engine.fetch_pr_body(session, "123")

        self.assertEqual(result, "test body")

    @patch("requests.Session.get")
    def test_fetch_pr_body_unauthorized(self, mock_get):

        mock_response = Mock(status_code=401)
        mock_get.return_value = mock_response

        session = Mock()
        session.get = mock_get

        with self.assertRaises(Exception):
            engine.fetch_pr_body(session, "123")

    def test_raise_api_error_401(self):
        response = Mock(status_code=401)

        with self.assertRaises(Exception):
            engine._raise_api_error(response, "123")

    def test_raise_api_error_403(self):
        response = Mock(
            status_code=403,
            text="Forbidden"
        )

        with self.assertRaises(Exception):
            engine._raise_api_error(response, "123")

    def test_raise_api_error_other(self):
        response = Mock(status_code=500)

        with self.assertRaises(Exception):
            engine._raise_api_error(response, "123")

    # ============================================================
    # PARSING TESTS
    # ============================================================

    def test_extract_intake_answers(self):

        result = engine.extract_intake_answers(
            self.sample_pr_body
        )

        self.assertEqual(
            result["objective"],
            "Build new pipeline"
        )

        self.assertEqual(
            result["data_flow"],
            "Source -> Target"
        )

        self.assertEqual(
            result["priority"],
            "High"
        )

        self.assertEqual(
            result["approval"],
            "Approved"
        )

        self.assertEqual(
            result["compute"],
            "Medium"
        )

        self.assertEqual(
            result["dependencies"],
            "Vendor feed"
        )

    def test_normalize_text(self):
        text = "Hello,   World!!"

        result = engine._normalize(text)

        self.assertEqual(result, "hello world")

    def test_clean_answer(self):
        result = engine._clean_answer("> hello")
        self.assertEqual(result, "hello")

    def test_join(self):
        result = engine._join(["a", "b"])
        self.assertEqual(result, "a\nb")

    def test_join_empty(self):
        result = engine._join([])
        self.assertIsNone(result)

    # ============================================================
    # DOCUMENT BUILDING TESTS
    # ============================================================

    def test_build_document(self):

        doc = engine._build_document(
            self.sample_pr_body
        )

        self.assertEqual(
            doc["q1_objective"],
            "Build new pipeline"
        )

        self.assertEqual(
            doc["q6_dependencies"],
            "Vendor feed"
        )

    # ============================================================
    # RULE ENGINE TESTS
    # ============================================================

    @patch(f"{MODULE_NAME}.PV")
    def test_evaluate_string_rule_pass(self, mock_pv):

        mock_pv.build_result.return_value = {
            "status": "PASSED"
        }

        rule = self.rules["RULE_1"].copy()
        rule["id"] = "RULE_1"

        result = engine.evaluate_string_rule(
            rule,
            "valid_value",
            "PR#1"
        )

        self.assertEqual(
            result["status"],
            "PASSED"
        )

    @patch(f"{MODULE_NAME}.PV")
    def test_evaluate_string_rule_fail(self, mock_pv):

        mock_pv.build_result.return_value = {
            "status": "FAILED"
        }

        rule = self.rules["RULE_1"].copy()
        rule["id"] = "RULE_1"

        result = engine.evaluate_string_rule(
            rule,
            "na",
            "PR#1"
        )

        self.assertEqual(
            result["status"],
            "FAILED"
        )

    @patch(f"{MODULE_NAME}.PV")
    def test_default_template_rule_pass(self, mock_pv):

        mock_pv.build_result.return_value = {
            "status": "PASSED"
        }

        rule = {
            "id": "RULE_TEMP",
            "type": "not_default_template_value",
            "target_field": "q1_objective"
        }

        result = engine.evaluate_default_template_rule(
            rule,
            "Custom business objective",
            "PR#1"
        )

        self.assertEqual(
            result["status"],
            "PASSED"
        )

    @patch(f"{MODULE_NAME}.PV")
    def test_default_template_rule_fail(self, mock_pv):

        mock_pv.build_result.return_value = {
            "status": "FAILED"
        }

        rule = {
            "id": "RULE_TEMP",
            "type": "not_default_template_value",
            "target_field": "q1_objective"
        }

        result = engine.evaluate_default_template_rule(
            rule,
            engine.DEFAULT_TEMPLATE_VALUES["q1_objective"],
            "PR#1"
        )

        self.assertEqual(
            result["status"],
            "FAILED"
        )

    @patch(f"{MODULE_NAME}.PV")
    def test_apply_rule_unknown(self, mock_pv):

        mock_pv.build_result.return_value = {
            "status": "FAILED"
        }

        rule = {
            "type": "unknown",
            "id": "R1",
            "name": "test"
        }

        result = engine.apply_rule(
            rule,
            {},
            "PR#1"
        )

        self.assertEqual(
            result[0]["status"],
            "FAILED"
        )

    @patch(f"{MODULE_NAME}.PV")
    def test_apply_rules(self, mock_pv):

        mock_pv.get_value_by_path.return_value = (
            "valid_value"
        )

        mock_pv.build_result.return_value = {
            "status": "PASSED"
        }

        parsed_doc = {
            "q1_objective": "valid_value"
        }

        results = engine._apply_rules(
            self.rules,
            parsed_doc,
            "PR#1"
        )

        self.assertEqual(len(results), 1)
        self.assertEqual(
            results[0]["status"],
            "PASSED"
        )

    # ============================================================
    # PROCESS FILE TESTS
    # ============================================================

    @patch(f"{MODULE_NAME}.extract_pr_number")
    @patch(f"{MODULE_NAME}.fetch_pr_body")
    @patch(f"{MODULE_NAME}.PV")
    def test_process_file_success(
        self,
        mock_pv,
        mock_fetch,
        mock_extract
    ):

        mock_extract.return_value = "3714"
        mock_fetch.return_value = self.sample_pr_body

        mock_pv.get_value_by_path.return_value = (
            "valid_value"
        )

        mock_pv.build_result.return_value = {
            "status": "PASSED"
        }

        results = engine._process_file(
            "file.txt",
            self.rules,
            Mock()
        )

        self.assertTrue(len(results) > 0)

    @patch(
        f"{MODULE_NAME}.extract_pr_number",
        side_effect=Exception("fail")
    )
    @patch(f"{MODULE_NAME}.PV")
    def test_process_file_pr_number_error(
        self,
        mock_pv,
        mock_extract
    ):

        mock_pv.build_result.return_value = {
            "status": "FAILED"
        }

        results = engine._process_file(
            "file.txt",
            self.rules,
            Mock()
        )

        self.assertEqual(
            results[0]["status"],
            "FAILED"
        )

    @patch(
        f"{MODULE_NAME}.fetch_pr_body",
        side_effect=Exception("API failure")
    )
    @patch(f"{MODULE_NAME}.extract_pr_number")
    @patch(f"{MODULE_NAME}.PV")
    def test_process_file_fetch_error(
        self,
        mock_pv,
        mock_extract,
        mock_fetch
    ):

        mock_extract.return_value = "3714"

        mock_pv.build_result.return_value = {
            "status": "FAILED"
        }

        results = engine._process_file(
            "file.txt",
            self.rules,
            Mock()
        )

        self.assertEqual(
            results[0]["status"],
            "FAILED"
        )

    # ============================================================
    # VALIDATE INTEGRATION TESTS
    # ============================================================

    @patch.dict(os.environ, {"secret": "dummy_token"})
    @patch(f"{MODULE_NAME}.extract_pr_number")
    @patch(f"{MODULE_NAME}.fetch_pr_body")
    @patch(f"{MODULE_NAME}.create_session")
    @patch(f"{MODULE_NAME}.PV")
    def test_validate_integration(
        self,
        mock_pv,
        mock_session,
        mock_fetch,
        mock_extract
    ):

        mock_extract.return_value = "3714"

        mock_fetch.return_value = (
            self.sample_pr_body
        )

        mock_session.return_value = Mock()

        mock_pv.get_value_by_path.return_value = (
            "valid_value"
        )

        mock_pv.build_result.return_value = {
            "status": "PASSED"
        }

        results = engine.validate(
            ["file.txt"],
            self.rules
        )

        self.assertTrue(len(results) > 0)

        self.assertEqual(
            results[0]["status"],
            "PASSED"
        )


if __name__ == "__main__":
    unittest.main()