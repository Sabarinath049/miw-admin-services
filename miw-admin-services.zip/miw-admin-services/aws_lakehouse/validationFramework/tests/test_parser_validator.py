import unittest
from unittest.mock import patch, mock_open, Mock
import json
import os, sys
import importlib

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(BASE_DIR, "src"))

MODULE_NAME = "validation_framework.validators.global.parser_validator"
validator = importlib.import_module(MODULE_NAME)


class TestValidatorEngine(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        """Runs once for the entire test class"""
        cls.sample_json = '{"intake_id": "M1234567", "name": "test"}'
        cls.sample_yaml = "intake_id: M1234567\nname: test"

        cls.rules = {
            "REQ_001": {
                "type": "required_field",
                "target_field": "intake_id",
                "severity": "ERROR",
                "message": "Missing intake_id"
            },
            "REGEX_001": {
                "type": "regex_match",
                "target_field": "intake_id",
                "severity": "ERROR",
                "message": "Invalid format {actual_value}",
                "params": {
                    "pattern": "^M[0-9]{7}$"
                }
            },
            "ASCII_001": {
                "type": "ascii_only",
                "severity": "ERROR",
                "params": {
                    "max_examples": 2
                }
            }
        }

    def setUp(self):
        """Runs before each test"""
        self.file_path = "test.json"

    # ============================================================
    # FILE UTILITIES TESTS
    # ============================================================

    @patch("builtins.open", new_callable=mock_open, read_data='{"a":1}')
    def test_load_file_success(self, mock_file):
        result = validator.load_file("dummy.json")
        self.assertEqual(result, '{"a":1}')
        mock_file.assert_called_once()

    @patch("builtins.open", side_effect=Exception("error"))
    def test_load_file_failure(self, mock_file):
        result = validator.load_file("dummy.json")
        self.assertIsNone(result)

    def test_detect_extension(self):
        self.assertEqual(validator.detect_extension("file.JSON"), ".json")
        self.assertEqual(validator.detect_extension("file.yaml"), ".yaml")

    def test_parse_file_json(self):
        result = validator.parse_file('{"a":1}', ".json")
        self.assertEqual(result, {"a": 1})

    def test_parse_file_yaml(self):
        result = validator.parse_file("a: 1", ".yaml")
        self.assertEqual(result, {"a": 1})

    def test_parse_file_invalid(self):
        result = validator.parse_file("{invalid}", ".json")
        self.assertIsNone(result)

    # ============================================================
    # HELPER FUNCTIONS
    # ============================================================

    def test_get_value_by_path(self):
        doc = {"a": {"b": 10}}
        self.assertEqual(validator.get_value_by_path(doc, "a.b"), 10)
        self.assertIsNone(validator.get_value_by_path(doc, "a.c"))

    def test_normalize_to_string(self):
        self.assertEqual(validator.normalize_to_string("abc"), ("abc", True))
        self.assertEqual(validator.normalize_to_string(123), ("123", True))
        self.assertEqual(validator.normalize_to_string(None), ("", False))

    def test_is_present(self):
        self.assertTrue(validator.is_present("abc"))
        self.assertFalse(validator.is_present(""))
        self.assertFalse(validator.is_present(None))
        self.assertTrue(validator.is_present([None, "x"]))

    def test_to_list(self):
        self.assertEqual(validator.to_list(["a", "b"]), ["a", "b"])
        self.assertEqual(validator.to_list("a"), ["a"])
        self.assertEqual(validator.to_list(None), [])

    # ============================================================
    # ASCII TESTS
    # ============================================================

    def test_find_non_ascii(self):
        result = validator.find_non_ascii("abcé", 5)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["char"], "é")

    def test_ascii_handler_fail(self):
        rule = {"severity": "ERROR", "params": {"max_examples": 2}}
        res = validator.handle_ascii(rule, "abcé", ".json", "file.json", "R1", "ascii")
        self.assertEqual(res["status"], "FAILED")

    def test_ascii_handler_pass(self):
        rule = {"severity": "ERROR", "params": {"max_examples": 2}}
        res = validator.handle_ascii(rule, "abc", ".json", "file.json", "R1", "ascii")
        self.assertEqual(res["status"], "PASSED")

    # ============================================================
    # RULE HANDLER TESTS
    # ============================================================

    def test_required_field_pass(self):
        rule = {"severity": "ERROR", "message": "Missing"}
        res = validator.handle_required(rule, "value", "file", "R1", "req")
        self.assertEqual(res["status"], "PASSED")

    def test_required_field_fail(self):
        rule = {"severity": "ERROR", "message": "Missing"}
        res = validator.handle_required(rule, "", "file", "R1", "req")
        self.assertEqual(res["status"], "FAILED")

    def test_regex_match_pass(self):
        rule = {
            "severity": "ERROR",
            "message": "Invalid {actual_value}",
            "params": {"pattern": "^M[0-9]{7}$"}
        }
        res = validator.handle_regex(rule, "M1234567", "file", "R1", "regex", "file")
        self.assertEqual(res["status"], "PASSED")

    def test_regex_match_fail(self):
        rule = {
            "severity": "ERROR",
            "message": "Invalid {actual_value}",
            "params": {"pattern": "^M[0-9]{7}$"}
        }
        res = validator.handle_regex(rule, "X123", "file", "R1", "regex", "file")
        self.assertEqual(res["status"], "FAILED")

    def test_list_items_regex(self):
        rule = {
            "severity": "ERROR",
            "params": {"item_pattern": "^[0-9]{3}$"}
        }
        res = validator.handle_list_items_regex(rule, ["123", "abc"], "file", "R1", "list")
        self.assertEqual(res["status"], "FAILED")

    def test_field_allowed_only_in_path(self):
        rule = {
            "severity": "ERROR",
            "params": {"allowed_path_contains": "allowed"}
        }
        res = validator.handle_field_allowed_only_in_path(
            rule, "value", "wrong/path", "R1", "rule"
        )
        self.assertEqual(res["status"], "FAILED")

    def test_list_not_contain_field_value(self):
        rule = {
            "severity": "ERROR",
            "params": {"other_field": "account_id"},
            "message": "Invalid"
        }
        doc = {"account_id": "123", "list": ["123"]}
        res = validator.handle_list_not_contain_field_value(
            rule, ["123"], doc, "file", "R1", "rule"
        )
        self.assertEqual(res["status"], "FAILED")

    def test_string_key_regex(self):
        rule = {
            "severity": "ERROR",
            "params": {
                "key_regex": "desc",
                "disallowed_values": ["na"]
            },
            "message": "Invalid {actual_value} at {field_path}"
        }
        doc = {"description": "na"}
        res = validator.handle_string_key_regex(rule, doc, "file", "R1", "rule")
        self.assertEqual(res[0]["status"], "FAILED")

    # ============================================================
    # PROCESS RULE TESTS
    # ============================================================

    def test_process_unknown_rule(self):
        res = validator.process_rule(
            "R1",
            {"type": "unknown"},
            {},
            "",
            ".json",
            "file"
        )
        self.assertEqual(res[0]["status"], "FAILED")

    # ============================================================
    # INTEGRATION TEST (validate)
    # ============================================================

    @patch("validation_framework.validators.global.parser_validator.load_file")
    @patch("validation_framework.validators.global.parser_validator.parse_file")
    def test_validate_integration(self, mock_parse, mock_load):
        mock_load.return_value = self.sample_json
        mock_parse.return_value = {"intake_id": "M1234567"}

        results = validator.validate(["file.json"], self.rules)

        self.assertTrue(len(results) > 0)
        statuses = [r["status"] for r in results]
        self.assertIn("PASSED", statuses)


if __name__ == "__main__":
    unittest.main()