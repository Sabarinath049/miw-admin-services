import unittest
from unittest.mock import patch, mock_open
import os
import sys
import importlib

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(BASE_DIR, "src"))

# ✅ Update if needed
MODULE_NAME = "validation_framework.validators.object_scope_smus_roles"
validator = importlib.import_module(MODULE_NAME)


class TestObjectScopeSMUSRoles(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.file_path = "test.yaml"

        cls.sample_payload = {
            "role_name": "sample_role"
        }

        cls.rules = {
            "RULE_FAIL": {
                "name": "block_smus_roles",
                "enabled": True,
                "severity": "ERROR",
                "type": "always_fail",
                "message": "SMUS roles not allowed",
                "recommendation": "Use other account"
            },
            "RULE_PASS": {
                "name": "allow_smus_roles",
                "enabled": True,
                "severity": "INFO",
                "type": "always_pass",
                "message": "SMUS roles allowed"
            }
        }

    # ============================================================
    # RESULT BUILDERS
    # ============================================================

    def test_build_result(self):
        res = validator.build_result("R1", "rule", "PASSED", "INFO", "file", "msg")
        self.assertEqual(res["status"], "PASSED")
        self.assertEqual(res["rule_id"], "R1")

    def test_build_summary(self):
        res = validator.build_file_summary_result(
            "file.yaml", "PASSED", "msg", 1, 0, 0, 1, {"env": "dev"}
        )
        self.assertEqual(res["status"], "PASSED")
        self.assertEqual(res["evidence"]["env"], "dev")

    # ============================================================
    # FILE LOADER
    # ============================================================

    @patch("builtins.open", new_callable=mock_open, read_data='{"a":1}')
    def test_load_json(self, mock_file):
        res = validator.load_yaml_or_json("file.json")
        self.assertEqual(res, {"a": 1})

    @patch("builtins.open", new_callable=mock_open, read_data="a: 1")
    def test_load_yaml(self, mock_file):
        res = validator.load_yaml_or_json("file.yaml")
        self.assertEqual(res, {"a": 1})

    @patch("builtins.open", side_effect=Exception("error"))
    def test_load_fail(self, mock_file):
        res = validator.load_yaml_or_json("file.yaml")
        self.assertIsNone(res)

    # ============================================================
    # ALWAYS FAIL RULE
    # ============================================================

    def test_always_fail(self):
        rule = self.rules["RULE_FAIL"]

        res = validator._always_fail(
            "RULE_FAIL", rule, self.sample_payload, self.file_path
        )

        self.assertEqual(res["status"], "FAILED")
        self.assertEqual(res["evidence"]["resource_detected"], True)

    # ============================================================
    # ALWAYS PASS RULE
    # ============================================================

    def test_always_pass(self):
        rule = self.rules["RULE_PASS"]

        res = validator._always_pass(
            "RULE_PASS", rule, self.sample_payload, self.file_path
        )

        self.assertEqual(res["status"], "PASSED")
        self.assertEqual(res["evidence"]["resource_detected"], True)

    # ============================================================
    # VALIDATE FUNCTION
    # ============================================================

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_fail_rule(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        rules = {"RULE_FAIL": self.rules["RULE_FAIL"]}

        results = validator.validate(["file.yaml"], rules)

        statuses = [r["status"] for r in results]
        self.assertIn("FAILED", statuses)

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_pass_rule(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        rules = {"RULE_PASS": self.rules["RULE_PASS"]}

        results = validator.validate(["file.yaml"], rules)

        statuses = [r["status"] for r in results]
        self.assertIn("PASSED", statuses)

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_mixed_rules(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        results = validator.validate(["file.yaml"], self.rules)

        statuses = [r["status"] for r in results]

        self.assertIn("FAILED", statuses)
        self.assertIn("PASSED", statuses)

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_file_error(self, mock_loader):
        mock_loader.return_value = None

        results = validator.validate(["file.yaml"], self.rules)

        self.assertEqual(results[0]["rule_id"], "FILE_LOAD_ERROR")
        self.assertEqual(results[0]["status"], "FAILED")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_summary_failed(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        rules = {"RULE_FAIL": self.rules["RULE_FAIL"]}

        results = validator.validate(["file.yaml"], rules)

        summary = [r for r in results if r["rule_id"] == "FILE_SUMMARY"][0]
        self.assertEqual(summary["status"], "FAILED")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_summary_passed(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        rules = {"RULE_PASS": self.rules["RULE_PASS"]}

        results = validator.validate(["file.yaml"], rules)

        summary = [r for r in results if r["rule_id"] == "FILE_SUMMARY"][0]
        self.assertEqual(summary["status"], "PASSED")

    @patch(f"{MODULE_NAME}.load_yaml_or_json")
    def test_validate_summary_mixed(self, mock_loader):
        mock_loader.return_value = self.sample_payload

        results = validator.validate(["file.yaml"], self.rules)

        summary = [r for r in results if r["rule_id"] == "FILE_SUMMARY"][0]
        self.assertEqual(summary["status"], "FAILED")


if __name__ == "__main__":
    unittest.main()