from src.validation_framework.core.validation_wrapper import main


if __name__ == "__main__":
    main()