output "s3_bucket_arns" {
  value       = join(
    "\n",
    distinct([
      for b in values(module.s3_bucket) : b.bucket_arn
    ])
  )
}
