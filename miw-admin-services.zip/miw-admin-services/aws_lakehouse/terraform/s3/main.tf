module "s3_bucket" {
  for_each            = local.s3_parsed_configs
  source              = "git::https://git.cglcloud.com/Minerva/minerva-terraform-modules.git//modules/s3_bucket?ref=1.5.1"
  bucket_name         = each.value.bucket_name
  additional_tags     = each.value.tags
  logging_bucket_name = each.value.logging_bucket
  encryption_option   = "S3-SS"
  kms_key_id          = ""
  providers = {
    aws = aws.assumed
  }
}


resource "aws_s3_bucket_policy" "miw_bucket_policy" {
  for_each = {
    for k, v in local.s3_parsed_configs : k => v
    if try(length(v.bucket_policy), 0) > 0
  }

  provider = aws.assumed
  bucket   = each.value.bucket_name
  policy   = each.value.bucket_policy

  depends_on = [module.s3_bucket]
}
