provider "aws" {
  region = "us-east-1"  # Change to your preferred region
}

provider "aws" {
  alias  = "assumed"
  region = var.region

  assume_role {
    role_arn     = local.cross_acc_deploy_role
    session_name = "terraform-${var.region}"
  }

  default_tags {
    tags = var.default_tags
  }
}

terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "= 6.55.0"
    }
  }
}

