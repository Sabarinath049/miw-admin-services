variable "project" {}
variable "env" {}
variable "generated_json_dir" {}
variable "account_id" {}
variable "account_name" {}

variable "region" {
  default = "us-east-1"
}

variable "default_tags" {
  type    = map(string)
  default = {}
}

locals {
  cross_acc_deploy_role         = "arn:aws:iam::${var.account_id}:role/minerva-${var.env}-corp-miw-cross-acc-deploy-role"
  glue_connections_config_files = fileset("${var.generated_json_dir}/${var.account_name}", "glue_connections/*.json")
  glue_connections_configs = {
    for file in local.glue_connections_config_files :
    basename(file) => jsondecode(file("${var.generated_json_dir}/${var.account_name}/${file}"))
  }
}
