data "aws_caller_identity" "current" {}

data "aws_region" "current" {}

data "aws_subnet" "glue_connection" {
  provider = aws.assumed
  for_each = {
    for k, v in local.glue_connections_configs : k => v
    if try(v.conn_configs.network.subnet_id, null) != null
  }
  id = each.value.conn_configs.network.subnet_id
}
