output "glue_connection_names" {
  value = join(
    "\n",
    [for c in values(aws_glue_connection.main) : c.name]
  )
}

output "glue_connection_arns" {
  value = join(
    "\n",
    [for c in values(aws_glue_connection.main) : c.arn]
  )
}

output "glue_connection_ids" {
  value = join(
    "\n",
    [for c in values(aws_glue_connection.main) : c.id]
  )
}