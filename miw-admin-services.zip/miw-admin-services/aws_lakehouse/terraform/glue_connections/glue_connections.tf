resource "aws_glue_connection" "main" {
  provider              = aws.assumed
  for_each              = local.glue_connections_configs
  name                  = each.value.conn_name
  description           = try(each.value.conn_description, null)
  connection_type       = upper(each.value.conn_type)
  connection_properties = try(each.value.connection_properties, {})
  match_criteria        = try(each.value.match_criteria, [])

  dynamic "physical_connection_requirements" {
    for_each = try(each.value.conn_configs.network, null) != null ? [1] : []

    content {
      subnet_id              = each.value.conn_configs.network.subnet_id
      security_group_id_list = try(each.value.conn_configs.network.security_group_ids, [])
      availability_zone      = data.aws_subnet.glue_connection[each.key].availability_zone
    }
  }

  tags = merge(
    var.default_tags,
    try(each.value.tags, {})
  )
}
