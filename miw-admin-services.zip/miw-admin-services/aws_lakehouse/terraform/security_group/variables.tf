variable "project" {}
variable "env" {}
variable "generated_json_dir" {}
variable "account_id" {}
variable "account_name" {}

variable "region" {
  default = "us-east-1"
}

variable "default_tags" {
  type = map(string)
  default = {}
}

locals {
  cross_acc_deploy_role = "arn:aws:iam::${var.account_id}:role/minerva-${var.env}-corp-miw-cross-acc-deploy-role"
  security_group_config_files = fileset("${var.generated_json_dir}/${var.account_name}", "security_group/*.json")
  security_group_parsed_configs = {
    for file in local.security_group_config_files :
    basename(file) => jsondecode(file("${var.generated_json_dir}/${var.account_name}/${file}"))
  }
}