output "security_group_ids" {
  description = "IDs of the created security groups"
  value = {
    for k, sg in aws_security_group.this :
    k => sg.id
  }
}

output "security_group_names" {
  description = "Names of the created security groups"
  value = {
    for k, sg in aws_security_group.this :
    k => sg.name
  }
}

output "security_group_arns" {
  description = "ARNs of the created security groups"
  value = {
    for k, sg in aws_security_group.this :
    k => sg.arn
  }
}
