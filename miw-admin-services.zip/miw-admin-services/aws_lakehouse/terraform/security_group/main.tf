resource "aws_security_group" "this" {
  provider    = aws.assumed
  for_each    = local.security_group_parsed_configs
  name        = each.value.sg_name
  description = each.value.sg_description
  vpc_id      = each.value.vpc_id


  # -------------------------
  # INGRESS RULES
  # -------------------------
  dynamic "ingress" {
    for_each = lookup(each.value, "ingress_rules", [])
    content {
      protocol        = ingress.value.protocol
      from_port       = ingress.value.from_port
      to_port         = ingress.value.to_port
      description     = lookup(ingress.value, "rule_description", null)
      cidr_blocks     = (lookup(ingress.value, "source_type", "") == "cidr" ? [ingress.value.source_value] : null)
      security_groups = (lookup(ingress.value, "source_type", "") == "security_group" ? [ingress.value.source_value] : null)
      self            = (lookup(ingress.value, "source_type", "") == "self" ? true : null)
    }
  }

  # -------------------------
  # EGRESS RULES
  # -------------------------
  dynamic "egress" {
    for_each = lookup(each.value, "egress_rules", [])
    content {
      protocol        = egress.value.protocol
      from_port       = egress.value.from_port
      to_port         = egress.value.to_port
      description     = lookup(egress.value, "rule_description", null)
      cidr_blocks     = (lookup(egress.value, "destination_type", "") == "cidr" ? [egress.value.destination_value] : null)
      security_groups = (lookup(egress.value, "destination_type", "") == "security_group" ? [egress.value.destination_value] : null)
      self            = (lookup(egress.value, "destination_type", "") == "self" ? true : null)
    }
  }

  # -------------------------
  # TAGS
  # -------------------------

  tags = merge(
    var.default_tags,
    try(each.value.tags, {})
  )
}
