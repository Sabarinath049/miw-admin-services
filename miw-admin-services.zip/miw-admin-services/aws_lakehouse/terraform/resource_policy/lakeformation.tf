module "lf_db_permissions_for_resource_policy" {
  for_each                              = local.rp_parsed_configs
  source                                = "git::https://git.cglcloud.com/Minerva/minerva-terraform-modules.git//modules/lakeformation?ref=add-wait-resource-lakeformation"
  enable_lakeformation                  = true
  manage_lakeformation_settings         = true
  allow_full_table_external_data_access = true
  lakeformation_admin_arns              = concat(tolist(data.aws_lakeformation_data_lake_settings.current.admins), [local.cross_acc_deploy_role], [])
  data_lake_locations                   = fileexists("${var.generated_json_dir}/${var.account_name}/resource_policy/lake_formation/data_permission_s3/${each.value.resource_policy_name}.json") ? jsondecode(file("${var.generated_json_dir}/${var.account_name}/resource_policy/lake_formation/data_permission_s3/${each.value.resource_policy_name}.json")) : []
  data_permissions                      = try(jsondecode(file("${var.generated_json_dir}/${var.account_name}/resource_policy/lake_formation/data_permission_glue_db/${each.value.resource_policy_name}.json")), [])
  providers = {
    aws = aws.assumed
  }
  lf_parameters = {
    CROSS_ACCOUNT_VERSION = "4"
  }
}