
output "resource_policy_lf_arns" {
  description = "Lake Formation registered data lake locations (newline-separated)"
  value       = join(
    "\n",
    distinct(
      flatten([
        for lf in values(module.lf_db_permissions_for_resource_policy) :
        formatlist("%s", lf.registered_data_lake_locations)
      ])
    )
  )
}