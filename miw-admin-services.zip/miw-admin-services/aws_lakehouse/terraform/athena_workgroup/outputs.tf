output "athena_workgroup_names" {
  description = "Athena Workgroup names"
  value = {
    for k, v in aws_athena_workgroup.main : k => v.name
  }
}

output "athena_workgroup_arns" {
  description = "Athena Workgroup ARNs"
  value = {
    for k, v in aws_athena_workgroup.main : k => v.arn
  }
}

output "athena_workgroup_ids" {
  description = "Athena Workgroup IDs"
  value = {
    for k, v in aws_athena_workgroup.main : k => v.id
  }
}