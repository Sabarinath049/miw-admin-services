resource "aws_athena_workgroup" "main" {
  provider      = aws.assumed
  for_each      = local.athena_workgroup_configs
  name          = each.value.athena_workgroup_name
  description   = try(each.value.athena_workgroup_description, "") != "" ? each.value.athena_workgroup_description : "Athena Workgroup for ${each.value.athena_workgroup_name}"
  state         = try(each.value.enabled, true) ? "ENABLED" : "DISABLED"
  force_destroy = try(each.value.force_destroy, false)
  configuration {
    bytes_scanned_cutoff_per_query          = try(each.value.data_scanned_limit, null)
    enforce_workgroup_configuration         = try(each.value.enforce_workgroup_configuration, true)
    publish_cloudwatch_metrics_enabled      = try(each.value.publish_cloudwatch_metrics_enabled, true)
    requester_pays_enabled                  = try(each.value.requester_pays_enabled, false)
    enable_minimum_encryption_configuration = try(each.value.enable_minimum_encryption_configuration, false)
    execution_role                          = try(each.value.execution_role, null)

    dynamic "engine_version" {
      for_each = try(each.value.engine_version, null) != null ? [1] : []

      content {
        selected_engine_version = each.value.engine_version
      }
    }

    result_configuration {
      output_location = each.value.query_result_location

      encryption_configuration {
        encryption_option = try(each.value.encryption_option, "SSE_S3")
        kms_key_arn       = (try(each.value.encryption_option, "SSE_S3") == "SSE_KMS") ? try(each.value.kms_key_arn, null) : null
      }

      dynamic "acl_configuration" {
        for_each = try(each.value.s3_acl_option, null) != null ? [1] : []

        content {
          s3_acl_option = each.value.s3_acl_option
        }
      }
    }

    dynamic "customer_content_encryption_configuration" {
      for_each = try(each.value.customer_content_kms_key, null) != null ? [1] : []

      content {
        kms_key = each.value.customer_content_kms_key
      }
    }
  }

  tags = merge(
    var.default_tags,
    try(each.value.tags, {})
  )
}

