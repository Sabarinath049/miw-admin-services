
# # Read the file ONLY after the null_resource is done
# data "local_file" "python_results" {
#  depends_on = [null_resource.run_python]
#  filename   = "${var.generated_json_dir}/python_outputs.json"
# }

# # Parse the JSON and create a shell export string
# locals {
#  script_data = jsondecode(data.local_file.python_results.content)
# }
# output "glue_exports" {
#  value = "${local.script_data.db_names}"
# }