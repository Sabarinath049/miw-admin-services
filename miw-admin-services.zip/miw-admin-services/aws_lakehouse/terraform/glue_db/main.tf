# resource "aws_glue_catalog_database" "miw_glue_database" {
#   provider     = aws.assumed
#   for_each     = local.glue_db_configs
#   name         = each.value.database_name
#   description  = each.value.database_description
#   catalog_id   = each.value.catalog_name
#   location_uri = contains(keys(each.value), "database_s3_location") ? each.value.database_s3_location : null
#   tags         = each.value.tags
# }

resource "null_resource" "run_python" {
  # Force re-run each plan/apply
   triggers = {
    always_run = timestamp()
  }

  provisioner "local-exec" {
    command = "python3 -u ${var.CODEBUILD_SRC_DIR_admin}/aws_lakehouse/python/create_glue_db.py"

    # Environment passed to the Python process
    environment = {
      TF_WORKSPACE        = terraform.workspace
      aws_region          = var.region
      generated_json_dir  = var.generated_json_dir
      account_name        = var.account_name
      account_id          = var.account_id
      # glue_db_configs     = jsonencode(local.glue_db_configs) # For 360 files, this parameter couldn't be handled
    }
  }
}
