bucket         = "minerva-prd-corp-miw-tfstate-255914130710-useast1"
key            = "aws_lakehouse/${PRODUCT_KEY}/${component}.json"
region         = "us-east-1"
dynamodb_table = "minerva-prd-corp-miw-tfstate-dynamodb-table"