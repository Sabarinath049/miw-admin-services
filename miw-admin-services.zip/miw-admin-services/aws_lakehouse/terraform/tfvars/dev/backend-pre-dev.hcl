bucket         = "minerva-dev-corp-miw-tfstate-430118842002-useast1"
key            = "aws_lakehouse/dev/prerequisites/aws_lakehouse.json"
region         = "us-east-1"
dynamodb_table = "minerva-dev-corp-miw-tfstate-dynamodb-table"