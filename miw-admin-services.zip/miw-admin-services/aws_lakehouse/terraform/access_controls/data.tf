data "aws_caller_identity" "current" {}

data "aws_region" "current" {}

data "aws_lakeformation_data_lake_settings" "current" {
  provider = aws.assumed
}
