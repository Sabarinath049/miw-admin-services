module "iam_role" {
  for_each        = local.iam_parsed_configs
  source          = "git::https://git.cglcloud.com/Minerva/minerva-terraform-modules.git//modules/iam_role?ref=1.5.4"
  role_name       = each.value.role_name
  policy_name     = "${each.value.role_name}_policy"
  additional_tags = merge(var.default_tags, each.value.tags)
  policy          = fileexists("${var.generated_json_dir}/${var.account_name}/iam/policy/${each.value.role_name}/${each.value.role_name}_policy.json") ? file("${var.generated_json_dir}/${var.account_name}/iam/policy/${each.value.role_name}/${each.value.role_name}_policy.json") : ""
  trust_policy    = fileexists("${var.generated_json_dir}/${var.account_name}/iam/trust/${each.value.role_name}_trust.json") ? file("${var.generated_json_dir}/${var.account_name}/iam/trust/${each.value.role_name}_trust.json") : ""
  max_session_duration_hours = each.value.max_session_duration
  description     = each.value.role_description
  providers = {
    aws = aws.assumed
  }
}

# Adding a separate resource to attach multiple policies to a role if needed.
resource "aws_iam_policy" "custom_policy" {
  for_each = local.flattened_policies
  name   = replace(each.key, ".json", "")
  policy = file(each.value.file_path)
  tags = var.default_tags
  provider = aws.assumed
}

resource "time_sleep" "wait_for_iam" {
  depends_on = [module.iam_role]
  create_duration = "20s"
}
 
resource "aws_iam_role_policy_attachment" "attach_policy" {
  for_each = local.flattened_policies

  provider   = aws.assumed
  role       = module.iam_role[each.value.role].role_name
  policy_arn = aws_iam_policy.custom_policy[each.key].arn

  depends_on = [
    time_sleep.wait_for_iam
  ]
}