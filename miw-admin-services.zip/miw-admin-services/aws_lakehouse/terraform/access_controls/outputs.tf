output "iam_role_arns" {
  value       = join("\n", [for r in values(module.iam_role) : r.role_arn])
}

output "lakeformation_arns" {
  value = join(
    "\n",
    distinct(
      flatten([
        for lf in values(module.lf_db_all_tables_readonly) :
        formatlist("%s", lf.registered_data_lake_locations)
      ])
    )
  )
}