variable "project" {}
variable "env" {}
variable "generated_json_dir" {}
variable "account_id" {}
variable "account_name" {}

variable "region" {
  default = "us-east-1"
}

variable "default_tags" {
  type = map(string)
  default = {}
}

variable "kms_key_map" {
  type = map(string)
  default = {
    dev = "arn:aws:kms:us-east-1:430118842002:key/54ef7415-b4b1-4fb1-b168-a9f5d275daeb"
    snd = "arn:aws:kms:us-east-1:442426855665:key/bcb3ffb7-7b9d-41a6-8906-26e6897ddf82"
    prod = "arn:aws:kms:us-east-1:430118842002:key/prod-key-id"
  }
}

locals {
  cross_acc_deploy_role = "arn:aws:iam::${var.account_id}:role/minerva-${var.env}-corp-miw-cross-acc-deploy-role"
  iam_config_files = fileset("${var.generated_json_dir}/${var.account_name}", "iam/*.json")
  iam_parsed_configs = {
    for file in local.iam_config_files :
    basename(file) => jsondecode(file("${var.generated_json_dir}/${var.account_name}/${file}"))
    if basename(file) != "minerva-${var.env}-miw-s3-service-iam-role.json"
  }
}

# Adding the locals to attach multiple policies to a role if needed. 
locals {
  role_policy_files = {
    for role, cfg in local.iam_parsed_configs :
    role => [
      for file in fileset(
        "${var.generated_json_dir}/${var.account_name}/iam/policy/${cfg.role_name}",
        "*.json"
      ) : file
      if !endswith(file, "policy.json")
    ]
  }
}

locals {
  flattened_policies = {
    for policy in flatten([
      for role, files in local.role_policy_files : [
        for file in files : {
          key       = "${file}"
          role      = role
          role_name = local.iam_parsed_configs[role].role_name
          file_path = "${var.generated_json_dir}/${var.account_name}/iam/policy/${local.iam_parsed_configs[role].role_name}/${file}"
        }
      ]
    ]) : policy.key => policy
  }
}