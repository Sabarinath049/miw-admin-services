module "lf_db_all_tables_readonly" {
  depends_on                            = [module.iam_role]
  for_each                              = local.iam_parsed_configs
  source                                = "git::https://git.cglcloud.com/Minerva/minerva-terraform-modules.git//modules/lakeformation?ref=add-wait-resource-lakeformation"
  enable_lakeformation                  = true
  allow_full_table_external_data_access = true
  # manage_lakeformation_settings         = true
  lakeformation_admin_arns              = concat(tolist(data.aws_lakeformation_data_lake_settings.current.admins), [local.cross_acc_deploy_role], [])
  data_lake_locations                   = fileexists("${var.generated_json_dir}/${var.account_name}/lake_formation/data_permission_s3/${each.value.role_name}.json") ? jsondecode(file("${var.generated_json_dir}/${var.account_name}/lake_formation/data_permission_s3/${each.value.role_name}.json")) : []
  data_permissions                      = try(jsondecode(file("${var.generated_json_dir}/${var.account_name}/lake_formation/data_permission_glue_db/${each.value.role_name}.json")), [])
  hybrid_opt_ins                        = fileexists("${var.generated_json_dir}/${var.account_name}/lake_formation/data_permission_glue_db_hybrid/${each.value.role_name}.json") ? jsondecode(file("${var.generated_json_dir}/${var.account_name}/lake_formation/data_permission_glue_db_hybrid/${each.value.role_name}.json")) : []
  providers = {
    aws = aws.assumed
  }
}