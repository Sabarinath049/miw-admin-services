module "lf_data_federation" {
  for_each                              = local.data_federation_lf_parsed_configs
  source                                = "git::https://git.cglcloud.com/Minerva/minerva-terraform-modules.git//modules/lakeformation?ref=add-wait-resource-lakeformation"
  enable_lakeformation                  = true
  allow_full_table_external_data_access = true
  # manage_lakeformation_settings         = true
  lakeformation_admin_arns              = concat(tolist(data.aws_lakeformation_data_lake_settings.current.admins), [local.cross_acc_deploy_role], [])
  data_permissions                      = each.value
  providers = {
    aws = aws.assumed
  }
}
