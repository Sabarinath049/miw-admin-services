resource "aws_glue_catalog_database" "resource_link" {
  provider = aws.assumed
  for_each = local.resource_links_flattened
  name     = "${each.value.Name}"
  target_database {
    catalog_id    = each.value.CatalogId
    database_name = each.value.DatabaseName
  }
  lifecycle {
    ignore_changes = [description, tags]
  }
}