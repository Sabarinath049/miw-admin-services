output "lakeformation_permissions_with_grant_option" {
  value = join(
    "\n",
    flatten([
      for df in values(module.lf_data_federation) : [
        for k, grantable in try(df.permissions_grantable, {}) :
        "${k}=${length(grantable) > 0 ? join(",", grantable) : ""}"
      ]
    ])
  )
}

output "lakeformation_registered_locations" {
  value = join(
    "\n",
    distinct(
      flatten([
        for df in values(module.lf_data_federation) : df.registered_data_lake_locations
      ])
    )
  )
}

output "resource_link_arns" {
  value = join(
    "\n",
    distinct([
      for rl in values(aws_glue_catalog_database.resource_link) : rl.arn
    ])
  )
}
