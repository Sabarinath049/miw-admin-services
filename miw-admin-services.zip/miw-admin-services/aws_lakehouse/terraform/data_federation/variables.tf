variable "project" {}
variable "env" {}
variable "generated_json_dir" {}
variable "account_id" {}
variable "account_name" {}

variable "region" {
  default = "us-east-1"
}

variable "default_tags" {
  type    = map(string)
  default = {}
}

variable "kms_key_map" {
  type = map(string)
  default = {
    dev  = "arn:aws:kms:us-east-1:430118842002:key/54ef7415-b4b1-4fb1-b168-a9f5d275daeb"
    snd  = "arn:aws:kms:us-east-1:442426855665:key/bcb3ffb7-7b9d-41a6-8906-26e6897ddf82"
    prod = "arn:aws:kms:us-east-1:430118842002:key/prod-key-id"
  }
}


locals {
  env_from_map          = jsondecode(file("${var.generated_json_dir}/account_env_map.json"))[var.account_id]
  cross_acc_deploy_role = "arn:aws:iam::${var.account_id}:role/minerva-${local.env_from_map}-corp-miw-cross-acc-deploy-role"

  data_federation_lf_config_files = fileset("${var.generated_json_dir}/${var.account_name}/data_federation/lake_formation", "*.json")
  data_federation_lf_parsed_configs = {
    for file in local.data_federation_lf_config_files :
    basename(file) => jsondecode(file("${var.generated_json_dir}/${var.account_name}/data_federation/lake_formation/${file}"))
  }

  resource_links_config_files = fileset("${var.generated_json_dir}/${var.account_name}/data_federation/resource_links", "*.json")
  resource_links_parsed_configs = {
    for file in local.resource_links_config_files :
    basename(file) => jsondecode(file("${var.generated_json_dir}/${var.account_name}/data_federation/resource_links/${file}"))
  }
  resource_links_flattened = merge([
    for file, dbs in local.resource_links_parsed_configs : dbs
  ]...)
}