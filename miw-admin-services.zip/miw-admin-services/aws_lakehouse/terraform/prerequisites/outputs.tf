output "iam_role_arns" {
  value = join("\n", [for r in values(module.iam_role) : r.role_arn])
}
