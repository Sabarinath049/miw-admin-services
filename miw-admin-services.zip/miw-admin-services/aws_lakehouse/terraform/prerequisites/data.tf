data "aws_caller_identity" "current" {}

data "aws_region" "current" {}

data "aws_secretsmanager_secret_version" "github" {
  secret_id = var.secrets_manager
}
