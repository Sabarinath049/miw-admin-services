module "iam_role" {
  for_each        = local.iam_parsed_configs
  source          = "git::https://git.cglcloud.com/Minerva/minerva-terraform-modules.git//modules/iam_role?ref=1.5.4"
  role_name       = each.value.role_name
  policy_name     = "${each.value.role_name}_iam_policy"
  additional_tags = merge(var.default_tags, each.value.tags)
  policy          = fileexists("${var.generated_json_dir}/${var.account_name}/iam/policy/${each.value.role_name}/${each.value.role_name}_policy.json") ? file("${var.generated_json_dir}/${var.account_name}/iam/policy/${each.value.role_name}/${each.value.role_name}_policy.json") : ""
  trust_policy    = fileexists("${var.generated_json_dir}/${var.account_name}/iam/trust/${each.value.role_name}_trust.json") ? file("${var.generated_json_dir}/${var.account_name}/iam/trust/${each.value.role_name}_trust.json") : ""
  providers = {
    aws = aws.assumed
  }
}