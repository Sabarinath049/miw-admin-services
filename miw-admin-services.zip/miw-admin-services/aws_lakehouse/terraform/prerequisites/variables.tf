variable "project" {}
variable "env" {}
variable "secrets_manager" {}
variable "generated_json_dir" {}
variable "account_id" {}
variable "account_name" {}

variable "region" {
  default = "us-east-1"
}

variable "default_tags" {
  type = map(string)
  default = {}
}

variable "kms_key_map" {
  type = map(string)
  default = {
    dev = "arn:aws:kms:us-east-1:430118842002:key/54ef7415-b4b1-4fb1-b168-a9f5d275daeb"
    snd = "arn:aws:kms:us-east-1:442426855665:key/bcb3ffb7-7b9d-41a6-8906-26e6897ddf82"
    prod = "arn:aws:kms:us-east-1:430118842002:key/prod-key-id"
  }
}

locals {
  tfstate_bucket = "minerva-${var.env}-corp-miw-tfstate-${data.aws_caller_identity.current.account_id}-${replace(data.aws_region.current.name, "-", "")}"
  codepipeline_arn = "arn:aws:codepipeline:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:minerva-${var.env}-corp-${var.project}-lhdeploy-codepipeline"
  github_secret = jsondecode(data.aws_secretsmanager_secret_version.github.secret_string)
  notify_sns_topic_arn = "arn:aws:sns:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:minerva-${var.env}-corp-${var.project}-statelock-sns-topic"
  cross_acc_deploy_role = "arn:aws:iam::${var.account_id}:role/minerva-${var.env}-corp-miw-cross-acc-deploy-role"
  iam_config_files = fileset("${var.generated_json_dir}/${var.account_name}", "iam/minerva-${var.env}-miw-s3-service-iam-role.json")
  iam_parsed_configs = {
    for file in local.iam_config_files :
    basename(file) => jsondecode(file("${var.generated_json_dir}/${var.account_name}/${file}"))
  }
}