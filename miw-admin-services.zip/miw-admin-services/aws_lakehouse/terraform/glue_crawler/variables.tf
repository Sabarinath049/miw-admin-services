variable "project" {}
variable "env" {}
variable "generated_json_dir" {}
variable "account_id" {}
variable "account_name" {}
variable "enabled" {
  default = true
}

variable "region" {
  default = "us-east-1"
}

variable "default_tags" {
  type = map(string)
  default = {}
}

variable "kms_key_map" {
  type = map(string)
  default = {
    dev = "arn:aws:kms:us-east-1:430118842002:key/54ef7415-b4b1-4fb1-b168-a9f5d275daeb"
    snd = "arn:aws:kms:us-east-1:442426855665:key/bcb3ffb7-7b9d-41a6-8906-26e6897ddf82"
    prod = "arn:aws:kms:us-east-1:430118842002:key/prod-key-id"
  }
}

locals {
  cross_acc_deploy_role = "arn:aws:iam::${var.account_id}:role/minerva-${var.env}-corp-miw-cross-acc-deploy-role"
  glue_crawler_files = fileset("${var.generated_json_dir}/${var.account_name}", "glue_crawler/*.json")
  glue_crawler_configs = {
    for file in local.glue_crawler_files :
    basename(file) => jsondecode(file("${var.generated_json_dir}/${var.account_name}/${file}"))
  }
}
