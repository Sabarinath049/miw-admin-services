module "glue_crawler" {
  for_each               = local.glue_crawler_configs
  source                 = "git::https://git.cglcloud.com/Minerva/minerva-terraform-modules.git//modules/glue_crawler?ref=1.5.4"
  enabled                = var.enabled
  crawler_name           = each.value.crawler_name
  crawler_description    = each.value.crawler_description
  database_name          = each.value.database_name
  additional_tags        = each.value.tags
  role                   = "arn:aws:iam::${each.value.aws_account_id}:role/${each.value.crawler_name}_iam"
  schedule               = each.value.schedule.enabled ? "cron(${each.value.schedule.cron_expression})" : null
  classifiers            = null
  configuration          = null
  security_configuration = null
  table_prefix           = null
  catalog_target         = null
  delta_target           = null
  dynamodb_target        = null
  jdbc_target            = null
  mongodb_target         = null
  s3_target = each.value.s3_type != "iceberg" ? [
    {
      path                = each.value.s3_target_paths
      connection_name     = null
      exclusions          = null
      sample_size         = null
      event_queue_arn     = null
      dlq_event_queue_arn = null
    }
  ] : []
  lineage_configuration = null
  schema_change_policy = {
    delete_behavior = "DELETE_FROM_DATABASE"
    update_behavior = "UPDATE_IN_DATABASE"
  }
  recrawl_policy = {
    recrawl_behavior = each.value.recrawl_behavior
  }
  iceberg_target = each.value.s3_type == "iceberg" ? [
    {
      paths                   = each.value.s3_target_paths
      maximum_traversal_depth = 3
      exclusions              = null
      connection_name         = null
    }
  ] : []

  providers = {
    aws = aws.assumed
  }
}
