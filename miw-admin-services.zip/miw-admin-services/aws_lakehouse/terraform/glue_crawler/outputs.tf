output "glue_crawler_arns" {
  value       = join(
    "\n",
    distinct([
      for c in values(module.glue_crawler) : format("%s", c.arn)
    ])
  )
}