
import boto3
from botocore.exceptions import ClientError
import sys
import json
import os
import yaml

def list_lakeformation_locations(region: str, session):
    """
    Lists registered Lake Formation data lake locations (S3 resources) using list_resources
    and handles pagination via NextToken.
    """
    list_resources= {}
    region = region
    lf = session.client("lakeformation", region_name=region)

    next_token = None
    count = 0

    while True:
        params = {}
        if next_token:
            params["NextToken"] = next_token
        # (Optional) params["MaxResults"] = 100

        resp = lf.list_resources(**params)

        resources = resp.get("ResourceInfoList", [])
        for res in resources:
            count += 1
            resource_arn = res.get("ResourceArn")         
            role_arn = res.get("RoleArn")                  
            last_modified = res.get("LastModified")
            # Additional fields may appear depending on account config; safe to ignore if absent
            
            if resource_arn not in list_resources:
                list_resources[resource_arn]=[role_arn]
            else:
                list_resources[resource_arn].extend([role_arn])
        next_token = resp.get("NextToken")
        if not next_token:
            break

    if count == 0:
        print("No data lake locations (registered resources) found.")
    return list_resources

def sts_assume_role():
    # Create STS client
    sts_client = boto3.client('sts')
    
    # Assume the role
    response = sts_client.assume_role(
        RoleArn=cross_account_role_arn,
        RoleSessionName=session_name
    )
    
    # Extract temporary credentials
    creds = response['Credentials']
    
    # Example: use these credentials to create a new boto3 session
    assumed_session = boto3.session.Session(
        aws_access_key_id=creds['AccessKeyId'],
        aws_secret_access_key=creds['SecretAccessKey'],
        aws_session_token=creds['SessionToken']
    )
    return assumed_session

def ensure_lakeformation_admin(
    session: boto3.session.Session,
    region: str,
    admin_arn: str
) -> dict:
    """
    Ensures the given principal is a Lake Formation admin.
    Equivalent to lakeformation_admin_arns in Terraform.
    """
    lf = session.client("lakeformation", region_name=region)

    try:
        # 1. Get current LF settings
        resp = lf.get_data_lake_settings()
        settings = resp.get("DataLakeSettings", {})

        current_admins = set(settings.get("Admins", []))

        # 2. Check if already admin
        if admin_arn in current_admins:
            return {
                "status": "exists",
                "admin": admin_arn
            }

        settings["AllowFullTableExternalDataAccess"] = True

        # 3. Add admin
        current_admins.add(admin_arn)
        settings["Admins"] = list(current_admins)

        # 4. Update LF settings
        lf.put_data_lake_settings(
            DataLakeSettings=settings
        )

        return {
            "status": "added",
            "admin": admin_arn
        }

    except ClientError as e:
        return {
            "status": "error",
            "admin": admin_arn,
            "error": str(e)
        }

def register_lf_location(
    session: boto3.session.Session,
    region: str,
    s3_arn: str,
    role_arn: str = None,
    use_service_linked_role: bool = False,
    lakeformation_mode: bool = True,
    federated_data: bool = True
) -> dict:
    """
    Register an S3 location in Lake Formation with desired options.

    Parameters:
      session: boto3 Session (use your assumed session for cross-account).
      region: AWS region (e.g., 'us-east-1').
      s3_arn: 'arn:aws:s3:::bucket' OR 'arn:aws:s3:::bucket/prefix'.
      role_arn: IAM role LF will assume when vending credentials (ignored if use_service_linked_role=True).
      use_service_linked_role: True to use AWSServiceRoleForLakeFormationDataAccess.
      lakeformation_mode: True => LF-only mode; False => Hybrid access mode.
      federated_data: True to enable the "Federate data" checkbox.

    Returns:
      dict with 'status' and details.
    """

    lf = session.client("lakeformation", region_name=region)

    # Map to API parameters
    params = {
        "ResourceArn": s3_arn,
        "UseServiceLinkedRole": use_service_linked_role,
        # HybridAccessEnabled=True means HYBRID; False means LF mode
        "HybridAccessEnabled": (not lakeformation_mode),
        "WithFederation": federated_data
    }
    if not use_service_linked_role:
        if not role_arn:
            raise ValueError("role_arn is required when use_service_linked_role=False")
        params["RoleArn"] = role_arn

    try:
        lf.register_resource(**params)  # returns empty dict on success
        return {
            "status": "registered",
            "region": region,
            "params": params
        }
    except ClientError as e:
        return {
            "status": "error",
            "error": str(e),
            "region": region,
            "params": params
        }

def read_yaml_files(folder_path : str) -> list :
    """
    Used to read s3 yaml files and fetch bucket name out of it, prepare data_dictionary to register paths if doesn't exist.
    """
    input = []
    try:
        files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]

        for file in files:
            with open(os.path.join(folder_path,file), 'r') as f:
                s3_data = yaml.safe_load(f)

                if 'assets' in s3_data['bucket_name']:
                    continue
                
                input.append({"s3_arn":f"arn:aws:s3:::{s3_data['bucket_name']}","role_arn":s3_service_role_arn})
        return input
    except Exception as e:
        raise Exception(f"Unable to read s3 files and create input list for registration of resources due to error -> {e}")
            

## Get job arguments
try:
    session_name = "miw-session-lf-register-s3-paths"
    env=os.getenv("CODEBUILD_ENV")
    aws_region = os.getenv("aws_region", "us-east-1")
    account_id= os.getenv("account_id")
    account_name = os.getenv("account_name")
    cross_account_role_arn = f"arn:aws:iam::{account_id}:role/minerva-{env}-corp-miw-cross-acc-deploy-role"
    s3_service_role_arn = f"arn:aws:iam::{account_id}:role/minerva-{env}-miw-s3-service-iam-role"

    # Read environment variables
    generated_json_dir = os.getenv("lakehouse_output_dir")
    account_name = os.getenv("account_name")

    # Validate values
    if not generated_json_dir or not account_name:
        raise ValueError("Missing required environment variables: generated_json_dir or account_name")

    # Construct the path
    s3_files_path = f"{generated_json_dir}/{account_name}/s3/"

except:
    raise Exception(f"Unable to fetch arguments passed to python program register_s3_location_lf.py, arguments passed are : {sys.argv}")

assumed_session=sts_assume_role()

# admin_resp = ensure_lakeformation_admin(
#     session=assumed_session,
#     region=aws_region,
#     admin_arn=cross_account_role_arn
# )

# print(f"Lake Formation admin check: {admin_resp}")

aws_data_lake_dic=list_lakeformation_locations(region=aws_region, session=assumed_session)
# print(aws_data_lake_dic)

#### Polpulate the below variables by reading files in data_location ####
# input_data=[{"s3_arn":"arn:aws:s3:::dummy-poc-test-tharun","role_arn":"arn:aws:iam::904233109241:role/minerva-snd-miw-s3-service-iam-role"},{"s3_arn":"arn:aws:s3:::dummy-poc-test-tharun123","role_arn":"arn:aws:iam::904233109241:role/minerva-snd-miw-s3-service-iam-role123"},{"s3_arn":"arn:aws:s3:::dummy-poc-test-tharun456","role_arn":"arn:aws:iam::904233109241:role/minerva-snd-miw-s3-service-iam-role"}]
input_data = read_yaml_files(s3_files_path)

to_register_resources=[]
already_registered_resources=[]
for i in input_data:
    s3_location=i["s3_arn"]
    role_arn=i["role_arn"]
    
    exists=False
    ## Validate if s3_location and role_arn record already exists ##
    if s3_location in aws_data_lake_dic:
        if role_arn in aws_data_lake_dic[s3_location]:
            exists=True
        else:
            exists=False
    else:
        exists=False
    
    if exists:
        already_registered_resources.append({"s3_arn":s3_location, "role_arn":role_arn})
        print(f"{s3_location} and {role_arn} record exists in data lake locations, skipping it!!!")
        continue
    else:
        print(f"{s3_location} and {role_arn} record doesn't exist in data lake locations, thus adding to it")
        to_register_resources.append({"s3_arn":s3_location, "role_arn":role_arn})

## Assuming the role again before registering the resources, ##
## so that I won't see session timeout while registering the resources ##
assumed_session=sts_assume_role()
for i in to_register_resources:
    s3_location=i["s3_arn"]
    role_arn=i["role_arn"]
    register_lf_location(session= assumed_session, region= aws_region, s3_arn=s3_location, role_arn=role_arn)
    print(f"Registration Successful for {s3_location} & {role_arn}")


