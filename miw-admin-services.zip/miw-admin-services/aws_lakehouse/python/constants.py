import os

# Logging configuration
LOGGING_LEVEL, LOG_FOLDER = "INFO", "logs"

# Environment variable
ENV = os.getenv("env")

# Region
REGION = os.getenv("region", "us-east-1")

# DynamoDB table name for validation details
VALIDATION_DETAILS_TABLE = "minerva_lakehouse_validation_details"

# DynamoDB table name for reference json
REFERENCE_JSON_TABLE = "minerva_lakehouse_reference_json"
