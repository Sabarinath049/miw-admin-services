import os, sys, yaml, json, re, copy
from helpers.config_log import logger
from constants import ENV, VALIDATION_DETAILS_TABLE, REFERENCE_JSON_TABLE, REGION
from helpers.utils import (
    get_items_from_dynamodb, 
    execute_expression,
    replace_placeholders, 
    load_yaml, 
    filter_by_object_type
)
from typing import Tuple, Dict, List
from collections import defaultdict

def check_tabs(lines, file_path):
    """Validate that the YAML file does not contain tab characters."""
    errors = []

    for line_num, line in enumerate(lines, start=1):
        if "\t" in line:
            errors.append(
                f"{file_path}: Line {line_num}: Tab character found"
            )

    return errors


def check_trailing_whitespace(lines, file_path):
    """Validate that lines do not contain trailing whitespace."""
    errors = []

    for line_num, line in enumerate(lines, start=1):
        if line.rstrip() != line:
            errors.append(
                f"{file_path}: Line {line_num}: Trailing whitespace found"
            )

    return errors


def check_blank_lines(lines, file_path):
    """Validate that there are no multiple consecutive blank lines."""
    errors = []

    trimmed_lines = lines[:]
    while trimmed_lines and not trimmed_lines[-1].strip():
        trimmed_lines.pop()

    blank_count = 0

    for line_num, line in enumerate(trimmed_lines, start=1):
        if not line.strip():
            blank_count += 1

            if blank_count > 1:
                errors.append(
                    f"{file_path}: Line {line_num}: Multiple consecutive blank lines found"
                )
        else:
            blank_count = 0

    return errors


def check_indentation(lines, file_path):
    """Validate indentation uses multiples of 2 spaces."""
    errors = []

    for line_num, line in enumerate(lines, start=1):
        if not line.strip():
            continue

        if line.lstrip().startswith("#"):
            continue

        leading_spaces = len(line) - len(line.lstrip(" "))

        if leading_spaces % 2 != 0:
            errors.append(
                f"{file_path}: Line {line_num}: Indentation must be multiple of 2 spaces"
            )

    return errors


def check_yaml_syntax(content, file_path):
    """Validate YAML syntax."""
    errors = []

    try:
        yaml.safe_load(content)
    except yaml.YAMLError as ex:
        errors.append(
            f"{file_path}: Invalid YAML syntax: {str(ex)}"
        )

    return errors


def check_duplicate_keys(content, file_path):
    """Validate duplicate YAML keys."""
    errors = []

    try:
        class DuplicateKeyLoader(yaml.SafeLoader):
            pass

        def construct_mapping(loader, node, deep=False):
            mapping = {}

            for key_node, value_node in node.value:
                key = loader.construct_object(key_node, deep=deep)

                if key in mapping:
                    raise ValueError(f"Duplicate key found: {key}")

                mapping[key] = loader.construct_object(
                    value_node,
                    deep=deep
                )

            return mapping

        DuplicateKeyLoader.add_constructor(
            yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
            construct_mapping
        )

        yaml.load(content, Loader=DuplicateKeyLoader)

    except Exception as ex:
        errors.append(f"{file_path}: {str(ex)}")

    return errors


def lint_yaml_file(file_path):
    """
    Checks:
      1. Tab characters
      2. Trailing whitespace
      3. Multiple consecutive blank lines
      4. Indentation multiple of 2 spaces
      5. YAML syntax
      6. Duplicate keys
    """
    errors = []

    try:
        with open(file_path, "r", encoding="utf-8") as file:
            content = file.read()

        lines = content.splitlines()

        errors.extend(check_tabs(lines, file_path))
        errors.extend(check_trailing_whitespace(lines, file_path))
        errors.extend(check_blank_lines(lines, file_path))
        errors.extend(check_indentation(lines, file_path))
        errors.extend(check_yaml_syntax(content, file_path))
        errors.extend(check_duplicate_keys(content, file_path))

    except Exception as ex:
        errors.append(
            f"{file_path}: Unable to lint file. {str(ex)}"
        )

    return errors

def convert_to_json(yaml_data: dict) -> str:
    """
    Convert YAML data to JSON format.

    :param yaml_data: Dictionary representation of the YAML file contents

    :return: JSON string representation of the YAML data
    """
    return json.dumps(yaml_data, indent=2)

def is_json_loadable(s: str) -> bool:
    try:
        json.loads(s)
        return True
    except (ValueError, TypeError):
        return False
    
def map_keys(data: dict, key_mappings: dict) -> dict:
    """
    Map keys in the data dictionary based on the provided key mappings.

    :param data: The original data dictionary
    :param key_mappings: The dictionary of key mappings (old_key: new_key)

    :return: The updated data dictionary with keys mapped
    """
    for old_key, new_key in key_mappings.items():
        if old_key in data:
            data[new_key] = data.pop(old_key)
    return data

def add_default_values(data: dict, defaults: dict) -> dict:
    """
    Recursively add default values to the data dictionary.

    :param data: The original data dictionary
    :param defaults: The dictionary of default values

    :return: The updated data dictionary with defaults applied
    """
    data_cpy = data.copy()
    data_cpy['ENV'] = ENV
    data_cpy['aws_region'] = data.get('aws_region', REGION).replace("-", "")
    defaults_replaced = replace_placeholders(defaults, data_cpy)
    for key, value in defaults_replaced.items():
        if key not in data:
            data[key] = value
        elif isinstance(value, dict) and isinstance(data.get(key), dict):
            add_default_values(data[key], value)
        elif data[key] in (None, "", [], {}) and value not in (None, "", [], {}):
            logger.warning(f"Key '{key}' is empty in input data. Setting default value: {value}")
            data[key] = value
    return data

def get_nested_value(data: dict, key: str):
    """
    Retrieve a nested value from a dictionary using a dot-separated key.

    :param data: The data dictionary
    :param key: The dot-separated key string (e.g., "a.b.c")

    :return: The nested value if found, None otherwise
    """
    for part in key.split("."):
        if not isinstance(data, dict) or part not in data:
            return None
        data = data[part]
    return data

def is_mandatory_fields_available(data: dict, mandatory_keys: list, is_tag_mandatory_check: bool = False) -> bool:
    """
    Check if all mandatory (NOT NULL) fields are available in the data dictionary.

    :param data: The data dictionary to check
    :param mandatory_keys: The list of mandatory keys to check for
    :param is_tag_mandatory_check: Flag to indicate if it's a tag mandatory check

    :return: True if all mandatory fields are present, False otherwise
    """
    missing = [
        key_expr for key_expr in mandatory_keys
        if not any(
            (lambda v: v not in (None, "", [], {}))(
                get_nested_value(data, key.strip())
            )
            for key in key_expr.split("||")
        )
    ]

    if missing:
        is_plural = len(missing) > 1
        if is_tag_mandatory_check:
            logger.error(f"Mandatory tag{ 's' if is_plural else ''} missing: {missing}")
        else:
            logger.error(f"Mandatory field{ 's' if is_plural else ''} missing: {missing}")
        return False
    logger.info("All mandatory fields are present")
    return True

def add_tag_values(data: dict, default_tag_mappings: dict, validation_details: dict) -> dict:
    """
    Add tag values to the data dictionary based on predefined mappings.

    :param data: The original data dictionary

    :return: The updated data dictionary with tags applied
    """
    tags = default_tag_mappings
    specific_dict = data.copy()
    specific_dict["ENV"] = ENV
    specific_dict["env"] = ENV.upper()
    if data.get("role_name"):
        specific_dict["role"] = get_role_from_role_name(data.get("role_name", ""), validation_details).upper()[4:]
    specific_dict["map-migrated"] = get_python_constants(validation_details).get("map-migrated", "")
    specific_dict["gov_approved_env"] = get_python_constants(validation_details).get("gov_approved_env", "") # added gov_approved_env in specific dict for placeholder replacement in tags
    specific_dict["MIW_account_id"] = get_python_constants(validation_details).get("MIW_account_id", "")
    specific_dict["REGION"] = data.get('aws_region', data.get('region', REGION))
    tags = replace_placeholders(tags, specific_dict)

    # Adding src_system tags if the resource is a source system resource
    if is_src_sys_resource(data, validation_details):
        src_sys_tags = [item for item in filter_by_object_type(validation_details, "src_system") if item.get("action") == "tag_mapping"][0].get("json_structure", {})
        tags = replace_placeholders(tags, src_sys_tags)

    # Removing unresolved placeholders from tags (specifically for s3 buckets which may not have enterprise_or_func_subgrp_name)
    tags = remove_keys_with_unresolved_placeholders(tags)

    if "tags" not in data:
        data["tags"] = {}
    data["tags"].update(tags)
    # Remove any empty string keys from tags
    if "" in data["tags"]:
        del data["tags"][""]
    return data

def check_mandatory_keys_for_tagging(
    data: dict,
    tag_mandatory_keys: dict,
    validation_details: dict,
    resource_type: str,
    account_type: str = None
) -> bool:
    """
    Check if mandatory keys for tagging are present in the data dictionary
    based on the resource type.

    :param data: The data dictionary to check
    :param tag_mandatory_keys: Mandatory tagging configuration
    :param validation_details: Validation details dictionary
    :param resource_type: Resource type (e.g., s3, glue_db, glue_crawler, iam)
    :return: True if all mandatory keys are present, False otherwise
    """

    constants = get_python_constants(validation_details)
    mandatory_keys = []

    # ---------- S3 ----------
    if resource_type == "s3":
        if not account_type:
            logger.error("Account type is required for s3 resource to determine mandatory keys for tagging.")
            return False
        mandatory_keys = list(tag_mandatory_keys.get("general", []).get(account_type, []))
        usage_type = data.get("usage_type")

        s3_mapping = constants.get("value_mapping", {}).get("s3", {})

        if usage_type in s3_mapping.get("DataProduct", []):
            mandatory_keys += tag_mandatory_keys.get("DataProduct", {}).get(account_type, [])
        elif usage_type in s3_mapping.get("Source", []):
            mandatory_keys += tag_mandatory_keys.get("Source", {}).get(account_type, [])
        elif usage_type in s3_mapping.get("Scripts", []):
            mandatory_keys += tag_mandatory_keys.get("Scripts", {}).get(account_type, [])
        elif usage_type in s3_mapping.get("EngAssets", []):
            mandatory_keys += tag_mandatory_keys.get("EngAssets", {}).get(account_type, [])
        elif usage_type in s3_mapping.get("Ops", []):
            mandatory_keys += tag_mandatory_keys.get("Ops", {}).get(account_type, [])
        else:
            valid_usage_types = [ut for sublist in s3_mapping.values() for ut in sublist]
            logger.error(
                f"Unknown usage_type '{usage_type}' for s3 resource. Cannot determine mandatory keys for tagging. Valid usage types are: {valid_usage_types}"
            )
            return "Failed"

    # ---------- GLUE (DB & CRAWLER) ----------
    elif resource_type in ("glue_db", "glue_crawler"):
        mandatory_keys = list(
            tag_mandatory_keys.get("general", [])
        )
        data_layer = data.get("data_layer")

        glue_mapping = constants.get("value_mapping", {}).get("glue_db||glue_crawler", {})

        if data_layer in glue_mapping.get("Bronze", []):
            mandatory_keys += tag_mandatory_keys.get("Bronze", [])
        elif data_layer in glue_mapping.get("Silver", []):
            mandatory_keys += tag_mandatory_keys.get("Silver", [])
        elif data_layer in glue_mapping.get("Gold", []):
            mandatory_keys += tag_mandatory_keys.get("Gold", [])
        else:
            valid_data_layers = [dl for sublist in glue_mapping.values() for dl in sublist]
            logger.error(
                f"Unknown data_layer '{data_layer}' for {resource_type} resource. Cannot determine mandatory keys for tagging. Valid data layers are: {valid_data_layers}"
            )
            return "Failed"

    # ---------- IAM ----------
    elif resource_type == "iam":
        mandatory_keys = list(tag_mandatory_keys.get("general", []))
        role_name = data.get("role_name")

        if not role_name:
            logger.error("Missing role_name for iam resource.")
            return False

        role = get_role_from_role_name(role_name, validation_details).lower()

        if role == "procingestionengineer":
            mandatory_keys += tag_mandatory_keys.get(
                "procingestionengineer", []
            )
        elif role == "procintegratedingestionengineer":
            mandatory_keys += tag_mandatory_keys.get(
                "procintegratedingestionengineer", []
            )
        elif role == "procdataengineer" or role == "snfcatalogfed":
            mandatory_keys += tag_mandatory_keys.get("procdataengineer", [])
        else:
            valid_roles = get_python_constants(validation_details).get("role_type", [])
            logger.error(
                f"Unknown role '{role}' derived from role_name '{role_name}' for iam resource. Valid roles are: {valid_roles}"
            )
            return "Failed"

    # ---------- UNKNOWN RESOURCE ----------
    else:
        logger.error(
            f"Unknown resource type '{resource_type}'. Cannot determine mandatory keys for tagging."
        )
        return False
    logger.debug(f"Mandatory keys for tagging for resource type '{resource_type}': {mandatory_keys}")
    return is_mandatory_fields_available(data.get("tags", {}), mandatory_keys, is_tag_mandatory_check=True)


def remove_keys_with_unresolved_placeholders(data: dict) -> dict:
    """
    Remove keys from the data dictionary that contain unresolved placeholders.

    :param data: The original data dictionary

    :return: The updated data dictionary with unresolved placeholder keys removed
    """
    keys_to_remove = [key for key, value in data.items() if isinstance(value, str) and re.search(r"<(.*?)>", value)]
    for key in keys_to_remove:
        logger.info(f"Removing key '{key}' with unresolved placeholder from data.")
        del data[key]
    return data

def is_src_sys_resource(data: dict, validation_details: dict) -> bool:
    """
    Check whether the resource is a source system resource related by checking key which starts with 'src_sys'.

    :param data: The original data dictionary
    :param validation_details: The validation details dictionary

    :return: True if the resource is a source system resource, False otherwise
    """
    src_sys_check_str = [item for item in filter_by_object_type(validation_details, "src_system") if item.get("action") == "check_str"][0].get("json_structure", {}).get("check_str", "src_sys")
    for key in data.keys():
        if src_sys_check_str.lower() in key.lower():
            return True
    return False

def change_critical_keys(data: dict, critical_keys: dict) -> dict:
    """
    Change the keys in the data dictionary based on critical key mappings.

    :param data: The original data dictionary
    :param service_type: The service type (e.g., "s3")

    :return: The updated data dictionary with critical keys changed
    """
    return map_keys(data, critical_keys)

def map_src_system_keys(data: dict, src_system_mappings: dict) -> dict:
    """
    Map source system keys in the data dictionary based on predefined mappings.

    :param data: The original data dictionary

    :return: The updated data dictionary with source system keys mapped
    """
    return map_keys(data, src_system_mappings)

def get_minerva_lakehouse_validation_details() -> list:
    """
    Fetch all items from the DynamoDB table "minerva_lakehouse_validation_details".

    :return: List of items from the DynamoDB table
    """
    return get_items_from_dynamodb(VALIDATION_DETAILS_TABLE)

def get_reference_json() -> list:
    """
    Fetch all items from the DynamoDB table "minerva_lakehouse_reference_json".

    :return: List of items from the DynamoDB table
    """
    return get_items_from_dynamodb(REFERENCE_JSON_TABLE)

def filter_reference_by_key_and_value(reference_json: list, key: str, value: str) -> list:
    """
    Filter reference JSON by a specific key-value pair.

    :param reference_json: List of reference JSON entries
    :param key: The key to filter by (e.g., "object_type")
    :param value: The value to filter by (e.g., "s3")

    :return: Filtered list of reference JSON entries matching the specified key-value pair
    """
    return [entry for entry in reference_json if entry.get(key) == value]

def get_python_constants(validation_details: list) -> dict:
    return [item for item in filter_by_object_type(validation_details, "general") if item.get("action") == "python_constants"][0].get("json_structure", {})

def get_policy_jsons(data: dict, reference_json: dict, validation_details: dict, role_name: str = None) -> dict:
    MAX_POLICY_SIZE = int(get_python_constants(validation_details).get("max_policy_size", 6000))
    data = copy.deepcopy(data)

    policy_jsons = {}
    current_policy_id = 0

    policy_json = {
        "Version": "2012-10-17",
        "Statement": []
    }

    # consistent JSON size calculation everywhere
    def json_size(obj):
        return len(json.dumps(obj, separators=(",", ":")))

    # Split statement by resources if too large
    def split_statement_by_resources(statement: dict, max_size: int):
        if statement.get("Resource") == "*" or not isinstance(statement.get("Resource"), list):
            return [statement]

        if json_size(statement) <= max_size:
            return [statement]

        base_stmt = copy.deepcopy({k: v for k, v in statement.items() if k != "Resource"})
        resources = list(dict.fromkeys(statement["Resource"]))  # dedup while preserving order

        chunks = []
        current_chunk = []

        for resource in resources:
            temp_chunk = current_chunk + [resource]
            temp_stmt = {**base_stmt, "Resource": temp_chunk}

            if json_size(temp_stmt) > max_size:
                if not current_chunk:
                    # single resource itself too large
                    single_stmt = {**base_stmt, "Resource": [resource]}
                    if json_size(single_stmt) > max_size:
                        logger.error(f"Base Statement + Single resource exceeds max policy size: {single_stmt}. Try to reduce the base statement size in DynamoDB reference_json table")
                        # optional: raise Exception
                    chunks.append(single_stmt)
                    current_chunk = []
                else:
                    chunks.append({**base_stmt, "Resource": current_chunk})
                    current_chunk = [resource]
            else:
                current_chunk = temp_chunk

        if current_chunk:
            chunks.append({**base_stmt, "Resource": current_chunk})

        return chunks

    # Helper: Split policies if size exceeds limit
    def add_policy_statement(statement: dict):
        nonlocal policy_json, current_policy_id

        current_size = json_size(policy_json)
        new_size = json_size(statement)

        # account for comma/array overhead (+1 buffer safety)
        if current_size + new_size + 1 > int(MAX_POLICY_SIZE):
            logger.info("Policy size limit reached. Creating new policy.")

            policy_jsons[f"{data.get('role_name','')}_policy{current_policy_id if current_policy_id != 0 else ''}"] = policy_json

            current_policy_id += 1

            policy_json = {
                "Version": "2012-10-17",
                "Statement": []
            }

        policy_json["Statement"].append(statement)

    reference_lookup = {
        r["reference_policy_name"]: r
        for r in reference_json
    }

    if not role_name:
        role_name = "iam_" + get_role_from_role_name(
            data.get("role_name", ""), validation_details
        ).lower()

    grants_map = reference_lookup.get(role_name, {}).get("reference_details_iam", {})

    access_resources = data.setdefault("access_to_resources", {})

    # ordered dedup (IMPORTANT for Terraform diff stability)
    data_prefixes = access_resources.get("data_prefixes", [])
    execution_prefixes = access_resources.get("execution_asset_prefixes", [])
    access_resources["data_prefixes"] = list(dict.fromkeys(data_prefixes + execution_prefixes))
    access_resources.pop("execution_asset_prefixes", None)

    glue_db = access_resources.pop("glue_databases", {})
    access_resources["glue_databases.write"] = glue_db.get("write", [])
    access_resources["glue_databases.read"] = glue_db.get("read", [])

    if access_resources["glue_databases.write"]:
        access_resources["glue_databases.write"].extend(
            access_resources["glue_databases.read"]
        )
        access_resources.pop("glue_databases.read", None)

    def get_s3_placeholders(resource: str) -> Dict[str, str]:
        """Normalize an S3 location for generic and Athena IAM templates."""
        clean = resource.removeprefix("s3://").rstrip("/")
        return {
            "S3_PREFIX_PATH": clean,
            "S3_BUCKET_NAME": clean.split("/")[0],
        }

    def fill_placeholders(resources, resource_type, json_structure, reference_format):
        if role_name in [
            "iam_s3_service",
        ] and resource_type == "data_prefixes":
            json_structure["Resource"] = ["*"]
            return json_structure

        json_structure["Resource"] = []

        for resource in resources:
            if not resource:
                continue

            if resource_type in ("data_prefixes", "execution_asset_prefixes"):
                specific = get_s3_placeholders(resource)

            elif resource_type.startswith("glue_databases"):
                if isinstance(resource, dict):
                    catalog_id = list(resource.keys())[0]
                    db = resource[catalog_id]
                elif ":" in resource:
                    catalog_id, db = resource.split(":", 1)
                else:
                    catalog_id = data.get("aws_account_id")
                    db = resource

                account_id = catalog_id
                if db.lower().endswith("_rl"):
                    account_id = "*"

                specific = {
                    "region": data.get("aws_region", REGION),
                    "aws_account_id": account_id,
                }

            elif resource_type == "glue_jobs":
                specific = {
                    "region": data.get("aws_region", REGION),
                    "aws_account_id": data.get("aws_account_id"),
                    "glue_job": resource,
                }

            elif resource_type == "glue_crawler":
                specific = {
                    "region": data.get("aws_region", REGION),
                    "aws_account_id": data.get("aws_account_id"),
                    "crawler_name": resource,
                }

            else:
                specific = {}

            resources_list = [
                replace_placeholders(rf, specific)
                for rf in reference_format
            ]

            json_structure["Resource"].extend(resources_list)

        # ordered dedup again (VERY IMPORTANT)
        json_structure["Resource"] = list(dict.fromkeys(json_structure["Resource"]))
        return json_structure

    # Process resource grants
    for resource_type, resources in access_resources.items():
        grants = grants_map.get(resource_type, [])

        if not resources or resources in ([""], {}, [None]):
            logger.info(f"No resources for {resource_type}")
            continue

        for grant in grants:
            template = reference_lookup.get(grant.lower())
            if not template:
                continue

            json_structure = template.get("json_structure")

            if is_json_loadable(json_structure):
                json_structure = json.loads(json_structure)

            statements = json_structure if isinstance(json_structure, list) else [json_structure]

            for stmt in statements:
                stmt = copy.deepcopy(stmt)  # avoid mutation bug

                reference_format = stmt.get("Resource", [])
                stmt["Resource"] = [] if reference_format != "*" else reference_format

                if reference_format != "*":
                    stmt = fill_placeholders(resources, resource_type, stmt, reference_format)

                for split_stmt in split_statement_by_resources(stmt, MAX_POLICY_SIZE):
                    add_policy_statement(split_stmt)

    # Glue Interactive Session
    if data.get("enable_glue_interactive_session"):
        grants = grants_map.get("enable_glue_interactive_session", [])

        for grant in grants:
            template = reference_lookup.get(grant)
            json_structure = template.get("json_structure")

            if is_json_loadable(json_structure):
                json_structure = json.loads(json_structure)

            specific = {
                "REGION_NAME": data.get('aws_region', data.get('region', REGION)),
                "ENV": ENV,
                "AWS_ACCOUNT_ID": data.get("aws_account_id"),
                "map-migrated": get_python_constants(validation_details).get("map-migrated", ""),
                "gov_approved_env": get_python_constants(validation_details).get("gov_approved_env", "")
            }

            statements = json_structure if isinstance(json_structure, list) else [json_structure]

            for stmt in statements:
                stmt = copy.deepcopy(stmt)  
                stmt = replace_placeholders(stmt, specific)

                for split_stmt in split_statement_by_resources(stmt, MAX_POLICY_SIZE):
                    add_policy_statement(split_stmt)

    # Glue Job Access Config
    if data.get("glue_job_access_config", {}).get("enable_glue_jobs"):
        grants = grants_map.get("glue_job_access_config.enable_glue_jobs", [])
        job_configs = data.get("glue_job_access_config", {}).get("job_control_configs", [])

        if not job_configs:
            logger.error("No Glue jobs found for granting access in the input data.")
        else:
            for grant in grants:
                template = reference_lookup.get(grant)
                if not template:
                    continue

                json_structure = template.get("json_structure")

                if is_json_loadable(json_structure):
                    json_structure = json.loads(json_structure)

                specific = {
                    "region": data.get("aws_region", data.get("region", REGION)),
                    "ENV": ENV,
                    "aws_account_id": str(data.get("aws_account_id", "")),
                    "map-migrated": get_python_constants(validation_details).get("map-migrated", ""),
                    "gov_approved_env": get_python_constants(validation_details).get("gov_approved_env", "")
                }

                statements = json_structure if isinstance(json_structure, list) else [json_structure]

                for stmt in statements:
                    stmt = copy.deepcopy(stmt)  

                    reference_format = stmt.get("Resource", [])
                    stmt["Resource"] = [] if reference_format != "*" else reference_format

                    if reference_format != "*":
                        stmt = fill_placeholders(job_configs, "glue_jobs", stmt, reference_format)

                    stmt = replace_placeholders(stmt, specific)

                    for split_stmt in split_statement_by_resources(stmt, MAX_POLICY_SIZE):
                        add_policy_statement(split_stmt)

    # Athena Workgroup Access Config
    if data.get("athena_access_config", {}).get("enable_athena_access"):
        grants = grants_map.get("athena_access_config.enable_athena_access", [])
        athena_workgroup_name = data.get("athena_access_config", {}).get("athena_workgroup_name", "")
        is_valid_execution_asset_prefix, valid_path = is_execution_asset_prefix_valid_for_athena_access(
            data,
            execution_prefixes,
        )
        specific = {
            "region": data.get("aws_region", data.get("region", REGION)),
            "ENV": ENV,
            "aws_account_id": str(data.get("aws_account_id", "")),
            "athena_workgroup_name": athena_workgroup_name,
            **get_s3_placeholders(valid_path or ""),
        }
        if is_valid_execution_asset_prefix:
            for grant in grants:
                template = reference_lookup.get(grant)
                json_structure = template.get("json_structure")

                if is_json_loadable(json_structure):
                    json_structure = json.loads(json_structure)

                statements = json_structure if isinstance(json_structure, list) else [json_structure]

                for stmt in statements:
                    stmt = copy.deepcopy(stmt)  
                    stmt = replace_placeholders(stmt, specific)

                    for split_stmt in split_statement_by_resources(stmt, MAX_POLICY_SIZE):
                        add_policy_statement(split_stmt)
        else:
            logger.info(f"Invalid execution asset prefix for Athena access: {valid_path}. Skipping Athena workgroup access policy generation.")

    # General Grants
    for grant in grants_map.get("general", []):
        template = reference_lookup.get(grant)
        json_structure = template.get("json_structure")

        if is_json_loadable(json_structure):
            json_structure = json.loads(json_structure)

        specific = {
            "env": ENV.upper(),
            "compute_size": data.get("compute_size", "XSML"),
            "role": get_role_from_role_name(
                data.get("role_name", ""), validation_details
            ).upper()[4:],
            "region": data.get('aws_region', data.get('region', REGION)),
            "aws_account_id": str(data.get('aws_account_id', '')),
            "role_name": data.get("role_name", ""),
        }

        statements = json_structure if isinstance(json_structure, list) else [json_structure]

        for stmt in statements:
            stmt = copy.deepcopy(stmt)  
            stmt = replace_placeholders(stmt, specific)

            for split_stmt in split_statement_by_resources(stmt, MAX_POLICY_SIZE):
                add_policy_statement(split_stmt)

    policy_jsons[f"{data.get('role_name','')}_policy{current_policy_id if current_policy_id != 0 else ''}"] = policy_json

    return policy_jsons

def identify_placeholders_needed(statement: dict) -> list:
    """
    Function will return a list of placeholders needed in the given statement using re with pattern <>

    :param statement: The statement dictionary

    :return: A list of placeholders needed in the statement
    """
    return re.findall(r"<(.*?)>", json.dumps(statement))

def check_placeholders_availability(statement: dict, specific_dict: dict) -> bool:
    """
    Function will check if all placeholders in the statement are available in the specific_dict.

    :param statement: The statement dictionary
    :param specific_dict: The dictionary containing specific values for placeholders

    :return: True if all placeholders are available, False otherwise
    """
    unavailable_placeholders = []
    placeholders = identify_placeholders_needed(statement)
    for placeholder in placeholders:
        if placeholder not in specific_dict:
            unavailable_placeholders.append(placeholder)
    return len(unavailable_placeholders) == 0, unavailable_placeholders

def get_trust_json(data: dict, reference_json: dict, validation_details: dict, role_type: str = None) -> dict:
    """
    Get the trust JSON for IAM role.

    :param data: The original data dictionary
    :param reference_json: The reference JSON dictionary

    :return: The trust JSON dictionary
    """
    trust_json = {
        "Version": "2012-10-17",
        "Statement": []
    }
    specific_dict = {
        "oidc_webidentity_id" : get_python_constants(validation_details).get("oidc_webidentity_id", ""),
        "MEF_interactive_session_role" : get_python_constants(validation_details).get("MEF_interactive_session_role", ""),
        "MEF_imperative_pattern_role" : get_python_constants(validation_details).get("MEF_imperative_pattern_role", ""),
        "ingestion_pattern_role": get_python_constants(validation_details).get("ingestion_pattern_role", ""),
        "aws_account_id": str(data.get('aws_account_id', '')),
        "region" : data.get('aws_region', data.get('region', REGION)),
        "gov_approved_env" : get_python_constants(validation_details).get("gov_approved_env", ""), # added gov_approved_env in specific dict for placeholder replacement in trust policies
        "map-migrated" : get_python_constants(validation_details).get("map-migrated", ""), # added map-migrated in specific dict for placeholder replacement in trust policies
        # "principal_role_aws_id": str(data.get("principal_role_arn", "").split(":")[4]) if data.get("principal_role_arn") else "" # extracting aws account id from principal_role_arn for placeholder replacement in external trust policy,
    }

    # Adding principal_role_aws_id based on type of principal_role_arn
    if isinstance(data.get("principal_role_arn"), str) and data.get("principal_role_arn"):
        specific_dict["principal_role_aws_id"] = str(data.get("principal_role_arn").split(":")[4]) if data.get("principal_role_arn") else ""
    elif isinstance(data.get("principal_role_arn"), list) and data.get("principal_role_arn"):
        # adding the principal_role_aws_id only if all the ARNs belong to the same AWS account
        aws_ids = set()
        for arn in data.get("principal_role_arn"):
            if arn:
                aws_ids.add(str(arn.split(":")[4]))
        if len(aws_ids) == 1:
            specific_dict["principal_role_aws_id"] = aws_ids.pop()
        else:
            logger.error("Mentioning multiple ARNs from different AWS accounts is not supported")

    # Adding MEF imperative and intractive role's aws id
    if "MEF_interactive_session_role" in specific_dict and specific_dict["MEF_interactive_session_role"] not in [None, ""]:
        specific_dict["MEF_interactive_session_role_aws_id"] = str(specific_dict["MEF_interactive_session_role"].split(":")[4]) if specific_dict["MEF_interactive_session_role"] else ""
    
    if "MEF_imperative_pattern_role" in specific_dict and specific_dict["MEF_imperative_pattern_role"] not in [None, ""]:
        specific_dict["MEF_imperative_pattern_role_aws_id"] = str(specific_dict["MEF_imperative_pattern_role"].split(":")[4]) if specific_dict["MEF_imperative_pattern_role"] else ""

    # adding data values to specific dict for placeholder replacement in trust policies

    specific_dict.update(data)
    logger.debug(f"#### specific_dict: {specific_dict} Role: {data.get('role_name', '')}")
    if not role_type:
        role_type = get_role_from_role_name(data.get("role_name", ""), validation_details).lower()
    if role_type == "s3_service_role":
        default_statement = json.loads(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_s3_service")[0].get("json_structure", {})) if is_json_loadable(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_s3_service")[0].get("json_structure", {})) else filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_s3_service")[0].get("json_structure", {})
    else:
        default_statement = json.loads(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_default")[0].get("json_structure", {})) if is_json_loadable(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_default")[0].get("json_structure", {})) else filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_default")[0].get("json_structure", {})
    trust_json["Statement"].append(default_statement)

    # adding oidc for procdataengineer role
    if role_type == "procdataengineer":
        odic_statement = json.loads(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_OIDC_WebIdentity")[0].get("json_structure", {})) if is_json_loadable(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_OIDC_WebIdentity")[0].get("json_structure", {})) else filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_OIDC_WebIdentity")[0].get("json_structure", {})
        is_placeholders_available, unavailable_placeholders = check_placeholders_availability(odic_statement, specific_dict)
        if is_placeholders_available:
            trust_json["Statement"].append(replace_placeholders(odic_statement, specific_dict))
        else:
            logger.warning(f"iam_trust_OIDC_WebIdentity statement skipped due to unavailable placeholders: {unavailable_placeholders} for the role {data.get('role_name', '')}")

    # adding ingestion pattern role for procintegratedingestionengineer
    if role_type == "procintegratedingestionengineer":
        logger.debug(f"#### Entering ingestion pattern statement processing for role {data.get('role_name', '')}")
        ingestion_pattern_smt = json.loads(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_ingestion")[0].get("json_structure", {})) if is_json_loadable(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_ingestion")[0].get("json_structure", {})) else filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_ingestion")[0].get("json_structure", {})
        is_placeholders_available, unavailable_placeholders = check_placeholders_availability(ingestion_pattern_smt, specific_dict)
        if is_placeholders_available:
            trust_json["Statement"].append(replace_placeholders(ingestion_pattern_smt, specific_dict))
        else:
            logger.warning(f"iam_trust_ingestion statement skipped due to unavailable placeholders: {unavailable_placeholders} for the role {data.get('role_name', '')}")

    # adding external support statement if principal_role_arn and stsExternalIds are provided
    if (data.get("principal_role_arn") not in (None, "", [], {}) and data.get("stsExternalIds") not in (None, "", [], {})):
        iceberg_statement = json.loads(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_external")[0].get("json_structure", {})) if is_json_loadable(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_external")[0].get("json_structure", {})) else filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_external")[0].get("json_structure", {})
        if isinstance(data.get("principal_role_arn"), str) and isinstance(data.get("stsExternalIds"), str):
            trust_json["Statement"].append(replace_placeholders(iceberg_statement, specific_dict))
        elif isinstance(data.get("principal_role_arn"), str) and isinstance(data.get("stsExternalIds"), list):
            trust_json["Statement"].append(replace_placeholders(iceberg_statement, specific_dict))
        
    # adding tag session if role is an procintegratedingestionengineer or procingestionengineer
    if role_type in ("procintegratedingestionengineer", "procingestionengineer"):
        logger.debug(f"Entering tag session statement processing for role {data.get('role_name', '')}")
        tag_session_statement = json.loads(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_external_tag_session")[0].get("json_structure", {})) if is_json_loadable(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_external_tag_session")[0].get("json_structure", {})) else filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_external_tag_session")[0].get("json_structure", {})
        is_placeholders_available, unavailable_placeholders = check_placeholders_availability(tag_session_statement, specific_dict)
        if is_placeholders_available:
            trust_json["Statement"].append(replace_placeholders(tag_session_statement, specific_dict))
        else:
            logger.warning(f"iam_trust_external_tag_session statement skipped due to unavailable placeholders: {unavailable_placeholders} for the role {data.get('role_name', '')}")
    
    # adding glue interactive session trust statement
    if data.get("enable_glue_interactive_session") == "true" or data.get("enable_glue_interactive_session") == True:
        glue_statement = json.loads(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_glue_interactive_session")[0].get("json_structure", {})) if is_json_loadable(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_glue_interactive_session")[0].get("json_structure", {})) else filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_glue_interactive_session")[0].get("json_structure", {})
        is_placeholders_available, unavailable_placeholders = check_placeholders_availability(glue_statement, specific_dict)
        if is_placeholders_available:
            trust_json["Statement"].append(replace_placeholders(glue_statement, specific_dict))
        else:
            logger.warning(f"iam_trust_glue_interactive_session statement skipped due to unavailable placeholders: {unavailable_placeholders} for the role {data.get('role_name', '')}")

    # adding trust glue job access statement
    if data.get("glue_job_access_config", {}).get("enable_glue_jobs") == "true" or data.get("glue_job_access_config", {}).get("enable_glue_jobs") == True:
        glue_job_statement = json.loads(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_glue_jobs")[0].get("json_structure", {})) if is_json_loadable(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_glue_jobs")[0].get("json_structure", {})) else filter_reference_by_key_and_value(reference_json, "reference_policy_name", "iam_trust_glue_jobs")[0].get("json_structure", {})
        is_placeholders_available, unavailable_placeholders = check_placeholders_availability(glue_job_statement, specific_dict)
        if is_placeholders_available:
            trust_json["Statement"].append(replace_placeholders(glue_job_statement, specific_dict))
        else:
            logger.warning(f"iam_trust_glue_jobs statement skipped due to unavailable placeholders: {unavailable_placeholders} for the role {data.get('role_name', '')}")

    return trust_json

def generate_crawler_iam_role(crawler_data: dict, reference_json: dict, validation_details: dict) -> Tuple[dict, dict, dict]:
    """
    Generate IAM role details including policy and trust JSON.

    :param crawler_data: The original data dictionary for the crawler
    :param reference_json: The reference JSON dictionary
    :param validation_details: The validation details dictionary

    :return: Tuple containing IAM role data, policy JSON, and trust JSON
    """
    logger.debug(f"Crawler data received for IAM role generation: {crawler_data}")
    iam_role_data = {}
    iam_role_data["intake_id"] = crawler_data.get("intake_id", "")
    iam_role_data["role_name"] = crawler_data.get("crawler_name") + "_iam"
    iam_role_data["role_description"] = f"IAM role created for {crawler_data.get('crawler_name', '')}"
    iam_role_data["aws_account_id"] = str(crawler_data.get("aws_account_id", ""))
    iam_role_data["aws_region"] = crawler_data.get("aws_region", crawler_data.get("region", REGION))
    iam_role_data["enterprise_or_func_name"] = crawler_data.get("enterprise_or_func_name", "")
    iam_role_data["enterprise_or_func_subgrp_name"] = crawler_data.get("enterprise_or_func_subgrp_name", "")
    iam_role_data["data_leader"] = crawler_data.get("data_leader", "")
    iam_role_data["sub_function"] = crawler_data.get("sub_function", "")
    iam_role_data["compute_size"] = "XSML"
    iam_role_data["access_to_resources"] = {
        "glue_databases": {
            "read":
            [crawler_data.get("database_name", "")],
        },
        "data_prefixes" : crawler_data.get("s3_target_paths", []),
        "glue_crawler": [crawler_data.get("crawler_name", "")]
    }
    iam_role_data["glue_interactive_session"] = False
    iam_role_data["snowflake_iceberg_support"] = False
    iam_role_data["max_session_duration"] = "1"
    logger.debug(f"generated iam role data: {iam_role_data}")
    policy_jsons = get_policy_jsons(iam_role_data, reference_json, validation_details, role_name="iam_cwl")
    trust_json = get_trust_json(iam_role_data, reference_json, validation_details, role_type="glue_crawler")
    iam_role_data["tags"] = crawler_data.get("tags", {})
    # tags = [item for item in filter_by_object_type(validation_details, "crwl_iam_role") if item.get("action") == "tag_mapping"][0].get("json_structure", {})
    # iam_role_data["tags"] = replace_placeholders(tags, {"ENV": ENV, "env": ENV.upper(), "map-migrated": get_python_constants(validation_details).get("map-migrated", "")})

    return iam_role_data, policy_jsons, trust_json

def generate_s3_service_iam_role(aws_account_id: str, s3_buckets: list[str], reference_json: dict, validation_details: dict) -> Tuple[dict, dict, dict]:
    """
    Generate IAM role details including policy and trust JSON.

    :param s3_buckets: List of S3 bucket names
    :param reference_json: The reference JSON dictionary
    :param validation_details: The validation details dictionary

    :return: Tuple containing IAM role data, policy JSON, and trust JSON
    """
    iam_role_data = {}
    iam_role_data["intake_id"] = "MIW-1234"
    iam_role_data["role_name"] = f"minerva-{ENV}-miw-s3-service-iam-role"
    iam_role_data["role_description"] = f"This service role is owned by MIW team and will be leveraged to register all S3 buckets to support vended credentials based reads on data."
    iam_role_data["aws_account_id"] = aws_account_id
    iam_role_data["aws_region"] = REGION
    iam_role_data["enterprise_or_func_name"] = "CORP"
    iam_role_data["enterprise_or_func_subgrp_name"] = "DTD"
    iam_role_data["data_leader"] = "MIW Admin Team"
    iam_role_data["sub_function"] = ""
    iam_role_data["compute_size"] = "XSML"
    iam_role_data["access_to_resources"] = {
        "data_prefixes" : [f"s3://{bucket}" for bucket in s3_buckets]
    }
    iam_role_data["glue_interactive_session"] = False
    iam_role_data["snowflake_iceberg_support"] = False
    logger.debug(f"generated iam role data: {iam_role_data}")
    policy_jsons = get_policy_jsons(iam_role_data, reference_json, validation_details, role_name="iam_s3_service")
    trust_json = get_trust_json(iam_role_data, reference_json, validation_details, role_type="s3_service_role")
    tags = [item for item in filter_by_object_type(validation_details, "s3_service_role") if item.get("action") == "tag_mapping"][0].get("json_structure", {})
    iam_role_data["tags"] = replace_placeholders(tags, {"ENV": ENV, "env": ENV.upper(), "map-migrated": get_python_constants(validation_details).get("map-migrated", ""), "gov_approved_env": get_python_constants(validation_details).get("gov_approved_env", "")})
    return iam_role_data, policy_jsons, trust_json
    
def validate_keys(
    files_list: List[str],
    keys_to_validate: List[str],
    exceptional_services: set = None
) -> Tuple[bool, List[str]]:
    """
    Validate YAML files for required keys and ensure consistency.

    :param files_list: List of input YAML files to validate
    :param keys_to_validate: List of YAML keys to check (example: ["aws_account_id", "enterprise_or_func_name"])
    :param exceptional_services: Optional set of service dirs to skip subgroup validation
    :return:
        Success -> (True, [dict of {key: value}])
        Failure -> (False, [list of error messages])
    """
    key_maps: Dict[str, Dict[str, List[str]]] = {k: defaultdict(list) for k in keys_to_validate}
    errors: List[str] = []
    yaml_files: List[str] = []
    exceptional_services = exceptional_services or set()

    for file in files_list:
        if file.endswith((".yml", ".yaml")):
            service_type = os.path.basename(os.path.dirname(file))
            yaml_files.append(file)
            data = load_yaml(file) or {}

            for key in keys_to_validate:
                # Skip subgroup validation if file belongs to exceptional service
                if key == "enterprise_or_func_subgrp_name" and service_type in exceptional_services:
                    continue

                raw_val = str(data.get(key, "")).strip()
                if not raw_val:
                    errors.append(f"[ERROR] Missing '{key}' in: {file}")
                else:
                    # Normalize subgroup/enterprise keys for consistency
                    norm_val = raw_val.upper() if "subgrp" in key.lower() or "enterprise" in key.lower() else raw_val
                    key_maps[key][norm_val].append(file)

    # ---- Global validation ----
    if not yaml_files:
        return False, [f"[ERROR] No YAML files found under: {files_list}"]

    for key, values_map in key_maps.items():
        if len(values_map) > 1:
            errors.append(f"[ERROR] Multiple values for '{key}' detected: {dict(values_map)}")

    if errors:
        return False, errors

    # Extract final consistent values
    result = {key: list(values_map.keys())[0] if values_map else "" for key, values_map in key_maps.items()}
    return True, [result]


def patch_backend_terraform_file(account_id: str, subgroup: str) -> None:
    # --- Patch the backend file Terraform actually uses: $CODEBUILD_SRC_DIR_admin/aws_lakehouse/terraform/tfvars/<env>/backend-<env>.hcl
    env_name   = os.getenv("CODEBUILD_ENV") or os.getenv("ENV", "dev")
    admin_root = os.getenv("CODEBUILD_SRC_DIR_admin") or os.getenv("CODEBUILD_SRC_DIR", ".")
    backend_file = os.path.join(admin_root, "aws_lakehouse", "terraform", "tfvars", env_name, f"backend-{env_name}.hcl")
    try:
        with open(backend_file, "r+", encoding="utf-8") as f:
            txt = f.read()
            txt_new = re.sub(r'(?m)^\s*key\s*=\s*".*?"\s*$', f'key            = "aws_lakehouse/{account_id}/${{component}}.json"', txt)
            if txt_new != txt:
                f.seek(0); f.write(txt_new); f.truncate()
                logger.info(f"Patched backend key in {backend_file} → aws_lakehouse/{account_id}/${{component}}.json")
            else:
                logger.warning(f"No key line matched in {backend_file}; file unchanged")
    except FileNotFoundError:
        logger.warning(f"Backend file not found: {backend_file}")
    
def get_lf_data_permissions_s3(data: dict, reference_json: dict) -> dict:
    """
    Get the Lake Formation data permissions for S3 prefixes given in the iam data.

    :param data: The original data dictionary from iam
    :param reference_json: The reference JSON dictionary

    :return: The Lake Formation data permissions JSON for given S3 prefixes
    """
    lf_data_permission = []
    lf_data_permission_template = filter_reference_by_key_and_value(reference_json, "reference_policy_name", "lf_data_permission_s3")[0]
    json_structure = json.loads(lf_data_permission_template.get("json_structure", {})) if is_json_loadable(lf_data_permission_template.get("json_structure", {})) else lf_data_permission_template.get("json_structure", {})
    for resource in data.get("access_to_resources", {}).get("data_prefixes", []):
        if not re.match(r"^s3:\/\/[a-z0-9.-]{3,63}(?:\/[A-Za-z0-9._\-/]*)?\/?$", resource):
            logger.error(f"Invalid S3 prefix format: {resource}. Expected format: s3://bucket-name/prefix/")
            continue
        # building dict for each s3 prefix
        resource_dict = {}
        resource_dict["ROLE_ARN"] = f"arn:aws:iam::{data.get('aws_account_id', '')}:role/{data.get('role_name', '')}"
        resource_dict["S3_ARN"] = f"arn:aws:s3:::{'/'.join(resource.split('/')[2:])}" if not resource.endswith("/") else f"arn:aws:s3:::{'/'.join(resource.split('/')[2:-1])}"
        lf_data_permission.append(replace_placeholders(json_structure.copy(), resource_dict))
    return lf_data_permission

def get_lf_data_permissions_glue_db(data: dict, reference_json: dict, validation_details: dict) -> dict:
    """
    Get the Lake Formation data permissions for Glue databases given in the iam data.

    :param data: The original data dictionary from iam
    :param reference_json: The reference JSON dictionary
    :param validation_details: The validation details dictionary

    :return: The Lake Formation data permissions JSON for given Glue databases
    """
    data = copy.deepcopy(data)
    role_name = "iam_" + get_role_from_role_name(data.get("role_name", ""), validation_details).lower()
    lf_data_permission = []

    def _sort_perm(p):
        # deterministic ordering of permission verb arrays only; no schema/content change
        if isinstance(p.get("permissions"), list):
            p["permissions"] = sorted(p["permissions"])
        if isinstance(p.get("permissions_with_grant_option"), list):
            p["permissions_with_grant_option"] = sorted(p["permissions_with_grant_option"])
        return p

    grants_map = filter_reference_by_key_and_value(reference_json, "reference_policy_name", role_name)[0].get("reference_details_lf", {})
    _glue_db_sort_key = lambda r: json.dumps(r, sort_keys=True) if isinstance(r, dict) else str(r)
    glue_dbs_read = sorted(data.get("access_to_resources", {}).get("glue_databases", {}).get("read", []) or [], key=_glue_db_sort_key)
    glue_dbs_write = sorted(data.get("access_to_resources", {}).get("glue_databases", {}).get("write", []) or [], key=_glue_db_sort_key)
    for grant in sorted(grants_map.get("glue_databases.read", []) or []):
        lf_data_permission_template = filter_reference_by_key_and_value(reference_json, "reference_policy_name", grant)[0]
        json_structure = json.loads(lf_data_permission_template.get("json_structure", {})) if is_json_loadable(lf_data_permission_template.get("json_structure", {})) else lf_data_permission_template.get("json_structure", {})
        if not glue_dbs_read or glue_dbs_read == [None] or glue_dbs_read == [""] or glue_dbs_read == []:
            logger.info(f"No Glue databases found for granting read access in the input data.")
            continue
        for resource in glue_dbs_read:
            catalog_id = None
            if isinstance(resource, dict):
                catalog_id = list(resource.keys())[0]
                resource = resource[catalog_id]


            if not re.match(r"^(\d{12}:)?[a-zA-Z0-9._-]{1,255}$", resource):
                logger.error(f"Invalid Glue database name format: {resource}. Expected format: alphanumeric characters, underscores, hyphens, and periods only.")
                continue

            # if resource endswith _rl and grant is not for table, also grant permission for db without _rl
            if resource.endswith("_rl"):
                splits = resource.split(":")
                if len(splits) > 1:
                    catalog_id = splits[0].strip()
                    resource = splits[1].strip()
                if not catalog_id or catalog_id == None:
                    logger.error(f"Invalid format for Resource Linked Glue database name: {resource}. Expected format: <source_account_id>: <Resource Linked Database Name> (<source_db_name>_rl)")
                else:
                    catalog_id = str(catalog_id)
                if "tbl" not in grant.lower():
                    resource_dict = {}
                    resource_dict["NAME"] = data.get("role_name") + "_glue_db_" + resource[:-3] + "_" + grant  # iam role name + glue db name without _rl
                    resource_dict["PRINCIPAL_ARN"] = f"arn:aws:iam::{data.get('aws_account_id', '')}:role/{data.get('role_name', '')}"
                    resource_dict["DATABASE_NAME"] = resource[:-3]
                    perm = replace_placeholders(json_structure.copy(), resource_dict)
                    perm["resource"]["catalog_id"] = catalog_id
                    lf_data_permission.append(_sort_perm(perm))
                    # lf_data_permission.append(replace_placeholders(json_structure.copy(), resource_dict))
                elif "tbl" in grant.lower():
                    resource_dict = {}
                    resource_dict["NAME"] = data.get("role_name") + "_glue_db_" + resource[:-3] + "_" + grant  # iam role name + glue db name without _rl
                    resource_dict["PRINCIPAL_ARN"] = f"arn:aws:iam::{data.get('aws_account_id', '')}:role/{data.get('role_name', '')}"
                    resource_dict["DATABASE_NAME"] = resource[:-3]
                    perm = replace_placeholders(json_structure.copy(), resource_dict)
                    perm["resource"]["catalog_id"] = catalog_id
                    lf_data_permission.append(_sort_perm(perm))
                    # lf_data_permission.append(replace_placeholders(json_structure.copy(), resource_dict))
                    continue # skip tbl grant for db for with_rl since we already granted for without _rl
            # building dict for each glue database
            resource = resource.split(":")[-1].strip()  # in case of <account_id>:<db_name> format, take only db_name
            resource_dict = {}
            resource_dict["NAME"] = data.get("role_name") + "_glue_db_" + resource + "_" + grant  # iam role name + glue db name
            resource_dict["PRINCIPAL_ARN"] = f"arn:aws:iam::{data.get('aws_account_id', '')}:role/{data.get('role_name', '')}"
            resource_dict["DATABASE_NAME"] = resource
            perm = replace_placeholders(json_structure.copy(), resource_dict)
            perm["resource"]["catalog_id"] = data.get('aws_account_id', '')
            lf_data_permission.append(_sort_perm(perm))
            # lf_data_permission.append(replace_placeholders(json_structure.copy(), resource_dict))
    for grant in sorted(grants_map.get("glue_databases.write", []) or []):
        lf_data_permission_template = filter_reference_by_key_and_value(reference_json, "reference_policy_name", grant)[0]
        json_structure = json.loads(lf_data_permission_template.get("json_structure", {})) if is_json_loadable(lf_data_permission_template.get("json_structure", {})) else lf_data_permission_template.get("json_structure", {})
        if not glue_dbs_write or glue_dbs_write == [None] or glue_dbs_write == [""] or glue_dbs_write == []:
            logger.info(f"No Glue databases found for granting write access in the input data.")
            continue
        for resource in glue_dbs_write:
            catalog_id = None
            if isinstance(resource, dict):
                catalog_id = list(resource.keys())[0]
                resource = resource[catalog_id]


            if not re.match(r"^(\d{12}:)?[a-zA-Z0-9._-]{1,255}$", resource):
                logger.error(f"Invalid Glue database name format: {resource}. Expected format: alphanumeric characters, underscores, hyphens, and periods only.")
                continue

            # if resource endswith _rl and grant is not for table, also grant permission for db without _rl
            if resource.endswith("_rl"):
                splits = resource.split(":")
                if len(splits) > 1:
                    catalog_id = splits[0].strip()
                    resource = splits[1].strip()
                if not catalog_id or catalog_id == None:
                    logger.error(f"Invalid format for Resource Linked Glue database name: {resource}. Expected format: <source_account_id>: <Resource Linked Database Name> (<source_db_name>_rl)")
                else:
                    catalog_id = str(catalog_id)
                if "tbl" not in grant.lower():
                    resource_dict = {}
                    resource_dict["NAME"] = data.get("role_name") + "_glue_db_" + resource[:-3] + "_" + grant  # iam role name + glue db name without _rl
                    resource_dict["PRINCIPAL_ARN"] = f"arn:aws:iam::{data.get('aws_account_id', '')}:role/{data.get('role_name', '')}"
                    resource_dict["DATABASE_NAME"] = resource[:-3]
                    perm = replace_placeholders(json_structure.copy(), resource_dict)
                    perm["resource"]["catalog_id"] = catalog_id
                    lf_data_permission.append(_sort_perm(perm))
                    # lf_data_permission.append(replace_placeholders(json_structure.copy(), resource_dict))
                elif "tbl" in grant.lower():
                    resource_dict = {}
                    resource_dict["NAME"] = data.get("role_name") + "_glue_db_" + resource[:-3] + "_" + grant  # iam role name + glue db name without _rl
                    resource_dict["PRINCIPAL_ARN"] = f"arn:aws:iam::{data.get('aws_account_id', '')}:role/{data.get('role_name', '')}"
                    resource_dict["DATABASE_NAME"] = resource[:-3]
                    perm = replace_placeholders(json_structure.copy(), resource_dict)
                    perm["resource"]["catalog_id"] = catalog_id
                    lf_data_permission.append(_sort_perm(perm))
                    # lf_data_permission.append(replace_placeholders(json_structure.copy(), resource_dict))
                    continue # skip tbl grant for db for with_rl since we already granted for without _rl
            # building dict for each glue database
            resource = resource.split(":")[-1].strip()  # in case of <account_id>:<db_name> format, take only db_name
            resource_dict = {}
            resource_dict["NAME"] = data.get("role_name") + "_glue_db_" + resource + "_" + grant  # iam role name + glue db name
            resource_dict["PRINCIPAL_ARN"] = f"arn:aws:iam::{data.get('aws_account_id', '')}:role/{data.get('role_name', '')}"
            resource_dict["DATABASE_NAME"] = resource
            perm = replace_placeholders(json_structure.copy(), resource_dict)
            perm["resource"]["catalog_id"] = data.get('aws_account_id', '')
            lf_data_permission.append(_sort_perm(perm))
            # lf_data_permission.append(replace_placeholders(json_structure.copy(), resource_dict))
    for grant in sorted(grants_map.get("general", []) or []):
        lf_data_permission_template = filter_reference_by_key_and_value(reference_json, "reference_policy_name", grant)[0]
        json_structure = json.loads(lf_data_permission_template.get("json_structure", {})) if is_json_loadable(lf_data_permission_template.get("json_structure", {})) else lf_data_permission_template.get("json_structure", {})
        # building dict for the role
        resource_dict = {}
        resource_dict["PRINCIPAL_ARN"] = f"arn:aws:iam::{data.get('aws_account_id', '')}:role/{data.get('role_name', '')}"
        perm = replace_placeholders(json_structure.copy(), resource_dict)
        perm["resource"]["catalog_id"] = data.get('aws_account_id', '')
        lf_data_permission.append(_sort_perm(perm))
        # lf_data_permission.append(replace_placeholders(json_structure.copy(), resource_dict))
    # data location access for data_prefixes
    lf_data_permission += get_lf_data_permissions_s3_dl(data, reference_json, validation_details)
    # deterministic keep-first dedupe by name (avoids relying on dict/set iteration order), then sort by name
    _deduped_by_name = {}
    for _perm in lf_data_permission:
        _key = _perm.get("name", "")
        if _key not in _deduped_by_name:
            _deduped_by_name[_key] = _perm
    return sorted(_deduped_by_name.values(), key=lambda p: p.get("name", ""))

def get_lf_data_permissions_s3_dl(data: dict, reference_json: dict, validation_details: dict) -> dict:
    """
    Get the Lake Formation data permissions for S3 data locations given in the iam data.

    :param data: The original data dictionary from iam
    :param reference_json: The reference JSON dictionary

    :return: The Lake Formation data permissions JSON for given S3 data locations
    """
    data = copy.deepcopy(data)
    lf_data_permission = []

    def _sort_perm(p):
        # deterministic ordering of permission verb arrays only; no schema/content change
        if isinstance(p.get("permissions"), list):
            p["permissions"] = sorted(p["permissions"])
        if isinstance(p.get("permissions_with_grant_option"), list):
            p["permissions_with_grant_option"] = sorted(p["permissions_with_grant_option"])
        return p

    role_name = "iam_" + get_role_from_role_name(data.get("role_name", ""), validation_details).lower()
    grants = filter_reference_by_key_and_value(reference_json, "reference_policy_name", role_name)[0].get("reference_details_dl", [])
    logger.debug(f"Grants needed for LF data permissions for S3 DLs of role {role_name}: {grants}")
    data_prefixes = data.get("access_to_resources", {}).get("data_prefixes", [])
    # extending with execution_assest_prefixes as well
    execution_asset_prefixes = data.get("access_to_resources", {}).get("execution_asset_prefixes", [])
    data_prefixes = sorted(set(data_prefixes + execution_asset_prefixes))
    if not data_prefixes or data_prefixes == [None] or data_prefixes == [""] or grants == [] or grants == [None] or grants == [""] or not grants:
        logger.info(f"No S3 prefixes found for granting LF data permissions in the input data.")
        return lf_data_permission
    for grant in sorted(grants):
        lf_data_permission_template = filter_reference_by_key_and_value(reference_json, "reference_policy_name", grant)[0]
        json_structure = json.loads(lf_data_permission_template.get("json_structure", {})) if is_json_loadable(lf_data_permission_template.get("json_structure", {})) else lf_data_permission_template.get("json_structure", {})
        for resource in data_prefixes:
            if resource == "" or resource is None or not resource:
                continue
            if not re.match(r"^s3:\/\/[a-z0-9.-]{3,63}(?:\/[A-Za-z0-9._\-/]*)?\/?$", resource):
                logger.error(f"Invalid S3 prefix format: {resource}. Expected format: s3://bucket-name/prefix/")
                continue
            # building dict for each s3 prefix
            resource_dict = {}
            resource_dict["NAME"] = data.get("role_name") + "_s3_dl_" + resource.replace("s3://", "").replace("/", "_") + "_" + grant  # iam role name + s3 prefix
            resource_dict["PRINCIPAL_ARN"] = f"arn:aws:iam::{data.get('aws_account_id', '')}:role/{data.get('role_name', '')}"
            resource_dict["S3_ARN"] = f"arn:aws:s3:::{'/'.join(resource.split('/')[2:])}" if not resource.endswith("/") else f"arn:aws:s3:::{'/'.join(resource.split('/')[2:-1])}"
            perm = replace_placeholders(json_structure.copy(), resource_dict)
            lf_data_permission.append(_sort_perm(perm))
    return sorted(lf_data_permission, key=lambda p: p.get("name", ""))

def get_account_ids(files: list, resource_position_in_path: int, account_ids_map: dict) -> list:
    """
    Extract unique AWS account IDs from a list of YAML files.

    :param files: List of input YAML files
    :param resource_position_in_path: Position of the resource type in the file path
    :param account_ids_map: Mapping of AWS account IDs to account names

    :return: List of unique AWS account IDs
    """
    account_ids = {}
    for file in files:
        if file.endswith((".yml", ".yaml")):
            data = load_yaml(file) or {}
            aws_account_id = str(data.get("aws_account_id", "")).strip()
            resource_type = file.split('/')[resource_position_in_path]
            if resource_type.lower() in ["smus_project", "smus_roles"]:
                continue
            if aws_account_id and aws_account_id in account_ids:
                if resource_type not in account_ids[aws_account_id]:
                    account_ids[aws_account_id].append(resource_type)
                    if resource_type == "iam":
                        account_ids[aws_account_id].append("glue_crawler")
                        account_ids[aws_account_id].append("athena_workgroup")
                    if resource_type == "glue_crawler":
                        account_ids[aws_account_id].append("iam")
                    if resource_type == "resource_policy":
                        account_ids[aws_account_id].append("s3")
                    if resource_type == "s3":
                        account_ids[aws_account_id].append("resource_policy")
                    if resource_type == "data_federation":
                        for cross_account_aws_id in data.get("cross_account_aws_ids", []):
                            cross_account_aws_account_name = str(cross_account_aws_id).strip()
                            if cross_account_aws_id:
                                if cross_account_aws_account_name not in account_ids:
                                    account_ids[cross_account_aws_account_name] = [resource_type]
                                else:
                                    account_ids[cross_account_aws_account_name].append(resource_type)
                else:
                    continue
            elif aws_account_id and aws_account_id not in account_ids:
                account_ids[aws_account_id]=[resource_type]
                if resource_type == "resource_policy":
                    account_ids[aws_account_id].append("s3")
                if resource_type == "s3":
                    account_ids[aws_account_id].append("resource_policy")
                if resource_type == "iam":
                    account_ids[aws_account_id].append("glue_crawler")
                    account_ids[aws_account_id].append("athena_workgroup")
                if resource_type == "glue_crawler":
                    account_ids[aws_account_id].append("iam")
                if resource_type == "data_federation":
                    for cross_account_aws_id in data.get("cross_account_aws_ids", []):
                        cross_account_aws_account_name = str(cross_account_aws_id).strip()
                        if cross_account_aws_id:
                            if cross_account_aws_account_name not in account_ids:
                                account_ids[cross_account_aws_account_name] = [resource_type]
                            else:
                                account_ids[cross_account_aws_account_name].append(resource_type)
    return account_ids

# Modified this function to get relevant files based on account_id and resource type
def get_relevant_files(input_folder: str, account_ids_resources_map: dict, already_validated_files: list[str], account_ids_map: dict) -> list[str]:
    """
    To get relevant YAML files from the input folder based on the account_id and resource type.

    :param input_folder: Path to the input folder containing YAML files
    :param account_ids_resources_map: The mapping of aws_account_ids to resource types to match
    :param already_validated_files: List of files that have already been validated
    :param account_ids_map: Mapping of AWS account IDs to account names
    :return: List of relevant YAML files matching the account_id and resource type
    """
    relevant_files = []
    for account_id, resource_types in account_ids_resources_map.items():
        # listing files in the format <input_folder>/<account_name>/<resource_type>/*.yaml
        for resource_type in resource_types:
            dir = os.path.join(input_folder, account_ids_map.get(account_id, account_id), resource_type)
            if not os.path.exists(dir):
                logger.warning(f"Directory does not exist for account {account_id} and resource type {resource_type} at path {dir}")
                continue
            for f in os.listdir(dir):
                if f.endswith((".yml", ".yaml")):
                    file_path = os.path.join(dir, f)
                    if file_path not in already_validated_files:
                        relevant_files.append(file_path)
    return relevant_files

# function to get the list of s3 buckets in the account
def mapping_s3_buckets(folder_name: str, account_ids: list) -> dict:
    """
    List all S3 buckets files by just listing the files in a specified folder based on account_ids.

    :param folder_name: Path to the folder containing S3 bucket files
    :param account_ids: List of AWS account IDs to filter the S3 buckets

    :return: Dictionary mapping account_ids to their respective S3 bucket names (file names without extension (.yaml/.json))
    """
    s3_buckets = {}
    try:
        for account_name in account_ids:
            dir = os.path.join(folder_name, account_name, "s3")
            if not os.path.exists(dir):
                logger.warning(f"S3 folder does not exist for account {account_name} at path {dir}")
                continue
            for f in os.listdir(dir):
                if os.path.isfile(os.path.join(dir, f)):
                    # account_id = load_yaml(os.path.join(folder_name, f)).get("aws_account_id", "") if f.endswith((".yml", ".yaml")) and load_yaml(os.path.join(folder_name, f)) else ""
                    # if account_id not in account_ids:
                    #     continue
                    bucket_name = os.path.splitext(f)[0]
                    s3_buckets.setdefault(account_name, []).append(bucket_name)
        return s3_buckets
    except Exception as e:
        logger.error(f"Error listing S3 buckets in folder {folder_name}: {e}")
        return {}
    
def get_role_from_role_name(role_name: str, validation_details: dict) -> str:
    """
    Get the IAM role from the role name by get role fetching expression from validation details.

    :param role_name: The role name to fetch the IAM role for
    :param validation_details: The validation details dictionary

    :return: The IAM role corresponding to the given role name
    """
    list_of_role_type = get_python_constants(validation_details).get("role_type", [])
    try:
        for item in role_name.split('_'):
            if any(re.search(pattern, item, re.IGNORECASE) for pattern in list_of_role_type):
                return item.lower()
        logger.warning(f"Could not determine role type from role name: {role_name}")
        return ""
    except Exception as e:
        logger.error(f"Error executing role fetch expression: {e}")
        return ""

from urllib.parse import urlparse

def filter_paths_until_keyword(s3_paths: list, keywords: list) -> list:
    """
    Filters S3 paths to include only prefix up to keyword and appends /*
    """
    filtered_paths = set()

    for path in s3_paths:
        parsed = urlparse(path)

        if parsed.scheme != "s3":
            continue  # skip non-S3 paths

        bucket = parsed.netloc
        prefix = parsed.path.lstrip("/")  # remove leading '/'

        for keyword in keywords:
            if keyword in prefix:
                parts = prefix.split('/')
                
                # find exact segment match instead of substring
                for i, part in enumerate(parts):
                    if keyword == part:
                        filtered_prefix = '/'.join(parts[:i + 1]) + "/*"
                        filtered_paths.add(f"s3://{bucket}/{filtered_prefix}")
                        break
                break

    return list(filtered_paths)

def clean_s3_prefixes(s3_prefixes: list) -> list:
    '''
    function to clean s3 prefixes by removing trailing /* if present

    :param s3_prefixes: list of S3 prefixes
    
    :return: cleaned list of S3 prefixes
    '''
    cleaned_prefixes = []
    for prefix in s3_prefixes:
        clean = prefix.removeprefix("s3://").rstrip("/")
        parts = clean.split("/", 1)
        bucket = parts[0]
        cleaned_prefixes.append(f"arn:aws:s3:::{bucket}")
        if len(parts) > 1:
            cleaned_prefixes.append(f"arn:aws:s3:::{clean}/*" if not parts[1].endswith("/*") else f"arn:aws:s3:::{clean}")
    return cleaned_prefixes

def inject_rp_principal_arns_to_s3(resource_policy_files: dict, s3_files: list, reference_json: dict, validation_details: dict) -> None:
    """
    Updates S3 JSON files by injecting all unique principal ARNs into the 'resource_policy' field as a list.
    
    - Reads multiple resource policy JSON files.
    - Extracts 'principal_role_arn' and S3 prefixes from each file.
    - Matches S3 bucket names from prefixes with S3 JSON files in s3_files.
    - Aggregates all unique principal ARNs for the same bucket into a list in 'resource_policy'.
   
    Args:
        resource_policy_files (dict): Dictionary mapping account IDs to lists of resource policy JSON file paths.
        s3_files (list): List of file paths where S3 JSON files are stored.
        reference_json (dict): The reference JSON dictionary.
        validation_details (dict): The validation details dictionary.
    """
    # Dictionary to hold bucket_name -> set of principal ARNs
    bucket_principals_map = {} # which contains account-wise bucket principal mapping

    # Step 1: Collect all principal ARNs for each bucket from resource policy files
    for account_id, rp_files in resource_policy_files.items():
        if account_id not in bucket_principals_map:
            bucket_principals_map[account_id] = {}
        for resource_policy_file in rp_files:
            try:
                with open(resource_policy_file, "r") as f:
                    resource_policy_data = json.load(f)
            except Exception as e:
                logger.error(f"Failed to load resource policy JSON {resource_policy_file}: {e}")
                continue

            principal_arn = resource_policy_data.get("principal_role_arn")
            if not principal_arn:
                logger.warning(f"No principal_role_arn found in {resource_policy_file}. Skipping.")
                continue

            s3_prefixes = resource_policy_data.get("access_to_resources", {}).get("s3_prefixes", [])
            s3_prefixes = filter_paths_until_keyword(s3_prefixes, ["cdp_share", "cdp", "current"])
            for prefix in s3_prefixes:
                bucket_name = prefix.replace("s3://", "").split("/")[0]
                if bucket_name not in bucket_principals_map[account_id]:
                    bucket_principals_map[account_id][bucket_name] = [set(), set()]  
                bucket_principals_map[account_id][bucket_name][0].add(principal_arn)
                bucket_principals_map[account_id][bucket_name][1].add(prefix)
                
    # Step 2: Inject aggregated principal ARNs into matching S3 JSON file
    for account_id, bucket_map in bucket_principals_map.items():
        for bucket_name, items in bucket_map.items():
            principals_list = sorted(items[0])  # Convert set to sorted list
            s3_prefixes_list = sorted(items[1])  # Convert set to sorted list
            s3_prefixes_list = clean_s3_prefixes(s3_prefixes_list)
            s3_prefixes_list = list(set(s3_prefixes_list))  # Ensure uniqueness

            # Adding the resource policy to default bucket policy
            resource_policy_template = json.loads(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "resource_policy_template")[0].get("json_structure", {})) if is_json_loadable(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "resource_policy_template")[0].get("json_structure", {})) else filter_reference_by_key_and_value(reference_json, "reference_policy_name", "resource_policy_template")[0].get("json_structure", {})
            specific_dict = {
                "principal_arns": principals_list,
                "s3_prefixes": s3_prefixes_list
            }
            resource_policy = replace_placeholders(resource_policy_template, specific_dict)
            # Finding matching S3 JSON file for the bucket (*account_id/s3/<bucket_name>.json)
            matching_s3_file = next((s3_file for s3_file in s3_files if os.path.basename(s3_file).split(".")[0] == bucket_name and f"/{account_id}/s3" in s3_file and s3_file.endswith(".json")), None)
            if matching_s3_file:
                logger.info(f"Found matching S3 JSON file for bucket {bucket_name} in account {account_id}: {matching_s3_file}")
            else:
                logger.warning(f"No matching S3 JSON file found for bucket {bucket_name} in account {account_id} (i.e., May be the bucket {bucket_name} not exist)")
                continue
            try:
                with open(matching_s3_file, "r") as f:
                    s3_data = json.load(f)
            except Exception as e:
                logger.error(f"Failed to load S3 JSON {matching_s3_file}: {e}")
                continue
            logger.info(f"Injecting {len(principals_list)} principal ARNs into S3 bucket: {bucket_name}")
            s3_bucket_policy = s3_data.get("bucket_policy", None)
            if s3_bucket_policy is None:
                logger.warning(f"No default bucket policy found for bucket {bucket_name} in account {account_id}")
            if s3_bucket_policy and isinstance(s3_bucket_policy, str):
                s3_bucket_policy = json.loads(s3_bucket_policy)
                s3_bucket_policy["Statement"].append(resource_policy)
                s3_data["bucket_policy"] = json.dumps(s3_bucket_policy, indent=4)
            # Save updated S3 JSON
            try:
                with open(matching_s3_file, "w") as f:
                    json.dump(s3_data, f, indent=4)
                logger.info(f"Successfully updated resource policy in {matching_s3_file}")
            except Exception as e:
                logger.error(f"Failed to update S3 JSON {matching_s3_file}: {e}")

def add_default_s3_bucket_policy(s3_data: dict, reference_json: dict, validation_details: dict) -> dict:
    """
    Will add the default bucket policy for the given s3_data

    :param s3_data: The S3 data dictionary
    :param reference_json: The reference JSON dictionary
    :param validation_details: The validation details dictionary

    :return: The updated S3 data dictionary with the default bucket policy added
    """
    default_bucket_policy_template = json.loads(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "default_bucket_policy")[0].get("json_structure", {})) if is_json_loadable(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "default_bucket_policy")[0].get("json_structure", {})) else filter_reference_by_key_and_value(reference_json, "reference_policy_name", "default_bucket_policy")[0].get("json_structure", {})
    default_bucket_policy = replace_placeholders(default_bucket_policy_template, s3_data)
    s3_data["bucket_policy"] = json.dumps(default_bucket_policy, indent=4)
    return s3_data

def get_lf_data_permissions_glue_db_resource_policy(data: dict, reference_json: dict, validation_details: dict) -> dict:
    """
    Get the Lake Formation data permissions for Glue databases resource policy given in the resource policy data.

    :param data: The original data dictionary from resource policy
    :param reference_json: The reference JSON dictionary
    :param validation_details: The validation details dictionary

    :return: The Lake Formation data permissions JSON for Glue databases resource policy
    """
    grants = list(set(filter_reference_by_key_and_value(reference_json, "reference_policy_name", "lf_data_permission_glue_db_resource_policy")[0].get("reference_details_lf", [])))
    lf_data_permission = []
    # glue_dbs = list(set(data.get("access_to_resources", {}).get("glue_databases", [])))
    glue_dbs = data.get("access_to_resources", {}).get("glue_databases", []) if data.get("access_to_resources", {}).get("glue_databases", []) else []
    glue_dbs = list(set(glue_dbs))
    for grant in grants:
        lf_data_permission_template = filter_reference_by_key_and_value(reference_json, "reference_policy_name", grant)[0]
        json_structure = json.loads(lf_data_permission_template.get("json_structure", {})) if is_json_loadable(lf_data_permission_template.get("json_structure", {})) else lf_data_permission_template.get("json_structure", {})
        if not glue_dbs or glue_dbs == [None] or glue_dbs == [""] or glue_dbs == []:
            logger.info(f"No Glue databases found for granting access in the input data.")
            continue
        # Adding default glue database permission if "default" is in grant name only once
        if "default" in grant.lower() and glue_dbs:
            # building dict for the resource policy
            resource_dict = {}
            resource_dict["PRINCIPAL_ARN"] = f"{data.get('principal_role_arn', '')}"
            lf_data_permission.append(replace_placeholders(json_structure.copy(), resource_dict))
            continue

        for resource in glue_dbs:
            if not re.match(r"^[a-zA-Z0-9._-]{1,255}$", resource):
                logger.error(f"Invalid Glue database name format: {resource}. Expected format: alphanumeric characters, underscores, hyphens, and periods only.")
            # if resource endswith _rl and grant is not for table, also grant permission for db without _rl
            if resource.endswith("_rl") and "tbl" not in grant.lower():
                resource_dict = {}
                resource_dict["NAME"] = data.get("role_name") + "_glue_db_" + resource[:-3] + "_" + grant  # iam role name + glue db name without _rl
                resource_dict["PRINCIPAL_ARN"] = f"arn:aws:iam::{data.get('aws_account_id', '')}:role/{data.get('role_name', '')}"
                resource_dict["DATABASE_NAME"] = resource[:-3]
                lf_data_permission.append(replace_placeholders(json_structure.copy(), resource_dict))
            # building dict for each glue database
            resource_dict = {}
            resource_dict["NAME"] = data.get("resource_policy_name") + "_glue_db_" + resource + "_" + grant  # resource policy name + glue db name
            resource_dict["PRINCIPAL_ARN"] = f"{data.get('principal_role_arn', '')}"
            resource_dict["DATABASE_NAME"] = resource
            lf_data_permission.append(replace_placeholders(json_structure.copy(), resource_dict))

    # adding data location access for s3_prefixes
    lf_data_permission += get_lf_data_permissions_s3_dl_resource_policy(data, reference_json, validation_details)
    return list({perm["name"]: perm for perm in lf_data_permission}.values())

def get_lf_data_permissions_s3_dl_resource_policy(data: dict, reference_json: dict, validation_details: dict) -> dict:
    """
    Get the Lake Formation data permissions for S3 data locations given in the iam data.

    :param data: The original data dictionary from resource policy
    :param reference_json: The reference JSON dictionary

    :return: The Lake Formation data permissions JSON for given S3 data locations
    """
    lf_data_permission = []
    grants = filter_reference_by_key_and_value(reference_json, "reference_policy_name", "lf_data_permission_glue_db_resource_policy")[0].get("reference_details_dl", [])
    logger.debug(f"Grants needed for LF data permissions for S3 DLs of role lf_data_permission_glue_db_resource_policy: {grants}")
    data_prefixes = data.get("access_to_resources", {}).get("s3_prefixes", [])
    if not data_prefixes or data_prefixes == [None] or data_prefixes == [""] or grants == [] or grants == [None] or grants == [""] or not grants:
        logger.info(f"No S3 prefixes found for granting LF data permissions in the input data.")
        return lf_data_permission
    for grant in grants:
        lf_data_permission_template = filter_reference_by_key_and_value(reference_json, "reference_policy_name", grant)[0]
        json_structure = json.loads(lf_data_permission_template.get("json_structure", {})) if is_json_loadable(lf_data_permission_template.get("json_structure", {})) else lf_data_permission_template.get("json_structure", {})
        for resource in data_prefixes:
            if resource == "" or resource is None or not resource:
                continue
            if not re.match(r"^s3:\/\/[a-z0-9.-]{3,63}(?:\/[A-Za-z0-9._\-/]*)?\/?$", resource):
                logger.error(f"Invalid S3 prefix format: {resource}. Expected format: s3://bucket-name/prefix/")
                continue
            # building dict for each s3 prefix
            resource_dict = {}
            resource_dict["NAME"] = "resource_policy_s3_dl_" + resource.replace("s3://", "").replace("/", "_") + "_" + grant  # iam role name + s3 prefix
            resource_dict["PRINCIPAL_ARN"] = f"arn:aws:iam::{data.get('aws_account_id', '')}:role/minerva-{ENV}-miw-s3-service-iam-role"
            resource_dict["S3_ARN"] = f"arn:aws:s3:::{'/'.join(resource.split('/')[2:])}" if not resource.endswith("/") else f"arn:aws:s3:::{'/'.join(resource.split('/')[2:-1])}"
            lf_data_permission.append(replace_placeholders(json_structure.copy(), resource_dict))
    return lf_data_permission
            
def append_file_to_validation_list(files_for_validation: list, relevant_files: list, input_file: str, file_to_be_appended: str) -> List[str]:
    """
    Append a file to the validation list if it is not already present.

    :param files_for_validation: List of files to be validated
    :param relevant_files: List of relevant files
    :param input_file: input yaml file path
    :param file_to_be_appended: file path to be appended to validation list

    :return 
    """
    if file_to_be_appended not in files_for_validation and input_file not in relevant_files:
        files_for_validation.append(file_to_be_appended)

    return files_for_validation

def get_lf_data_permissions_data_federation(data: dict, reference_json: dict, validation_details: dict) -> dict:
    """
    Get the Lake Formation data permissions for data federation given in the data federation data.

    :param data: The original data dictionary from data federation
    :param reference_json: The reference JSON dictionary
    :param validation_details: The validation details dictionary

    :return: The Lake Formation data permissions JSON for data federation
    """
    grants = filter_reference_by_key_and_value(reference_json, "reference_policy_name", "lf_data_federation")[0].get("reference_details_lf", [])
    lf_data_permission = []
    glue_dbs = data.get("glue_databases", [])
    for cross_account_aws_id in data.get("cross_account_aws_ids", []):
        for grant in grants:
            lf_data_permission_template = filter_reference_by_key_and_value(reference_json, "reference_policy_name", grant)[0]
            json_structure = json.loads(lf_data_permission_template.get("json_structure", {})) if is_json_loadable(lf_data_permission_template.get("json_structure", {})) else lf_data_permission_template.get("json_structure", {})
            # adding default glue database permission if "default" is in grant name only once
            if "default" in grant.lower() and glue_dbs:
                # building dict for the cross account
                resource_dict = {}
                resource_dict["PRINCIPAL_ARN"] = f"{cross_account_aws_id}"
                lf_data_permission.append(replace_placeholders(json_structure.copy(), resource_dict))
                continue
            for glue_db in glue_dbs:
                # building dict for each glue database
                resource_dict = {}
                resource_dict["NAME"] = data.get("data_share_name") + str(cross_account_aws_id) + glue_db + "_" + grant  # data federation name + glue db name
                resource_dict["PRINCIPAL_ARN"] = f"{cross_account_aws_id}"
                resource_dict["DATABASE_NAME"] = glue_db
                lf_data_permission.append(replace_placeholders(json_structure.copy(), resource_dict))
    return lf_data_permission

def get_resource_links_data_federation(data: dict, reference_json: dict, validation_details: dict) -> dict:
    """
    Get the Lake Formation resource links for data federation given in the data federation data.

    :param data: The original data dictionary from data federation
    :param reference_json: The reference JSON dictionary
    :param validation_details: The validation details dictionary

    :return: The Lake Formation resource links JSON for data federation
    """
    resource_links = {}
    glue_dbs = data.get("glue_databases", [])
    for glue_db in glue_dbs:
        resource_link_template = filter_reference_by_key_and_value(reference_json, "reference_policy_name", "lf_resource_link_data_federation")[0]
        json_structure = json.loads(resource_link_template.get("json_structure", {})) if is_json_loadable(resource_link_template.get("json_structure", {})) else resource_link_template.get("json_structure", {})
        # building dict for each glue database
        resource_dict = {}
        resource_dict["DATABASE_NAME"] = glue_db
        resource_dict["CATALOG_ID"] = str(data.get("aws_account_id", ""))
        resource_links[glue_db] = replace_placeholders(json_structure.copy(), resource_dict)
    return resource_links

def convert_hr_to_sec(duration: int) -> int:
    """
    Converting given duration (in hrs) to sec

    :param duration: duration in hrs

    :return: The given time duration in to sec
    """
    return (duration)

def convert_iam_max_session_duration_to_sec(data: dict) -> dict:
    """
    Converting max_session_duration of given iam data

    :param data: The given iam data

    :return Modified iam data after conversion
    """
    hrs = data.get("max_session_duration", 1)
    try:
        hrs = int(hrs)
    except ValueError:
        logger.error(f"Invalid max_session_duration value: {hrs}. It should be an integer representing hours.")
    data["max_session_duration"] = str(convert_hr_to_sec(hrs))
    return data

def check_file_name_convention(data: dict, file_name_convention_key: str, file_path: str) -> bool:
    """
    Check if the file name follows the specified naming convention.

    :param data: The data dictionary containing the value to check
    :param file_name_convention_key: The key in the data dictionary to check against the file name
    :param file_path: The path of the file to check

    :return: True if the file name follows the convention, False otherwise
    """
    expected_value = data.get(file_name_convention_key, "")
    actual_file_name = os.path.splitext(os.path.basename(file_path))[0]
    if expected_value != actual_file_name:
        logger.error(f"File name convention error: Expected '{expected_value}' but found '{actual_file_name}' in file path '{file_path}'")
        return False
    return True

# Adding the following two functions to fix the issue found for Compute to Compute Data Federation
def is_data_federation_needed(account_ids_resources_map: dict) -> bool:
    """
    Check if data federation is needed based on the presence of "data_federation" in the resources of any account.

    :param account_ids_resources_map: A dictionary mapping account IDs to their respective resources

    :return: True if data federation is needed, False otherwise
    """
    for resources in account_ids_resources_map.values():
        if "data_federation" in resources:
            return True
    return False

def get_data_federation_files(input_folder: str) -> list:
    files = []
    for root, _, file_list in os.walk(input_folder):
        for file in file_list:
            file_path = os.path.join(root, file)
            parent_dir = os.path.dirname(file_path)
            service_type = os.path.basename(parent_dir)
            if service_type.lower() == "data_federation" and file.endswith((".yml", ".yaml")):
                files.append(os.path.join(root, file))
    logger.debug(f"Data federation files found: {files}")
    return files

def filter_context_only_files(candidate_files: list, already_processed_files: list) -> list:
    """
    Filter out any candidate file that is already part of the current run's
    primary/changed files set, so it isn't double-counted as "context only".

    This is used to fix a bug where `get_data_federation_files()` returns
    EVERY Data Federation YAML found anywhere in the repo (needed so cross-
    account Lake Formation grants/resource-links can be generated with full
    context), including the Data Federation file(s) that were actually
    changed in the current PR. Without this filter, the changed file(s) end
    up in `relevant_files`, and `append_file_to_validation_list()` then
    silently excludes their generated JSON (the primary data_federation
    JSON, Lake Formation permissions JSON, and resource-links JSON) from
    `files_for_validation_layer` / validation_files.txt -- because its guard
    treats any file present in `relevant_files` as "already covered
    elsewhere". The net effect: changed Data Federation files were never
    passed to validation_driver.py, so Glue DB existence errors (and any
    other data_federation validation) were silently skipped.

    :param candidate_files: Files to potentially treat as "context only" (e.g. from get_data_federation_files())
    :param already_processed_files: The current run's primary/changed files (e.g. files_to_be_processed before merging in relevant_files)

    :return: candidate_files with any file already present in already_processed_files removed
    """
    already_processed_abspaths = {os.path.abspath(f) for f in already_processed_files}
    return [f for f in candidate_files if os.path.abspath(f) not in already_processed_abspaths]

def is_execution_asset_prefix_valid_for_athena_access(data: dict, execution_asset_prefixes: list = None) -> Tuple[bool, str]:
    """
    Check if the execution asset prefixes are valid for Athena access.

    :param data: The original IAM data dictionary
    :param execution_asset_prefixes: Optional execution asset prefixes to validate

    :return: True if execution asset prefixes are valid, False otherwise
    """
    if execution_asset_prefixes is None:
        execution_asset_prefixes = data.get("access_to_resources", {}).get("execution_asset_prefixes", [])
    if execution_asset_prefixes is None:
        return False, None
    has_valid_prefix, valid_prefix = False, None
    # At least one prefix should contain both execution asset bucket naming and athena path keywords.
    for prefix in execution_asset_prefixes:
        if not isinstance(prefix, str):
            continue

        normalized_prefix = prefix.strip().lower()
        if not normalized_prefix.startswith("s3://"):
            continue

        has_eng_assets = "eng-assets" in normalized_prefix or "eng-assests" in normalized_prefix
        has_athena = "athena" in normalized_prefix

        if has_eng_assets and has_athena:
            has_valid_prefix = True
            valid_prefix = prefix
            break
    if not has_valid_prefix:
        return False, valid_prefix
    return True, valid_prefix

def build_athena_workgroup_data(data: dict, reference_json: dict, validation_details: dict) -> dict:
    """
    Build the Athena workgroup data for the given IAM data.

    :param data: The original IAM data dictionary
    :param reference_json: The reference JSON dictionary
    :param validation_details: The validation details dictionary

    :return: The Athena workgroup data dictionary
    """
    # Checking for valid execution asset prefixes for athena access
    is_valid, valid_prefix = is_execution_asset_prefix_valid_for_athena_access(data)
    if not is_valid:
        raise ValueError(f"Execution asset prefixes for Athena access  was not found in the input IAM data.")
    athena_workgroup_data = {}
    athena_workgroup_data["intake_id"] = data.get("intake_id", "")
    athena_workgroup_data["athena_workgroup_name"] = data.get("athena_access_config", {}).get("athena_workgroup_name", "")
    athena_workgroup_data["athena_workgroup_description"] = data.get("role_description", "")
    athena_workgroup_data["aws_account_id"] = data.get("aws_account_id", "")
    athena_workgroup_data["enterprise_or_func_name"] = data.get("enterprise_or_func_name", "")
    athena_workgroup_data["enterprise_or_func_subgrp_name"] = data.get("enterprise_or_func_subgrp_name", "")
    athena_workgroup_data["query_result_location"] = valid_prefix
    athena_workgroup_tags = [item for item in filter_by_object_type(validation_details, "athena_workgroup") if item.get("action") == "tag_mapping"][0].get("json_structure", {})
    athena_workgroup_data = add_tag_values(athena_workgroup_data, athena_workgroup_tags, validation_details)
    """
    T‑Shirt Size	Typical Use Case	Recommended Bytes Scanned
    XSML	Metadata queries, schema checks, basic exploration	10 GB
    SML	Lightweight filters, small joins	25 GB
    MED	Daily reports, moderate joins	50 GB
    LRG	Heavy aggregations, multi‑source joins	100 GB
    XLRG	Exploratory analysis, large datasets	200 GB
    """
    # Geeting the compute size from the input data and validating it against the mapping in validation details
    athena_workgroup_compute_size = data.get("compute_size", "XSML").upper()
    athena_compute_size_mapping = get_python_constants(validation_details).get("athena_compute_size_mapping", {})
    if athena_workgroup_compute_size not in athena_compute_size_mapping:
        raise ValueError(f"Invalid Athena workgroup compute size: {athena_workgroup_compute_size}. Expected one of {list(athena_compute_size_mapping.keys())}")
    athena_workgroup_data["data_scanned_limit"] = int(athena_compute_size_mapping.get(athena_workgroup_compute_size, 0)) * 1024 * 1024 * 1024  # Convert GB to bytes
    return athena_workgroup_data
