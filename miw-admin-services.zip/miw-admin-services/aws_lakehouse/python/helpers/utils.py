import boto3
from botocore.exceptions import ClientError
from helpers.config_log import logger
import json, yaml, os, sys, re
from typing import Any, Dict

def save_to_file(data:str, file_path:str) -> str:
    """
    Save data to a specified file.

    :param data: Data to be saved
    :param file_path: Path to the file where data should be saved

    :return: Path to the saved file
    """
    with open(file_path, "w") as f:
        f.write(data)
    logger.debug(f"Data saved to {file_path}, size: {len(data)} characters")
    return file_path

def make_terraform_friendly(json_data: dict) -> dict:
    """
    Convert JSON keys to be Terraform friendly by replacing placeholder '<' and '>' with "" for the time being.

    :param json_data: Original JSON data
    :return: JSON data with Terraform friendly keys
    """
    return json.loads(json.dumps(json_data).replace("<", "").replace(">", ""))

# Initialize DynamoDB resource (uses AWS CLI credentials or environment variables)
dynamodb = boto3.resource("dynamodb", region_name="us-east-1")  # change region if needed

def get_items_from_dynamodb(table_name: str) -> list:
    """
    Fetch all items from a specified DynamoDB table.

    :param table_name: Name of the DynamoDB table

    :return: List of items from the DynamoDB table
    """
    table = dynamodb.Table(table_name)
    items = []
    response = table.scan()   # fetch initial batch
    items.extend(response.get("Items", []))

    # Handle pagination (DynamoDB returns 1MB per scan)
    while "LastEvaluatedKey" in response:
        response = table.scan(ExclusiveStartKey=response["LastEvaluatedKey"])
        items.extend(response.get("Items", []))

    return items
    
def insert_item(table_name: str, item: dict) -> bool:
    """
    Insert or overwrite an item in DynamoDB.

    :param table_name: Name of the DynamoDB table
    :param item: Dictionary representing the item to insert
    :return: True if success, False otherwise
    """
    table = dynamodb.Table(table_name)
    try:
        table.put_item(Item=item)
        logger.info(f"✅ Inserted item into {table_name}: {item}")
        return True
    except ClientError as e:
        logger.info(f"❌ Failed to insert item: {e.response['Error']['Message']}")
        return False
    
def update_item(table_name: str, key: dict, updates: dict) -> bool:
    """
    Update attributes of an item in DynamoDB.

    :param table_name: Name of the DynamoDB table
    :param key: Dictionary with the primary key (partition key + sort key if applicable)
    :param updates: Dictionary of attributes to update
    :return: True if success, False otherwise
    """
    table = dynamodb.Table(table_name)

    # Build UpdateExpression dynamically
    update_expr = "SET " + ", ".join([f"#{k}=:{k}" for k in updates.keys()])
    expr_attr_names = {f"#{k}": k for k in updates.keys()}
    expr_attr_values = {f":{k}": v for k, v in updates.items()}

    try:
        table.update_item(
            Key=key,
            UpdateExpression=update_expr,
            ExpressionAttributeNames=expr_attr_names,
            ExpressionAttributeValues=expr_attr_values,
        )
        logger.info(f"✅ Updated item {key} in {table_name} with {updates}")
        return True
    except ClientError as e:
        logger.info(f"❌ Failed to update item: {e.response['Error']['Message']}")
        return False
    
def execute_expression(expression: str, variables: dict):
    """
    Safely evaluate a Python expression string using a restricted environment.
    """
    # Define allowed built-in functions to safeguard eval
    allowed_builtins = {
        "len": len,
        "str": str,
        "int": int,
        "float": float,
    }
    try:
        return eval(
            expression,
            {"__builtins__": allowed_builtins},  # Safe builtins
            variables  # Variables available in expression
        )
    except Exception as e:
        logger.error(f"Error executing expression '{expression}': {e}")
        return None

def replace_placeholders(data_with_placeholders: Any, replacements: Dict[str, Any]) -> Any:
    """
    Recursively replace placeholders in both KEYS and VALUES.
    Placeholder format: <key>

    - Preserves type if entire string is a single placeholder
    - Skips replacement if replacement value is None or empty
    """

    placeholder_pattern = re.compile(r"<([^<>]+)>")

    def is_valid_replacement(value: Any) -> bool:
        return value is not None and value != ""

    def replace_in_string(s: str) -> Any:
        # Case 1: entire string is exactly one placeholder → preserve type
        match = placeholder_pattern.fullmatch(s.strip())
        if match:
            key = match.group(1)
            value = replacements.get(key)
            if is_valid_replacement(value):
                return value
            return s  # leave placeholder unchanged

        # Case 2: partial replacements inside string
        def repl(m):
            key = m.group(1)
            value = replacements.get(key)
            if is_valid_replacement(value):
                return str(value)
            return m.group(0)

        return placeholder_pattern.sub(repl, s)

    def recursive_replace(data: Any) -> Any:
        if isinstance(data, dict):
            new_dict = {}
            for k, v in data.items():
                new_key = replace_in_string(k) if isinstance(k, str) else k
                new_dict[new_key] = recursive_replace(v)
            return new_dict

        elif isinstance(data, list):
            return [recursive_replace(item) for item in data]

        elif isinstance(data, str):
            return replace_in_string(data)

        else:
            return data

    return recursive_replace(data_with_placeholders)

def load_yaml(file_path: str) -> dict:
    """
    Load a YAML file and return its contents as a dictionary.

    :param file_path: Path to the YAML file

    :return: Dictionary representation of the YAML file contents
    """
    try:
        with open(file_path, "r") as f:
            return yaml.safe_load(f)
    except FileNotFoundError:
        logger.error(f"YAML file not found: {file_path}")
    except yaml.YAMLError as e:
        logger.error(f"Error parsing YAML file: {file_path}. Error: {e}")

def filter_by_object_type(validation_details: list, obj_type: str) -> list:
    """
    Filter validation details by object type and active status.

    :param validation_details: List of validation detail entries
    :param obj_type: The object type to filter by (e.g., "s3")

    :return: Filtered list of validation details for the specified object type and active status
    """
    return [entry for entry in validation_details if entry.get("object_type") == obj_type and entry.get("is_active") == "Y"]
