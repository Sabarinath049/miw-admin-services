import os
import os, sys, yaml, json, re
from helpers.config_log import logger
from helpers.utils import (
    load_yaml, 
)

def validate_resources_existence(data: dict, resource_type: str, existing_resources: dict, file_name: str, mandatory_json_keys: dict, python_constants: dict) -> list:
    errors = []

    account_id = str(data.get("aws_account_id", "")).strip()

    # IAM VALIDATION
    if resource_type.lower() == "iam":
        access = data.get("access_to_resources", {})

        # Glue DB Validation
        glue_databases = (
            access.get("glue_databases", {}).get("write", []) +
            access.get("glue_databases", {}).get("read", [])
        )

        for glue_db in glue_databases or []:

            account_id_mentioned = account_id
            glue_db_name = ""

            # Case 1: dict format
            if isinstance(glue_db, dict):
                account_id_mentioned = str(list(glue_db.keys())[0]).strip()
                glue_db_name = glue_db[account_id_mentioned].strip()

            # Case 2: string format
            elif isinstance(glue_db, str):
                glue_db = glue_db.strip()
                if ":" in glue_db:
                    account_id_mentioned, glue_db_name = glue_db.split(":", 1)
                    account_id_mentioned = account_id_mentioned.strip()
                    glue_db_name = glue_db_name.strip()
                else:
                    glue_db_name = glue_db

            # Validation
            existing_glue_dbs = existing_resources.get(account_id, {}).get("glue_db", [])
            if glue_db_name not in existing_glue_dbs:
                if glue_db_name.endswith("_rl"):
                    error_msg = f"In {file_name}, Resource Linked Glue DB '{glue_db_name}' not found in account '{account_id_mentioned}'. Check if Glue DB is federated."
                    errors.append(error_msg)
                    logger.error(error_msg)
                elif account_id_mentioned != account_id:
                    error_msg = f"In {file_name}, Glue DB '{glue_db_name}' from another account must use '_rl' suffix. Format: <account_id>:<db_name>_rl"
                    errors.append(error_msg)
                    logger.error(error_msg)
                else:
                    error_msg = f"In {file_name}, Glue DB '{glue_db_name}' not found in account '{account_id}' or not even included in the current PR."
                    errors.append(error_msg)
                    logger.error(error_msg)

        # S3 Validation
        prefixes = (
            access.get("data_prefixes", []) +
            access.get("execution_asset_prefixes", [])
        )

        for prefix in prefixes or []:
            parts = prefix.split("/")
            bucket_name = parts[2] if len(parts) > 2 else None

            if bucket_name:
                existing_buckets = existing_resources.get(account_id, {}).get("s3", [])
                if bucket_name not in existing_buckets:
                    error_msg = f"In {file_name}, S3 bucket '{bucket_name}' not found in account '{account_id}' or not even included in the current PR."
                    errors.append(error_msg)
                    logger.error(error_msg)

        # Glue Crawler Validation
        for crawler in access.get("glue_crawlers", []) or []:
            crawler = crawler.strip()
            existing_crawlers = existing_resources.get(account_id, {}).get("glue_crawler", [])

            if crawler not in existing_crawlers:
                error_msg = f"In {file_name}, Glue crawler '{crawler}' not found in account '{account_id}' or not even included in the current PR."
                errors.append(error_msg)
                logger.error(error_msg)

        return errors

    # DATA FEDERATION VALIDATION
    if resource_type.lower() == "data_federation":

        glue_databases = data.get("glue_databases", []) or []
        if not isinstance(glue_databases, list):
            glue_databases = [glue_databases]
        glue_databases = [str(db).strip() for db in glue_databases if str(db).strip()]

        logger.debug(
            f"[DF_EXISTENCE_CHECK_STARTED] file={file_name}, resource_type={resource_type}"
        )
        logger.debug(
            f"[DF_EXISTENCE_CHECK_INPUT] aws_account_id={account_id}, glue_databases={glue_databases}"
        )

        # If aws_account_id is missing/blank, fail clearly instead of silently
        # looking up an empty-string key in existing_resources.
        if not account_id:
            error_msg = (
                f"Data Federation validation failed: 'aws_account_id' is missing for file '{file_name}'. "
                f"Please specify the source aws_account_id before provisioning Data Federation."
            )
            errors.append(error_msg)
            logger.error(error_msg)
            logger.debug(f"[DF_EXISTENCE_CHECK_RESULT] errors_found={len(errors)} for file={file_name}")
            return errors

        # If glue_databases is empty, there is nothing to check here; mandatory-field
        # validation (DynamoDB mandatory_check / VALUE_VALIDATION) already covers
        # whether glue_databases must be populated, so we avoid duplicating that check.
        if not glue_databases:
            logger.debug(f"[DF_EXISTENCE_CHECK_RESULT] no glue_databases configured for file={file_name}, skipping")
            return errors

        logger.debug(
            f"[DF_EXISTENCE_CHECK_INVENTORY] account_present={account_id in existing_resources}, "
            f"inventory_keys={list(existing_resources.get(account_id, {}).keys())}"
        )

        # If the account itself was never fetched into existing_resources.json
        # (e.g. fetch_existing_resources.sh didn't run for this account, or the
        # account_id in the YAML doesn't match any account in the product key
        # file), fail clearly rather than silently treating every DB as missing
        # with no indication of the real problem.
        if account_id not in existing_resources:
            error_msg = (
                f"Data Federation validation failed: source account '{account_id}' was not found in the "
                f"fetched existing resources inventory for file '{file_name}'. Please verify the Data "
                f"Federation aws_account_id is correct and is included in the current PR's product key file."
            )
            errors.append(error_msg)
            logger.error(error_msg)
            logger.debug(f"[DF_EXISTENCE_CHECK_RESULT] errors_found={len(errors)} for file={file_name}")
            return errors

        # Normalize the fetched inventory the same way IAM/resource_policy do,
        # using the same "glue_db" key already populated by
        # fetch_existing_resources.sh for iam/resource_policy/data_federation.
        existing_glue_dbs = {
            str(db).strip()
            for db in existing_resources.get(account_id, {}).get("glue_db", [])
            if str(db).strip()
        }
        missing_glue_dbs = [db for db in glue_databases if db not in existing_glue_dbs]

        logger.debug(f"[DF_EXISTENCE_CHECK_RESULT] missing_glue_databases={missing_glue_dbs}")

        for glue_db_name in missing_glue_dbs:
            error_msg = (
                f"Data Federation validation failed: Glue database '{glue_db_name}' does not exist in "
                f"source account '{account_id}' for file '{file_name}'. Please verify the Data Federation "
                f"aws_account_id and ensure the source Glue database exists before provisioning Data Federation."
            )
            errors.append(error_msg)
            logger.error(error_msg)

        return errors


    # RESOURCE POLICY VALIDATION
    if resource_type.lower() == "resource_policy":

        access = data.get("access_to_resources", {})

        # S3
        for prefix in access.get("s3_prefixes", []) or []:
            parts = prefix.split("/")
            bucket_name = parts[2] if len(parts) > 2 else None

            if bucket_name:
                existing_buckets = existing_resources.get(account_id, {}).get("s3", [])
                if bucket_name not in existing_buckets:
                    error_msg = f"In {file_name}, S3 bucket '{bucket_name}' not found in account '{account_id}' or not even included in the current PR."
                    errors.append(error_msg)
                    logger.error(error_msg)

        # Glue DB
        for glue_db in access.get("glue_databases", []) or []:
            glue_db = glue_db.strip()
            glue_db_name = glue_db.split(":", 1)[1].strip() if ":" in glue_db else glue_db

            existing_glue_dbs = existing_resources.get(account_id, {}).get("glue_db", [])
            if glue_db_name not in existing_glue_dbs:
                error_msg = f"In {file_name}, Glue DB '{glue_db_name}' not found in account '{account_id}' or not even included in the current PR."
                errors.append(error_msg)
                logger.error(error_msg)

        return errors

    return errors

def find_config_file(base_path: str) -> str | None:
    """
    Check for .json, .yaml, and .yml file extensions and return the first match.
    Priority: JSON > YAML
    """
    for ext in [".json", ".yaml", ".yml"]:
        path = base_path + ext
        if os.path.exists(path):
            return path
    return None


def load_config_file(file_path: str) -> dict | None:
    """
    Load JSON or YAML config file.
    """
    try:
        if file_path.endswith(".json"):
            with open(file_path, "r") as f:
                return json.load(f)
        else:
            return load_yaml(file_path)  # assuming this function already exists
    except Exception as e:
        logger.error(f"Failed to load config file {file_path}: {e}")
        return None

def analyze_iam_access(
    data: dict,
    validation_details: dict,
    glue_db_files_folder: str,
    account_ids_map: dict
) -> dict:
    """
    Analyze IAM access to identify cross enterprise/functional subgroup access.
    """
    glue_db_access = data.get("access_to_resources", {}).get("glue_databases", {})
    glue_dbs = glue_db_access.get("write", []) + glue_db_access.get("read", [])

    iam_enterprise_or_func_subgrp_name = data.get("enterprise_or_func_subgrp_name", "")
    result_of_cross_subgroup_access = {}

    if glue_dbs and glue_db_files_folder:
        for glue_db in glue_dbs:

            # Parse glue_db input
            if isinstance(glue_db, dict):
                account_id = str(list(glue_db.keys())[0]).strip()
                glue_db_name = glue_db[account_id].strip()

                if glue_db_name.endswith("_rl"):
                    glue_db_name = glue_db_name[:-3]

            elif isinstance(glue_db, str):
                if ":" in glue_db:
                    account_id, glue_db_name = glue_db.split(":")
                    account_id = str(account_id).strip()
                    glue_db_name = glue_db_name.strip()

                    if glue_db_name.endswith("_rl"):
                        glue_db_name = glue_db_name[:-3]
                else:
                    glue_db_name = glue_db.strip()

                    if glue_db_name.endswith("_rl"):
                        logger.error(
                            f"Invalid format for Resource Linked Glue DB: {glue_db}. "
                            f"Expected format: <account_id>:<db_name_rl>"
                        )
                        continue

                    account_id = str(data.get("aws_account_id", "")).strip()
            else:
                logger.error(f"Invalid glue_db format: {glue_db}. Expected string or dict.")
                continue

            # Account validation
            account_name = account_ids_map.get(account_id)

            if not account_name:
                logger.info(
                    f"Account ID {account_id} not found. Skipping Glue DB: {glue_db_name}."
                )

                msg_key = "cross_env_RL_DBs"

                if msg_key not in result_of_cross_subgroup_access:
                    result_of_cross_subgroup_access[msg_key] = [list(), list()]

                result_of_cross_subgroup_access[msg_key][0].append(f"{account_id}:{glue_db_name}")
                result_of_cross_subgroup_access[msg_key][1].append(f"{glue_db_name}_rl")
                continue

            # File lookup
            base_path = os.path.join(
                glue_db_files_folder,
                account_name,
                "glue_db",
                glue_db_name
            )

            glue_db_file_path = find_config_file(base_path)

            if not glue_db_file_path:
                logger.warning(
                    f"No config file (.json/.yaml/.yml) found for Glue DB: {glue_db_name}. "
                    f"Expected at: {base_path}"
                )
                continue

            glue_db_data = load_config_file(glue_db_file_path)

            if not glue_db_data:
                logger.warning(
                    f"Could not load data from {glue_db_file_path} for Glue DB: {glue_db_name}."
                )
                continue

            # Cross subgroup check
            glue_db_subgrp = glue_db_data.get("enterprise_or_func_subgrp_name", "")

            if (
                glue_db_subgrp
                and iam_enterprise_or_func_subgrp_name
                and glue_db_subgrp != iam_enterprise_or_func_subgrp_name
            ):
                if glue_db_subgrp not in result_of_cross_subgroup_access:
                    result_of_cross_subgroup_access[glue_db_subgrp] = [glue_db_name]
                else:
                    result_of_cross_subgroup_access[glue_db_subgrp].append(glue_db_name)

    return result_of_cross_subgroup_access if result_of_cross_subgroup_access else None

def show_cross_subgroup_access_warning(file_path: str, cross_subgroup_access_analysis: dict, python_constants: dict):
    if cross_subgroup_access_analysis:
        MinervaGovernance_repo_link = python_constants.get(
            "MinervaGovernance_repo_link",
            "https://git.cglcloud.com/Minerva/minerva-governance/tree/dev/delegate%20access%20repo"
        )
        if "cross_env_RL_DBs" in cross_subgroup_access_analysis:
            # If only cross env RL DBs available
            if len(cross_subgroup_access_analysis) == 1:
                logger.warning(
                    f"\n[USER ACTION REQUIRED] – DATA OWNER APPROVAL REQUIRED FOR CROSS-ENVIRONMENT DB ACCESS\n\n"
                    f"The IAM role:\n"
                    f"{file_path}\n\n"
                    f"is attempting to access federated databases from an account of different environment.\n"
                    f"If the source database belongs to a different Enterprise / Function / Subgroup,\n"
                    f"data owner approval is mandatory before provisioning.\n\n"
                    f"Identified cross-env-account / federated DB resources requiring your evaluation and subsequent approval in case of different Enterprise/Function/Subgroup:\n"
                    f"- Source DBs : {', '.join(cross_subgroup_access_analysis.get('cross_env_RL_DBs', [])[0])}\n"
                    f"- Target DBs: {', '.join(cross_subgroup_access_analysis.get('cross_env_RL_DBs', [])[1])}\n\n"
                    f"Please attach approval from the respective data or resource owners to the PR.\n\n"
                    f"Refer to Governance repository for owner and delegate details:\n"
                    f"{MinervaGovernance_repo_link}\n\n"
                    f"⚠️ Any violation identified during access control audits will require the requesting team to formally justify why approvals were not secured prior to access provisioning."
                )
            else:
                # message for hybrid (both cross_env_RL_DBs and same environment)
                cross_env_RL_DBs = cross_subgroup_access_analysis.get('cross_env_RL_DBs', [[], []])
                # removing cross_env_RL_DBs from cross_subgroup_access_analysis to avoid duplication
                cross_subgroup_access_analysis.pop('cross_env_RL_DBs', None)
                # db_details of same environment cross subgroup access
                db_details = "\n".join(
                    f"{subgrp} : {', '.join(DBs)}"
                    for subgrp, DBs in cross_subgroup_access_analysis.items()
                )
                logger.warning(
                    f"\n[USER ACTION REQUIRED] – DATA OWNER APPROVAL REQUIRED FOR CROSS-ENVIRONMENT DB ACCESS AND CROSS Enterprise/Function/Subgroup DB ACCESS on SAME-ENVIRONMENT\n\n"
                    f"The IAM role:\n{file_path}\n\n"
                    f"is attempting to access federated databases from an account of different environment and cross Enterprise/Function/Subgroup on same environment.\n"
                    f"If the source database belongs to a different Enterprise / Function / Subgroup,\n"
                    f"data owner approval is mandatory before provisioning.\n\n"
                    f"Identified cross-env-account / federated DB resources requiring your evaluation and subsequent approval in case of different Enterprise/Function/Subgroup:\n"
                    f"- Source DBs : {', '.join(cross_env_RL_DBs[0])}\n"
                    f"- Target DBs: {', '.join(cross_env_RL_DBs[1])}\n\n"
                    f"Identified databases that belong to different Enterprise / Function / Subgroups on same environment:\n"
                    f"{db_details}\n\n"
                    f"Please attach approval from the respective data or resource owners to the PR.\n\n"
                    f"Refer to Governance repository for owner and delegate details:\n"
                    f"https://git.cglcloud.com/Minerva/minerva-governance/tree/dev/delegate%20access%20repo\n\n"
                    f"⚠️ Any violation identified during access control audits will require the requesting team to formally justify why approvals were not secured prior to access provisioning."
                )
        else:
            # only same environment warning
            db_details = "\n".join(
                f"{subgrp} : {', '.join(DBs)}"
                for subgrp, DBs in cross_subgroup_access_analysis.items()
            )

            logger.warning(
                f"\n[USER ACTION REQUIRED] – DATA OWNER APPROVAL REQUIRED FOR CROSS Enterprise/Function/Subgroup DB ACCESS\n\n"
                f"The IAM role:\n{file_path}\n\n"
                f"is requesting access to databases that belong to different Enterprise / Function / Subgroups.\n\n"
                f"Databases requiring approval:\n"
                f"{db_details}\n\n"
                f"As mandated by Minerva Governance policy, explicit approval from the respective database owner must be attached to the PR before provisioning can continue.\n\n"
                f"Refer to the Governance repository to identify approvers:\n"
                f"{MinervaGovernance_repo_link}\n\n"
                f"⚠️ Any violation identified during access control audits will require the requesting team to formally justify why approvals were not secured prior to access provisioning."
            )
    else:
        logger.info(
            f"No cross Ent/Func subgroup access found for IAM Role in {file_path.split('/')[-1]}. No data owner approval required for cross subgroup access."
        )

def show_glue_db_creation_warning(file_path: str, data: dict, python_constants: dict):
    MinervaGovernance_repo_link = python_constants.get("MinervaGovernance_repo_link", "https://git.cglcloud.com/Minerva/minerva-governance/tree/dev/delegate%20access%20repo")
    logger.warning(
        f"\n[USER ACTION REQUIRED] – DATA OWNER APPROVAL REQUIRED FOR DATABASE CREATION\n\n"
        f"The Glue database defined at:\n"
        f"{file_path}\n\n"
        f"(Enterprise/Function: {data.get('enterprise_or_func_name', '')}, Subgroup: {data.get('enterprise_or_func_subgrp_name', '')})\n\n"
        f"must be approved by the respective Data Owner or an authorized delegate before provisioning can proceed.\n\n"
        f"Approval must be attached to the PR as per Minerva Governance policy.\n"
        f"Data owners and delegates can be identified in the Governance repository:\n"
        f"{MinervaGovernance_repo_link}\n\n"
        f"⚠️ This approval is mandatory."
    )


def validate_ascii_json(json_data: str, file_name: str) -> None:
    """
    Validates that the provided JSON text is strictly ASCII-compliant
    AFTER decoding escape sequences.
    """

    # Step 1: Convert back to string with real characters
    normalized_text = json.dumps(json_data, ensure_ascii=False)

    # Step 2: Validate characters
    for idx, ch in enumerate(normalized_text):
        if ord(ch) > 0x7F:
            raise ValueError(
                f"Non-ASCII character detected in {file_name} at position {idx}: "
                f"'{ch}' (U+{ord(ch):04X}). "
                "Only ASCII characters are allowed. "
                "Example: use '-' (U+002D) instead of '–' (U+2013)."
            )

