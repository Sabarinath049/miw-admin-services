import os
import logging
import boto3
from datetime import datetime
from constants import LOGGING_LEVEL, LOG_FOLDER


class CloudWatchDebugHandler(logging.Handler):
	def __init__(self, log_group: str, log_stream: str, region: str, formatter: logging.Formatter):
		super().__init__(level=logging.DEBUG)
		self.log_group = log_group
		self.log_stream = log_stream
		self.client = boto3.client("logs", region_name=region) if region else boto3.client("logs")
		self.sequence_token = None
		self.addFilter(lambda record: record.levelno == logging.DEBUG)
		self.setFormatter(formatter)
		self._ensure_log_group_and_stream()

	def _ensure_log_group_and_stream(self):
		try:
			self.client.create_log_group(logGroupName=self.log_group)
		except self.client.exceptions.ResourceAlreadyExistsException:
			pass
		except Exception:
			pass

		try:
			self.client.create_log_stream(logGroupName=self.log_group, logStreamName=self.log_stream)
		except self.client.exceptions.ResourceAlreadyExistsException:
			pass
		except Exception:
			pass

		try:
			response = self.client.describe_log_streams(
				logGroupName=self.log_group,
				logStreamNamePrefix=self.log_stream,
				limit=1,
			)
			for stream in response.get("logStreams", []):
				if stream.get("logStreamName") == self.log_stream:
					self.sequence_token = stream.get("uploadSequenceToken")
					break
		except Exception:
			pass

	def _put_event(self, event):
		kwargs = {
			"logGroupName": self.log_group,
			"logStreamName": self.log_stream,
			"logEvents": [event],
		}
		if self.sequence_token:
			kwargs["sequenceToken"] = self.sequence_token
		response = self.client.put_log_events(**kwargs)
		self.sequence_token = response.get("nextSequenceToken")

	def emit(self, record):
		try:
			message = self.format(record)
			event = {
				"timestamp": int(record.created * 1000),
				"message": message,
			}
			self._put_event(event)
		except self.client.exceptions.InvalidSequenceTokenException:
			try:
				self._ensure_log_group_and_stream()
				self._put_event(event)
			except Exception:
				self.handleError(record)
		except Exception:
			self.handleError(record)

# Create logger
logger = logging.getLogger("dtd-miw-automated-provisioning")
logger.setLevel(logging.DEBUG)

# Ensure log folder exists
os.makedirs(LOG_FOLDER, exist_ok=True)

# Timestamped log file names
timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
log_format = '%(asctime)s - %(name)s - %(filename)s - %(levelname)s - %(message)s'

# === MAIN LOG FILE (All logs) ===
main_log_path = os.path.join(LOG_FOLDER, f'{timestamp}.log')
file_handler = logging.FileHandler(main_log_path)
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(logging.Formatter(log_format))

# === DEBUG LOG FILE (Only DEBUG statements) ===
debug_log_path = os.path.join(LOG_FOLDER, f'{timestamp}_debug.log')
debug_file_handler = logging.FileHandler(debug_log_path)
debug_file_handler.setLevel(logging.DEBUG)
debug_file_handler.addFilter(lambda record: record.levelno == logging.DEBUG)
debug_file_handler.setFormatter(logging.Formatter(log_format))

# === ERROR LOG FILE (Only errors) ===
error_log_path = os.path.join(LOG_FOLDER, f'{timestamp}_error.log')
error_file_handler = logging.FileHandler(error_log_path)
error_file_handler.setLevel(logging.ERROR)
error_file_handler.addFilter(lambda record: record.levelno >= logging.ERROR)
error_file_handler.setFormatter(logging.Formatter(log_format))

# === WARNING LOG FILE (Only warnings) ===
warning_log_path = os.path.join(LOG_FOLDER, f'{timestamp}_warning.log')
warning_file_handler = logging.FileHandler(warning_log_path)
warning_file_handler.setLevel(logging.WARNING)
warning_file_handler.addFilter(lambda record: record.levelno == logging.WARNING)
warning_file_handler.setFormatter(logging.Formatter(log_format))

# === CONSOLE OUTPUT ===
stream_handler = logging.StreamHandler()
stream_handler.setLevel(os.getenv("CONSOLE_LOG_LEVEL", "INFO"))
stream_handler.setFormatter(logging.Formatter(log_format))

# === CLOUDWATCH OUTPUT (DEBUG only) ===
cloudwatch_debug_enabled = os.getenv("DEBUG_CLOUDWATCH_ENABLED", "true").lower() == "true"
cloudwatch_region = os.getenv("AWS_REGION", os.getenv("AWS_DEFAULT_REGION", ""))
cloudwatch_log_group = os.getenv(
	"DEBUG_CW_LOG_GROUP",
	f"/aws/codebuild/{os.getenv('CODEBUILD_PROJECT_NAME', 'miw-admin-services')}/debug"
)
cloudwatch_log_stream = os.getenv(
	"DEBUG_CW_LOG_STREAM",
	os.getenv("CODEBUILD_BUILD_ID", f"local-{timestamp}")
)
# CloudWatch log stream names cannot contain colons or asterisks
cloudwatch_log_stream = cloudwatch_log_stream.replace(":", "-").replace("*", "-")

# Add all handlers
logger.addHandler(file_handler)
logger.addHandler(debug_file_handler)
logger.addHandler(error_file_handler)
logger.addHandler(warning_file_handler)
logger.addHandler(stream_handler)

if cloudwatch_debug_enabled:
	try:
		cloudwatch_debug_handler = CloudWatchDebugHandler(
			cloudwatch_log_group,
			cloudwatch_log_stream,
			cloudwatch_region,
			logging.Formatter(log_format),
		)
		logger.addHandler(cloudwatch_debug_handler)
	except Exception:
		logger.warning("Unable to initialize CloudWatch debug log handler; continuing with file logs only.")
