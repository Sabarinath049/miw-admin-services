import os
import shutil
from pathlib import Path
import sys


def prepare_unified_view(base_dir, head_dir, changed_files, output_dir):
    base_dir = Path(base_dir).resolve()
    head_dir = Path(head_dir).resolve()
    output_dir = Path(output_dir).resolve()

    # Step 1: Copy everything from base to output
    if not output_dir.exists():
        raise Exception(f"{output_dir} doesn't exist!!")

    # Step 2: Overlay changed files from head into output
    for rel_path in changed_files:
        print(f"rel_path : {rel_path}")
        src = head_dir / rel_path
        dst = output_dir / rel_path
        if src.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            print(f"Copied files from {src} to {dst}")
        else:
            print(f"⚠️ Skipping missing file: {src}")

    print(f"✅ Unified view created at: {output_dir}")

def check_files_for_diff(git_file_diff :str):
    if git_file_diff is None:
        git_file_diff=[]
    else:
        git_file_diff=git_file_diff.split()

    ## remove files other than .json, .yaml, .yml
    modify_git_file_diff=[]
    for file in git_file_diff:
        if file.lower().endswith('.json') or file.lower().endswith('.yaml') or file.lower().endswith('.yml'):
            modify_git_file_diff.append(file)
    return modify_git_file_diff

# ======= Example Usage =======
# Paths to local directories and diff file
base_dir = sys.argv[1]
head_dir =  sys.argv[2]
diff_file_path = sys.argv[3]
with open(diff_file_path) as f:
    diff_file = f.read()
print(f"base_dir : {base_dir}")
print(f"head_dir : {head_dir}")
print(f"diff_file : {diff_file}")
changed_files=check_files_for_diff(diff_file)
print(f"changed_files : {str(changed_files)}")



prepare_unified_view(base_dir, head_dir, changed_files, base_dir) 