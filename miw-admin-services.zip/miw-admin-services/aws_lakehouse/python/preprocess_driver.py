import os, sys, time, argparse, json
from datetime import datetime
from helpers.config_log import logger, error_log_path, warning_log_path
from helpers.utils import save_to_file, make_terraform_friendly, load_yaml, filter_by_object_type
from helpers.preprocessor import (
    convert_to_json,
    add_default_values,
    add_tag_values,
    get_lf_data_permissions_data_federation,
    get_resource_links_data_federation,
    is_mandatory_fields_available,
    change_critical_keys,
    get_minerva_lakehouse_validation_details,
    get_reference_json,
    get_policy_jsons,
    get_trust_json,
    is_json_loadable,
    generate_crawler_iam_role,
    generate_s3_service_iam_role,
    get_lf_data_permissions_s3,
    get_lf_data_permissions_glue_db,
    get_account_ids,
    get_relevant_files,
    mapping_s3_buckets,
    get_role_from_role_name,
    inject_rp_principal_arns_to_s3,
    append_file_to_validation_list,
    get_lf_data_permissions_glue_db_resource_policy,
    convert_iam_max_session_duration_to_sec,
    check_file_name_convention,
    check_mandatory_keys_for_tagging,
    get_python_constants,
    add_default_s3_bucket_policy,
    is_data_federation_needed,
    get_data_federation_files,
    filter_context_only_files,
    build_athena_workgroup_data,
    lint_yaml_file
)
from constants import ENV

## This is the resource type position in absolute path of a file. For example: in file aws_lakehouse/lakehouse-001/s3/minerva-src-corp.s3 file. 
##The last folder refers the resource type that we are provisioning.
resource_position_in_path=-2
account_id_pos_in_path=-3

def print_output_jsons(output_folder: str, log_per_file: bool = True) -> str:
    """
    Print all JSON files in the specified output folder.

    :param output_folder: Path to the output folder containing JSON files
    :param log_per_file: If True, log each file individually to avoid CloudWatch 1MB event limit
    :return: Summary string with file count and total size
    """
    file_count = 0
    total_size = 0
    
    for root, _, files in os.walk(output_folder):
        for file in files:
            if file == "validation_details.json" or file == "reference_json.json":
                continue
            if file.endswith(".json"):
                service_type = os.path.basename(root)
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, "r") as f:
                        content = f.read()
                        file_size = len(content)
                        total_size += file_size
                        file_count += 1
                        
                        if log_per_file:
                            logger.debug(f"File: {file_path} (Size: {file_size} characters)\n{content}")
                except Exception as e:
                    logger.error(f"Error reading file {file_path}: {e}")
    
    summary = f"Processed {file_count} JSON files with total size {total_size} characters"
    return summary
    
def main():
    """
    Main function to process YAML files and convert them to JSON.
    """
    script_starttime = time.time()
    logger.info(f"Python script {os.path.basename(__file__)} Script start time : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                
    parser = argparse.ArgumentParser(description="Process YAML files and convert them to JSON.")

    parser.add_argument(
        "--output-folder",
        default=None,
        help="Path to the output folder for JSON files. (Default: 'output_jsons' in the parent dir of cwd)"
    )
    parser.add_argument(
        "--clean-out",
        action="store_true",
        help="Clean the output folder before processing."
    )
    parser.add_argument(
        "--validate",
        action="store_true",
        help="Flag for to do validation stage."
    )
    parser.add_argument(
        "--input-files",
        required=True,
        help="Newline-separated list of input YAML files to process. It's needed only when not validating subgroup."
    )
    parser.add_argument(
        "--input-folder",
        required=False,
        help="Path to the input folder containing YAML files. (Needed only when validating subgroup)"
    )
    parser.add_argument(
        "--get-relevant-files",
        action="store_true",
        help="Flag to get relevant files based on the account_id."
    )

    args = parser.parse_args()

    # ✅ Conditional requirement
    if (args.validate or args.get_relevant_files) and not args.input_folder:
        parser.error("--input-folder is required when --validate or --get-relevant-files is set.")
    if args.get_relevant_files and not args.validate:
        parser.error("--validate is required when --get-relevant-files is set. It's only required for validation stage")

    # If --output-folder not provided, set default to 'output_jsons' in the parent dir of cwd
    if args.output_folder is None:
        cwd_root = os.path.dirname(os.path.abspath(os.getcwd()))
        args.output_folder = os.path.join(cwd_root, "output_jsons")

    # Prepare output folder 
    output_folder = args.output_folder
    if args.clean_out and os.path.exists(output_folder):
        os.system(f"rm -rf {output_folder}")
    os.makedirs(output_folder, exist_ok=True)
    relevant_files = []

    # fetching validation details and reference json from DynamoDB
    validation_details = get_minerva_lakehouse_validation_details()
    # saving the fetched validation details to a file in output folder for reference
    saved_validation_details_path = save_to_file(json.dumps(validation_details, indent=4), os.path.join(output_folder, "validation_details.json"))
    reference_json = get_reference_json()
    saved_reference_json_path = save_to_file(json.dumps(reference_json, indent=4), os.path.join(output_folder, "reference_json.json"))
    account_env_map = get_python_constants(validation_details).get("account_env_map", "")
    account_env_json_path = save_to_file(json.dumps(account_env_map, indent=4), os.path.join(output_folder, "account_env_map.json"))

    ## Get account-ids map with path from DynamoDB and swap actual account ids with resource path names. Eg: swapping 904233109241 with lakehouse-001
    account_ids_map = [item for item in filter_by_object_type(validation_details, "general") if item.get("action") == "python_constants"][0].get("json_structure", {}).get("account_ids_map",{})
    
    if args.validate:
        # files = args.input_files
        try:
            with open(args.input_files, "r") as f:
                files = f.read()
        except Exception as e:
            logger.error(f"Error reading input files: {e}")
            print(f'export AbstractionLayer_Errors_LogFilePath="{error_log_path}"')
            print(f'export AbstractionLayer_Warnings_LogFilePath="{warning_log_path}"')
            sys.exit(1)
        if not files or files.strip() == "":
            logger.error("No input files provided for validation.")
            print(f'export AbstractionLayer_Errors_LogFilePath="{error_log_path}"')
            print(f'export AbstractionLayer_Warnings_LogFilePath="{warning_log_path}"')
            sys.exit(1)
        files_to_be_validated = files.split("\n")
        files_to_be_validated = [os.path.join(args.input_folder, f) if not os.path.isabs(f) else f for f in files_to_be_validated]
        logger.info(f"Validating account id in the files: {files_to_be_validated}")
        account_ids_resources_map = get_account_ids(files_to_be_validated, resource_position_in_path, account_ids_map)
        modified_account_ids = { account_ids_map[key] : list(set(value)) for key, value in account_ids_resources_map.items() if key in account_ids_map}
        logger.debug(f"Modified account ids : {modified_account_ids}")
        product_key_file_content = "\n".join(
            f"{account_ids_map[account_id]}:{account_id}:prerequisites,{','.join(res_type)}" if len(account_ids_map[account_id].split('-')) <= 2 
            else f"{account_ids_map[account_id]}:{account_id}:{','.join(res_type)}" 
            for account_id, res_type in account_ids_resources_map.items()
                                              )
        logger.debug(f"###### Product Key File Content ######\n{product_key_file_content}\n####################################")
        saved_productkey_path = save_to_file(product_key_file_content, os.path.join(output_folder, "product_key.txt"))
        # Printing export statements that need to be set as env variables
        print(f"export TF_VAR_generated_json_dir=\"{output_folder}\"")
        print(f"export PRODUCT_KEY_FILEPATH=\"{saved_productkey_path}\"")
        logger.debug(f"export commands for environment variables printed to console.")

        relevant_files = []
        # Getting relevant files if flag is set
        if args.get_relevant_files:
            if not account_ids_resources_map or len(account_ids_resources_map) == 0:
                logger.error("No aws_account_id found in the validated files.")
                print(f'export AbstractionLayer_Errors_LogFilePath="{error_log_path}"')
                print(f'export AbstractionLayer_Warnings_LogFilePath="{warning_log_path}"')
                sys.exit(1)
            logger.info(f"Fetching relevant files for account_ids: {account_ids_resources_map.keys()}")
            try:
                relevant_files = get_relevant_files(f"{args.input_folder}/aws_lakehouse/", account_ids_resources_map, files_to_be_validated, account_ids_map)
                logger.info(f"Relevant files found: {relevant_files}")
            except:
                print(f'export AbstractionLayer_Errors_LogFilePath="{error_log_path}"')
                print(f'export AbstractionLayer_Warnings_LogFilePath="{warning_log_path}"')
                sys.exit(1)
        
    else:
        # If not validating keys in deploy stage, read account_id from env variable
        account_ids = os.getenv("account_ids").split("\n")
        print(f"export TF_VAR_generated_json_dir=\"{output_folder}\"")
        logger.debug(f"export command for TF_VAR_generated_json_dir environment variable printed to console.")
        modified_account_ids={}
        for i in account_ids:
            # print(f"{i} ", flush=True)
            temp_i=i.split(':')
            # print(f'{i.split(":")[0]} {i.split(":")[-1]}', flush=True)
            modified_account_ids[temp_i[0]]=temp_i[-1].split(',')
        logger.debug(f"Modified account ids : {modified_account_ids}")

    
    # files for Validation Layer
    files_for_validation_layer = []

    # # Initializing lists needed for resource_policy automation for s3
    s3_files = []
    resource_policy_files = {}
    
    # Process each YAML file in the input folder and its subfolders
    logger.info("Starting processing of YAML files...")
    '''
    Changing the files getting logic to solve "Argument list too long" error in case of large number of files and also to filter files based on account_ids env variable which is needed for deploy stage. 
    For validation stage, we will process the files that are passed as input_files argument and get the account_ids from those files to filter the files for deploy stage.
    '''
    # files = args.input_files
    if args.validate:
        try:
            with open(args.input_files, "r") as f:
                files = f.read()
            logger.debug(f"Files read from input_files argument: {files}")
        except Exception as e:
            logger.error(f"Error reading input files: {e}")
            print(f'export AbstractionLayer_Errors_LogFilePath="{error_log_path}"')
            print(f'export AbstractionLayer_Warnings_LogFilePath="{warning_log_path}"')
            sys.exit(1)
    else:
        try:
            with open(args.input_files, "r") as f:
                account_ids = f.read().splitlines()
                files = ""
                account_ids_resources_map = {}
        except Exception as e:
            logger.error(f"Error reading input files: {e}")
            print(f'export AbstractionLayer_Errors_LogFilePath="{error_log_path}"')
            print(f'export AbstractionLayer_Warnings_LogFilePath="{warning_log_path}"')
            sys.exit(1)
        for entry in account_ids:
            account_name = entry.split(':')[0]
            resources = entry.split(':')[2].split(',')
            account_id = entry.split(':')[1]
            account_ids_resources_map[account_id] = resources
            for resource in resources:
                if resource != "prerequisites":
                    found_files = []
                    for ext in ("*.yaml", "*.yml"):
                        found_files.extend(
                            [os.path.join(dp, f) for dp, dn, filenames in os.walk(os.path.join(args.input_folder, "aws_lakehouse", account_name, resource)) for f in filenames if f.endswith(ext[1:])]
                        )
                    if not found_files:
                        if resource in ["data_federation", "resource_policy", "glue_crawler", "athena_workgroup"]:
                            logger.info(f"No YAML files found for resource '{resource}' in {account_name} — skipping.")
                            continue
                        else:
                            logger.error(f"No YAML files found for resource '{resource}' in {account_name}")
                    else:
                        abs_files = [os.path.abspath(f) for f in found_files]
                        logger.info(f"Files found for resource {resource} in {account_name}: {abs_files}")
                        files += "\n" + "\n".join(abs_files)
        logger.debug(f"List of files to be processed in deploy stage based on account_ids env variable: {files}")

    if not files or files.strip() == "":
        logger.error("No input files provided to process.")
        print(f'export AbstractionLayer_Errors_LogFilePath="{error_log_path}"')
        print(f'export AbstractionLayer_Warnings_LogFilePath="{warning_log_path}"')
        sys.exit(1)
    files_to_be_processed = files.strip().split("\n")
    files_to_be_processed = [os.path.join(args.input_folder, f) if not os.path.isabs(f) else f for f in files_to_be_processed]
    
    # Getting list of s3 buckets
    # folder_name_for_S3_files = os.path.join(os.path.dirname(os.path.dirname(args.input_folder)), "s3")
    s3_buckets_map, is_updated_s3_map = mapping_s3_buckets(f"{args.input_folder}/aws_lakehouse/", modified_account_ids.keys()), False
    logger.debug(f"Validating the values of variable {s3_buckets_map=} and {is_updated_s3_map=} ")

    # Getting all accounts data federation files to relevant files if there are any data federation requests found
    if is_data_federation_needed(account_ids_resources_map):
        data_federation_files = get_data_federation_files(f"{args.input_folder}/aws_lakehouse/")
        # Exclude any Data Federation file that is already part of the current
        # run's primary/changed files_to_be_processed set. Without this, a
        # changed Data Federation YAML would ALSO end up in relevant_files
        # (added purely as cross-account context), causing
        # append_file_to_validation_list() to silently drop that file's
        # generated JSON from files_for_validation_layer -- so it would never
        # reach validation_driver.py's existence check. See
        # filter_context_only_files() docstring for full root-cause details.
        context_only_data_federation_files = filter_context_only_files(data_federation_files, files_to_be_processed)
        relevant_files.extend(context_only_data_federation_files)
        relevant_files = list(set(relevant_files))  # remove duplicates if any

    # If relevant_files are there, add those files to the processing list
    if relevant_files:
        files_to_be_processed.extend(relevant_files)
        files_to_be_processed = list(set(files_to_be_processed))  # remove duplicates if any
    
    # commenting out the below code to avoid filtering files based on account_ids
    # files_to_be_processed = [
    #     f for f in files_to_be_processed
    #     if f.split('/')[account_id_pos_in_path] in modified_account_ids.keys() and f.split('/')[resource_position_in_path] in modified_account_ids.get(f.split('/')[account_id_pos_in_path],[])
    # ]

    # logging the files to be processed
    logger.info(f"Files to be processed: {files_to_be_processed}")
    for file in files_to_be_processed:
        # parent dir is the service_type
        root = os.path.dirname(file)
        service_type = os.path.basename(root)
        active_validation_details_for_service = filter_by_object_type(validation_details, service_type)
        if file.endswith(".yml") or file.endswith(".yaml"):
            logger.info(f"Processing file: YAML File {file}")

            lint_errors = lint_yaml_file(file)
            if lint_errors:
                for error in lint_errors:
                    logger.error(f"[LINT] {error}")

                print(f'export AbstractionLayer_Errors_LogFilePath="{error_log_path}"')
                print(f'export AbstractionLayer_Warnings_LogFilePath="{warning_log_path}"')
                sys.exit(1)

            data = load_yaml(file)
            if data is None:
                logger.error(f"Failed to load YAML file: {file}. Skipping this file.")
                continue
            if service_type == "iam":
                role = get_role_from_role_name(data.get("role_name", ""), validation_details)
                if role == "":
                    logger.warning(f"Role not found for IAM Role defined in {file}. Skipping this file.")
                    continue
                # Excluding exceptional roles from processing and automation
                elif role == "procdataengineer" and (
                    data.get("role_name", "") == f"corp_fin_jarvis_{ENV}_procdataengineer"
                    or data.get("role_name", "") == f"fin_jarvis_{ENV}_procdataengineer"
                    or data.get("role_name", "") == f"corp_dtd_mef_sparkhistory_{ENV}_procdataengineer"
                    or data.get("role_name", "") in get_python_constants(validation_details).get("exceptional_roles", [])
                ):
                    logger.info(f"Skipping testing role from our process {data.get('role_name', '')} defined in {file}.")
                    continue
            # Order of actions
            # ['critical_keys', 'default_values', 'tag_mapping', 'mandatory_check']
            action_order = {"critical_keys": 1, "default_values": 2, "tag_mapping": 3, "file_name_convention":  4, "mandatory_check": 5, "mandatory_check_for_tags": 6}
            active_validation_details_for_service.sort(key=lambda x: action_order.get(x.get("action"), 99))
            for detail in active_validation_details_for_service:
                action = detail.get("action")
                if action == "mandatory_check":
                    mandatory_fields = detail.get("json_structure", [])
                    if not is_mandatory_fields_available(data, mandatory_fields):
                        logger.error(f"Failed to process: Mandatory fields are missing in the input YAML {file}.")
                elif action == "default_values":
                    defaults = detail.get("json_structure", {})
                    if defaults and isinstance(defaults, str) and is_json_loadable(defaults):
                        defaults = json.loads(defaults)
                    data = add_default_values(data, defaults)
                elif action == "tag_mapping":
                    default_key_mappings = detail.get("json_structure", {})
                    if default_key_mappings and isinstance(default_key_mappings, str) and is_json_loadable(default_key_mappings):
                        default_key_mappings = json.loads(default_key_mappings)
                    data = add_tag_values(data, default_key_mappings, validation_details)
                elif action == "critical_keys":
                    critical_keys = detail.get("json_structure", {})
                    if critical_keys and isinstance(critical_keys, str) and is_json_loadable(critical_keys):
                        critical_keys = json.loads(critical_keys)
                    data = change_critical_keys(data, critical_keys)
                elif action == "file_name_convention":
                    file_name_convention_key = detail.get("json_structure", {})
                    if file_name_convention_key and isinstance(file_name_convention_key, str) and check_file_name_convention(data, file_name_convention_key, file):
                        logger.info(f"File name convention check passed for file {file} based on key {file_name_convention_key}")
                    else:
                        logger.error(f"File name convention check failed for file {file} based on key {file_name_convention_key}")
                elif action == "mandatory_check_for_tags" and args.validate: 
                    # Checking tag standarision only on validation phase to avoid showing pipeline failure after successful provisioning
                    tag_mandatory_keys = detail.get("json_structure", {})
                    if tag_mandatory_keys:
                        account_type = account_ids_map.get(str(data.get("aws_account_id")).strip()).split("-")[0] # assuming account_id format is like lakehouse-001, where lakehouse is the account type
                        tag_mandatory_check_result = check_mandatory_keys_for_tagging(data, tag_mandatory_keys, validation_details, service_type, account_type)
                        if tag_mandatory_check_result == "Failed":
                            logger.error(f"Unable to validate mandatory tags for {file} due to missing information or invalid values in the YAML. Please check the error logs for more details.")
                        else:
                            if not tag_mandatory_check_result:
                                logger.error(f"Mandatory tags are missing for {file}")

            # converting max_session_duration of iam
            if service_type == "iam":
                data = convert_iam_max_session_duration_to_sec(data)
                if data.get("athena_access_config", {}).get("enable_athena_access", False):
                    try:
                        athena_workgroup_data = build_athena_workgroup_data(data, reference_json, validation_details)
                        # saving the athena workgroup json separately in 'athena_workgroup' folder
                        account_id = account_ids_map.get(str(athena_workgroup_data.get("aws_account_id")).strip())
                        athena_wg_file_path = os.path.join(output_folder, account_id, "athena_workgroup", f"{athena_workgroup_data.get('athena_workgroup_name')}.json")
                        os.makedirs(os.path.dirname(athena_wg_file_path), exist_ok=True)
                        try:
                            saved_path = save_to_file(json.dumps(athena_workgroup_data, indent=4), athena_wg_file_path)
                            files_for_validation_layer = append_file_to_validation_list(files_for_validation_layer, relevant_files, file, saved_path)
                            logger.info(f"Successfully processed and saved Athena Workgroup JSON to {saved_path}")
                        except Exception as e:
                            logger.error(f"Error saving Athena Workgroup JSON for IAM file {file}: {e}")
                    except Exception as e:
                        logger.info(f"Error building Athena workgroup data for IAM file {file}: {e}")
                    

            # Adding default s3 bucket policy
            if service_type == "s3":
                data = add_default_s3_bucket_policy(data, reference_json, validation_details)
                
            json_data = convert_to_json(data)


            # getting account_id for multi-account support
            account_id = account_ids_map.get(str(data.get("aws_account_id")).strip())
            logger.debug(f"Fetched account_id: {account_id}")
            output_file_path = os.path.join(output_folder, account_id, service_type, f"{os.path.splitext(os.path.basename(file))[0]}.json")
            os.makedirs(os.path.dirname(output_file_path), exist_ok=True)
            saved_path = save_to_file(json_data, output_file_path)
            files_for_validation_layer = append_file_to_validation_list(files_for_validation_layer, relevant_files, file, saved_path)
            logger.info(f"Successfully processed and saved JSON to {saved_path}")

            # Handling appending of saved_path for resource_policy automation for s3
            if service_type == "s3":
                s3_files.append(saved_path)
            if service_type == "resource_policy":
                resource_policy_files[account_id] = resource_policy_files.get(account_id, []) + [saved_path]
                lf_permissions_glue_db_resource_policy = get_lf_data_permissions_glue_db_resource_policy(data, reference_json, validation_details)
                if lf_permissions_glue_db_resource_policy:
                    rp_file_path = os.path.join(output_folder, account_id, service_type, "lake_formation", "data_permission_glue_db", f"{os.path.splitext(os.path.basename(file))[0]}.json")
                    os.makedirs(os.path.dirname(rp_file_path), exist_ok=True)
                    saved_path = save_to_file(json.dumps(lf_permissions_glue_db_resource_policy, indent=4), rp_file_path)
                    files_for_validation_layer = append_file_to_validation_list(files_for_validation_layer, relevant_files, file, saved_path)
                    logger.info(f"Successfully processed and saved LF Permissions for Glue DB Resource Policy JSON to {saved_path}")
                
            # handle special case for the services like iam where we need to create policy json and trust relationship json separately
            if service_type == "iam":
                try:
                    logger.info(f"Generating IAM Policy and Trust Relationship for IAM Role defined in {file}")
                    policy_jsons = get_policy_jsons(data, reference_json, validation_details)
                    # saving the mulitple policy jsons separately in iam/policies/role_name/ folder
                    policy_file_folder = os.path.join(output_folder, account_id, service_type, "policy", data.get('role_name', ''))
                    os.makedirs(os.path.dirname(policy_file_folder), exist_ok=True)
                    for policy_name, policy_json in policy_jsons.items():
                        policy_file_path = os.path.join(policy_file_folder, f"{policy_name}.json")
                        os.makedirs(os.path.dirname(policy_file_path), exist_ok=True)
                        saved_path = save_to_file(json.dumps(policy_json, indent=4), policy_file_path)
                        files_for_validation_layer = append_file_to_validation_list(files_for_validation_layer, relevant_files, file, saved_path)
                    logger.info(f"Successfully processed and saved {len(policy_jsons)} IAM Policy JSONs to {policy_file_folder}")
                    trust_json = get_trust_json(data, reference_json, validation_details)
                    trust_json = make_terraform_friendly(trust_json)  # making the json terraform friendly for the time being
                    # saving the trust relationship json separately in 'iam/trust' folder
                    trust_file_path = os.path.join(output_folder, account_id, service_type, "trust", f"{data['role_name']}_trust.json")
                    os.makedirs(os.path.dirname(trust_file_path), exist_ok=True)
                    saved_path = save_to_file(json.dumps(trust_json, indent=4), trust_file_path)
                    files_for_validation_layer = append_file_to_validation_list(files_for_validation_layer, relevant_files, file, saved_path)
                    logger.info(f"Successfully processed and saved IAM Trust Relationship JSON to {saved_path}")
                except Exception as e:
                    logger.error(f"Error generating IAM Policy or Trust Relationship for IAM Role defined in {file}: {e}")

                # data_permission for s3 and glue_db
                try:
                    logger.info(f"Generating LF Data Permissions for IAM Role defined in {file}")
                    role = get_role_from_role_name(data.get("role_name", ""), validation_details)
                    if role == "snfcatalogfed":
                        data_permission_for_s3 = get_lf_data_permissions_s3(data, reference_json)
                        if data_permission_for_s3:
                            dp_s3_file_path = os.path.join(output_folder, account_id, "lake_formation", "data_permission_s3", f"{data['role_name']}.json")
                            os.makedirs(os.path.dirname(dp_s3_file_path), exist_ok=True)
                            saved_path = save_to_file(json.dumps(data_permission_for_s3, indent=4), dp_s3_file_path)
                            files_for_validation_layer = append_file_to_validation_list(files_for_validation_layer, relevant_files, file, saved_path)
                            logger.info(f"Successfully processed and saved LF Data Permission for S3 JSON to {saved_path}")
                    data_permission_for_glue_db = get_lf_data_permissions_glue_db(data, reference_json, validation_details)
                    logger.debug(f"LF Data Permissions for Glue DB generated: {data_permission_for_glue_db}")
                    if data_permission_for_glue_db:
                        dp_glue_db_file_path = os.path.join(output_folder, account_id, "lake_formation", "data_permission_glue_db", f"{data['role_name']}.json")
                        os.makedirs(os.path.dirname(dp_glue_db_file_path), exist_ok=True)
                        saved_path = save_to_file(json.dumps(data_permission_for_glue_db, indent=4), dp_glue_db_file_path)
                        files_for_validation_layer = append_file_to_validation_list(files_for_validation_layer, relevant_files, file, saved_path)
                        logger.info(f"Successfully processed and saved LF Data Permission for Glue DB JSON to {saved_path}")
                except Exception as e:
                    logger.error(f"Error generating LF Data Permissions for IAM Role defined in {file}: {e}")
            
            # handle special case for glue_crawler where we need to create a role
            if service_type == "glue_crawler":
                logger.info(f"Generating IAM Role for Glue Crawler defined in {file}")
                iam_role, policy_jsons, trust_json = generate_crawler_iam_role(data, reference_json, validation_details)
                if iam_role:
                    # saving the iam role json separately in 'iam' folder
                    role_file_path = os.path.join(output_folder, account_id, "iam", f"{iam_role['role_name']}.json")
                    os.makedirs(os.path.dirname(role_file_path), exist_ok=True)
                    saved_path = save_to_file(json.dumps(iam_role, indent=4), role_file_path)
                    files_for_validation_layer = append_file_to_validation_list(files_for_validation_layer, relevant_files, file, saved_path)
                    logger.info(f"Successfully processed and saved IAM Role JSON to {saved_path}")
                    # Saving the policy jsons separately in 'iam/policy/role_name/' folder
                    policy_file_folder = os.path.join(output_folder, account_id, "iam", "policy", iam_role['role_name'])
                    os.makedirs(os.path.dirname(policy_file_folder), exist_ok=True)
                    for policy_name, policy_json in policy_jsons.items():
                        policy_file_path = os.path.join(policy_file_folder, f"{policy_name}.json")
                        os.makedirs(os.path.dirname(policy_file_path), exist_ok=True)
                        saved_path = save_to_file(json.dumps(policy_json, indent=4), policy_file_path)
                        files_for_validation_layer = append_file_to_validation_list(files_for_validation_layer, relevant_files, file, saved_path)
                    logger.info(f"Successfully processed and saved {len(policy_jsons)} IAM Policy JSONs to {policy_file_folder}")
                    trust_json = make_terraform_friendly(trust_json)  # making the json terraform friendly for the time being
                    # saving the trust relationship json separately in 'iam/trust' folder
                    trust_file_path = os.path.join(output_folder, account_id, "iam", "trust", f"{iam_role['role_name']}_trust.json")
                    os.makedirs(os.path.dirname(trust_file_path), exist_ok=True)
                    saved_path = save_to_file(json.dumps(trust_json, indent=4), trust_file_path)
                    files_for_validation_layer = append_file_to_validation_list(files_for_validation_layer, relevant_files, file, saved_path)
                    logger.info(f"Successfully processed and saved IAM Trust Relationship JSON to {saved_path}")
                    logger.info(f"Generated IAM Role, Policy and Trust JSON for Glue Crawler defined in {file}")
                else:
                    logger.error(f"Failed to generate IAM Role, Policy or Trust JSON for Glue Crawler defined in {file}")
            
            if service_type == "data_federation":
                logger.info(f"Processing data federation for Glue databases defined in {file}")
                # lake formation permissions for data federation
                lake_formation_permissions = get_lf_data_permissions_data_federation(data, reference_json, validation_details)
                lf_permissions_path = os.path.join(output_folder, account_id, "data_federation", "lake_formation", f"{os.path.splitext(os.path.basename(file))[0]}.json")
                os.makedirs(os.path.dirname(lf_permissions_path), exist_ok=True)
                saved_path = save_to_file(json.dumps(lake_formation_permissions, indent=4), lf_permissions_path)
                files_for_validation_layer = append_file_to_validation_list(files_for_validation_layer, relevant_files, file, saved_path)
                logger.info(f"Successfully processed and saved LF Data Permissions for Data Federation JSON to {saved_path}")
                # lake formation resource links for data federation
                lake_formation_resource_links = get_resource_links_data_federation(data, reference_json, validation_details)
                for cross_account_aws_id in data.get("cross_account_aws_ids", []):
                    cross_account_aws_id = account_ids_map.get(str(cross_account_aws_id).strip())
                    lf_resource_links_path = os.path.join(output_folder, str(cross_account_aws_id), "data_federation", "resource_links", f"{os.path.splitext(os.path.basename(file))[0]}.json")
                    os.makedirs(os.path.dirname(lf_resource_links_path), exist_ok=True)
                    saved_path = save_to_file(json.dumps(lake_formation_resource_links, indent=4), lf_resource_links_path)
                    files_for_validation_layer = append_file_to_validation_list(files_for_validation_layer, relevant_files, file, saved_path)
                    logger.info(f"Successfully processed and saved LF Resource Links for Data Federation JSON to {saved_path}")

            # handle special case for the services like s3 where we need to create a service-role
            if service_type == "s3":
                logger.info(f"Adding new s3 bucket to the list")
                bucket_name = data.get("bucket_name")
                s3_account_id = account_ids_map.get(str(data.get("aws_account_id")).strip(),"")
                s3_buckets_for_account = s3_buckets_map.get(s3_account_id, [])
                if s3_buckets_for_account is not None:
                    if bucket_name and bucket_name not in s3_buckets_for_account:
                        s3_buckets_for_account.append(bucket_name)
                        is_updated_s3_map = True
                else:
                    s3_buckets_map[s3_account_id] = [bucket_name]
                    is_updated_s3_map = True
                logger.debug(f"Updated s3 buckets map: {s3_buckets_map}")

    # # Ingesting principal arns from resource_policy_files to matching s3 buckets
    if s3_files and resource_policy_files:
        inject_rp_principal_arns_to_s3(resource_policy_files, s3_files, reference_json, validation_details)
    
    # Creating S3 Service IAM Role
    if s3_buckets_map:
        logger.info(f"Generating IAM Role for S3 Service with buckets: {s3_buckets_map}")
        for s3_account_id, s3_buckets in s3_buckets_map.items():
            update_account_id=""
            for key,value in account_ids_map.items():
                if value.strip()==s3_account_id.strip():
                    update_account_id=key
                else:
                    update_account_id=s3_account_id
            iam_role, policy_jsons, trust_json = generate_s3_service_iam_role(update_account_id, s3_buckets, reference_json, validation_details)
            if iam_role and policy_jsons and trust_json:
                # saving the iam role json separately in 'iam' folder
                role_file_path = os.path.join(output_folder, s3_account_id, "iam", f"{iam_role['role_name']}.json")
                os.makedirs(os.path.dirname(role_file_path), exist_ok=True)
                saved_path = save_to_file(json.dumps(iam_role, indent=4), role_file_path)
                if is_updated_s3_map:
                    files_for_validation_layer = append_file_to_validation_list(files_for_validation_layer, relevant_files, "", saved_path)
                logger.info(f"Successfully processed and saved IAM Role JSON to {saved_path}")
                # Saving the policy jsons separately in 'iam/policy/role_name/' folder
                policy_file_folder = os.path.join(output_folder, s3_account_id, "iam", "policy", iam_role['role_name'])
                os.makedirs(os.path.dirname(policy_file_folder), exist_ok=True)
                for policy_name, policy_json in policy_jsons.items():
                    policy_file_path = os.path.join(policy_file_folder, f"{policy_name}.json")
                    os.makedirs(os.path.dirname(policy_file_path), exist_ok=True)
                    saved_path = save_to_file(json.dumps(policy_json, indent=4), policy_file_path)
                    if is_updated_s3_map:
                        files_for_validation_layer = append_file_to_validation_list(files_for_validation_layer, relevant_files, "", saved_path)
                logger.info(f"Successfully processed and saved {len(policy_jsons)} IAM Policy JSONs to {policy_file_folder}")
                # saving the trust relationship json separately in 'iam/trust' folder
                trust_file_path = os.path.join(output_folder, s3_account_id, "iam", "trust", f"{iam_role['role_name']}_trust.json")
                os.makedirs(os.path.dirname(trust_file_path), exist_ok=True)
                saved_path = save_to_file(json.dumps(trust_json, indent=4), trust_file_path)
                if is_updated_s3_map:
                    files_for_validation_layer = append_file_to_validation_list(files_for_validation_layer, relevant_files, "", saved_path)
                logger.info(f"Successfully processed and saved IAM Trust Relationship JSON to {saved_path}")
                logger.info(f"Generated IAM Role, Policy and Trust JSON for S3 Service for account {s3_account_id}")
            else:
                logger.error(f"Failed to generate IAM Role, Policy or Trust JSON for S3 Service for account {s3_account_id}")
                print(f'export AbstractionLayer_Errors_LogFilePath="{error_log_path}"')
                print(f'export AbstractionLayer_Warnings_LogFilePath="{warning_log_path}"')
                sys.exit(1)
    else:
        logger.warning(f"No S3 buckets found to generate S3 Service IAM Role")

    # exporting the files needed for validation layer as line separated and validation details json file path
    files_for_validation_layer = "\n".join(files_for_validation_layer)
    # logger.debug(f"Files for validation layer:\n{files_for_validation_layer}")
    # logger.debug(f"Validation details file path: {saved_validation_details_path}")

    validation_files_path = os.path.join(output_folder, "validation_files.txt")
    saved_validation_files_path = save_to_file(files_for_validation_layer, validation_files_path)
    logger.debug(f"Saved files for validation layer to {saved_validation_files_path}")
    print(f'export VALIDATION_DETAILS_FILEPATH="{saved_validation_details_path}"')
    print(f'export REFERENCE_JSON_FILEPATH="{saved_reference_json_path}"')
    print(f'export TF_VAR_ACCOUNT_ENV_MAP_FILEPATH="{account_env_json_path}"')

    
    logger.debug("##############################################################################################################")
    logger.debug("All files processed. Printing output JSON files:")
    logger.debug(print_output_jsons(output_folder))
    logger.debug("##############################################################################################################")

    # Calculate and log total runtime
    logger.info(f"Script {os.path.basename(__file__)} end time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    script_endtime = time.time()  # Record the end time
    total_runtime = script_endtime - script_starttime  # Calculate runtime
    logger.info(f"Total runtime of script {os.path.basename(__file__)}: {total_runtime:.2f} seconds")
    
    # exporting error and warning log file paths
    print(f'export AbstractionLayer_Errors_LogFilePath="{error_log_path}"')
    print(f'export AbstractionLayer_Warnings_LogFilePath="{warning_log_path}"')

if __name__ == "__main__":
    main()
