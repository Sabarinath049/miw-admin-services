import os
import sys,json, time
from pathlib import Path
from helpers.utils import (
    load_yaml,
    filter_by_object_type,
    replace_placeholders
)
from helpers.validator import (
    validate_resources_existence,
    analyze_iam_access,
    show_cross_subgroup_access_warning,
    show_glue_db_creation_warning,
    validate_ascii_json
)
from helpers.config_log import logger, error_log_path, warning_log_path
from datetime import datetime
import argparse


import re


def run_validation_framework(files_for_validation_layer: str, args: argparse.Namespace) -> int:
    file_paths = [path.strip() for path in files_for_validation_layer.split("\n") if path.strip()]
    if not file_paths:
        logger.info("Skipping Validation Framework execution as no files were provided.")
        return 0

    framework_root = Path(__file__).resolve().parents[1] / "validationFramework"
    if str(framework_root) not in sys.path:
        sys.path.insert(0, str(framework_root))

    env_value = os.getenv("CODEBUILD_ENV") or os.getenv("ENV") or os.getenv("env")
    if not env_value:
        logger.error(
            "Unable to execute Validation Framework: missing environment value. "
            "Set one of CODEBUILD_ENV, ENV, or env."
        )
        return 2

    try:
        from src.validation_framework.core import validation_wrapper
    except Exception as e:
        logger.error(f"Unable to import Validation Framework wrapper due to error -> {e}")
        return 2

    try:
        output_dir = os.getenv("TF_VAR_generated_json_dir", args.input_folder)
        wrapper_args = [
            "--env",
            env_value,
            "--files",
            *file_paths,
            "--store-txt",
            "--store-csv",
            "--store-summary-table",
            "--enable-pr-checks",
            # "--show-passed",
            # "--show-skipped",
        ]
        if output_dir:
            wrapper_args.extend(["--output-dir", output_dir])
        else:
            logger.warning("No output directory specified for Validation Framework. Defaulting to current directory.")
        return validation_wrapper.main(cli_args=wrapper_args, exit_process=False)
    except Exception as e:
        logger.error(f"Unexpected error while executing Validation Framework -> {e}")
        return 3


def filter_validations_per_resource(validation_details : str,resource_type : list, validations_list : list , python_constants : dict) -> dict:
    """
    Function to retrieve validations per resource type from dynamodb table
    """
    perform_validation = {}
    for i in validations_list:
        json_structure = [item for item in filter_by_object_type(validation_details, resource_type) if item.get("action") == i]
        if len(json_structure)>=1:
            json_structure=json_structure[0].get("json_structure", {})
        else:
            json_structure={}
            logger.warning(f"{i.upper()} is not available for {resource_type}, thus skipping it!!")
        # json_structure=update_values(json_structure, python_constants)
        json_structure=replace_placeholders(json_structure, python_constants)
        perform_validation[i]=json_structure
    return perform_validation

def throw_error(field : str , value : str, errors : list, error_msg: str, mandatory_keys_per_resource : list) -> list:
    """
    Function used to check if the field is as part of Mandatory keys and then throw the error, else skip the errror
    """
    if '.' in field:
        if field.split('.')[0] in mandatory_keys_per_resource:
            errors.append(error_msg)
        elif field.split('.')[0] not in mandatory_keys_per_resource and value is not None:
            errors.append(error_msg)
    else:
        if field in mandatory_keys_per_resource:
            errors.append(error_msg)
        elif field in mandatory_keys_per_resource and value is not None:
            errors.append(error_msg)
    return errors

def apply_all_validations(resource_type : str , data : dict, file_name: str, gov_approved_tags : list, gov_approved_tag_values : dict, python_constants : dict, perform_validations : dict, mandatory_keys_per_resource : dict):
    """
    Function to apply validation rules against input json. The validation rules are fetched from Dynamo DB table.
    """
    errors = []

    logger.debug(f"Input data: {json.dumps(data, indent=2)}")

    for key, value in perform_validations.items():
        for field, check_value in value.items():

            # DynamoDB stores the multiple level items separated by a dot. For eg: access_to_resources.s3_prefixes are stored at 2 levels i..e, "access_to_resources"={"s3_prefixes":[.,.],"databases":[.,.]}
            # The below logic is used to retrive the values from input json by separating the keys using a dot.
            if '.' in field:
                try:
                    actual= ""
                    field_path=field.split('.')
                    temp_var=data.get(field_path[0]).copy() if data.get(field_path[0]) else None
                    for i in range(1, len(field_path)):
                        temp_var = temp_var.get(field_path[1]).copy() if data.get(field_path[1]) else None
                        actual=temp_var
                except Exception as e:
                    error_msg = f"Unable to fetch the attribute {field} from data due to error = {e}"
                    logger.info(error_msg)
                    errors.append(error_msg)
            else:
                actual = data.get(field)
            
            ## Validation rules to be checked
            if key.upper()== "VALUE_VALIDATION":
                logger.debug(f"Validating data against Value check defined in DynamoDB")
                # Value Check                
                logger.debug(f"Validating field '{field}' with value '{actual}' against expected '{check_value}'")

                if isinstance(check_value, list):
                    if str(actual) not in check_value:
                        error_msg = f"In {file_name}, Field '{field}' has invalid value '{actual}'. Expected one of {check_value}."
                        logger.info(error_msg)
                        errors=throw_error(field, actual, errors,error_msg, mandatory_keys_per_resource)

                else:
                    if actual != check_value:
                        error_msg = f"In {file_name}, Field '{field}' must be '{check_value}', but got '{actual}'."
                        logger.info(error_msg)
                        errors=throw_error(field, actual, errors,error_msg, mandatory_keys_per_resource)
                
                logger.debug(f"Validation data against Value check completed")
    
            elif key.upper()== "REGEX_VALIDATION":
                logger.debug(f"Validating data against regular expressions check defined in DynamoDB")
                logger.debug(f"Regex validating field '{field}' with value '{actual}' against pattern '{check_value}'")

                if isinstance(actual, list):
                    for item in actual:
                        if item is None or not re.match(check_value, item):
                            error_msg = f"In {file_name}, Field '{field}' item '{item}' does not match pattern '{check_value}'."
                            logger.info(error_msg)
                            errors=throw_error(field, actual, errors,error_msg, mandatory_keys_per_resource)
                else:
                    if actual is None or not re.match(check_value, actual):
                        error_msg = f"In {file_name}, Field '{field}' value '{actual}' does not match pattern '{check_value}'."
                        logger.info(error_msg)
                        errors=throw_error(field, actual, errors, error_msg, mandatory_keys_per_resource)
                logger.debug(f"Validation data against regular expressions completed")
        
    logger.debug(f"Validating Defined Tags vs Governance Approved tags ")
    # Tag validation to check against governance repo and check if the value tag has empty value
    tags = data.get("tags", {})
    logger.debug(f"Validating tags as per governance approved tags and values: {tags}")
    if isinstance(tags, dict):
        if not tags:
            # If resource is resource_policy or data_federation, then tags can be empty as these are not resources and thus don't have any tags associated with them. Thus skipping the error for these types.
            if resource_type.lower() not in ["resource_policy", "data_federation"]:
                error_msg = f"Tags should not be empty for the file {file_name}"
                logger.info(error_msg)
                errors.append(error_msg)
        for k, v in tags.items():
            if k not in gov_approved_tags and k.strip() not in ["glue:UsageProfile", "Source", "Layer", "UsageType", "Region"]:
                error_msg = f"In {file_name}, Tag '{k}' is not approved by Governance."
                logger.info(error_msg)
                errors.append(error_msg)
            if k in gov_approved_tags and v == "":
                error_msg = f"In {file_name}, Tag '{k}' has empty value."
                logger.info(error_msg)
                errors.append(error_msg)
            elif k in gov_approved_tags :
                if k not in gov_approved_tag_values:
                    logger.info(f"In {file_name}, Governance team didn't set any fixed values for Tag '{k}'.")
                else:
                    if v not in gov_approved_tag_values[k]:
                        error_msg = f"In {file_name}, Tag '{k}' has incorrect value {v}. Approved values by Governance are: {','.join(gov_approved_tag_values[k])}"
                        logger.info(error_msg)
                        errors.append(error_msg)     
    else:
        error_msg=f"In {file_name}, Tags are not of dictionary type. Validate preprocess_driver output to fix this. "
        logger.info(error_msg)
        errors.append(error_msg)

    logger.debug(f"Validation Defined Tags vs Governance Approved tags completed")
    return errors

def validate_file(validation_details : str,file_path : str, resource_type : str, gov_approved_tags : list, gov_approved_tag_values : list, python_constants : dict, mandatory_json_keys: dict, account_ids_map: dict, input_folder_path: str, existing_resources: dict = {}) -> list:
    """
    Function to validate every file as per the validation rules defined
    """
    errors = []

    ## Read json file and validate if the json content is valid using loads
    try:
        if not file_path.endswith(".json"):
            raise Exception(f"{file_path.split('/')[-1]} is not a valid file for validation")
        
        # with open(file_path, 'r') as f:
        #     data=json.load(f)

        with open(file_path, 'r', encoding='utf-8') as f:
            raw_json = f.read()

        # Safe to parse JSON only after validation passes
        data = json.loads(raw_json)

        # ASCII compliance check (fail fast)
        try:           
            validate_ascii_json(data, os.path.basename(file_path))
        except ValueError as e:
            logger.error(str(e))
            errors.append(str(e))

        except ValueError as ve:
            # If you raised ValueError(errors_list), unpack it nicely
            if ve.args and isinstance(ve.args[0], list):
                errors.extend(ve.args[0])
                for msg in ve.args[0]:
                    logger.error(msg)
            else:
                # If you raised ValueError("msg"), keep it
                msg = str(ve)
                errors.append(msg)
                logger.error(msg)

        except Exception as e:
            # Any unexpected bug inside validate_intake_fields should still be surfaced
            msg = f"Unexpected error validating intake fields in {os.path.basename(file_path)}: {e}"
            logger.error(msg)
            errors.append(msg)            

    except Exception as e:
        logger.error(f"Failed to read JSON from {file_path}: {e}")
        return [f"Failed to read JSON: {e}"]

    # Normalize resource_type once up-front so every comparison below (existence
    # check gate, glue_db creation warning, iam cross-subgroup warning,
    # mandatory_keys_per_resource lookup) consistently uses the same
    # lower-cased/stripped value instead of repeating `resource_type.lower()`.
    normalized_resource_type = str(resource_type or "").strip().lower()

    ## Existing check for the resource_type "iam"/"resource_policy"/"data_federation" to check the access_to_resources.glue_databases.write, access_to_resources.glue_databases.read, data_prefixes (or glue_databases for data_federation) against existing resources json file
    if normalized_resource_type in ("iam", "resource_policy", "data_federation") and existing_resources:
        try:
            logger.info(f"Performing existing resource validation for {file_path.split('/')[-1]} as the resource type is {resource_type} and existing resources data is available")
            existence_errors = validate_resources_existence(
                data=data,
                resource_type=normalized_resource_type,
                existing_resources=existing_resources,
                file_name=file_path.split('/')[-1],
                mandatory_json_keys=mandatory_json_keys,
                python_constants=python_constants,
            )
            if existence_errors:
                errors.extend(existence_errors)
        except Exception as e:
            logger.error(f"Error occurred while validating existing resources for {file_path.split('/')[-1]} due to error -> {e}")
            errors.append(f"Error occurred while validating existing resources for {file_path.split('/')[-1]} due to error -> {e}")
    
    # Warning log for Glue DB Creation to get approval from data owner or relevant delegates before creation
    if normalized_resource_type == "glue_db":
        try:
            show_glue_db_creation_warning(file_path, data, python_constants)
        except Exception as e:
            logger.error(f"Error occurred while analyzing glue db creation for {file_path.split('/')[-1]} due to error -> {e}")

    # Warning log for IAM Cross Ent/Func access to get approval from data owner or relevant delegates before creation
    if normalized_resource_type == "iam":
        try:
            cross_subgroup_access_analysis = analyze_iam_access(data, validation_details, input_folder_path, account_ids_map)
            show_cross_subgroup_access_warning(file_path, cross_subgroup_access_analysis, python_constants)
        except Exception as e:
            logger.error(f"Error occurred while analyzing cross subgroup access for {file_path.split('/')[-1]} due to error -> {e}")

    ## get validations with respect to resource type from Dynamodb table
    validations_list = python_constants.get("validations_list", {})
    # Initialize both to safe empty defaults up-front so that when validations_list
    # is empty, the code below doesn't crash with UnboundLocalError (previously
    # perform_validations/mandatory_keys_per_resource were only assigned inside the
    # `else` branch, so an empty validations_list -- even for otherwise-valid dict
    # data -- caused validate_file() to blow up with an unhandled exception instead
    # of gracefully skipping the DynamoDB-driven VALUE_VALIDATION/REGEX_VALIDATION
    # checks).
    perform_validations = {}
    mandatory_keys_per_resource = {}
    if len(validations_list)==0:
        logger.warning("There are no validations list added in python_constants action in DynamoDB table, check and update the dynamoDB table. No validations are performed!!")
    else:
        mandatory_keys_per_resource = next((item.get("json_structure", {}) for item in mandatory_json_keys if item.get("action") == normalized_resource_type),{})
        perform_validations=filter_validations_per_resource(validation_details, resource_type, validations_list, python_constants)

    if not isinstance(data, dict):
        logger.error(f"Unsupported data format in {file_path}: {type(data)}")
        errors.append(f"Data is not formatted as dictionary for file {{file_path.split('/')[-1]}} in resource {resource_type}: {type(data)}")
        return errors

    if len(perform_validations)>0:
        logger.info(f"Starting Validation for {resource_type} in {file_path.split('/')[-1]}")
        errors.extend(apply_all_validations(resource_type, data ,file_path.split('/')[-1], gov_approved_tags, gov_approved_tag_values, python_constants,perform_validations, mandatory_keys_per_resource))

    if errors:
        logger.error(f"Validation failed for {resource_type} in {file_path.split('/')[-1]}:")
        for err in errors:
            logger.error(f"  - {err}")
    else:
        logger.info(f"Validation passed for {resource_type} in {file_path.split('/')[-1]}")

    return errors

def get_gov_approved_tags_and_values(gov_tag_repo: str, tag_abbreviations: str , tag_folder: str, validation_details: str) ->  list:
    """
    Function used to get the list of governance approved tags and their corresponding values from the governance repo
    Returns list of tags and their approved values
    """
    gov_approved_tag=[]
    gov_approved_tag_values={}
    try:
        import os, inspect

        logger.info(f"Executing {inspect.currentframe().f_code.co_name} to fetch Governance approved tags and values")

        # Replace with your target directory path
        tags_folder=os.path.join(gov_tag_repo, tag_folder)

        # List all files in the directory
        file_names = os.listdir(tags_folder)
        only_files = [f for f in file_names if os.path.isfile(os.path.join(tags_folder, f))]

        ## Iterate all the tag files in gov repo and fetch the tag names
        for file_name in only_files:
            __file_name_with_path=os.path.join(tags_folder, file_name)
            __json_tag_file = load_yaml(__file_name_with_path)

            gov_approved_tag.append(__json_tag_file["name"])

        logger.debug(f"Tag keys approved by Governance: {gov_approved_tag}")

        ## Read abbreviations file and fetch the tag values supported by governance
        if tag_abbreviations.endswith(".yml") or tag_abbreviations.endswith(".yaml"):
            file_path = os.path.join(gov_tag_repo, tag_abbreviations)
            # try:
            #     tag_abbreviations = load_yaml(file_path)
            # except Exception as e:
                # logger.info(f"Unable to read the tag abbreviations file {file_path} due to error -> {e}. Thus fetching the tag_abbreviations from MIW DynamoDB table record")
            tag_abbreviations = [item for item in filter_by_object_type(validation_details, "generic") if item.get("action") == "tag_validation"][0].get("json_structure", {})
            
            for tag in gov_approved_tag:
                if tag in tag_abbreviations:
                    gov_approved_tag_values[tag]=tag_abbreviations[tag]
            
            logger.debug(f"Tag values approved by Governance: {gov_approved_tag_values}")
        
        logger.info(f"Successfully executed {inspect.currentframe().f_code.co_name} to fetch Governance approved tags and values")

        return gov_approved_tag, gov_approved_tag_values
    except Exception as e:
        logger.error(f"Unable to fetch tag keys and values from governance repo due to the error -> {e}")
        raise Exception(f"Unable to fetch tag keys and values from governance repo due to the error -> {e}")

def main():
    """
    Main function to trigger all the validations for the json files created
    """
    starttime=datetime.now()
    script_starttime = time.time()  # Record the start time
    logger.info(f"Python script {os.path.basename(__file__)} Script start time : {starttime.strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info("Running validation Cases....")

    parser = argparse.ArgumentParser(description="Process YAML files and convert them to JSON.")

    parser.add_argument(
        "--gov_tag_folder",
        default=None,
        help="Path to the git clone of gov tag repo folder"
    )
    parser.add_argument(
        "--existing_resources_file",
        default=None,
        help="Path to the existing resources JSON file"
    )
    parser.add_argument(
        "--input-folder",
        default=None,
        help="Path to the input folder having all the generated json files for validation"
    )
    parser.add_argument(
        "--run-vf-only",
        action="store_true",
        default=False
    )
    args = parser.parse_args()
   
    output_dir = os.getenv("TF_VAR_generated_json_dir", args.input_folder)
    logger.debug(f"#### Output directory for Validation Framework: {output_dir}")
    files_for_validation_layer_path = os.path.join(output_dir, "validation_files.txt")
    try:
        with open(files_for_validation_layer_path) as f:
            files_for_validation_layer = f.read()
            logger.info(f"Successfully loaded files for validation layer from path {files_for_validation_layer_path}")
    except Exception as e:
        logger.error(f"Unable to read files for validation layer from path {files_for_validation_layer_path} due to error -> {e}")
        files_for_validation_layer = ""
    logger.debug(f"FILES_FOR_VALIDATION_LAYER: {files_for_validation_layer}")
    if not args.run_vf_only:
        validation_details_filepath = os.getenv("VALIDATION_DETAILS_FILEPATH")
        logger.info(f"The dynamodb records are stored at file {validation_details_filepath}")
        try:
            with open(validation_details_filepath) as f:
                validation_details=json.loads(f.read())
                logger.info(f"Successfully loaded validation details file from path {validation_details_filepath}")
        except Exception as e:
            logger.error(f"Unable to read json from validation details file {validation_details_filepath} due to error -> {e}")
        
        # loading the existing resources json file
        try:
            with open(args.existing_resources_file) as f:
                existing_resources=json.loads(f.read())
                logger.info(f"Successfully loaded existing resources file from path {args.existing_resources_file}")
        except Exception as e:
            logger.error(f"Unable to read json from existing resources file {args.existing_resources_file} due to error -> {e}")
            existing_resources={}

        json_structure = [item for item in filter_by_object_type(validation_details, "general") if item.get("action") == "python_constants"][0].get("json_structure", {})
        ## adding aws_account_ids as keys in json_structure
        if json_structure.get("account_ids_map") is None:
            logger.error(f"Can't fetch account_id_map with python_constants action key in DynamoDB table. Fix the DynamoDB table record!!")
        else:
            account_name_account_id_map = {}
            account_ids_map = json_structure.get("account_ids_map", {})
            for account_id, account_name in account_ids_map.items():
                account_name_account_id_map[account_name] = account_id
        
        json_structure["aws_account_ids"]=list(account_ids_map.keys())
        supported_yaml_resource_types=json_structure.get("validation_supported_resources",[])
        # SAFETY NET: the Glue DB existence check for data_federation (verifying that
        # every referenced Glue database actually exists in the source aws_account_id)
        # must always run, even if someone forgets to add "data_federation" to
        # DynamoDB's validation_supported_resources list. We deliberately do NOT mutate
        # supported_yaml_resource_types itself -- that list still fully controls routing
        # to apply_all_validations() and the Validation Framework further below -- we
        # only force-include "data_federation" for the internal existence-check gate.
        existence_check_resource_types = list(supported_yaml_resource_types)
        if "data_federation" not in existence_check_resource_types:
            logger.warning(
                "'data_federation' is missing from DynamoDB's validation_supported_resources list. "
                "Force-enabling it here so the Data Federation Glue DB existence check always runs "
                "regardless of DynamoDB configuration. Please also add 'data_federation' to the "
                "DynamoDB table for clarity."
            )
            existence_check_resource_types.append("data_federation")
        mandatory_json_keys = [item for item in filter_by_object_type(validation_details, "mandatory_check")]
        gov_abbreviations=json_structure.get("abbreviations",None)
        gov_tags = json_structure.get("tags_folder",None)
        gov_tags,gov_values=get_gov_approved_tags_and_values(args.gov_tag_folder, gov_abbreviations, gov_tags, validation_details)
        
        all_errors = []

    if files_for_validation_layer:
        file_paths = files_for_validation_layer.strip().split("\n")
        if not args.run_vf_only:
            # Adding current PR resources to existing resources list to identify the resources which are being created in current PR and thus avoid throwing errors for those resources in case of existing resource validation check in IAM resource type. This is required as the existing resources json file is being fetched before the execution of current PR and thus doesn't have the details of resources being created in current PR.
            for file_path in file_paths:
                resource_type = os.path.basename(os.path.dirname(file_path))
                account_id = account_name_account_id_map.get(str(file_path.split('/')[-3]).strip(), None)
                resource_name = file_path.split('/')[-1].split('.')[0]
                if account_id and resource_type and resource_name:
                    if resource_type.lower() == "glue_db" or resource_type.lower() == "s3" or resource_type.lower() == "glue_crawler":
                        existing_resources.setdefault(account_id, {}).setdefault(resource_type.lower(), []).append(resource_name)
                        
            for file_path in file_paths:
                if "validation_details.json" in file_path:
                    logger.debug(f"Skipping file: {file_path}")
                    continue

                if not os.path.exists(file_path):
                    logger.error(f"File does not exist: {file_path}")
                    continue

                resource_type = os.path.basename(os.path.dirname(file_path))
                if not resource_type:
                    logger.error(f"Could not determine resource type from path: {file_path}")
                    continue

                errors=[]
                if file_path.split('/')[-2] in existence_check_resource_types:
                    errors = validate_file(validation_details, file_path, resource_type, gov_tags, gov_values, json_structure, mandatory_json_keys, account_ids_map, args.input_folder, existing_resources)
                else:
                    logger.info(f"Skipping {file_path.split('/')[-1]} as we don't have any validation supporting this yet!!")
                if errors:
                    all_errors.extend(errors)
    
    if not args.run_vf_only:
        logger.info(f"Python script {os.path.basename(__file__)} Script end time : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        # Calculate and log total runtime
        logger.info(f"Script {os.path.basename(__file__)} end time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        script_endtime = time.time()  # Record the end time
        total_runtime = script_endtime - script_starttime  # Calculate runtime
        logger.info(f"Total runtime of script {os.path.basename(__file__)}: {total_runtime:.2f} seconds")

    # Starting Validation Framework
    validation_framework_start_time = time.time()
    logger.info("Starting Validation Framework execution...")
    # filtering the files for validation framework to have only the validation supported resource types
    if not args.run_vf_only:
        validation_supported_files = []
        for file_path in files_for_validation_layer.strip().split("\n"):
            resource_type = os.path.basename(os.path.dirname(file_path))
            if resource_type in supported_yaml_resource_types:
                validation_supported_files.append(file_path)
            else:
                logger.info(f"Excluding {file_path.split('/')[-1]} from Validation Framework execution as we don't have any validation supporting this yet!!")
        files_for_validation_layer = "\n".join(validation_supported_files)
    validation_framework_exit_code = run_validation_framework(files_for_validation_layer, args)
    validation_framework_end_time = time.time()
    logger.info(
        f"Validation Framework execution completed with exit code {validation_framework_exit_code} "
        f"in {(validation_framework_end_time - validation_framework_start_time):.2f} seconds"
    )
    if validation_framework_exit_code != 0 and args.run_vf_only:
        logger.error("Validation Framework reported failures.")

    validation_failed = False
    if not args.run_vf_only:
        validation_failed = bool(all_errors) or validation_framework_exit_code != 0
        if validation_failed:
            logger.error("Validation failed.")
            logger.error(f"Total validation errors: {len(all_errors)}")
            for err in all_errors:
                logger.error(f"  - {err}")
        else:
            logger.info("Validation successful.")

    # exporting error and warning log file paths
    print(f'export ValidationLayer_Errors_LogFilePath="{error_log_path}"')
    print(f'export ValidationLayer_Warnings_LogFilePath="{warning_log_path}"')

    # Fail the process (non-zero exit) when validation errors exist so the calling
    # shell ("source <(python3 validation_driver.py ...) || exit 1") actually stops
    # the pipeline before Terraform executes. Previously this function never called
    # sys.exit() on validation failures, so all_errors/validation_framework_exit_code
    # were logged but never blocked the build for ANY resource type (iam,
    # resource_policy, data_federation, etc.).
    if validation_failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
