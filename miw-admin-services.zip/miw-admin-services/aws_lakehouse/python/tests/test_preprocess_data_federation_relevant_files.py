"""
Unit tests for the Data Federation "relevant files" root-cause fix in
aws_lakehouse/python/helpers/preprocessor.py.

Background / root cause:
  `get_data_federation_files()` walks the ENTIRE input folder and returns
  EVERY Data Federation YAML file found anywhere -- including the file(s)
  that were actually changed in the current PR -- so that cross-account
  Lake Formation grants/resource-links can be generated with full context.

  preprocess_driver.py then did:
      relevant_files.extend(get_data_federation_files(...))

  Later, `append_file_to_validation_list(files_for_validation, relevant_files,
  input_file, file_to_be_appended)` only appends `file_to_be_appended` when
  `input_file not in relevant_files`. Because the changed Data Federation
  file was ALSO present in `relevant_files` (get_data_federation_files()
  doesn't exclude it), its generated JSON (the primary data_federation JSON,
  Lake Formation permissions JSON, and resource-links JSON) was silently
  excluded from files_for_validation_layer / validation_files.txt.

  As a result, validation_driver.py never received the changed Data
  Federation file, so validate_resources_existence() was never invoked for
  it and no Glue DB existence error was ever raised -- even though the same
  mechanism worked correctly for IAM.

  `filter_context_only_files()` fixes this by excluding any file that is
  already part of the current run's primary/changed files_to_be_processed
  set from being treated as "context only".
"""

import os
import sys
import tempfile
import unittest

os.environ.setdefault("DEBUG_CLOUDWATCH_ENABLED", "false")

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from helpers.preprocessor import (  # noqa: E402
    get_data_federation_files,
    filter_context_only_files,
    append_file_to_validation_list,
)


class TestFilterContextOnlyFiles(unittest.TestCase):

    def test_excludes_files_already_in_processed_set(self):
        already_processed = ["/repo/lakehouse-001/data_federation/changed_df.yaml"]
        candidates = [
            "/repo/lakehouse-001/data_federation/changed_df.yaml",
            "/repo/lakehouse-002/data_federation/other_context_df.yaml",
        ]

        result = filter_context_only_files(candidates, already_processed)

        self.assertEqual(result, ["/repo/lakehouse-002/data_federation/other_context_df.yaml"])

    def test_normalizes_paths_before_comparing(self):
        # Same file referenced via a relative-looking path with redundant
        # separators/segments vs. an absolute path -- both should resolve to
        # the same abspath and therefore be excluded.
        already_processed = [os.path.join("repo", ".", "lakehouse-001", "data_federation", "changed_df.yaml")]
        changed_abspath = os.path.abspath(already_processed[0])
        candidates = [changed_abspath, "/repo/lakehouse-002/data_federation/other_context_df.yaml"]

        result = filter_context_only_files(candidates, already_processed)

        self.assertNotIn(changed_abspath, result)
        self.assertIn("/repo/lakehouse-002/data_federation/other_context_df.yaml", result)

    def test_returns_all_candidates_when_none_already_processed(self):
        already_processed = ["/repo/lakehouse-001/iam/some_role.yaml"]
        candidates = [
            "/repo/lakehouse-001/data_federation/a.yaml",
            "/repo/lakehouse-002/data_federation/b.yaml",
        ]

        result = filter_context_only_files(candidates, already_processed)

        self.assertEqual(sorted(result), sorted(candidates))

    def test_empty_candidates_returns_empty_list(self):
        self.assertEqual(filter_context_only_files([], ["/repo/x/data_federation/a.yaml"]), [])


class TestGetDataFederationFilesIntegration(unittest.TestCase):
    """
    Confirms get_data_federation_files() still finds every Data Federation
    YAML (including the changed one -- that part of its behavior is
    intentional and unchanged), and that combining it with
    filter_context_only_files() correctly leaves only the "other account"
    context files, matching the pattern now used in preprocess_driver.py.
    """

    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.addCleanup(lambda: __import__("shutil").rmtree(self.tmp_dir, ignore_errors=True))

        self.changed_file = os.path.join(self.tmp_dir, "lakehouse-001", "data_federation", "changed_df.yaml")
        self.context_file = os.path.join(self.tmp_dir, "lakehouse-002", "data_federation", "context_df.yaml")
        self.unrelated_file = os.path.join(self.tmp_dir, "lakehouse-001", "iam", "some_role.yaml")

        for path in (self.changed_file, self.context_file, self.unrelated_file):
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w") as f:
                f.write("aws_account_id: '123456789012'\n")

    def test_get_data_federation_files_finds_changed_and_context_files(self):
        found = get_data_federation_files(self.tmp_dir)

        self.assertIn(self.changed_file, found)
        self.assertIn(self.context_file, found)
        self.assertNotIn(self.unrelated_file, found)

    def test_changed_file_is_excluded_after_filtering(self):
        # files_to_be_processed represents the current run's primary/changed
        # files set, computed BEFORE relevant_files gets merged in.
        files_to_be_processed = [self.changed_file]

        data_federation_files = get_data_federation_files(self.tmp_dir)
        context_only = filter_context_only_files(data_federation_files, files_to_be_processed)

        self.assertNotIn(self.changed_file, context_only)
        self.assertIn(self.context_file, context_only)


class TestAppendFileToValidationListWithFix(unittest.TestCase):
    """
    End-to-end reproduction of the actual bug and its fix using
    append_file_to_validation_list(), the same function
    preprocess_driver.py calls to build files_for_validation_layer.
    """

    def test_bug_reproduction_without_fix_drops_changed_file(self):
        # BEFORE the fix: relevant_files contains the changed file too
        # (because get_data_federation_files() doesn't exclude it), so its
        # generated JSON is silently dropped from files_for_validation_layer.
        changed_input_file = "/repo/lakehouse-001/data_federation/changed_df.yaml"
        generated_json_path = "/output/lakehouse-001/data_federation/changed_df.json"
        relevant_files_without_fix = [changed_input_file, "/repo/lakehouse-002/data_federation/context_df.yaml"]

        files_for_validation = []
        files_for_validation = append_file_to_validation_list(
            files_for_validation, relevant_files_without_fix, changed_input_file, generated_json_path
        )

        self.assertNotIn(generated_json_path, files_for_validation)

    def test_fix_keeps_changed_file_in_validation_list(self):
        # AFTER the fix: filter_context_only_files() removes the changed
        # file from relevant_files before it's used, so
        # append_file_to_validation_list() correctly includes the changed
        # file's generated JSON.
        changed_input_file = "/repo/lakehouse-001/data_federation/changed_df.yaml"
        generated_json_path = "/output/lakehouse-001/data_federation/changed_df.json"
        files_to_be_processed = [changed_input_file]
        raw_data_federation_files = [changed_input_file, "/repo/lakehouse-002/data_federation/context_df.yaml"]

        relevant_files = filter_context_only_files(raw_data_federation_files, files_to_be_processed)

        files_for_validation = []
        files_for_validation = append_file_to_validation_list(
            files_for_validation, relevant_files, changed_input_file, generated_json_path
        )

        self.assertIn(generated_json_path, files_for_validation)


if __name__ == "__main__":
    unittest.main()
