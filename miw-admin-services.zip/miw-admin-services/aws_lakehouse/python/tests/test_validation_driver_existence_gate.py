"""
Unit tests confirming validation_driver.validate_file() calls
validate_resources_existence() for the "data_federation" resource type (in
addition to the existing "iam" / "resource_policy" resource types), that the
resulting errors are appended to (not overwritten in) the returned error
list, and that main() actually fails the process when validation errors
exist.
"""

import json
import os
import sys
import tempfile
import unittest
from unittest.mock import patch

# Disable the network-dependent CloudWatch debug log handler during tests so
# importing validation_driver (-> helpers.config_log) doesn't attempt any AWS
# calls in a local/offline test environment.
os.environ.setdefault("DEBUG_CLOUDWATCH_ENABLED", "false")

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import validation_driver  # noqa: E402


class TestValidateFileExistenceGate(unittest.TestCase):

    def _write_json_file(self, data):
        tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False)
        json.dump(data, tmp)
        tmp.close()
        self.addCleanup(os.remove, tmp.name)
        return tmp.name

    # ------------------------------------------------------------------
    # data_federation
    # ------------------------------------------------------------------
    @patch("validation_driver.apply_all_validations", return_value=[])
    @patch("validation_driver.filter_validations_per_resource", return_value={"VALUE_VALIDATION": {}})
    @patch("validation_driver.validate_resources_existence")
    def test_calls_validate_resources_existence_for_data_federation(
        self, mock_validate_existence, mock_filter_validations, mock_apply_all
    ):
        mock_validate_existence.return_value = []

        data = {
            "aws_account_id": "068887784423",
            "glue_databases": ["abc_raw_dev"],
            "tags": {},
        }
        file_path = self._write_json_file(data)

        existing_resources = {"068887784423": {"glue_db": ["abc_raw_dev"]}}
        python_constants = {"validations_list": ["VALUE_VALIDATION"]}

        errors = validation_driver.validate_file(
            validation_details=[],
            file_path=file_path,
            resource_type="data_federation",
            gov_approved_tags=[],
            gov_approved_tag_values={},
            python_constants=python_constants,
            mandatory_json_keys=[],
            account_ids_map={},
            input_folder_path="/tmp",
            existing_resources=existing_resources,
        )

        mock_validate_existence.assert_called_once()
        call_kwargs = mock_validate_existence.call_args.kwargs
        self.assertEqual(call_kwargs["resource_type"], "data_federation")
        self.assertEqual(call_kwargs["existing_resources"], existing_resources)
        self.assertEqual(errors, [])

    @patch("validation_driver.apply_all_validations", return_value=[])
    @patch("validation_driver.filter_validations_per_resource", return_value={"VALUE_VALIDATION": {}})
    @patch("validation_driver.validate_resources_existence")
    def test_data_federation_existence_errors_are_not_dropped(
        self, mock_validate_existence, mock_filter_validations, mock_apply_all
    ):
        mock_validate_existence.return_value = [
            "Data Federation validation failed: Glue database 'wrong_db_name' does not exist "
            "in source account '068887784423' for file 'sample_df.json'. Please verify the "
            "Data Federation aws_account_id and ensure the source Glue database exists before "
            "provisioning Data Federation."
        ]

        data = {
            "aws_account_id": "068887784423",
            "glue_databases": ["wrong_db_name"],
            "tags": {},
        }
        file_path = self._write_json_file(data)

        python_constants = {"validations_list": ["VALUE_VALIDATION"]}

        errors = validation_driver.validate_file(
            validation_details=[],
            file_path=file_path,
            resource_type="data_federation",
            gov_approved_tags=[],
            gov_approved_tag_values={},
            python_constants=python_constants,
            mandatory_json_keys=[],
            account_ids_map={},
            input_folder_path="/tmp",
            existing_resources={"068887784423": {"glue_db": []}},
        )

        # The existence-check error must survive through to the final
        # validate_file() return value (i.e. must not be wiped out by the
        # `errors = apply_all_validations(...)` overwrite bug), so it can
        # reach the all_errors flow in main().
        self.assertEqual(len(errors), 1)
        self.assertIn("wrong_db_name", errors[0])
        self.assertIn("data federation", errors[0].lower())

    # ------------------------------------------------------------------
    # iam / resource_policy regression coverage
    # ------------------------------------------------------------------
    @patch("validation_driver.apply_all_validations", return_value=[])
    @patch("validation_driver.filter_validations_per_resource", return_value={"VALUE_VALIDATION": {}})
    @patch("validation_driver.show_cross_subgroup_access_warning")
    @patch("validation_driver.analyze_iam_access", return_value={})
    @patch("validation_driver.validate_resources_existence")
    def test_iam_still_calls_validate_resources_existence(
        self, mock_validate_existence, mock_analyze_iam, mock_show_warning,
        mock_filter_validations, mock_apply_all
    ):
        mock_validate_existence.return_value = []

        data = {"aws_account_id": "123456789012", "tags": {}}
        file_path = self._write_json_file(data)

        python_constants = {"validations_list": ["VALUE_VALIDATION"]}

        validation_driver.validate_file(
            validation_details=[],
            file_path=file_path,
            resource_type="iam",
            gov_approved_tags=[],
            gov_approved_tag_values={},
            python_constants=python_constants,
            mandatory_json_keys=[],
            account_ids_map={},
            input_folder_path="/tmp",
            existing_resources={"123456789012": {}},
        )

        mock_validate_existence.assert_called_once()
        self.assertEqual(mock_validate_existence.call_args.kwargs["resource_type"], "iam")

    @patch("validation_driver.apply_all_validations", return_value=[])
    @patch("validation_driver.filter_validations_per_resource", return_value={"VALUE_VALIDATION": {}})
    @patch("validation_driver.validate_resources_existence")
    def test_resource_policy_still_calls_validate_resources_existence(
        self, mock_validate_existence, mock_filter_validations, mock_apply_all
    ):
        mock_validate_existence.return_value = []

        data = {"aws_account_id": "123456789012", "tags": {}}
        file_path = self._write_json_file(data)

        python_constants = {"validations_list": ["VALUE_VALIDATION"]}

        validation_driver.validate_file(
            validation_details=[],
            file_path=file_path,
            resource_type="resource_policy",
            gov_approved_tags=[],
            gov_approved_tag_values={},
            python_constants=python_constants,
            mandatory_json_keys=[],
            account_ids_map={},
            input_folder_path="/tmp",
            existing_resources={"123456789012": {}},
        )

        mock_validate_existence.assert_called_once()
        self.assertEqual(mock_validate_existence.call_args.kwargs["resource_type"], "resource_policy")

    def test_iam_regression_errors_not_dropped_by_apply_all_validations(self):
        # Regression test for the `errors = apply_all_validations(...)` bug:
        # existence-check errors accumulated for iam must survive to the
        # final return value, using the REAL apply_all_validations (not
        # mocked) with an empty perform_validations dict so nothing else
        # contributes new errors.
        data = {
            "aws_account_id": "123456789012",
            "tags": {"CostCenter": "1234"},
            "access_to_resources": {
                "glue_databases": {"write": ["missing_db"], "read": []},
                "data_prefixes": [],
                "execution_asset_prefixes": [],
                "glue_crawlers": [],
            },
        }
        file_path = self._write_json_file(data)

        python_constants = {"validations_list": []}

        with patch("validation_driver.analyze_iam_access", return_value={}), \
                patch("validation_driver.show_cross_subgroup_access_warning"):
            errors = validation_driver.validate_file(
                validation_details=[],
                file_path=file_path,
                resource_type="iam",
                gov_approved_tags=["CostCenter"],
                gov_approved_tag_values={},
                python_constants=python_constants,
                mandatory_json_keys=[],
                account_ids_map={},
                input_folder_path="/tmp",
                existing_resources={"123456789012": {"glue_db": []}},
            )

        self.assertTrue(any("missing_db" in e for e in errors), errors)

    # ------------------------------------------------------------------
    # Existence check should be skipped when no existing_resources data is
    # available yet, matching current iam / resource_policy behavior.
    # ------------------------------------------------------------------
    @patch("validation_driver.apply_all_validations", return_value=[])
    @patch("validation_driver.filter_validations_per_resource", return_value={"VALUE_VALIDATION": {}})
    @patch("validation_driver.validate_resources_existence")
    def test_skips_existence_check_when_no_existing_resources(
        self, mock_validate_existence, mock_filter_validations, mock_apply_all
    ):
        data = {"aws_account_id": "123456789012", "glue_databases": [], "tags": {}}
        file_path = self._write_json_file(data)

        python_constants = {"validations_list": ["VALUE_VALIDATION"]}

        validation_driver.validate_file(
            validation_details=[],
            file_path=file_path,
            resource_type="data_federation",
            gov_approved_tags=[],
            gov_approved_tag_values={},
            python_constants=python_constants,
            mandatory_json_keys=[],
            account_ids_map={},
            input_folder_path="/tmp",
            existing_resources={},
        )

        mock_validate_existence.assert_not_called()

    @patch("validation_driver.apply_all_validations", return_value=[])
    @patch("validation_driver.filter_validations_per_resource", return_value={"VALUE_VALIDATION": {}})
    @patch("validation_driver.validate_resources_existence")
    def test_does_not_call_existence_check_for_unrelated_resource_type(
        self, mock_validate_existence, mock_filter_validations, mock_apply_all
    ):
        data = {"aws_account_id": "123456789012", "tags": {}}
        file_path = self._write_json_file(data)

        python_constants = {"validations_list": ["VALUE_VALIDATION"]}

        validation_driver.validate_file(
            validation_details=[],
            file_path=file_path,
            resource_type="s3",
            gov_approved_tags=[],
            gov_approved_tag_values={},
            python_constants=python_constants,
            mandatory_json_keys=[],
            account_ids_map={},
            input_folder_path="/tmp",
            existing_resources={"123456789012": {"s3": []}},
        )

        mock_validate_existence.assert_not_called()


class TestMainExitsNonZeroOnValidationFailure(unittest.TestCase):
    """
    validation_driver.main() must exit non-zero when all_errors is
    non-empty (or the Validation Framework reports failures), so the
    calling shell's `source <(python3 validation_driver.py ...) || exit 1`
    actually stops the pipeline before Terraform executes.
    """

    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()
        self.addCleanup(lambda: __import__("shutil").rmtree(self.tmp_dir, ignore_errors=True))

        # existing_resources.json referenced by --existing_resources_file
        self.existing_resources_path = os.path.join(self.tmp_dir, "existing_resources.json")
        with open(self.existing_resources_path, "w") as f:
            json.dump({"068887784423": {"glue_db": []}}, f)

        # data_federation JSON file with a Glue DB that does not exist
        df_dir = os.path.join(self.tmp_dir, "lakehouse-001", "data_federation")
        os.makedirs(df_dir, exist_ok=True)
        self.df_file_path = os.path.join(df_dir, "sample_df.json")
        with open(self.df_file_path, "w") as f:
            json.dump({
                "aws_account_id": "068887784423",
                "glue_databases": ["wrong_db_name"],
                "tags": {},
            }, f)

        # validation_files.txt read by main() via TF_VAR_generated_json_dir
        with open(os.path.join(self.tmp_dir, "validation_files.txt"), "w") as f:
            f.write(self.df_file_path.replace("\\", "/"))

        # validation_details.json content consumed via VALIDATION_DETAILS_FILEPATH
        self.validation_details_path = os.path.join(self.tmp_dir, "validation_details.json")
        validation_details = [
            {
                "object_type": "general",
                "action": "python_constants",
                "is_active": "Y",
                "json_structure": {
                    "account_ids_map": {"068887784423": "lakehouse-001"},
                    "validation_supported_resources": ["iam", "resource_policy"],
                    # NOTE: non-empty on purpose (mirrors real DynamoDB config).
                    # An empty validations_list triggers an unrelated pre-existing
                    # latent bug in validate_file() (perform_validations left
                    # unassigned) -- out of scope for this Data Federation fix.
                    "validations_list": ["VALUE_VALIDATION"],
                    "abbreviations": None,
                    "tags_folder": None,
                },
            }
        ]
        with open(self.validation_details_path, "w") as f:
            json.dump(validation_details, f)

        self._env_patch = patch.dict(os.environ, {
            "TF_VAR_generated_json_dir": self.tmp_dir,
            "VALIDATION_DETAILS_FILEPATH": self.validation_details_path,
        })
        self._env_patch.start()
        self.addCleanup(self._env_patch.stop)

    @patch("validation_driver.run_validation_framework", return_value=0)
    @patch("validation_driver.get_gov_approved_tags_and_values", return_value=([], {}))
    def test_main_exits_nonzero_when_data_federation_glue_db_missing(
        self, mock_gov_tags, mock_run_vf
    ):
        test_args = [
            "validation_driver.py",
            "--gov_tag_folder", "/tmp/gov",
            "--existing_resources_file", self.existing_resources_path,
            "--input-folder", self.tmp_dir,
        ]
        with patch.object(sys, "argv", test_args):
            with self.assertRaises(SystemExit) as cm:
                validation_driver.main()

        self.assertNotEqual(cm.exception.code, 0)

    @patch("validation_driver.run_validation_framework", return_value=0)
    @patch("validation_driver.get_gov_approved_tags_and_values", return_value=([], {}))
    def test_main_does_not_exit_nonzero_when_glue_db_exists(
        self, mock_gov_tags, mock_run_vf
    ):
        # Fix up existing_resources.json so the referenced Glue DB now exists.
        with open(self.existing_resources_path, "w") as f:
            json.dump({"068887784423": {"glue_db": ["wrong_db_name"]}}, f)

        test_args = [
            "validation_driver.py",
            "--gov_tag_folder", "/tmp/gov",
            "--existing_resources_file", self.existing_resources_path,
            "--input-folder", self.tmp_dir,
        ]
        with patch.object(sys, "argv", test_args):
            try:
                validation_driver.main()
            except SystemExit as e:
                self.fail(f"main() unexpectedly called sys.exit({e.code}) when validation should pass")


if __name__ == "__main__":
    unittest.main()

