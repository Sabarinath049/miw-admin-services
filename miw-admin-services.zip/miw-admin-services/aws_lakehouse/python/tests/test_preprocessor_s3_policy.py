"""Offline policy regressions using real generation code and synthetic templates."""

import copy
import importlib.util
import json
import logging
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import Mock, patch


BASE_DIR = Path(__file__).resolve().parents[1]


def load_offline_preprocessor():
    """Bypass import-time AWS clients, credentials, environment and file logging."""
    constants = types.ModuleType("constants")
    constants.ENV = "prd"
    constants.REGION = "us-east-1"
    constants.VALIDATION_DETAILS_TABLE = "unused-validation"
    constants.REFERENCE_JSON_TABLE = "unused-reference"
    config_log = types.ModuleType("helpers.config_log")
    config_log.logger = logging.getLogger("offline-policy-tests")
    boto3 = types.ModuleType("boto3")
    # utils initializes a resource at import time. Any subsequent AWS access fails.
    boto3.resource = Mock(return_value=object())
    boto3.client = Mock(side_effect=AssertionError("AWS access forbidden"))
    helpers = types.ModuleType("helpers")
    helpers.__path__ = [str(BASE_DIR / "helpers")]
    replacements = {
        "constants": constants,
        "helpers": helpers,
        "helpers.config_log": config_log,
        "boto3": boto3,
    }
    with patch.dict(sys.modules, replacements):
        for name in ("utils", "preprocessor"):
            spec = importlib.util.spec_from_file_location(
                "helpers." + name, BASE_DIR / "helpers" / (name + ".py")
            )
            module = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = module
            spec.loader.exec_module(module)
        return module


class TestS3PolicyGeneration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.preprocessor = load_offline_preprocessor()

    def setUp(self):
        self.prefixes = [
            "s3://prd-cmp3-anh-eng-assets/prd/spec/anh/athena/",
            "s3://prd-cmp3-anh-eng-assets/prd/spec/anh/glue/",
            "s3://prd-cmp3-anh-scripts/prd/spec/anh/glue/",
        ]
        self.data = {
            "role_name": "test_prd_EgressEngineer",
            "access_to_resources": {"execution_asset_prefixes": self.prefixes},
            "athena_access_config": {"enable_athena_access": True},
        }
        self.validation = [{
            "object_type": "general",
            "is_active": "Y",
            "action": "python_constants",
            "json_structure": {"role_type": ["^EgressEngineer$"]},
        }]
        self.references = [{
            "reference_policy_name": "iam_egressengineer",
            "reference_details_iam": {
                "data_prefixes": ["generic_s3"],
                "athena_access_config.enable_athena_access": ["athena_s3"],
            },
        }]
        for name, sid in (("generic_s3", "Generic"), ("athena_s3", "Athena")):
            statements = [
                {"Sid": sid + "Bucket", "Effect": "Allow",
                 "Action": ["s3:GetBucketLocation", "s3:ListBucketMultipartUploads", "s3:ListBucket"],
                 "Resource": ["arn:aws:s3:::<S3_BUCKET_NAME>"]},
                {"Sid": sid + "Object", "Effect": "Allow",
                 "Action": ["s3:AbortMultipartUpload", "s3:ListMultipartUploadParts",
                            "s3:GetObject", "s3:PutObject", "s3:PutObjectTagging", "s3:DeleteObject"],
                 "Resource": ["arn:aws:s3:::<S3_PREFIX_PATH>/*"]},
            ]
            self.references.append({
                "reference_policy_name": name,
                # Exercise both runtime template representations.
                "json_structure": json.dumps(statements) if sid == "Generic" else statements,
            })

    def resources(self):
        policies = self.preprocessor.get_policy_jsons(
            self.data, self.references, self.validation
        )
        policies = json.loads(json.dumps(policies))
        return {stmt["Sid"]: stmt["Resource"]
                for policy in policies.values() for stmt in policy["Statement"]}

    def test_generic_sample_resources(self):
        result = self.resources()
        self.assertEqual(result["GenericBucket"], [
            "arn:aws:s3:::prd-cmp3-anh-eng-assets",
            "arn:aws:s3:::prd-cmp3-anh-scripts",
        ])
        self.assertEqual(result["GenericObject"], [
            "arn:aws:s3:::prd-cmp3-anh-eng-assets/prd/spec/anh/athena/*",
            "arn:aws:s3:::prd-cmp3-anh-eng-assets/prd/spec/anh/glue/*",
            "arn:aws:s3:::prd-cmp3-anh-scripts/prd/spec/anh/glue/*",
        ])

    def test_athena_resources_preserve_complete_prefix(self):
        result = self.resources()
        self.assertEqual(result["AthenaBucket"], ["arn:aws:s3:::prd-cmp3-anh-eng-assets"])
        self.assertEqual(result["AthenaObject"], [
            "arn:aws:s3:::prd-cmp3-anh-eng-assets/prd/spec/anh/athena/*"
        ])
        for resources in result.values():
            for resource in resources:
                self.assertNotIn("arn:aws:s3:::s3://", resource)
                self.assertNotEqual(resource, "arn:aws:s3:::s3:")

    def test_inputs_and_templates_are_not_mutated(self):
        before = copy.deepcopy((self.data, self.references, self.validation))
        self.resources()
        self.assertEqual((self.data, self.references, self.validation), before)

    def test_generic_supported_prefix_forms(self):
        self.data["athena_access_config"]["enable_athena_access"] = False
        cases = [
            ("s3://bucket", "bucket"),
            ("s3://bucket/", "bucket"),
            ("s3://bucket/prefix", "bucket/prefix"),
            ("s3://bucket/prefix/", "bucket/prefix"),
            ("s3://bucket/nested/prefix/", "bucket/nested/prefix"),
            ("bucket/prefix/", "bucket/prefix"),
            ("s3://bucket/nested//prefix///", "bucket/nested//prefix"),
        ]
        for prefix, clean in cases:
            with self.subTest(prefix=prefix):
                self.data["access_to_resources"]["execution_asset_prefixes"] = [prefix]
                self.assertEqual(self.resources(), {
                    "GenericBucket": ["arn:aws:s3:::bucket"],
                    "GenericObject": ["arn:aws:s3:::" + clean + "/*"],
                })

    def test_athena_trailing_slash_variants(self):
        expected = self.resources()
        for suffix in ("", "/", "///"):
            with self.subTest(suffix=suffix):
                self.prefixes[0] = self.prefixes[0].rstrip("/") + suffix
                self.assertEqual(self.resources(), expected)

    def test_duplicate_prefixes_and_buckets_are_deduplicated(self):
        expected = self.resources()
        self.prefixes.extend([self.prefixes[0], self.prefixes[0].rstrip("/")])
        self.data["access_to_resources"]["data_prefixes"] = self.prefixes[:2]
        self.assertEqual(self.resources(), expected)

    def test_athena_selects_first_qualifying_prefix_without_changing_uri(self):
        first = self.prefixes[0]
        self.prefixes[:] = [
            "s3://other-bucket/glue/",
            first,
            "s3://second-eng-assets/other/athena/",
        ]
        self.assertEqual(
            self.preprocessor.is_execution_asset_prefix_valid_for_athena_access(self.data),
            (True, first),
        )
        result = self.resources()
        self.assertEqual(result["AthenaObject"], [
            "arn:aws:s3:::prd-cmp3-anh-eng-assets/prd/spec/anh/athena/*"
        ])
        self.assertEqual(result["AthenaBucket"], ["arn:aws:s3:::prd-cmp3-anh-eng-assets"])
        self.assertEqual(len(result["GenericBucket"]), 3)

    def test_athena_without_qualifying_prefix_is_skipped(self):
        self.prefixes[:] = ["s3://bucket/glue/"]
        self.assertNotIn("AthenaObject", self.resources())
        self.assertNotIn("AthenaBucket", self.resources())

    def test_disabled_athena_does_not_add_statements(self):
        self.data["athena_access_config"]["enable_athena_access"] = False
        self.assertEqual(set(self.resources()), {"GenericBucket", "GenericObject"})


if __name__ == "__main__":
    unittest.main()