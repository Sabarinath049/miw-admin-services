"""
Unit tests for validate_resources_existence() Data Federation Glue DB
existence checks in aws_lakehouse/python/helpers/validator.py.

These tests cover:
  - Passing when all glue_databases exist in existing_resources.json for the
    configured aws_account_id.
  - Failing when one or more glue_databases are missing.
  - Failing clearly when existing resources are missing entirely for the
    aws_account_id.
  - Handling glue_databases provided as a list (and a stray non-list value).
  - No regression to the existing iam / resource_policy behavior.
"""

import os
import sys
import unittest

# Disable the network-dependent CloudWatch debug log handler during tests so
# importing helpers.validator (-> helpers.config_log) doesn't attempt any AWS
# calls in a local/offline test environment.
os.environ.setdefault("DEBUG_CLOUDWATCH_ENABLED", "false")

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from helpers.validator import validate_resources_existence  # noqa: E402


class TestValidateResourcesExistenceDataFederation(unittest.TestCase):

    def setUp(self):
        self.file_name = "src_raw_dev_df.yaml"
        self.mandatory_json_keys = {}
        self.python_constants = {}

    def test_passes_when_all_glue_databases_exist(self):
        data = {
            "aws_account_id": "123456789012",
            "glue_databases": ["abc_raw_dev", "abc_cdp_dev"],
        }
        existing_resources = {
            "123456789012": {
                "glue_db": ["abc_raw_dev", "abc_cdp_dev", "other_db"]
            }
        }

        errors = validate_resources_existence(
            data, "data_federation", existing_resources, self.file_name,
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(errors, [])

    def test_fails_when_one_glue_database_missing(self):
        data = {
            "aws_account_id": "123456789012",
            "glue_databases": ["abc_raw_dev", "abc_missing_dev"],
        }
        existing_resources = {
            "123456789012": {
                "glue_db": ["abc_raw_dev"]
            }
        }

        errors = validate_resources_existence(
            data, "data_federation", existing_resources, self.file_name,
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(len(errors), 1)
        message = errors[0]
        # file path
        self.assertIn(self.file_name, message)
        # aws_account_id
        self.assertIn("123456789012", message)
        # missing Glue database name
        self.assertIn("abc_missing_dev", message)
        # recommendation wording
        self.assertIn("Data Federation validation failed", message)
        self.assertIn("provisioning Data Federation", message)

    def test_fails_for_every_missing_glue_database(self):
        data = {
            "aws_account_id": "123456789012",
            "glue_databases": ["missing_one_dev", "missing_two_dev"],
        }
        existing_resources = {
            "123456789012": {
                "glue_db": ["existing_db"]
            }
        }

        errors = validate_resources_existence(
            data, "data_federation", existing_resources, self.file_name,
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(len(errors), 2)
        self.assertTrue(any("missing_one_dev" in e for e in errors))
        self.assertTrue(any("missing_two_dev" in e for e in errors))

    def test_fails_clearly_when_account_missing_from_existing_resources(self):
        data = {
            "aws_account_id": "999999999999",
            "glue_databases": ["abc_raw_dev"],
        }
        existing_resources = {
            "123456789012": {
                "glue_db": ["abc_raw_dev"]
            }
        }

        errors = validate_resources_existence(
            data, "data_federation", existing_resources, self.file_name,
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(len(errors), 1)
        self.assertIn("999999999999", errors[0])
        self.assertIn(self.file_name, errors[0])
        self.assertIn("Data Federation validation failed", errors[0])

    def test_fails_clearly_when_aws_account_id_is_missing(self):
        data = {
            "glue_databases": ["abc_raw_dev"],
        }
        existing_resources = {
            "123456789012": {
                "glue_db": ["abc_raw_dev"]
            }
        }

        errors = validate_resources_existence(
            data, "data_federation", existing_resources, self.file_name,
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(len(errors), 1)
        self.assertIn("aws_account_id", errors[0])
        self.assertIn(self.file_name, errors[0])

    def test_fails_clearly_when_aws_account_id_is_blank_string(self):
        data = {
            "aws_account_id": "   ",
            "glue_databases": ["abc_raw_dev"],
        }
        existing_resources = {
            "123456789012": {
                "glue_db": ["abc_raw_dev"]
            }
        }

        errors = validate_resources_existence(
            data, "data_federation", existing_resources, self.file_name,
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(len(errors), 1)
        self.assertIn("aws_account_id", errors[0])

    def test_handles_glue_databases_as_list_with_empty_entries_ignored(self):
        data = {
            "aws_account_id": "123456789012",
            "glue_databases": ["abc_raw_dev", "", "  "],
        }
        existing_resources = {
            "123456789012": {
                "glue_db": ["abc_raw_dev"]
            }
        }

        errors = validate_resources_existence(
            data, "data_federation", existing_resources, self.file_name,
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(errors, [])

    def test_handles_glue_databases_as_single_string_gracefully(self):
        data = {
            "aws_account_id": "123456789012",
            "glue_databases": "abc_raw_dev",
        }
        existing_resources = {
            "123456789012": {
                "glue_db": ["abc_raw_dev"]
            }
        }

        errors = validate_resources_existence(
            data, "data_federation", existing_resources, self.file_name,
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(errors, [])

    def test_no_glue_databases_configured_produces_no_errors(self):
        data = {
            "aws_account_id": "123456789012",
            "glue_databases": [],
        }
        existing_resources = {
            "123456789012": {
                "glue_db": []
            }
        }

        errors = validate_resources_existence(
            data, "data_federation", existing_resources, self.file_name,
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(errors, [])

    # ------------------------------------------------------------------
    # Regression coverage: adding data_federation support must not change
    # the existing iam / resource_policy behavior.
    # ------------------------------------------------------------------
    def test_iam_validation_still_passes_for_existing_glue_db(self):
        data = {
            "aws_account_id": "123456789012",
            "access_to_resources": {
                "glue_databases": {
                    "write": ["abc_raw_dev"],
                    "read": [],
                },
                "data_prefixes": [],
                "execution_asset_prefixes": [],
                "glue_crawlers": [],
            },
        }
        existing_resources = {
            "123456789012": {
                "glue_db": ["abc_raw_dev"]
            }
        }

        errors = validate_resources_existence(
            data, "iam", existing_resources, self.file_name,
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(errors, [])

    def test_iam_validation_still_fails_for_missing_glue_db(self):
        data = {
            "aws_account_id": "123456789012",
            "access_to_resources": {
                "glue_databases": {
                    "write": ["missing_db"],
                    "read": [],
                },
                "data_prefixes": [],
                "execution_asset_prefixes": [],
                "glue_crawlers": [],
            },
        }
        existing_resources = {
            "123456789012": {
                "glue_db": []
            }
        }

        errors = validate_resources_existence(
            data, "iam", existing_resources, self.file_name,
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(len(errors), 1)
        self.assertIn("missing_db", errors[0])

    def test_resource_policy_validation_still_passes_for_existing_glue_db(self):
        data = {
            "aws_account_id": "123456789012",
            "access_to_resources": {
                "s3_prefixes": [],
                "glue_databases": ["abc_raw_dev"],
            },
        }
        existing_resources = {
            "123456789012": {
                "glue_db": ["abc_raw_dev"]
            }
        }

        errors = validate_resources_existence(
            data, "resource_policy", existing_resources, self.file_name,
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(errors, [])

    def test_resource_policy_validation_still_fails_for_missing_glue_db(self):
        data = {
            "aws_account_id": "123456789012",
            "access_to_resources": {
                "s3_prefixes": [],
                "glue_databases": ["missing_db"],
            },
        }
        existing_resources = {
            "123456789012": {
                "glue_db": []
            }
        }

        errors = validate_resources_existence(
            data, "resource_policy", existing_resources, self.file_name,
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(len(errors), 1)
        self.assertIn("missing_db", errors[0])

    def test_unsupported_resource_type_returns_no_errors(self):
        data = {"aws_account_id": "123456789012", "glue_databases": ["abc_raw_dev"]}
        existing_resources = {}

        errors = validate_resources_existence(
            data, "s3", existing_resources, self.file_name,
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(errors, [])

    # ------------------------------------------------------------------
    # Actual generated Data Federation JSON structure (not a simplified mock).
    #
    # This mirrors exactly what preprocess_driver.py's generic
    # `json_data = convert_to_json(data)` / `save_to_file(...)` block writes to
    # <output_folder>/<account_folder>/data_federation/<file>.json: the same
    # `data` dict used (unmodified) by get_lf_data_permissions_data_federation()
    # and get_resource_links_data_federation() to build the Lake Formation
    # permissions/resource-links JSONs, which is why "aws_account_id" and
    # "glue_databases" are guaranteed to be present at the top level.
    # ------------------------------------------------------------------
    def _generated_data_federation_payload(self, glue_databases):
        return {
            "aws_account_id": "068887784423",
            "data_share_name": "src_raw_dev_df",
            "cross_account_aws_ids": ["904233109241"],
            "glue_databases": glue_databases,
            "tags": {
                "CostCenter": "1234",
                "Source": "lakehouse-001",
            },
        }

    def test_actual_generated_json_structure_passes_when_glue_databases_exist(self):
        data = self._generated_data_federation_payload(["abc_raw_dev", "abc_cdp_dev"])
        existing_resources = {
            "068887784423": {
                "glue_db": ["abc_raw_dev", "abc_cdp_dev", "other_db"],
                "s3": [],
                "glue_crawler": [],
            }
        }

        errors = validate_resources_existence(
            data, "data_federation", existing_resources, "src_raw_dev_df.json",
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(errors, [])

    def test_actual_generated_json_structure_fails_when_glue_database_missing(self):
        data = self._generated_data_federation_payload(["wrong_db_name"])
        existing_resources = {
            "068887784423": {
                "glue_db": ["abc_raw_dev"],
                "s3": [],
                "glue_crawler": [],
            }
        }

        errors = validate_resources_existence(
            data, "data_federation", existing_resources, "src_raw_dev_df.json",
            self.mandatory_json_keys, self.python_constants
        )

        self.assertEqual(len(errors), 1)
        self.assertIn("wrong_db_name", errors[0])
        self.assertIn("068887784423", errors[0])
        self.assertIn("src_raw_dev_df.json", errors[0])


if __name__ == "__main__":
    unittest.main()

