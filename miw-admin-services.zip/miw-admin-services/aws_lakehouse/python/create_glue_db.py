import boto3, os, json, sys, time
import yaml
from botocore.exceptions import ClientError
from helpers.config_log import logger, error_log_path, warning_log_path
## boto3__version__= 1.40.19

def sts_assume_role(role_arn, session_name):
    sts_client = boto3.client("sts")
    creds = sts_client.assume_role(RoleArn=role_arn, RoleSessionName=session_name)["Credentials"]
    return boto3.session.Session(
        aws_access_key_id=creds["AccessKeyId"],
        aws_secret_access_key=creds["SecretAccessKey"],
        aws_session_token=creds["SessionToken"]
    )

def get_all_glue_databases(region, glue_client, catalog_id):
    """Fetch all Glue databases and their tags."""
    paginator = glue_client.get_paginator("get_databases")
    dbs = {}
    for page in paginator.paginate(CatalogId=catalog_id):
        for db in page["DatabaseList"]:
            arn = f"arn:aws:glue:{region}:{catalog_id}:database/{db['Name']}"
            tags = glue_client.get_tags(ResourceArn=arn)["Tags"]
            dbs[db["Name"]] = {
                "description": db.get("Description", ""),
                "location": db.get("LocationUri", ""),
                "catalog_id": catalog_id,
                "arn": arn,
                "tags": tags,
            }
    return dbs

def sync_glue_databases(session, catalog_id, terraform_configs, region):
    """
    Creating Glue DB's if it doesn't exist. If it exists, updating Glue DB if there is any change in Description, s3 location or tags
    """
    modified_databases=[]
    add_count=0
    modify_count=0
    destroy_count=0
    try:
        glue_client = session.client("glue")
    except:
        session = sts_assume_role(role_arn, session_name)
        glue_client = session.client("glue")
    
    aws_dbs = get_all_glue_databases(region, glue_client, catalog_id)

    for _, value in terraform_configs.items():
        name = value["database_name"]
        desc = value["database_description"]
        s3_loc = value.get("database_s3_location", "")
        tags = value.get("tags", {})
        arn = f"arn:aws:glue:{region}:{catalog_id}:database/{name}"

        if name in aws_dbs:
            db = aws_dbs[name]
            logger.info(f"Database '{name}' exists.")

            # Skipping tableflow Database for updates
            if name.strip()=='lkc-myrp67':
                continue
            
            # # Compare description/location
            # if db["description"] != desc or db["location"] != s3_loc:
            #     if stage=="apply":
            #         glue_client.update_database(
            #             CatalogId=catalog_id,
            #             Name=name,
            #             DatabaseInput={"Name": name, "Description": desc, "LocationUri": s3_loc}
            #         )
            #         logger.info(f"Database '{name}' updated.")
            #     modified_databases.append(arn)
            #     modify_count+=1

            # Compare tags
            if db["tags"] != tags:
                if stage=="apply":
                    glue_client.tag_resource(ResourceArn=arn, TagsToAdd=tags)
                    logger.info(f"Tags updated for '{name}'.")
                modified_databases.append(arn)
                modify_count+=1
        else:
            if stage=="apply":
                # Create new database
                glue_client.create_database(
                    CatalogId=catalog_id,
                    DatabaseInput={"Name": name, "Description": desc, "LocationUri": s3_loc}
                )
                logger.info(f"Database '{name}' created.")
            modified_databases.append(arn)
            add_count+=1

            if tags:
                if stage=="apply":
                    glue_client.tag_resource(ResourceArn=arn, TagsToAdd=tags)
                    logger.info(f"Tags applied to new database '{name}'.")
    return modified_databases, add_count,modify_count, destroy_count


def read_yaml_files(folder_path : str) -> list :
    """
    Used to read s3 yaml files and fetch bucket name out of it, prepare data_dictionary to register paths if doesn't exist.
    """
    input = {}
    try:
        files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
        logger.debug(f"Number of files: {len(files)}")
        for file in files:
            with open(os.path.join(folder_path,file), 'r') as f:
                glue_db_data = yaml.safe_load(f)
                
                input[file]=glue_db_data
        return input
    except Exception as e:
        raise Exception(f"Unable to read glue_db files due to error -> {e}")


def main():    
    env = os.getenv("CODEBUILD_ENV")
    region = os.getenv("aws_region", "us-east-1")
    account_id = os.getenv("account_id")
    account_name = os.getenv("account_name")
    generated_json_dir = os.getenv("lakehouse_output_dir")
    role_arn = f"arn:aws:iam::{account_id}:role/minerva-{env}-corp-miw-cross-acc-deploy-role"
    session_name = "Deploy_Glue_DB"
    # Construct the path
    glue_db_path = f"{generated_json_dir}/{account_name}/glue_db/"

    glue_parameters=read_yaml_files(glue_db_path)
    # logger.debug(f"{glue_parameters=}")
    # glue_parameters = json.loads(os.getenv("glue_db_configs","{}"))
    session = sts_assume_role(role_arn, session_name)

    modified_databases, add, modify,destroy=sync_glue_databases(session, account_id, glue_parameters, region)
    logger.info(f"{modified_databases=}")
    output={}
    output["db_names"]=modified_databases
    output["added"]=add
    output["modified"]=modify
    output["destroyed"]=destroy
    logger.info(f"******************GlueDB changes************************\n{json.dumps(output,indent=4)}\n**************************\n")

    f_w=open(f"{generated_json_dir}/Create_Glue_DB_Errors_LogFilePath.txt","w+")
    with open(error_log_path,"r") as f:
        error_logs=f.read()
        f_w.write(error_logs)
        f_w.close()
    
    f_w=open(f"{generated_json_dir}/Create_Glue_DB_Warnings_LogFilePath.txt","w+")
    with open(warning_log_path,"r") as f:
        warning_logs=f.read()
        f_w.write(warning_logs)
        f_w.close()

    with open(f"{generated_json_dir}/{account_id}_python_outputs.json","w+") as f:
        f.write(json.dumps(output))




if __name__ == "__main__":
    try:
        stage=os.getenv("python_stage","plan")
        logger.info(f"Python stage set as  {stage}")

        main()
        # # exporting error and warning log file paths
        # sys.stderr.write(f'export Create_Glue_DB_Errors_LogFilePath="{error_log_path}"')
        # sys.stderr.write(f'export Create_Glue_DB_Warnings_LogFilePath="{warning_log_path}"')
    except Exception as e:
        logger.error(f"Error: {e}")
        sys.exit(1)
