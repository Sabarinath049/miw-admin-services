import os
from colorama import Fore, Style, init
import sys


terraform_output= sys.argv[1]
try:
    error_code = sys.argv[2]
    executor_exit_code = sys.argv[3]
except:
    error_code = os.getenv("error_flag", "0")
    executor_exit_code = os.getenv("EXECUTOR_EXIT_CODE", "0")

# Initialize colorama (for Windows compatibility too)
init(autoreset=True)

def get_warnings_errors_log_paths() -> dict[str, dict[str, str]]:
    """
    Extract log file paths for warnings and errors from environment variables.
    Example ENV format:
        AbstractionLayer_Warnings_LogFilePath=/path/to/warning.log
        AbstractionLayer_Errors_LogFilePath=/path/to/error.log
    """
    log_file_paths: dict[str, dict[str, str]] = {}

    for key, value in os.environ.items():
        if "LogFilePath" in key:
            parts = key.split('_')
            if len(parts) < 3:
                continue  # skip malformed keys
            layer = parts[0]
            level = parts[-2].capitalize()  # e.g. 'Warnings' → 'Warnings'
            log_file_paths.setdefault(layer, {})[level] = value

    # Adding these specific paths from glue db creation logs
    generated_json_dir = os.getenv("generated_json_dir", "")
    error_log_path = f"{generated_json_dir}/Create_Glue_DB_Errors_LogFilePath.txt"
    warning_log_path = f"{generated_json_dir}/Create_Glue_DB_Warnings_LogFilePath.txt"
    if os.path.exists(error_log_path):
        log_file_paths.setdefault("GlueDBCreation", {})["Errors"] = error_log_path
    if os.path.exists(warning_log_path):
        log_file_paths.setdefault("GlueDBCreation", {})["Warnings"] = warning_log_path

    return log_file_paths


def beautify_logs(layer: str, layer_logs: dict[str, dict[str, str]]) -> bool:
    """
    Print log contents with colors and better readability.
    """
    got_errors = False
    # Choose colors by level
    color_map = {
        "Warning": [Fore.YELLOW, '🟡'],
        "Error": [Fore.RED, '🔴'],
    }
    header_color, icon = [Fore.CYAN, '🔵']
    path_color = Fore.MAGENTA

    print(f"\n{header_color}{'=' * 70}")
    print(f"{header_color}{icon * 3} LOGS of {layer} {icon * 3}")
    print(f"{header_color}{'=' * 70}\n")

    for sub_layer, levels in layer_logs.items():
        print(f"{Fore.GREEN}Layer: {sub_layer}")
        for level, path in levels.items():
            level_key = level.rstrip('s')  # Normalize plural
            level_color, level_icon = color_map.get(level_key, [Fore.WHITE, '⚪'])
            print(f"\n{level_icon} {level.upper()}")

            if not os.path.exists(path):
                print(Fore.LIGHTBLACK_EX + f"No log file found at {path}")
                continue

            try:
                with open(path, "r", encoding="utf-8") as file:
                    printed_any = False
                    for line in file:
                        stripped = line.strip()
                        if stripped:
                            print(level_color + stripped)
                            printed_any = True
                    if not printed_any:
                        print(Fore.LIGHTBLACK_EX + f"No {level.lower()} found!!")
                    else:
                        if level_key == "Error":
                            got_errors = True
            except Exception as e:
                print(Fore.RED + f"❌ [!] Error reading {path}: {e}")
    
    # Adding the validation framework summary table for the validation layer if it exists
    if layer == "Validation Layer":
        output_path = f"{os.getenv('TF_VAR_generated_json_dir', '')}/validation_summary_table.txt"
        if os.path.exists(output_path):
            print(f"\n{Fore.BLUE}📊 Validation Summary Table:")
            try:
                with open(output_path, "r", encoding="utf-8") as file:
                    for line in file:
                        print(Fore.BLUE + line.strip())
            except Exception as e:
                print(Fore.RED + f"❌ [!] Error reading validation summary table: {e}")
        else:
            print(Fore.LIGHTBLACK_EX + f"No validation summary table found!! Path: {output_path}")
    return got_errors


if __name__ == "__main__":
    log_paths = get_warnings_errors_log_paths()
    abstraction_layer_error = False
    validation_layer_error = False
    if not log_paths:
        print(Fore.LIGHTBLACK_EX + "No log file paths found in environment variables.")
    else:
        abstraction_layer_logs = {key: value for key, value in log_paths.items() if "AbstractionLayer" in key}
        if abstraction_layer_logs:
            abstraction_layer_error = beautify_logs("Abstraction Layer", abstraction_layer_logs)

        validation_layer_logs = {key: value for key, value in log_paths.items() if "ValidationLayer" in key}
        if validation_layer_logs:
            validation_layer_error = beautify_logs("Validation Layer", validation_layer_logs)
    print(open(terraform_output).read())
    if abstraction_layer_error or validation_layer_error or int(error_code) != 0 or int(executor_exit_code) != 0:
        sys.exit(1)
