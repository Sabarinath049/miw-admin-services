import boto3
import os

LF_TAG_KEY = os.environ.get("LF_TAG_KEY", "dev_discoverability")
LF_TAG_VALUE = os.environ.get("LF_TAG_VALUE", "enabled")

# Support multiple keywords via comma-separated env var
KEYWORD_FILTERS = os.environ.get("KEYWORD_FILTERS", "_cln_").split(",")

lakeformation = boto3.client("lakeformation")

def lambda_handler(event, context):
    try:
        detail = event.get("detail", {})
        change_type = detail.get("typeOfChange")
        database_name = detail.get("databaseName")

        print(f"Received event: {event}")
        # Check if it's a CreateDatabase event and name contains any keyword
        if change_type == "CreateDatabase" and any(keyword in database_name for keyword in KEYWORD_FILTERS):
            print(f"Applying LF tag to database: {database_name}")

            response = lakeformation.add_lf_tags_to_resource(
                Resource={
                    "Database": {
                        "Name": database_name
                    }
                },
                LFTags=[
                    {
                        "TagKey": LF_TAG_KEY,
                        "TagValues": [LF_TAG_VALUE]
                    }
                ]
            )
            print("LF tag applied successfully:", response)
        else:
            print(f"No action taken for database: {database_name} with change type: {change_type}")

    except Exception as e:
        print("Error processing event:", str(e))
        raise
