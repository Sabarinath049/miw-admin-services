import os
import json
import sys

## Import the mapping_keys_src_system from python/constants.py
# Get the path to the parent directory (project_root) and add it to the python path
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(os.path.join(parent_dir, 'python'))

from constants import mapping_keys_src_system, mapping_critical_keys

env=os.getenv('env')
ENV=env.upper()


# Persona Mapping
data_integrator="dataintegrator"
persona_mapping = {
    "procdataengineer": "Proc_Data_Engineer",
    "proclh_dataconsumer": "Proc_LH_Data_Consumer",
    "rls": "RLS",
    "cls": "CLS",
    "dataengineer": "Data_Engineer",
    "dataanalyst": "Data_Analyst",
    "dataleader":"Data_Leader",
    "platformgovernance": "Platform_Governance",
    "dataproductmanager": "Data_Product_Manager",
    "platformadmin": "Data_Platform_Administrator",
    "datascientist": "Data_Scientist",
    "procdataconsumer":"Proc_Data_Consumer",
    "dataconsumer":"Data_Consumer",
    data_integrator: "Data_Integrator",
    "techanalyst": "Tech_Analyst"
}

## integrator persona allowed on the following objects
integrator_persona_mapping = {
    "warehouses":{"ALL_WH_MANAGE":"WAR_$ENV_ALL_WH_MMO_RW"},
    "schemas":{"ALL_SCH_READ":"DBR_$ENV_ALL_DB.ALL_SC_RO"}
}

## integrator allowed roles to add ALL_DB_READ, ALL_SCH_READ and ALL_WH_MANAGE
integrator_restricted_persona = [data_integrator,'platformadmin','platformgovernance']

## ADMIN roles created for terraform provisioning purpose in roles folder
admin_roles_list=[os.getenv("TF_VAR_wh_role").upper(),os.getenv("TF_VAR_db_role").upper(),os.getenv("TF_VAR_oauth_role").upper(),os.getenv("TF_VAR_db_pipln").upper(),
os.getenv("TF_VAR_account_admin_role").upper(),os.getenv("TF_VAR_glass_breaker_role").upper(),os.getenv("TF_VAR_miw_security_admin_role").upper()]

product_key_list=[]

## Rename the keys for important keys if there is an change
def map_critical_keys_in_input_json(input_json: dict,original_file_path: str, obj_type: str):
    """Purpose: To change the keys in the input JSON for source system specific requests"""
    
    if obj_type in mapping_critical_keys:
        modified_json = {}
        for key in input_json:
            if key in mapping_critical_keys[obj_type]:
                # Map keys if they exist in the mapping
                new_key = mapping_critical_keys[obj_type].get(key)
                modified_json[new_key] = input_json[key]
            else:
                modified_json[key]=input_json[key]

        with open(original_file_path, 'w') as f:
            f.write(json.dumps(modified_json))
        
        return modified_json
    else:
        return input_json


## Rename the keys for src_system input json keys with product key input json keys

def map_src_system_keys_with_prd_keys(input_json: dict, original_file_path: str, obj_type: str, src_key: str = 'src_system'):
    """Purpose: To change the keys in the input JSON for source system specific requests"""

    # Define the object types where mapping should be applied
    allowed_obj_types_product_grp_id = ['catalog_integrations', 'databases', 'external_volumes', 'schemas']
    allowed_obj_types_ent_and_func_nm = ['catalog_integrations', 'external_volumes', 'schemas']
    if obj_type in mapping_keys_src_system.get(src_key, {}):
        modified_json = {}
        for key in input_json:
            # Map keys if they exist in the mapping
            new_key = mapping_keys_src_system[src_key][obj_type].get(key, key)
            modified_json[new_key] = input_json[key]

            if obj_type in allowed_obj_types_product_grp_id:
                modified_json["product_group_identifier"]=""
            if obj_type in allowed_obj_types_ent_and_func_nm:
                modified_json["enterprise_or_func_name"]=""                

        # Do not enforce or inject any keys like 'product_group_identifier' if not already present
        with open(original_file_path, 'w') as f:
            f.write(json.dumps(modified_json))

        return modified_json
    else:
        return input_json


def check_persona_roles(persona_role : str):
    """Purpose: Validate if the persona_role passed is among the inetgrator_restricted_persona"""
    for role_nm in integrator_restricted_persona:
        if role_nm.lower() in persona_role.lower():
            return True
    return False


def get_unique_roles(functional_roles: dict, object_name: str,ENV: str):
    """Purpose: Get only unique roles for RO/RW as per the object type and their respective grants. 
    This function will be useful in revoking the grants per persona when necessary in future"""

    unique_ro_rw_with_grants={}

    for key,val in functional_roles.items():
        tech_role=val[0]['tech_role'].replace('$OBJECTNAME',object_name).replace('$ENV',ENV)
        if  tech_role not in unique_ro_rw_with_grants:
            unique_ro_rw_with_grants[tech_role]=val[0]['grants']
        else:
            continue
    return unique_ro_rw_with_grants

def redefine_catalog_integration_access_roles(input :dict) -> dict:
    output={}
    access_roles=input.get("access_roles", []).copy()
    catalog_namespace=list(set(input.get("catalog_namespace",[]).copy()))

    for i in catalog_namespace:
        for j in access_roles:
            temp={}
            ci_access_name=i+"_ci_"+j["tech_role"]
            temp["tech_role"]=j["tech_role"]
            temp["grants"]=j["grants"]
            temp["catalog_integration"]=i+"_ci"

            if ci_access_name not in output:
                output[ci_access_name]=temp
            else:
                continue
    
    input["access_roles_ci_map"]=output
    return input

def enrich_access_roles(input_json, reference_json, object_type, objects_in_schema_json):
    """Enrich access roles in the input JSON using the reference JSON."""
    enriched_access_roles = []

    # Ensure the object type is valid and get the functional roles key
    functional_roles_key = {
        'warehouses': 'Warehouse_functional_roles',
        'databases': 'Database_functional_roles',
        'schemas': 'Schema_functional_roles',
        'storage_integrations' : 'Storage_Integration_functional_roles',
        'roles': 'Roles_Integrator_functional_roles',
        'external_volumes':'External_Volume_functional_roles',
        'catalog_integrations':'Catalog_Integration_functional_roles'
    }.get(object_type)

    
    if not functional_roles_key:
        raise ValueError(f"Invalid object type: {object_type}")   
    
     # Get functional roles from reference JSON
    functional_roles = reference_json.get(functional_roles_key, {})

    ## The roles functional keys should only be active when we want to grant roles to Integrator personas 
    ## and add_group_nm in the input json for roles should be active when it is among the integrator_restricted_persona
    if object_type=='roles' and not check_persona_roles(input_json.get("aad_group_name").lower()):
        print(f"Warning: The persona {input_json.get('aad_group_name')} is not among {','.join(integrator_restricted_persona)}, thus not assigning access_role_alias to it!!")
        functional_roles={}

    ## Add explicit integrator persona for the objects as per integrator persona mapping
    integrator_role=integrator_persona_mapping.get(object_type)

    # get warehouse, database, schema as object_type
    object_type=object_type[:-1]

    # Extract the object name (warehouse_name, database_name, schema_name) based on the object type
    if object_type == "schema":
      # Use "parent_db_name.schema_name" for schema
      parent_db_name = input_json.get("parent_db_name", "UNKNOWN").upper()
      schema_name = input_json.get("schema_name", "UNKNOWN").upper()
      object_name = f"{parent_db_name}_{schema_name}"
    else:
      object_name_key = f"{object_type}_name"
      object_name = input_json.get(object_name_key, "UNKNOWN").upper()
    
    ## get unique ro and rw roles and their respective grants from functional roles as per the object type
    ro_rw_roles_with_grants=get_unique_roles(functional_roles, object_name, ENV)

    ## Explicitly adding integrator persona for object type wh, db and schema
    if object_type!='role':
        access_roles=input_json.get("access_roles", [])
    else:
        access_roles=input_json.get("access_roles_alias",[])
        if not isinstance(access_roles, list):
            raise Exception(f'The {access_roles} is not a list. Change access_roles_alias to a list variable!! For eg: ["ALL_SCH_READ"]')
    
    if integrator_role is not None:
        access_roles.append(data_integrator)

    for access_role in access_roles:
        persona=None
        if object_type!='role':
            # It doesn't matter where the persona role type is present in the order
            for key,val in persona_mapping.items():
                if key.lower() in access_role.lower():
                    persona=val
                    break

            if not persona:
                print(f"Warning: No persona found for role suffix '{persona}' in access role '{access_role}' for object type '{object_type}' and object name '{object_name}")
                continue  # Skip if persona not found
        else:
            ## Assuming the person role to be equal to access role
            persona=access_role

        # Find matching persona in the functional roles and enrich the access roles
        mapping_sch_objects={}
        matched = False
        for role, mappings in functional_roles.items():
            # Changing the condition such that Proc_Data_Engineer and Data_Engineer are fully compared without object type in mapping json
            parts = role.split("_")
            new_role = "_".join(parts[:-1])
            if persona==new_role:
                for mapping in mappings:
                    # Dynamically update the tech_role with the object name
                    dynamic_tech_role = mapping["tech_role"].replace("$OBJECTNAME", object_name).replace('$ENV',ENV)
                   
                    if object_type!="role":
                        enriched_access_roles.append({
                            "access_role": access_role,
                            "tech_role": dynamic_tech_role,
                            "grants": mapping["grants"]
                        })
                    else:
                        enriched_access_roles.append({
                            "access_role": input_json.get("aad_group_name"),
                            "tech_role": dynamic_tech_role,
                            "grants": mapping["grants"]
                        })
                        
                matched = True
                break
        if not matched:
            print(f"Warning: No match found for access role '{access_role}' with persona '{persona}'")

    if object_type!='role':
        input_json["access_roles"] = enriched_access_roles
    else:
        input_json["access_roles_alias"]=enriched_access_roles
    if object_type == "schema":
        input_json["schema_object_related_privileges"]=objects_in_schema_json
    input_json['unique_roles_ro_rw']=ro_rw_roles_with_grants

    if object_type== "catalog_integration":
        if type(input_json.get("catalog_namespace"))==str:
            input_json["catalog_namespace"]=[input_json.get("catalog_namespace")]
        input_json=redefine_catalog_integration_access_roles(input_json)
    
    return input_json

def check_skipped_objects(skip_folders, folder_name):
    """Validate the to-be skipped folders and check if the folder matches with skip_folders"""
    for i in skip_folders:
        if i in folder_name:
            return True

    return False

def add_tags_to_input_json(input_json, tag_reference):
    """Add tags as per the tag reference json to the input json"""
    tags={}

    for k,v in tag_reference.items():
        if v in input_json.keys() and '$val' not in v:
            tags[k]=input_json[v]
        elif v not in input_json.keys() and '$val' in v:
            tags[k]=v.replace('$val','')

    input_json['tags']=tags
    return input_json

def process_files(base_folder,objects_in_schema_path, reference_json_path, output_folder, skip_objects, git_file_diff, tag_references):
    """Process the input JSON files, enrich access roles, and save the enriched files."""
    
    final_file_diff=[]

    bkp_output_folder=output_folder

    # Load the reference JSON data
    with open(reference_json_path, "r") as ref_file:
        reference_json = json.load(ref_file)

    with open(objects_in_schema_path,"r") as sch_obj_file:
        objects_in_schema_json=json.load(sch_obj_file)

    
    for file in git_file_diff:
        #Get the object type from folder name (e.g., 'warehouse', 'database', 'schema')
        object_type = file.split('/')[0]
        folder = os.path.join(base_folder,object_type)
    
        filename=file.split('/')[1]

        ## Need to skip the files if the roles for admin files is found
        if object_type.lower()=='roles' and filename.replace('.json','').upper() in admin_roles_list:
            print(f"Warning! The {filename} is an admin role, thus skipping it.")
            continue
        ## Need to skip the data_shares folder
        if object_type.lower() == "data_shares":
            print(f"Warning! The {filename} is under data_shares object. So we're ignoring it")
            continue
               

        # Process each JSON file in the input folder
        if os.path.exists(folder):
            if filename.endswith(".json"):
                # Load the input JSON
                # with open(os.path.join(base_folder,file), "r") as input_file:
                #     input_json = json.load(input_file)
                
                # Load the input JSON
                input_file_path = os.path.join(base_folder, file)

                print(f"[DEBUG] Processing git diff entry: {file}", flush=True)
                print(f"[DEBUG] Resolved object_type: {object_type}", flush=True)
                print(f"[DEBUG] Resolved filename: {filename}", flush=True)
                print(f"[DEBUG] Full input file path: {input_file_path}", flush=True)

                try:
                    with open(input_file_path, "r") as input_file:
                        raw_json_content = input_file.read()

                    print(f"[DEBUG] Successfully read file: {input_file_path}", flush=True)
                    print(f"[DEBUG] File size in chars: {len(raw_json_content)}", flush=True)

                    try:
                        input_json = json.loads(raw_json_content)
                    except json.JSONDecodeError as json_err:
                        print("[ERROR] Failed to parse JSON file.", flush=True)
                        print(f"[ERROR] File path: {input_file_path}", flush=True)
                        print(f"[ERROR] JSON error message: {json_err.msg}", flush=True)
                        print(f"[ERROR] JSON error line: {json_err.lineno}", flush=True)
                        print(f"[ERROR] JSON error column: {json_err.colno}", flush=True)
                        print(f"[ERROR] JSON error char position: {json_err.pos}", flush=True)

                        lines = raw_json_content.splitlines()
                        error_line_index = json_err.lineno - 1

                        print("[ERROR] JSON context around failure:", flush=True)
                        for idx in range(max(0, error_line_index - 3), min(len(lines), error_line_index + 4)):
                            marker = ">>>" if idx == error_line_index else "   "
                            print(f"{marker} line {idx + 1}: {lines[idx]}", flush=True)

                        raise

                except FileNotFoundError:
                    print(f"[ERROR] File not found while processing: {input_file_path}", flush=True)
                    raise
                except Exception as err:
                    print(f"[ERROR] Unexpected error while reading/parsing file: {input_file_path}", flush=True)
                    print(f"[ERROR] Exception type: {type(err).__name__}", flush=True)
                    print(f"[ERROR] Exception details: {err}", flush=True)
                    raise                


                ## Validate if the input json passed is of type product or is from source system
                if "enterprise_or_func_subgrp_name" in input_json.keys():
                    product_key=input_json.get("enterprise_or_func_subgrp_name",None) if input_json.get("enterprise_or_func_subgrp_name",None) is not None else "other"
                    product_key=product_key.lower()
                    input_json_changed=input_json.copy()
                    tag_per_object_type=tag_references.get(object_type[:-1].upper(),None)
                else:
                    ## Source system input json changes: 1. Use src_sys_name as the state file key separator
                    ## 2. Map the product keys with src_system similar to prd keys
                    product_key=input_json.get("src_sys_name",None) if input_json.get("src_sys_name",None) is not None else "other"
                    product_key=product_key.lower()
                    tag_per_object_type=tag_references.get("SRC_"+object_type[:-1].upper(),None)
                    input_json_changed=map_src_system_keys_with_prd_keys(input_json, os.path.join(base_folder,file),object_type)
                
                input_json_changed_critical_keys=map_critical_keys_in_input_json(input_json_changed,os.path.join(base_folder,file),object_type)
                input_json=input_json_changed_critical_keys
                
                if product_key not in product_key_list:
                    if len(product_key_list)==0:
                        product_key_list.append(product_key)
                    else:
                        product_key_list.append(product_key)
                        if operation.upper()=="VALIDATE":
                            raise Exception(f"There are too many product keys included in this PR\nHere is the list of product keys that are available: {product_key_list}")
                        
                output_subfolder = os.path.join(f"{output_folder}/{product_key}", object_type)
                # Save the enriched JSON to the appropriate subfolder in output
                enriched_filename = f"enriched_{filename}"
                enriched_file_path = os.path.join(output_subfolder, enriched_filename)

                if "DEPLOY" in operation.upper() and product_key.upper()!=product_key_deploy.upper():
                    continue
                elif "DEPLOY" in operation.upper() and product_key.upper()==product_key_deploy.upper():
                    final_file_diff.append(enriched_file_path)


                if check_skipped_objects(skip_objects, folder):
                    ## No access role in the json object, thus passing the json as it is.
                    enriched_json=input_json                    
                else:
                    # Enrich access roles
                    enriched_json = enrich_access_roles(input_json, reference_json, object_type, objects_in_schema_json)

                ## Adding tags per object type
                if tag_per_object_type is not None:
                    enriched_json=add_tags_to_input_json(enriched_json,tag_per_object_type)
                else:
                    enriched_json["tags"]={}

                print(f"Enriched json => {enriched_json}", flush=True)
                # Create the corresponding subfolder in the output folder
                os.makedirs(output_subfolder, exist_ok=True)

                if not os.path.exists(enriched_file_path):
                    with open(enriched_file_path, "w") as output_file:
                        json.dump(enriched_json, output_file, indent=4)
                
                    print(f"Enriched file saved at: {enriched_file_path}")
                elif os.path.exists(enriched_file_path):
                    print(f"Skipping the file as it is already available, thus skipping re-creation for file {enriched_file_path}")
                    continue
        else:
            print(f"No file found at: {folder}")

    if operation.upper()=="VALIDATE":
        with open( os.path.join(bkp_output_folder, "productkey.txt"),"w") as f:
            f.write("\n".join(product_key_list))
    

    return final_file_diff

def check_files_for_diff(git_file_diff :str):
    if git_file_diff is None or git_file_diff.strip()=="":
        git_file_diff=[]
    else:
        git_file_diff=git_file_diff.split('\n')

    ## remove files other than .json
    modify_git_file_diff=[]
    for file in git_file_diff:
        if file.lower().endswith('.json'):
            ## Ignore tag.json if it is present in git files diff
            if 'tag.json' in file:
                print(f"Skipping file tag.json as it need not be processed by jsonpreprocess.py")
                continue
            modify_git_file_diff.append(file)
    return modify_git_file_diff


# Example usage:
base_folder = sys.argv[2]
operation = sys.argv[3]
output_folder = sys.argv[1]+'output'
existing_files_git=product_key_deploy=None
rerun_for_existing_files=False
git_file_diff_env_var = os.getenv('CODEBUILD_FILES_DIFF')
git_file_diff=check_files_for_diff(git_file_diff_env_var)
print("The files passed from git_file_diff are :" ,git_file_diff)

if "VALIDATE" in operation.upper().strip():
    existing_files=os.getenv('TF_VAR_EXISTING_FILES')
    print(f"The existing files passed are: {existing_files}")
    existing_files_git=check_files_for_diff(existing_files)
    rerun_for_existing_files=True

## for deploy- reading the product key from the file
if "DEPLOY" in operation.upper().strip():
    product_key_reference_file=sys.argv[4]
    with open(product_key_reference_file,"r") as f:
        product_key_deploy=f.read().strip()

## Tag creation
tag_mapping_json=sys.argv[1]+env+'/tag_mapping.json'
tag_json=os.path.join(base_folder,'tags/tag.json')

with open(tag_mapping_json,"r") as tag_mapping_json_file:
    tag_references=json.load(tag_mapping_json_file)

with open(tag_json,"r") as tag_json_file:
    tags_creation=json.load(tag_json_file)

## Creating a file for terraform to create key tags
# print(f"The following tags will be created: {tags_creation}")

tags_output=os.path.join(output_folder,"tags")
os.makedirs(tags_output, exist_ok=True)
with open(os.path.join(tags_output,"tag_config_file.json"),"w") as f:
    f.write(json.dumps(tags_creation))

print(f"The file ",os.path.join(tags_output,"tag_config_file.json")," is created to create tags.")


if len(git_file_diff)>0:
    reference_json_path = sys.argv[1]+env+'/reference_json.json'
    objects_in_schema_path=sys.argv[1]+env+'/schema_privileges_reference.json'
    
    skip_objects = ['oauth','database','tags'] # Let's have it as json file to skip the Snowflake to-be provisioned objects so that it would cater for future objects as well.

    final_file_diff=process_files(base_folder,objects_in_schema_path, reference_json_path, output_folder, skip_objects, git_file_diff,tag_references)
    
    if "DEPLOY" in operation.upper():
        # os.environ["NEW_DEPLOY_CODEBUILD_FILES_DIFF"]="\n".join(final_file_diff)

        env_files_var_path=os.path.join(sys.argv[1]+env,"new_codebuild_file_diff.txt")
        with open(env_files_var_path,"w") as f:
            f.write(str("\n".join(final_file_diff)))

        #print("The code file differences is updated to the below files: ", final_file_diff)

    # if rerun_for_existing_files:
    #     with open( os.path.join(output_folder, "productkey.txt"),"r") as f:
    #         product_key_deploy=f.read().strip()
    #     operation='DEPLOY'
    #     final_file_diff=process_files(base_folder,objects_in_schema_path, reference_json_path, output_folder, skip_objects, existing_files_git ,tag_references )      

    if rerun_for_existing_files:
        print("[DEBUG] Starting rerun for existing files in DEPLOY mode after VALIDATE.", flush=True)
        print(f"[DEBUG] Existing files list: {existing_files_git}", flush=True)

        product_key_file_path = os.path.join(output_folder, "productkey.txt")
        print(f"[DEBUG] Reading product key from: {product_key_file_path}", flush=True)

        with open(product_key_file_path, "r") as f:
            product_key_deploy = f.read().strip()

        print(f"[DEBUG] Product key selected for deploy rerun: {product_key_deploy}", flush=True)

        operation = 'DEPLOY'

        final_file_diff = process_files(
            base_folder,
            objects_in_schema_path,
            reference_json_path,
            output_folder,
            skip_objects,
            existing_files_git,
            tag_references
        )    

else:
    if "DEPLOY" in operation.upper():
        
        ## Creating dummy new_code_build_file_diff
        env_files_var_path=os.path.join(sys.argv[1]+env,"new_codebuild_file_diff.txt")
        with open(env_files_var_path,"w") as f:
            f.write("")
    else:
        os.makedirs(output_folder, exist_ok=True)
        ## Creating dummy productkey.txt
        with open( os.path.join(output_folder, "productkey.txt"),"w") as f:
            f.write("")

    
    print("No file differences found!! The variable CODEBUILD_FILES_DIFF is either empty or contains only tag.json!!!")