-- Set the environment variable
SET ENV = 'DEV';

-- Set the warehouse name variable
SET wh_name = UPPER($ENV || '_DTD_MIW_PIPLN_SNF_01_WH');

-- Set the Database name variable
SET db_name = UPPER($ENV || '_DTD_MIW_DB');

--DROP WAREHOUSE 
--DROP WAREHOUSE IDENTIFIER($wh_name);

--DROP Database
--DROP DATABASE IDENTIFIER($db_name);

-- Create Warehouse
CREATE WAREHOUSE IF NOT EXISTS IDENTIFIER($wh_name)
WITH 
  WAREHOUSE_SIZE = 'SMALL',
  AUTO_SUSPEND = 600,
  AUTO_RESUME = TRUE,
  MIN_CLUSTER_COUNT = 1,
  MAX_CLUSTER_COUNT = 2,
  SCALING_POLICY = 'ECONOMY',
  INITIALLY_SUSPENDED = TRUE,
  STATEMENT_TIMEOUT_IN_SECONDS = 3600;


  
-- Create Database

CREATE DATABASE IF NOT EXISTS IDENTIFIER($db_name);

-- Set the schema name variable
SET sc_name = UPPER($ENV || '_DTD_MIW_DB.FDP_SF_OBJECTS_METADATA_GBL_CUR_SC');

-- Create Schema

CREATE SCHEMA IF NOT EXISTS IDENTIFIER($sc_name);

-- CONTEXT SETUP

USE WAREHOUSE IDENTIFIER($wh_name);
USE DATABASE IDENTIFIER($db_name);
USE SCHEMA IDENTIFIER($sc_name);


--PREREQUISITES PROCEDURE

CREATE OR REPLACE PROCEDURE CREATE_PREREQUISITES("ENV" VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    wh_name VARCHAR DEFAULT UPPER(env || ''_DTD_MIW_PIPLN_SNF_01_WH'');
    db_name VARCHAR DEFAULT UPPER(env || ''_DTD_MIW_DB'');
    schema_name VARCHAR DEFAULT ''FDP_SF_OBJECTS_METADATA_GBL_CUR_SC'';
    var_dbpipln VARCHAR DEFAULT UPPER(''MINERVA_DTD_MIW_SNF_DBPIPLN_'' || env );
    var_whadmin VARCHAR DEFAULT UPPER(''MINERVA_DTD_MIW_SNF_WHADMIN_'' || env );
    var_dbadmin VARCHAR DEFAULT UPPER(''MINERVA_DTD_MIW_SNF_DBADMIN_'' || env );
    var_oauthadmin VARCHAR DEFAULT UPPER(''MINERVA_DTD_MIW_SNF_OAUTHADMIN_'' || env );
	var_accntadmin VARCHAR DEFAULT UPPER(''MINERVA_DTD_MIW_SNF_ACCNTADMIN_'' || env );
	var_GLSBRKR VARCHAR DEFAULT UPPER(''MINERVA_DTD_MIW_SNF_GLSBRKR_'' || env );	
    role_exists BOOLEAN;
    query VARCHAR;
    table_creation_error VARCHAR DEFAULT NULL;
    grant_error VARCHAR DEFAULT NULL;
BEGIN
        
    -- Create Tables
    BEGIN
        EXECUTE IMMEDIATE ''CREATE TABLE IF NOT EXISTS '' || db_name || ''.'' || schema_name || ''.DATABASE_METADATA_TBL (INTAKE_ID VARCHAR(16777216),DATABASE_ID VARCHAR(16777216),DATABASE_NAME VARCHAR(16777216),PR_ID VARCHAR(16777216),ACCESS_ROLES VARCHAR(16777216),DATA_FIRST_CLASSIFICATION VARCHAR(16777216),DESCRIPTION VARCHAR(16777216),DB_TYPE VARCHAR(16777216),ENT_OR_FUNC_NAME VARCHAR(16777216),enterprise_or_func_subgrp_name VARCHAR(16777216),DATA_LEADER VARCHAR(16777216),CREATED_TIMESTAMP TIMESTAMP_NTZ(9))'';
		
        EXECUTE IMMEDIATE ''CREATE TABLE IF NOT EXISTS '' || db_name || ''.'' || schema_name || ''.GRANTS_LOOKUP_TBL (PERSONA_ROLE_TYPE VARCHAR(16777216),ASSOCIATED_TECH_ROLE VARCHAR(16777216),ASSOCIATED_TECH_ROLE_TYPE VARCHAR(16777216),OBJECT_TYPE VARCHAR(16777216),OBJECT_ATTRIBUTE VARCHAR(16777216),PRIVILEGE_LIST ARRAY)'';
		
        EXECUTE IMMEDIATE ''CREATE TABLE IF NOT EXISTS '' || db_name || ''.'' || schema_name || ''.MIW_PROVISIONING_LOG_TBL (PR_ID VARCHAR(16777216),PR_STATUS VARCHAR(16777216),SOURCE_BRANCH_OR_FORK VARCHAR(16777216),OBJECTS_PROVISIONED_LIST ARRAY,CREATED_AT TIMESTAMP_NTZ(9),UPDATED_AT TIMESTAMP_NTZ(9),MERGED_AT TIMESTAMP_NTZ(9),CREATED_TIMESTAMP TIMESTAMP_NTZ(9),UPDATED_TIMESTAMP TIMESTAMP_NTZ(9))'';
		
        EXECUTE IMMEDIATE ''CREATE TABLE IF NOT EXISTS '' || db_name || ''.'' || schema_name || ''.OAUTH_METADATA_TBL (INTAKE_ID VARCHAR(16777216),PS_ID VARCHAR(16777216),PR_ID VARCHAR(16777216),PS_ACCOUNT_ID VARCHAR(16777216),PS_EMAIL_ID VARCHAR(16777216),PS_ACCOUNT_OWNER VARCHAR(16777216),LEAD_ENGINEER VARCHAR(16777216),DATA_PRODUCT_MANAGER VARCHAR(16777216),GOVERNANCE_AND_ACCESS_LEAD VARCHAR(16777216),AAD_GROUP VARCHAR(16777216),AAD_GROUP_OWNER VARCHAR(16777216),ATTACHED_SUB_UUID VARCHAR(16777216),PURPOSE VARCHAR(16777216),CONSUMPTION_STACK VARCHAR(16777216),ENT_OR_FUNC_NAME VARCHAR(16777216),enterprise_or_func_subgrp_name VARCHAR(16777216),SUBJECT_OR_PROD_NAME VARCHAR(16777216),CREATED_TIMESTAMP TIMESTAMP_NTZ(9))'';
		
        EXECUTE IMMEDIATE ''CREATE TABLE IF NOT EXISTS '' || db_name || ''.'' || schema_name || ''.RESOURCE_MONITOR_METADATA_TBL (RM_ID VARCHAR(16777216),RM_NAME VARCHAR(16777216),PR_ID VARCHAR(16777216),ASSOCIATED_WH VARCHAR(16777216),CREDIT_QUOTA VARCHAR(16777216),RM_TYPE VARCHAR(16777216),RM_FREQUENCY VARCHAR(16777216),ALERT_SUBSCRBR_LIST VARCHAR(16777216),ENT_OR_FUNC_NAME VARCHAR(16777216),enterprise_or_func_subgrp_name VARCHAR(16777216),DATA_LEADER VARCHAR(16777216),CREATED_TIMESTAMP TIMESTAMP_NTZ(9))'';
		
        EXECUTE IMMEDIATE ''CREATE TABLE IF NOT EXISTS '' || db_name || ''.'' || schema_name || ''.ROLES_METADATA_TBL (INTAKE_ID VARCHAR(16777216),ROLE_ID VARCHAR(16777216),ROLE_NAME VARCHAR(16777216),PR_ID VARCHAR(16777216),ROLE_TYPE VARCHAR(16777216),ROLE_PURPOSE VARCHAR(16777216),PARENT_ROLE VARCHAR(16777216),ROLE_OWNER VARCHAR(16777216),ROLE_OWNER_EMAIL VARCHAR(16777216),ENT_OR_FUNC_NAME VARCHAR(16777216),enterprise_or_func_subgrp_name VARCHAR(16777216),DATA_LEADER VARCHAR(16777216),GOVERNANCE_AND_ACCESS_LEAD VARCHAR(16777216),CREATED_TIMESTAMP TIMESTAMP_NTZ(9),ACCESS_ROLES_ALIAS VARCHAR(16777216))'';
		
        EXECUTE IMMEDIATE ''CREATE TABLE IF NOT EXISTS '' || db_name || ''.'' || schema_name || ''.SCHEMA_METADATA_TBL (INTAKE_ID VARCHAR(16777216),SCHEMA_ID VARCHAR(16777216),SCHEMA_NAME VARCHAR(16777216),PR_ID VARCHAR(16777216),PARENT_DB_NAME VARCHAR(16777216),ACCESS_ROLES VARCHAR(16777216),DATA_FIRST_CLASSIFICATION VARCHAR(16777216),DESCRIPTION VARCHAR(16777216),DATA_PRODUCT_MANAGER VARCHAR(16777216),LEAD_ENGINEER VARCHAR(16777216),GOVERNANCE_AND_ACCESS_LEAD VARCHAR(16777216),DATA_RETENTION_IN_DAYS NUMBER(38,0),ATTACHED_EXTERNAL_VOLUME VARCHAR(16777216),SCHEMA_CATALOG VARCHAR(16777216),SUBJECT_OR_PROD_NAME VARCHAR(16777216),PRODUCT_COST_ID VARCHAR(16777216),CREATED_TIMESTAMP TIMESTAMP_NTZ(9))'';
		
        EXECUTE IMMEDIATE ''CREATE TABLE IF NOT EXISTS '' || db_name || ''.'' || schema_name || ''.WAREHOUSE_METADATA_TBL (INTAKE_ID VARCHAR(16777216),WAREHOUSE_ID VARCHAR(16777216) NOT NULL,WAREHOUSE_NAME VARCHAR(16777216),PR_ID VARCHAR(16777216),ACCESS_ROLES VARCHAR(16777216),DESCRIPTION VARCHAR(16777216),WAREHOUSE_SIZE VARCHAR(16777216),WAREHOUSE_COUNTER NUMBER(38,0),AUTO_SUSPEND_IN_SECONDS NUMBER(38,0),MIN_CLUSTER_COUNT NUMBER(38,0),MAX_CLUSTER_COUNT NUMBER(38,0),SCALING_POLICY VARCHAR(16777216),MONTHLY_CREDIT_LIMIT NUMBER(38,0),WAREHOUSE_TYPE VARCHAR(16777216),ATTACHED_RESOURCE_MONITOR VARCHAR(16777216),ALERT_SUBSCRBR_LIST VARCHAR(16777216),WORKLOAD_CATEGORY VARCHAR(16777216),CONSUMPTION_STACK VARCHAR(16777216),ENT_OR_FUNC_NAME VARCHAR(16777216),enterprise_or_func_subgrp_name VARCHAR(16777216),DATA_LEADER VARCHAR(16777216),CREATED_TIMESTAMP TIMESTAMP_NTZ(9))'';
		
        EXECUTE IMMEDIATE ''CREATE TABLE IF NOT EXISTS '' || db_name || ''.'' || schema_name || ''.PERSONA_MAPPING_TBL (ID NUMBER(38,0) autoincrement start 1 increment 1 noorder,	PERSONA_ROLE VARCHAR(8),	PERSONA_ROLE_DESCRIPTION VARCHAR(100))'';
		
		EXECUTE IMMEDIATE ''CREATE TABLE IF NOT EXISTS '' || db_name || ''.'' || schema_name || ''.STORAGE_INTEGRATION_METADATA_TBL(STORAGE_INTEGRATION_ID NUMBER ,STORAGE_INTEGRATION_NAME  VARCHAR(16777216),PR_ID  VARCHAR(16777216),INTAKE_ID  VARCHAR(16777216),ACCESS_ROLES  VARCHAR(16777216),ENT_OR_FUNC_NAME  VARCHAR(16777216),enterprise_or_func_subgrp_name  VARCHAR(16777216),DATA_LEADER  VARCHAR(16777216),DATA_FIRST_CLASSIFICATION  VARCHAR(16777216),STAGE_TYPE  VARCHAR(16777216),STORAGE_ROLE_ARN  VARCHAR(16777216),ALLOWED_STORAGE_LOCATIONS  VARCHAR(16777216),BLOCKED_STORAGE_LOCATIONS  VARCHAR(16777216),DESCRIPTION  VARCHAR(16777216),CREATED_TIMESTAMP  TIMESTAMP_NTZ(9))'';
		
    EXCEPTION WHEN OTHER THEN
         RETURN ''Error creating tables: '' || SQLERRM;
    END;
    
   -- IF table_creation_error IS NOT NULL THEN
   --     RETURN ''Error creating tables: '' || table_creation_error;
    -- END IF;
    

    -- VALIDATE_DATABASE
    BEGIN
        EXECUTE IMMEDIATE ''CREATE OR REPLACE FUNCTION '' || db_name || ''.'' || schema_name || ''.VALIDATE_DATABASE(RESOURCE_NAME VARCHAR(16777216), RULE_TYPE VARCHAR(16777216), RULE_VALUE VARCHAR(16777216) DEFAULT null) RETURNS BOOLEAN LANGUAGE SQL AS ''''
			CASE 
				WHEN rule_type = ''''''''suffix_check'''''''' THEN
					UPPER(resource_name) LIKE CONCAT(''''''''%'''''''', UPPER(rule_value))
				ELSE
					FALSE
			END
        '''''';
    EXCEPTION WHEN OTHER THEN
        RETURN ''Error creating function VALIDATE_DATABASE: '' || SQLERRM;
    END;
	
	--VALIDATE_ACCESSROLES
    BEGIN
        EXECUTE IMMEDIATE ''CREATE OR REPLACE FUNCTION '' || db_name || ''.'' || schema_name ||''.VALIDATE_ACCESSROLES(RULE_TYPE VARCHAR(16777216), RULE_VALUE VARCHAR(16777216) DEFAULT null)
		RETURNS BOOLEAN LANGUAGE SQL AS ''''
			CASE 
				WHEN rule_type = ''''''''access_roles_existence_check'''''''' THEN
				NOT EXISTS (
						SELECT 1 
						FROM '' || db_name || ''.'' || schema_name || ''.ROLES_METADATA_TBL
						WHERE UPPER(ROLE_NAME) = UPPER(rule_value)
					)
				ELSE
					FALSE
			END
        '''''';
    EXCEPTION WHEN OTHER THEN
        RETURN ''Error creating function VALIDATE_ACCESSROLES: '' || SQLERRM;
    END;
	
	--VALIDATE_GENERIC
    BEGIN
        EXECUTE IMMEDIATE ''CREATE OR REPLACE FUNCTION '' || db_name || ''.'' || schema_name || ''.VALIDATE_GENERIC(RESOURCE_NAME VARCHAR(16777216), RULE_TYPE VARCHAR(16777216)) RETURNS BOOLEAN LANGUAGE SQL AS ''''
			CASE 
				WHEN RULE_TYPE = ''''''''existence_check'''''''' THEN
					EXISTS (
						SELECT 1 
						FROM '' || db_name || ''.'' || schema_name || ''.DATABASE_METADATA_TBL
						WHERE UPPER(DATABASE_NAME) = UPPER(RESOURCE_NAME)
						UNION ALL
						SELECT 1 
						FROM '' || db_name || ''.'' || schema_name || ''.WAREHOUSE_METADATA_TBL
						WHERE UPPER(WAREHOUSE_NAME) = UPPER(RESOURCE_NAME)
						UNION ALL
						SELECT 1
						FROM  '' || db_name || ''.'' || schema_name || ''.SCHEMA_METADATA_TBL
						WHERE UPPER(SCHEMA_NAME) = UPPER(RESOURCE_NAME)
						UNION ALL
						SELECT 1
						FROM '' || db_name || ''.'' || schema_name || ''.ROLES_METADATA_TBL
						WHERE UPPER(ROLE_NAME) = UPPER(RESOURCE_NAME)
						UNION ALL
						SELECT 1
						FROM '' || db_name || ''.'' || schema_name || ''.OAUTH_METADATA_TBL
						WHERE UPPER(PS_ACCOUNT_ID) = UPPER(RESOURCE_NAME)
						UNION ALL
						SELECT 1
						FROM '' || db_name || ''.'' || schema_name || ''.STORAGE_INTEGRATION_METADATA_TBL
						WHERE UPPER(STORAGE_INTEGRATION_NAME) = UPPER(RESOURCE_NAME) 						
					)
				ELSE
					FALSE
			END
        '''''';
    EXCEPTION WHEN OTHER THEN
        RETURN ''Error creating function VALIDATE_GENERIC: '' || SQLERRM;
    END;
	
	--VALIDATE_SCHEMA
    BEGIN
        EXECUTE IMMEDIATE ''CREATE OR REPLACE FUNCTION '' || db_name || ''.'' || schema_name || ''.VALIDATE_SCHEMA(SCHEMA_NAME VARCHAR(16777216), RULE_TYPE VARCHAR(16777216), RULE_VALUE VARCHAR(16777216)) RETURNS BOOLEAN LANGUAGE SQL AS ''''
			CASE 
				WHEN RULE_TYPE = ''''''''seperator_count'''''''' THEN
					LENGTH(SCHEMA_NAME) - LENGTH(REPLACE(SCHEMA_NAME, ''''''''_'''''''', '''''''''''''''')) = RULE_VALUE::INTEGER
				ELSE
					FALSE
			END
        '''''';
    EXCEPTION WHEN OTHER THEN
        RETURN ''Error creating function VALIDATE_SCHEMA: '' || SQLERRM;
    END;
	
	--VALIDATE_WAREHOUSE
    BEGIN
        EXECUTE IMMEDIATE ''CREATE OR REPLACE FUNCTION '' || db_name || ''.'' || schema_name || ''.VALIDATE_WAREHOUSE(RESOURCE_NAME VARCHAR(16777216), RULE_TYPE VARCHAR(16777216), RULE_VALUE VARCHAR(16777216) DEFAULT null) RETURNS BOOLEAN LANGUAGE SQL AS ''''
			CASE 
				WHEN rule_type = ''''''''seperator_count'''''''' THEN
					LENGTH(resource_name) - LENGTH(REPLACE(resource_name, ''''''''_'''''''', '''''''''''''''')) = CAST(rule_value AS INT)
				ELSE
					FALSE
			END

        '''''';
    EXCEPTION WHEN OTHER THEN
        RETURN ''Error creating function VALIDATE_DATABASE: '' || SQLERRM;
    END;
	
	BEGIN
    
    EXECUTE IMMEDIATE ''
    CREATE OR REPLACE PROCEDURE '' || db_name || ''.'' || schema_name ||''.VALIDATE_RESOURCES(
        "INPUT_JSON" VARCHAR(16777216)
    )
    RETURNS VARCHAR(16777216)
    LANGUAGE JAVASCRIPT
    EXECUTE AS CALLER
    AS
    \\''
    try {
        var input = JSON.parse(arguments[0]);
        var output = { "warehouse": [], "database": [], "schema": [], "oauth": [],"persona": [], "storage_integration" : [] };

        function getValidationQuery(objectType, resourceName, ruleType, ruleValue) {
            if (objectType === "WAREHOUSE") {
                switch (ruleType) {
                    case "existence_check":
                        return {
                            query: "SELECT VALIDATE_GENERIC(?, ?)", 
                            params: [resourceName, "existence_check"],
                            error: "warehouse exists."
                        };
                    case "seperator_count":
                        return {
                            query: "SELECT VALIDATE_WAREHOUSE(?, ?, ?)", 
                            params: [resourceName, "seperator_count",ruleValue],
                            error: "expected " +ruleValue+ " separators but validation failed."
                        };	                        
                    case "access_roles_existence_check":
                        return {
                            query: "SELECT VALIDATE_ACCESSROLES(?, ?)", 
                            params: ["access_roles_existence_check", ruleValue],
                            error: "access role " +ruleValue+ " is  not found."
                        };
                    default:
                        throw new Error("Unsupported rule type: " + ruleType);
                }
            } else if (objectType === "DATABASE") {
                switch (ruleType) {
                    case "existence_check":
                        return {
                            query: "SELECT VALIDATE_GENERIC(?, ?)", 
                            params: [resourceName, "existence_check"],
                            error: "database exists."
                        };
                    case "suffix_check":
                        return {
                            query: "SELECT VALIDATE_DATABASE(?, ?, ?)", 
                            params: [resourceName, "suffix_check",ruleValue],
                            error: "expected suffix " +ruleValue+ " not found."
                        };	                        
                    case "access_roles_existence_check":
                        return {
                            query: "SELECT VALIDATE_ACCESSROLES(?, ?)", 
                            params: ["access_roles_existence_check", ruleValue],
                            error: "access role " +ruleValue+ " is  not found."
                        };
                    default:
                        throw new Error("Unsupported rule type: " + ruleType);
                }
            } else if (objectType === "SCHEMA") {
                switch (ruleType) {
                    case "existence_check":
                        return {
                            query: "SELECT VALIDATE_GENERIC(?, ?)", 
                            params: [resourceName, "existence_check"],
                            error: "schema exists."
                        };
                    case "seperator_count":
                        return {
                            query: "SELECT VALIDATE_SCHEMA(?, ?, ?)", 
                            params: [resourceName, "seperator_count",ruleValue],
                            error: "expected "  +ruleValue+ " separators but validation failed."
                        };                        
                    case "access_roles_existence_check":
                        return {
                            query: "SELECT VALIDATE_ACCESSROLES(?, ?)", 
                            params: ["access_roles_existence_check", ruleValue],
                            error: "access role " +ruleValue+ " is  not found."
                        };
                    default:
                        throw new Error("Unsupported rule type: " + ruleType);
                }
            }else if (objectType === "PERSONA") {
                switch (ruleType) {
                    case "existence_check":
                        return {
                            query: "SELECT VALIDATE_GENERIC(?, ?)", 
                            params: [resourceName, "existence_check"],
                            error: "persona exists."
                        };                      
                    case "access_roles_existence_check":
                        return {
                            query: "SELECT VALIDATE_ACCESSROLES(?, ?)", 
                            params: ["access_roles_existence_check", ruleValue],
                            error: "access role " +ruleValue+ " is  not found."
                        };
                    default:
                        throw new Error("Unsupported rule type: " + ruleType);
                }
            } else if (objectType === "OAUTH") {
                switch (ruleType) {
                    case "existence_check":
                        return {
                            query: "SELECT VALIDATE_GENERIC(?, ?)", 
                            params: [resourceName, "existence_check"],
                            error: "oauth exists."
                        };                        
                    case "access_roles_existence_check":
                        return {
                            query: "SELECT VALIDATE_ACCESSROLES(?, ?)", 
                            params: ["access_roles_existence_check", ruleValue],
                            error: "access role " +ruleValue+ " is  not found."
                        };
                    default:
                        throw new Error("Unsupported rule type: " + ruleType);
                }
            } else if (objectType === "STORAGE_INTEGRATION") {
                switch (ruleType) {
                    case "existence_check":
                        return {
                            query: "SELECT VALIDATE_GENERIC(?, ?)", 
                            params: [resourceName, "existence_check"],
                            error: "storage integration exists."
                        };                        
                    case "access_roles_existence_check":
                        return {
                            query: "SELECT VALIDATE_ACCESSROLES(?, ?)", 
                            params: ["access_roles_existence_check", ruleValue],
                            error: "access role " +ruleValue+ " is  not found."
                        };
                    default:
                        throw new Error("Unsupported rule type: " + ruleType);
                }
            }else {
                throw new Error("Unsupported object type: " + objectType);
            }
        }

        function validateResource(objectType, resourceName, rules) {
            var errors = [];
            rules.forEach(function(rule) {
                var ruleType = Object.keys(rule)[0];
                var ruleValue = rule[ruleType] || null;

                try {
                    var validation = getValidationQuery(objectType, resourceName, ruleType, ruleValue);
                    var sqlQuery = validation.query;
                    var errorMessage = validation.error;

                    var stmt = snowflake.createStatement({ sqlText: sqlQuery, binds: validation.params });
                    var rs = stmt.execute();
                    if (rs.next()) {
                        var validationResult = rs.getColumnValue(1);
                        if (validationResult) {
                            errors.push({
                                "rule": ruleType,
                                "error": objectType + ":" + resourceName + ":" + ruleType + ":" + errorMessage
                            });
                        }
                    }
                } catch (err) {
                    errors.push({
                        "rule": ruleType,
                        "error": objectType + ":" + resourceName + ":" + ruleType + ":" + err.message
                    });
                }
            });
            return errors;
        }

        if (Array.isArray(input.warehouse)) {
            input.warehouse.forEach(function(wh) {
                var errors = validateResource("WAREHOUSE", wh.name, wh.rules);
                if (errors.length > 0) {
                    output.warehouse.push({ "name": wh.name, "errors": errors });
                }
            });
        }

        if (Array.isArray(input.database)) {
            input.database.forEach(function(db) {
                var errors = validateResource("DATABASE", db.name, db.rules);
                if (errors.length > 0) {
                    output.database.push({ "name": db.name, "errors": errors });
                }
            });
        }

        if (Array.isArray(input.schema)) {
            input.schema.forEach(function(sc) {
                var errors = validateResource("SCHEMA", sc.name, sc.rules);
                if (errors.length > 0) {
                    output.schema.push({ "name": sc.name, "errors": errors });
                }
            });
        }
        if (Array.isArray(input.persona)) {
            input.persona.forEach(function(pe) {
                var errors = validateResource("PERSONA", pe.name, pe.rules);
                if (errors.length > 0) {
                    output.persona.push({ "name": pe.name, "errors": errors });
                }
            });
        }	
        if (Array.isArray(input.oauth)) {
            input.oauth.forEach(function(oa) {
                var errors = validateResource("OAUTH", oa.name, oa.rules);
                if (errors.length > 0) {
                    output.oauth.push({ "name": oa.name, "errors": errors });
                }
            });
        }
        if (Array.isArray(input.storage_integration)) {
            input.storage_integration.forEach(function(si) {
                var errors = validateResource("STORAGE_INTEGRATION", si.name, si.rules);
                if (errors.length > 0) {
                    output.storage_integration.push({ "name": si.name, "errors": errors });
                }
            });
        }		

        return JSON.stringify(output);

    } catch (err) {
        return JSON.stringify({ "error": "Exception occurred: " + err.message });
    }
    \\'';
    '';
    EXCEPTION WHEN OTHER THEN
        RETURN ''Error creating function VALIDATE_RESOURCES: '' || SQLERRM;
    END;

   
    -- Grants to Admin roles
    BEGIN
        EXECUTE IMMEDIATE ''GRANT USAGE ON DATABASE '' || db_name || '' TO ROLE '' || var_dbpipln;
        EXECUTE IMMEDIATE ''GRANT USAGE ON SCHEMA '' || db_name || ''.'' || schema_name || '' TO ROLE '' || var_dbpipln;
        EXECUTE IMMEDIATE ''GRANT SELECT ON ALL TABLES IN SCHEMA '' || db_name || ''.'' || schema_name || '' TO ROLE '' || var_dbpipln;
        EXECUTE IMMEDIATE ''GRANT USAGE ON WAREHOUSE '' || wh_name || '' TO ROLE '' || var_dbpipln;
        EXECUTE IMMEDIATE ''GRANT INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA '' || db_name || ''.'' || schema_name || '' TO ROLE '' || var_dbpipln;
        EXECUTE IMMEDIATE ''GRANT CREATE FUNCTION ON SCHEMA '' || db_name || ''.'' || schema_name || '' TO ROLE '' || var_dbpipln;
        EXECUTE IMMEDIATE ''GRANT CREATE PROCEDURE ON SCHEMA '' || db_name || ''.'' || schema_name || '' TO ROLE '' || var_dbpipln;
        EXECUTE IMMEDIATE ''GRANT CREATE TABLE ON SCHEMA '' || db_name || ''.'' || schema_name || '' TO ROLE '' || var_dbpipln;
        EXECUTE IMMEDIATE ''GRANT USAGE ON PROCEDURE '' || db_name || ''.'' || schema_name || ''.'' || ''VALIDATE_RESOURCES(VARCHAR) TO ROLE '' || var_dbpipln;
        EXECUTE IMMEDIATE ''GRANT USAGE ON FUNCTION '' || db_name || ''.'' || schema_name || ''.'' || ''VALIDATE_ACCESSROLES(VARCHAR, VARCHAR) TO ROLE '' || var_dbpipln;
        EXECUTE IMMEDIATE ''GRANT USAGE ON FUNCTION '' || db_name || ''.'' || schema_name || ''.'' || ''VALIDATE_DATABASE(VARCHAR, VARCHAR, VARCHAR) TO ROLE '' || var_dbpipln;
        EXECUTE IMMEDIATE ''GRANT USAGE ON FUNCTION '' || db_name || ''.'' || schema_name || ''.'' || ''VALIDATE_GENERIC(VARCHAR, VARCHAR) TO ROLE '' || var_dbpipln;
        EXECUTE IMMEDIATE ''GRANT USAGE ON FUNCTION '' || db_name || ''.'' || schema_name || ''.'' || ''VALIDATE_SCHEMA(VARCHAR, VARCHAR, VARCHAR) TO ROLE '' || var_dbpipln;
        EXECUTE IMMEDIATE ''GRANT USAGE ON FUNCTION '' || db_name || ''.'' || schema_name || ''.'' || ''VALIDATE_WAREHOUSE(VARCHAR, VARCHAR, VARCHAR) TO ROLE '' || var_dbpipln;
        EXECUTE IMMEDIATE ''GRANT ROLE ACCOUNTADMIN TO ROLE '' || var_whadmin;		
		EXECUTE IMMEDIATE ''GRANT CREATE DATABASE ON ACCOUNT TO ROLE '' || var_dbadmin;
        EXECUTE IMMEDIATE ''GRANT CREATE ROLE ON ACCOUNT TO ROLE '' || var_dbadmin;
        EXECUTE IMMEDIATE ''GRANT MANAGE GRANTS ON ACCOUNT TO ROLE '' || var_dbadmin;
        EXECUTE IMMEDIATE ''GRANT CREATE INTEGRATION ON ACCOUNT TO ROLE '' || var_dbadmin;				
        EXECUTE IMMEDIATE ''GRANT CREATE USER ON ACCOUNT TO ROLE '' || var_oauthadmin;
        EXECUTE IMMEDIATE ''GRANT MANAGE GRANTS ON ACCOUNT TO ROLE '' || var_oauthadmin;
        EXECUTE IMMEDIATE ''GRANT ROLE ACCOUNTADMIN TO ROLE '' || var_accntadmin;
        EXECUTE IMMEDIATE ''GRANT ROLE ACCOUNTADMIN TO ROLE '' || var_GLSBRKR;	
		EXECUTE IMMEDIATE ''GRANT ROLE '' || var_oauthadmin || '' TO ROLE useradmin'' ;
		EXECUTE IMMEDIATE ''GRANT ROLE '' || var_dbadmin || '' TO ROLE SYSADMIN'' ;
		EXECUTE IMMEDIATE ''GRANT ROLE '' || var_dbpipln || '' TO ROLE SYSADMIN'' ;		
        EXECUTE IMMEDIATE ''GRANT IMPORT SHARE ON ACCOUNT TO ROLE '' || var_dbadmin;        
    EXCEPTION WHEN OTHER THEN
        -- grant_error := SQLERRM; 
        RETURN ''Error on grants: '' || SQLERRM;

    END;
    
    
    RETURN ''Prerequisites created successfully'';
EXCEPTION WHEN OTHER THEN
    RETURN ''Unexpected error: '' || SQLERRM;
END;
';


--Call 

CALL CREATE_PREREQUISITES($ENV);



