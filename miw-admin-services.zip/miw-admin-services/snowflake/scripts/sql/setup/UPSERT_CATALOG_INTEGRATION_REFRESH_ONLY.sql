USE ROLE MINERVA_DTD_MIW_ACCNTADMIN_SNF_DEV;

USE WAREHOUSE DEV_DTD_MIW_PIPLN_SNF_01_WH;

USE DATABASE DEV_DTD_MIW_DB;

USE SCHEMA FDP_SF_OBJECTS_METADATA_GBL_CUR_SC;

create or replace procedure UPSERT_CATALOG_INTEGRATION_REFRESH_ONLY(
  NAME                      STRING,
  VAR_CATALOG_SOURCE        STRING,  
  VAR_TABLE_FORMAT          STRING,  
  EACH_VALUE_NAMESPACE      STRING,  

  VAR_REST_CATALOG_URI      STRING,
  VAR_REST_CATALOG_NAME     STRING,
  VAR_REST_CATALOG_API_TYPE STRING,  
  LOCAL_REVAL_ENABLE_VENDED STRING,  

  VAR_REST_AUTH_TYPE        STRING,  
  VAR_REST_AUTH_IAM_ROLE    STRING,
  VAR_REST_AUTH_SIGN_REGION STRING,

  VAR_ICEBERG_ENABLED       BOOLEAN,
  VAR_REFRESH_INTERVAL_SECS NUMBER,
  VAR_COMMENT               STRING
)
returns variant
language sql
execute as owner
as
$$
DECLARE
  v_exists         BOOLEAN DEFAULT FALSE;
  v_action         STRING  DEFAULT 'NOOP';
  v_sql            STRING;

  -- quoted string literals
  v_name_q         STRING;
  v_ns_q           STRING;
  v_uri_q          STRING;
  v_restname_q     STRING;
  v_role_q         STRING;
  v_region_q       STRING;
  v_comment_q      STRING;

  -- booleans/numerics formatted as text where needed
  v_enabled_txt    STRING;
  v_refresh_val    NUMBER;

  -- refresh interval tracking
  v_curr_refresh   NUMBER;
BEGIN
  /* pre-quote all string literals we embed in dynamic SQL */
  v_name_q     := '''' || REPLACE(NAME, '''', '''''') || '''';
  v_ns_q       := '''' || REPLACE(EACH_VALUE_NAMESPACE, '''', '''''') || '''';
  v_uri_q      := '''' || REPLACE(VAR_REST_CATALOG_URI, '''', '''''') || '''';
  v_restname_q := CASE WHEN VAR_REST_CATALOG_NAME IS NULL THEN 'NULL' ELSE '''' || REPLACE(VAR_REST_CATALOG_NAME, '''', '''''') || '''' END;
  v_role_q     := '''' || REPLACE(VAR_REST_AUTH_IAM_ROLE, '''', '''''') || '''';
  v_region_q   := CASE WHEN VAR_REST_AUTH_SIGN_REGION IS NULL THEN 'NULL' ELSE '''' || REPLACE(VAR_REST_AUTH_SIGN_REGION, '''', '''''') || '''' END;
  v_comment_q  := CASE WHEN VAR_COMMENT IS NULL THEN 'NULL' ELSE '''' || REPLACE(VAR_COMMENT, '''', '''''') || '''' END;

  IF (VAR_ICEBERG_ENABLED) THEN
    v_enabled_txt := 'TRUE';
  ELSE
    v_enabled_txt := 'FALSE';
  END IF;

  IF (VAR_REFRESH_INTERVAL_SECS IS NULL) THEN
    v_refresh_val := 30;   -- default if not provided
  ELSE
    v_refresh_val := VAR_REFRESH_INTERVAL_SECS;
  END IF;

  /* 1) Does it exist? */
  EXECUTE IMMEDIATE 'SHOW CATALOG INTEGRATIONS LIKE ' || v_name_q;
  v_exists := (SELECT COUNT(*) > 0 FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())));

  IF (NOT v_exists) THEN
    /* 2) CREATE */
    v_sql :=
      'CREATE CATALOG INTEGRATION IDENTIFIER(' || v_name_q || ') ' ||
      ' CATALOG_SOURCE = ' || VAR_CATALOG_SOURCE ||
      '  TABLE_FORMAT = '  || VAR_TABLE_FORMAT ||
      '  CATALOG_NAMESPACE = ' || v_ns_q ||
      '  REST_CONFIG = ( CATALOG_URI = ' || v_uri_q ||
      ', CATALOG_NAME = ' || v_restname_q ||
      ',  CATALOG_API_TYPE = ' || VAR_REST_CATALOG_API_TYPE ||
      COALESCE(LOCAL_REVAL_ENABLE_VENDED, '') || '  )' ||
      '     REST_AUTHENTICATION = ( TYPE = ' || VAR_REST_AUTH_TYPE ||
      ', SIGV4_IAM_ROLE = ' || v_role_q ||
      ', SIGV4_SIGNING_REGION = ' || v_region_q || ' )' ||
      ' ENABLED = ' || v_enabled_txt ||
      '      REFRESH_INTERVAL_SECONDS = ' || v_refresh_val ||
      '  COMMENT = ' || v_comment_q;

    EXECUTE IMMEDIATE v_sql;
    v_action := 'CREATE';

  ELSE
/* 3) EXISTS — ONLY update refresh interval if it changed */


 IF (VAR_REFRESH_INTERVAL_SECS IS NOT NULL) THEN
 
 -- DESCRIBE (quote the name to be safe with case/special chars)
 EXECUTE IMMEDIATE 'DESCRIBE INTEGRATION "' || REPLACE(NAME, '"', '""') || '"';
 
 /* Read by POSITION to avoid identifier issues across shapes:
  - $1 = 'property'   (or first column whatever its header is)
  - $2 = 'value'      (4-col shape) 
  - $3 = 'property_value' (5-col shape)
  We COALESCE($3, $2) so it works in both layouts.
 */
 SELECT TRY_TO_NUMBER(COALESCE($3::STRING, $2::STRING))
  INTO v_curr_refresh
 FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
 WHERE UPPER($1::STRING) = 'REFRESH_INTERVAL_SECONDS'
 QUALIFY ROW_NUMBER() OVER (ORDER BY $1) = 1;
 
 -- Only ALTER if different
 IF (NVL(v_curr_refresh, -1) <> VAR_REFRESH_INTERVAL_SECS) THEN
  v_sql := 'ALTER CATALOG INTEGRATION IDENTIFIER(' || v_name_q || ')' ||
    ' SET REFRESH_INTERVAL_SECONDS = ' || VAR_REFRESH_INTERVAL_SECS;
  EXECUTE IMMEDIATE v_sql;
  v_action := 'ALTER';
 ELSE
  v_action := 'NOOP';
 END IF;
 
 ELSE
 v_action := 'NOOP';
 END IF;

  END IF;

  RETURN OBJECT_CONSTRUCT(
    'name', NAME,
    'action', v_action,
    'requested_refresh_interval', VAR_REFRESH_INTERVAL_SECS,
    'current_refresh_interval', v_curr_refresh
  );
END;
$$;
