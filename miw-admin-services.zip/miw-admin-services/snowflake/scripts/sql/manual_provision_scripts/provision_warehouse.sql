-- Below is the SQL how we can request the provisioning.
CALL PROVISION_WAREHOUSE(
    'ACCOUNTADMIN',
    'SBX_DTD_MIW_PIPLN_SNF_01_WH',
    '{
        "PERSONA_TEST": ["TECH_ANALYST_ROLE1", "TECH_ANALYST_ROLE2"],
        "PERSONA_TEST1": ["TECH_DS_ROLE1", "TECH_DS_ROLE2", "TECH_DS_ROLE3"]
    }',
    '{
        "TECH_ANALYST_ROLE1": ["USAGE", "OPERATE"],
        "TECH_ANALYST_ROLE2": ["MONITOR"],
        "TECH_DS_ROLE1": ["USAGE"],
        "TECH_DS_ROLE2": ["USAGE", "OPERATE", "MONITOR"],
        "TECH_DS_ROLE3": ["USAGE", "MONITOR"]
    }',
    'DEV_DTD_MIW_PIPLN_SNF_04_WH',
    'XSMALL',
    'WH_OWNER',
    500,
    600,
    TRUE,
    1,
    1,
    'ECONOMY',
    1800,
    120,
    8);


-- Below is the stored procedure that can be used for provisioning warehouses, granting persona, attaching tech role, creating RM and attaching it to WH.
CREATE OR REPLACE PROCEDURE PROVISION_WAREHOUSE(
    execution_role VARCHAR,
    execution_wh VARCHAR,
    persona_tech_mapping VARCHAR,
    tech_role_grants_mapping VARCHAR,
    warehouse_name VARCHAR,
    warehouse_size VARCHAR,
    warehouse_own_role VARCHAR,
    monthly_credit_limit INTEGER,
    auto_suspend_in_seconds INTEGER,
    auto_resume BOOLEAN,
    min_cluster_count INTEGER,
    max_cluster_count INTEGER,
    scaling_policy VARCHAR,
    query_timeout_in_seconds INTEGER,
    statement_queued_timeout_in_seconds INTEGER,
    max_concurrency_level INTEGER
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
'
DECLARE
    result_set RESULTSET;
    result_set1 RESULTSET;
    persona_role STRING;
    tech_role STRING;
    create_role_stmt STRING;
    grant_role_stmt STRING;
    grants_result_set RESULTSET;
    grant_type STRING;
    grant_stmt STRING;
    resource_monitor_name STRING;
BEGIN
    -- Step 1: Set the execution role and warehouse
	BEGIN
	
		EXECUTE IMMEDIATE ''USE ROLE '' || execution_role;
	
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error using  execution role: '' || SQLERRM;
    END;
	
	BEGIN
	
		EXECUTE IMMEDIATE ''USE WAREHOUSE '' || execution_wh;
		
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error using  warehouse: '' || SQLERRM;
    END;
    -- Step 2: Create the warehouse
	BEGIN
	
    EXECUTE IMMEDIATE ''CREATE WAREHOUSE IF NOT EXISTS '' || warehouse_name || 
        '' WAREHOUSE_SIZE = '' || warehouse_size || 
        '' AUTO_SUSPEND = '' || auto_suspend_in_seconds || 
        '' AUTO_RESUME = '' || IFF(auto_resume, ''TRUE'', ''FALSE'') || 
        '' MIN_CLUSTER_COUNT = '' || min_cluster_count || 
        '' MAX_CLUSTER_COUNT = '' || max_cluster_count || 
        '' SCALING_POLICY = '' || scaling_policy ||
        '' STATEMENT_TIMEOUT_IN_SECONDS = '' || query_timeout_in_seconds || 
        '' STATEMENT_QUEUED_TIMEOUT_IN_SECONDS = '' || statement_queued_timeout_in_seconds || 
        '' MAX_CONCURRENCY_LEVEL = '' || max_concurrency_level;
			
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error creating warehouse: '' || SQLERRM;
    END;
    -- Step 3: Transfer Ownership and add additional privileges to the specified Owner Role
	BEGIN
		EXECUTE IMMEDIATE ''GRANT OWNERSHIP ON WAREHOUSE '' || warehouse_name || '' TO ROLE '' || warehouse_own_role;
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error granting ownership: '' || SQLERRM;
    END;
	
	BEGIN
		EXECUTE IMMEDIATE ''GRANT MONITOR ON WAREHOUSE '' || warehouse_name || '' TO ROLE '' || warehouse_own_role;
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error granting monitor on: '' || SQLERRM;
    END;
	
	BEGIN
		EXECUTE IMMEDIATE ''GRANT USAGE ON WAREHOUSE '' || warehouse_name || '' TO ROLE '' || warehouse_own_role;
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error granting usage: '' || SQLERRM;
    END;	
	
	BEGIN
		EXECUTE IMMEDIATE ''GRANT OPERATE ON WAREHOUSE '' || warehouse_name || '' TO ROLE '' || warehouse_own_role;
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error granting operate: '' || SQLERRM;
    END;
	
    -- Step 4: Create Resource Monitor and Attach to Warehouse
    resource_monitor_name := REPLACE(warehouse_name, ''_WH'', ''_RM'');
	
	BEGIN
		EXECUTE IMMEDIATE ''CREATE RESOURCE MONITOR IF NOT EXISTS '' || resource_monitor_name || 
					'' WITH CREDIT_QUOTA = '' || monthly_credit_limit || 
					'' TRIGGERS ON 50 PERCENT DO NOTIFY '' || 
					'' ON 75 PERCENT DO NOTIFY '' || 
					'' ON 90 PERCENT DO NOTIFY '' || 
					'' ON 98 PERCENT DO NOTIFY '' || 
					'' ON 90 PERCENT DO SUSPEND '' || 
					'' ON 100 PERCENT DO SUSPEND_IMMEDIATE'';
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error creating Resource Monitor: '' || SQLERRM;
    END;				  
    
    -- Step 5: Attaching the RM to Warehouse
	BEGIN
    
	EXECUTE IMMEDIATE ''ALTER WAREHOUSE '' || warehouse_name || '' SET RESOURCE_MONITOR = '' || resource_monitor_name;
	
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error attaching the RM to Warehouse: '' || SQLERRM;
    END;
    -- Step 6: Changing the RM Ownership
	BEGIN
	
		EXECUTE IMMEDIATE ''GRANT OWNERSHIP ON RESOURCE MONITOR '' || resource_monitor_name || '' TO ROLE '' || warehouse_own_role;
		
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error changing the RM Ownership: '' || SQLERRM;
    END;    
    -- Step 7: Prepare a tabular structure by mapping a persona to each tech role it will get
    result_set := (SELECT 
                        f.key AS persona_role,
                        v.value AS role_name
                   FROM 
                        TABLE(FLATTEN(INPUT => PARSE_JSON(:persona_tech_mapping))) AS f,
                        LATERAL FLATTEN(INPUT => f.value) AS v);
						
    -- Step 9: Prepare a tabular structure with keys and values for tech_role and grants mapping
    grants_result_set := (SELECT 
                        f.key AS tech_role,
                        v.value AS grant_type
                   FROM 
                        TABLE(FLATTEN(INPUT => PARSE_JSON(:tech_role_grants_mapping))) AS f,
                        LATERAL FLATTEN(INPUT => f.value) AS v);						

    -- Step 8: Iterate over each persona_role:tech_role mapping record
    -- Create Tech roles and attach them to Persona role
    FOR record IN result_set DO
        persona_role := record.persona_role;
        tech_role := record.role_name;

        -- Prepare and execute the CREATE ROLE statement
		BEGIN
			create_role_stmt := ''CREATE ROLE IF NOT EXISTS '' || tech_role;
			EXECUTE IMMEDIATE create_role_stmt;
		EXCEPTION WHEN OTHER THEN
		RETURN ''Error creating role: '' || SQLERRM;
		END; 		
    END FOR;
	
    -- Step 10: Iterate over each grant and apply it to the tech role
    FOR grant_record IN grants_result_set DO
            tech_role := grant_record.tech_role;
            grant_type := grant_record.grant_type;

            -- Prepare and execute the GRANT statement
			BEGIN
				grant_stmt := ''GRANT '' || grant_type || '' ON WAREHOUSE '' || warehouse_name || '' TO ROLE '' || tech_role;
				EXECUTE IMMEDIATE grant_stmt;
			EXCEPTION WHEN OTHER THEN
			RETURN ''Error granting privillage to tech role: '' || SQLERRM;
			END;			
			
    END FOR;	

    result_set1 := (SELECT 
                        f.key AS persona_role,
                        v.value AS role_name
                   FROM 
                        TABLE(FLATTEN(INPUT => PARSE_JSON(:persona_tech_mapping))) AS f,
                        LATERAL FLATTEN(INPUT => f.value) AS v);

    FOR record IN result_set1 DO
        persona_role := record.persona_role;
        tech_role := record.role_name;
       
        -- Prepare and execute the CREATE ROLE statement
		BEGIN
			create_role_stmt := ''GRANT ROLE '' || tech_role || '' TO ROLE '' || persona_role;
             
			EXECUTE IMMEDIATE create_role_stmt;
		EXCEPTION WHEN OTHER THEN
		RETURN ''Error granting tech role to persona role '' || SQLERRM;
		END; 		
    END FOR;
        
 
     RETURN ''Warehouse provisioned successfully'';  
END;
';
