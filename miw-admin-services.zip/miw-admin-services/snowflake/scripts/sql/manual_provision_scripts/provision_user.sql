-- Sample Command to call the stored proc
CALL PROVISION_USER(
    'ACCOUNTADMIN',
    'SBX_DTD_MIW_PIPLN_SNF_01_WH',
    '88d9ec99-9ca9-9d9e-a99c-9ae9b0990e88',
    'ABC',
    'XYZ',
    'MIW_DTAD_EPAM');
    

-- Stored Proc to Create a User
CREATE OR REPLACE PROCEDURE PROVISION_USER(
    execution_role VARCHAR,
    execution_wh VARCHAR,
    sub_uuid VARCHAR,
    first_name VARCHAR,
    last_name VARCHAR,
    default_role VARCHAR
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
'
DECLARE
    login_name STRING;
    display_name STRING;
    create_stmt STRING;
BEGIN
    -- Step 1: Set the execution role and warehouse
	BEGIN
	
		EXECUTE IMMEDIATE ''USE ROLE '' || execution_role;
		
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error using  execution role: '' || SQLERRM;
    END;
	
	BEGIN
	
		EXECUTE IMMEDIATE ''USE WAREHOUSE '' || execution_wh;
		
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error using  execution_wh : '' || SQLERRM;
    END;	

    -- Step 2: Set login_name and display_name to sub_uuid
    login_name := sub_uuid;
    display_name := sub_uuid;

	
    BEGIN
        -- Create user
       -- create_stmt := 
       EXECUTE IMMEDIATE
            ''CREATE OR REPLACE USER "'' || sub_uuid || ''"''||
            '' LOGIN_NAME = "'' || login_name || ''"'' || 
            '' DISPLAY_NAME = "'' || sub_uuid || ''"'' || 
            '' FIRST_NAME = '' || first_name || '''' || 
            '' LAST_NAME = '' || last_name || '''' || 
            '' MUST_CHANGE_PASSWORD = FALSE '' || 
            '' DEFAULT_ROLE = '' || default_role || '''';

        --RETURN create_stmt;
    EXCEPTION WHEN OTHER THEN
        RETURN ''Error creating user: '' || SQLERRM;
    END;
    
   --Step 3 : Grant role to user
   BEGIN
		EXECUTE IMMEDIATE '' GRANT ROLE '' || default_role || '' TO USER "''  || sub_uuid ||''"'' ;
		
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error granting role to user: '' || SQLERRM;
    END;	

    RETURN ''User "'' || sub_uuid || ''" created and role '' || default_role || '' granted.'';
END;
';