-- Stored Procedure Call Example
CALL PROVISION_DATABASE(
    'ACCOUNTADMIN',
    'SBX_DTD_MIW_PIPLN_SNF_01_WH',
    '{
        "PERSONA1": ["TECH_ANALYST_ROLE1", "TECH_ANALYST_ROLE2"],
        "PERSONA2": ["TECH_DS_ROLE1", "TECH_DS_ROLE2", "TECH_DS_ROLE3"]
    }',
    '{
        "TECH_ANALYST_ROLE1": ["USAGE", "CREATE SCHEMA"],
        "TECH_ANALYST_ROLE2": ["MONITOR"],
        "TECH_DS_ROLE1": ["MODIFY"],
        "TECH_DS_ROLE2": ["USAGE", "MODIFY", "MONITOR"],
        "TECH_DS_ROLE3": ["USAGE", "CREATE SCHEMA"]
    }',
    'SBX_FIN_PROD_GRP_DB4',
    'PERMANENT',
    'DB_OWNER1');


-- Stored Procedure to create a Database
CREATE OR REPLACE PROCEDURE PROVISION_DATABASE(
    execution_role VARCHAR,
    execution_wh VARCHAR,
    persona_tech_mapping VARCHAR,
    tech_role_grants_mapping VARCHAR,
    database_name VARCHAR,
    database_type VARCHAR,
    database_own_role VARCHAR
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
'
DECLARE
    result_set RESULTSET;
	result_set1 RESULTSET;
    persona_role STRING;
    tech_role STRING;
    create_role_stmt STRING;
    grant_role_stmt STRING;
    grants_result_set RESULTSET;
    grant_type STRING;
    grant_stmt STRING;
BEGIN
    -- Step 1: Set the execution role and warehouse
    BEGIN
    
        EXECUTE IMMEDIATE ''USE ROLE '' || execution_role;
        
        EXCEPTION WHEN OTHER THEN
        RETURN ''Error using role: '' || SQLERRM;
    END;
    
    BEGIN
    
        EXECUTE IMMEDIATE ''USE WAREHOUSE '' || execution_wh;
        
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error using warehouse: '' || SQLERRM;
    END;
    
    -- Step 2: Create the database
    BEGIN
    
        EXECUTE IMMEDIATE 
            ''CREATE DATABASE IF NOT EXISTS '' || database_name || 
            '' DATA_RETENTION_TIME_IN_DAYS = '' || IFF(database_type = ''TRANSIENT'', ''0'', ''1'');
        
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error creating database: '' || SQLERRM;
    END;        
    
    -- Step 3: Prepare a tabular structure by mapping a persona to each tech role it will get
    result_set := (SELECT 
                        f.key AS persona_role,
                        v.value AS role_name
                   FROM 
                        TABLE(FLATTEN(INPUT => PARSE_JSON(:persona_tech_mapping))) AS f,
                        LATERAL FLATTEN(INPUT => f.value) AS v);

    -- Step 4: Prepare a tabular structure with keys and values for tech_role and grants mapping
    grants_result_set := (SELECT 
                        f.key AS tech_role,
                        v.value AS grant_type
                   FROM 
                        TABLE(FLATTEN(INPUT => PARSE_JSON(:tech_role_grants_mapping))) AS f,
                        LATERAL FLATTEN(INPUT => f.value) AS v);						

    -- Step 5: Iterate over each persona_role:tech_role mapping record Create Tech roles 

    
    FOR record IN result_set DO
        persona_role := record.persona_role;
        tech_role := record.role_name;

        BEGIN
            -- Prepare and execute the CREATE ROLE statement
            create_role_stmt := ''CREATE ROLE IF NOT EXISTS '' || tech_role;
            EXECUTE IMMEDIATE create_role_stmt;
            
        EXCEPTION WHEN OTHER THEN
        RETURN ''Error creating role: '' || SQLERRM;
        END;         
	END FOR;

    -- Step 6: Iterate over each grant and apply it to the tech role
    FOR grant_record IN grants_result_set DO
            tech_role := grant_record.tech_role;
            grant_type := grant_record.grant_type;

            BEGIN
            
                -- Prepare and execute the GRANT statement
                grant_stmt := ''GRANT '' || grant_type || '' ON DATABASE '' || database_name || '' TO ROLE '' || tech_role;
                EXECUTE IMMEDIATE grant_stmt;
            
            EXCEPTION WHEN OTHER THEN
            RETURN ''Error granting privillage on database: '' || SQLERRM;
            END;            
    END FOR;

    -- Step 7: Iterate over each persona_role:tech_role mapping record attach them to Persona role	
    result_set1 := (SELECT 
                        f.key AS persona_role,
                        v.value AS role_name
                   FROM 
                        TABLE(FLATTEN(INPUT => PARSE_JSON(:persona_tech_mapping))) AS f,
                        LATERAL FLATTEN(INPUT => f.value) AS v);

    FOR record IN result_set1 DO
        persona_role := record.persona_role;
        tech_role := record.role_name;
       
        -- Prepare and execute the CREATE ROLE statement
		BEGIN
			create_role_stmt := ''GRANT ROLE '' || tech_role || '' TO ROLE '' || persona_role;
             
			EXECUTE IMMEDIATE create_role_stmt;
		EXCEPTION WHEN OTHER THEN
		RETURN ''Error granting tech role to persona role '' || SQLERRM;
		END; 		
    END FOR;
    



    -- Step 8: Transfer Ownership and add additional privileges to the specified Owner Role
    BEGIN
    
        EXECUTE IMMEDIATE ''GRANT ALL PRIVILEGES ON DATABASE '' || database_name || '' TO ROLE '' || database_own_role;
        
    EXCEPTION WHEN OTHER THEN
    RETURN ''Error Transfer ownership on database: '' || SQLERRM;
    END;

    RETURN ''Database provisioned successfully'';
END;
';