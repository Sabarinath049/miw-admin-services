import os
import logging
from datetime import datetime
from constants import LOGGING_LEVEL, LOG_FOLDER

logger = logging.getLogger("dtd-miw-automated-provisioning")
logger.setLevel(logging.DEBUG)

if not os.path.exists(LOG_FOLDER):
    os.makedirs(LOG_FOLDER)

# Generate a timestamp
timestamp = datetime.now().strftime('%Y%m%d%H%M%S')

# Construct the log file, formatting
log_file_name = f'{timestamp}.log'
log_format = '%(asctime)s - %(name)s - %(filename)s - %(levelname)s - %(message)s'

# Setting up file Handler
file_handler = logging.FileHandler(f'{LOG_FOLDER}/{log_file_name}')
file_handler.setLevel("DEBUG")
file_handler.setFormatter(logging.Formatter(log_format))

# Setting up Stream Handler
stream_handler = logging.StreamHandler()
stream_handler.setLevel(LOGGING_LEVEL)
stream_handler.setFormatter(logging.Formatter(log_format))

# Adding the Handlers to Logger
logger.addHandler(file_handler)
logger.addHandler(stream_handler)
