import copy
import hashlib
import inspect
import json
import os
import sys

import boto3
import requests
from botocore.exceptions import ClientError, BotoCoreError

from constants import ERROR_FORMAT, SNF_OBJ_MANDATORY_KEYS, REQD_ENV_VARS, OAUTH_URL,  SEPERATOR, \
    USER_INPUT_SNF_TBL_MAP, SUPPORTED_SNF_OBJS_LIST, IP_JSON_KEY_PATTERNS_TO_IGNORE, OBJ_TYPE_NAME_MAP
from helpers.config_log import logger
from snowflake_objects.snowflake_objects import Warehouse, Database, Schema, Persona, OAuth, Storage_Integration, External_Volume, Catalog_Integration

# Constants
CLASS_MAP = {
    "warehouse": Warehouse,
    "database": Database,
    "schema": Schema,
    "persona": Persona,
    "oauth": OAuth,
    "storage_integration": Storage_Integration,
    "external_volume" : External_Volume,
    "catalog_integration": Catalog_Integration
}

def generate_s3_client(region_name="us-east-1"):
    return boto3.client("s3", region_name=region_name)


def write_content_to_s3(s3_client, bucket_name, key, content):
    try:
        s3_client.put_object(Bucket=bucket_name, Key=key, Body=content)
        logger.debug(f"File {key} successfully uploaded in S3 Bucket {bucket_name}")
        return None
    except ClientError as ce:
        logger.error(f"File {key} failed to upload in S3 Bucket {bucket_name} due to exception code : {ce.response['Error']['Code']} and error message : {ce.response['Error']['Message']}")
    except BotoCoreError as bce:
        logger.error(
            f"File {key} failed to upload in S3 Bucket {bucket_name} due to botocore exception : {str(bce)}")
    except Exception as base_ex:
        logger.error(f"Unknown exception {base_ex} encountered while writing the file {key} from s3 bucket : {bucket_name}")

def read_text_file_from_s3(s3_client, bucket_name, key):
    try:
        logger.debug(f"utils >> read_text_file_from_s3 >> bucket_name : {bucket_name}")
        logger.debug(f"utils >> read_text_file_from_s3 >> key : {key}")
        response = s3_client.get_object(Bucket=bucket_name, Key=key)
        content = response['Body'].read().decode('utf-8')

        # Split into lines and check if all lines are empty or contain only whitespace
        lines = content.splitlines()
        all_blank = all(line.strip() == '' for line in lines)

        if all_blank:
            return None
        else:
            return content
    except ClientError as ex:
        if ex.response['Error']['Code'] == "NoSuchKey":
            logger.info(f"File {key} doesn't exist in s3 since likely there is no such GITHUB change identified as part of this PR.")
        else:
            logger.error(
                f"File {key} couldn't be read from s3 bucket : {bucket_name} with exception : {ex}")
    except Exception as base_ex:
        logger.error(f"Unknown exception {base_ex} encountered while reading the file {key} from s3 bucket : {bucket_name}")
    return None

def publish_logs_to_s3(log_folder, log_file_key, region_name="us-east-1"):
    """
    Publishes log files from a local folder to an S3 bucket.

    This function iterates through a specified folder, finds all `.log` files, and uploads them to S3.
    Each log file is uploaded to a specific S3 location defined by the log_file_key.

    :param log_folder: The local folder containing log files to be uploaded.
    :param log_file_key: The S3 key prefix under which the log files will be uploaded.
    :param region_name: AWS region where the S3 bucket is located (default is "us-east-1").
    :return: None
    """
    s3_client = generate_s3_client(region_name)

    # Walk through the log folder and find all log files
    for root, dirs, files in os.walk(log_folder):
        for file in files:
            if file.endswith('.log'):
                local_file_path = os.path.join(root, file)
                s3_key = os.path.join(log_file_key, file) if log_file_key else file

                try:
                    # Upload the log file to S3
                    s3_client.upload_file(local_file_path, S3_LOG_BUCKET, s3_key)
                    logger.info(f"Log file: {file} successfully published to {S3_LOG_BUCKET}/{s3_key}")
                except Exception as ex:
                    # Handle any errors during file upload
                    logger.exception(f"Log file {file} couldn't be published to S3 due to exception: {ex}")


def list_files(path):
    """
    Retrieves all files from a given directory path and returns a list of their absolute paths.

    :param path: The directory path to search for files.
    :return: A list of absolute file paths if successful, or None if an error occurs.
    """
    result_file_list = []
    try:
        # Walk through the directory and append all file paths to the result list
        for root, dirs, files in os.walk(path):
            for name in files:
                result_file_list.append(os.path.join(root, name))
    except Exception as ex:
        # Log any exception encountered during directory traversal
        logger.exception(f"Couldn't read the files inside the base path provided due to exception: {ex}")
        return None
    return result_file_list


def prep_ip_json_list(base_path):
    """
    Prepares a list of file paths from the specified base directory. If the base path is valid and contains files,
    it returns the list of file paths. Otherwise, it logs an error and terminates the program.

    :param base_path: The base directory path from which files will be listed.
    :return: A list of file paths if successful.
    :raises: Exits the program with an error message if no files are found.
    """
    if base_path:
        # Get the list of files from the specified directory path
        file_list = list_files(base_path)
        if file_list:
            return file_list

    # Log an error and exit if the file list is empty or the base path is invalid
    logger.critical("Couldn't read files from input base path. Exiting code with exit code -1....!")
    sys.exit(-1)

def read_json(json_file_path):
    """
    Reads a JSON file and returns its contents as a Python dictionary.

    :param json_file_path: The path to the JSON file to be read.
    :return: A Python dictionary representing the JSON file's content if successful.
    :raises: Logs error if the file is not found or the JSON cannot be decoded.
    """
    try:
        with open(json_file_path, 'r') as json_file:
            return json.load(json_file)
    except FileNotFoundError:
        logger.exception(f"Error: File '{json_file_path}' not found.")
    except json.JSONDecodeError:
        logger.exception(f"Error: Failed to decode JSON from '{json_file_path}'.")
    except Exception as ex:
        logger.exception(f"Unexpected error while reading file '{json_file_path}': {ex}")


def reverse_dict(ip_dict):
    """
    Reverses the key-value pairs of a dictionary.

    :param ip_dict: The dictionary to be reversed.
    :return: A new dictionary with keys and values swapped.
    """
    return {ip_val: ip_key for ip_key, ip_val in ip_dict.items()}


def validate_tf_output(obj_type, obj_name, user_input, tf_output):
    """
    Validates the presence of required attributes in Terraform output.

    :param obj_type: Type of the object (e.g., Warehouse, Schema, etc.).
    :param obj_name: Name of the object.
    :param user_input: User input dictionary, typically containing expected attributes.
    :param tf_output: Terraform output dictionary to validate.

    :return: A dictionary with validated attributes if all required attributes are present,
             otherwise None if validation fails.
    """
    val_result = validate_attribute_presence(obj_type, user_input, tf_output)

    if isinstance(val_result, dict):
        logger.debug(f"All required attributes for {obj_type} : {obj_name} are present in output...!")
        logger.debug(val_result)
        return val_result
    elif val_result and "failed" in val_result:
        logger.warning(f"Attributes missing from terraform output for {obj_type} : {obj_name}.")
        logger.warning(f"Metadata entry won't be performed for {obj_type} : {obj_name}.")
    else:
        logger.warning(f"Terraform attribute validation can't be performed for {obj_type} : {obj_name}.")

    return None


def create_tgt_dict(obj_type, src_dict_a, src_dict_b, tgt_dict):
    """
    Combines two source dictionaries (`src_dict_a` and `src_dict_b`) into a target dictionary (`tgt_dict`).
    If any keys in `tgt_dict` are missing in both source dictionaries, returns "failed".

    :param src_dict_a: The first source dictionary.
    :param src_dict_b: The second source dictionary.
    :param tgt_dict: The target dictionary that needs to be populated.

    :return: The updated target dictionary if all keys are found in the source dictionaries,
             otherwise "failed" if any required keys are missing.
    """
    logger.debug(f"{create_tgt_dict=}")
    logger.debug(f"create_tgt_dict >> src_dict_a : {src_dict_a}")
    logger.debug(f"create_tgt_dict >> src_dict_b : {src_dict_b}")

    if src_dict_a and src_dict_b and tgt_dict:
        combined_keys = set(src_dict_a.keys()).union(src_dict_b.keys())
        missing_keys = set(tgt_dict.keys()) - combined_keys

        logger.error(f"Keys missing in source dictionaries: {missing_keys}")
        if any(missing_key in SNF_OBJ_MANDATORY_KEYS[str(obj_type).lower()] for missing_key in list(missing_keys)):
            logger.error(
                f"For the Object type : {str(obj_type)}, mandatory attributes are : {str(SNF_OBJ_MANDATORY_KEYS[str(obj_type).lower()])}")
            return "failed"

        # Update the target dictionary with values from the source dictionaries
        for key in tgt_dict.keys():
            if key in src_dict_a:
                tgt_dict[key] = src_dict_a[key]
            elif key in src_dict_b:
                tgt_dict[key] = src_dict_b[key]
            else:
                tgt_dict[key] = None

        logger.debug(f"create_tgt_dict >> tgt_dict : {tgt_dict}")
        return tgt_dict
    else:
        logger.error("One or more input dictionaries are None.")
        return "failed"


def validate_attribute_presence(obj_type, user_input, tf_output):
    """
    Validates the presence of attributes in the terraform output for a given object type.

    This function checks if the object type is supported and if a corresponding mapping exists.
    It then combines the user input and terraform output into a target dictionary, ensuring all required
    attributes are present. If the object type is unsupported, the function returns "unsupported object".

    :param obj_type: The type of the object (e.g., "database", "schema").
    :param user_input: The user-provided input data as a dictionary.
    :param tf_output: The terraform output data as a dictionary.

    :return: A dictionary with merged attributes from user input and terraform output, or a string indicating
             an unsupported object.
    """
    logger.debug(f"Validating attribute presence for object type: {obj_type}...")
    logger.debug(f"User input: {user_input}")
    logger.debug(f"Terraform output: {tf_output}")

    if obj_type in SUPPORTED_SNF_OBJS_LIST:
        table_mapping = USER_INPUT_SNF_TBL_MAP.get(obj_type)
        if table_mapping:
            # Create a deep copy of the table mapping to avoid modifying the original
            placeholder_dict = copy.deepcopy(table_mapping)
            return create_tgt_dict(obj_type, user_input, tf_output, placeholder_dict)
        else:
            logger.warning(f"No mapping found for object type {obj_type}. Returning 'unsupported object'.")
            return "unsupported object"
    else:
        logger.warning(f"Object type {obj_type} is not supported. Returning None.")
        return None


def extract_sub_dicts(input_dict, key_pattern):
    """
    Extracts and transforms sub-dictionaries from an input dictionary based on a key pattern.

    This function searches for keys in the input dictionary that contain the specified pattern, extracts
    the 'value' sub-dictionary associated with those keys, and generates a new key by splitting the original key.

    :param input_dict: The dictionary to search within.
    :param key_pattern: The pattern to match in keys.

    :return: A dictionary with transformed keys and their corresponding 'value' sub-dictionaries.
    """
    return_dict = {}

    for key, value in input_dict.items():
        if key_pattern in key:
            # Extract the 'value' sub-dictionary if it exists
            value_sub_dict = value.get('value') if isinstance(value, dict) else None
            if value_sub_dict is not None:
                # Generate a new key by splitting on the separator
                generated_key=key.replace(SEPERATOR+key.split(SEPERATOR)[-1],'')
                logger.debug(f"extract_sub_dicts >> {generated_key=} {key=} {key_pattern=} {SEPERATOR=}")
                return_dict[generated_key] = value_sub_dict
            else:
                logger.warning(f"Key '{key}' does not contain a valid 'value' sub-dictionary.")

    return return_dict


def dict_safe_retrieval(ip_dict, keys):
    """
    Safely retrieves a value from a nested dictionary.

    This function traverses a dictionary along the specified keys path
    and returns the value at the final key. If any key is missing,
    it returns None without raising an exception.

    :param ip_dict: Dictionary to traverse.
    :param keys: A list of keys representing the path to the value.
    :return: The value at the specified path or None if any key is missing.
    """
    current_value = ip_dict

    for key in keys:
        if isinstance(current_value, dict):
            current_value = current_value.get(key)
        else:
            return None  # Stop traversal if the current value isn't a dictionary

    return current_value


def get_secret(secret_name, region_name="us-east-1"):
    """
    Retrieves a secret from AWS Secrets Manager.

    :param secret_name: The name or ARN of the secret to retrieve.
    :param region_name: AWS region where the secret is stored.
    :return: A dictionary containing the secret's key-value pairs.
    """
    try:
        # Create a Secrets Manager client
        client = boto3.client("secretsmanager", region_name=region_name)

        # Retrieve the secret value
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)

        # Extract and parse the secret
        secret = get_secret_value_response.get("SecretString")
        if secret:
            return json.loads(secret)

        logger.error("SecretString not found in the secret response.")
        raise ValueError("SecretString missing in Secrets Manager response.")

    except Exception as ex:
        logger.exception(f"Exception encountered while retrieving secret '{secret_name}': {ex}")
        exit_process(
            "exception",
            f"Exception encountered while retrieving secret '{secret_name}' from Secrets Manager",
            ex,
        )
        exit_process("exception", "Exiting code with exit code -1.....!", None, -1)


def generate_oauth_token(client_id, client_secret, scope):
    """
    Generates an oauth token using client credentials.

    :param client_id: The client ID for oauth authentication.
    :param client_secret: The client secret for oauth authentication.
    :param scope: The scope of the oauth token.
    :return: The access token as a string, or None if the token is not present in the response.
    """
    try:
        headers = {"Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"}
        data = {
            "client_id": client_id,
            "client_secret": client_secret,
            "grant_type": "client_credentials",
            "scope": scope,
        }

        logger.debug("Sending oauth token request...")
        response = requests.post(OAUTH_URL, headers=headers, data=data)

        logger.debug(f"Response code received from oauth request URL: {response.status_code}")
        response.raise_for_status()

        # Parse the JSON response to extract the access token
        token_response = response.json()
        access_token = token_response.get("access_token")

        if not access_token:
            logger.error("Access token not found in oauth response.")
            raise ValueError("Access token missing in oauth response.")

        logger.debug("oauth token generated successfully.")
        return access_token

    except requests.exceptions.RequestException as req_err:
        logger.exception(f"HTTP error occurred during oauth token generation: {req_err}")
    except ValueError as val_err:
        logger.exception(f"Value error during oauth token generation: {val_err}")
    except Exception as ex:
        logger.exception(f"Unexpected error during oauth token generation: {ex}")
        exit_process('exception', 'Error encountered while generating oauth token', ex)
        exit_process('exception', 'Exiting code with exit code -1.....!', None, -1)

def remove_keys_by_pattern(ip_dict):
    # Create a new dictionary excluding keys that match any pattern
    filtered_dict = {key: value for key, value in ip_dict.items()
                     if not any(pattern in key for pattern in IP_JSON_KEY_PATTERNS_TO_IGNORE)}

    return filtered_dict

def preprocess_keys(obj_type, obj_ip_json, key_map):
    """
    Preprocesses the keys of an input JSON object by renaming keys based on a mapping.

    :param obj_type: The type of the object being processed (used for logging and exception preparation).
    :param obj_ip_json: The input JSON object (dictionary) to preprocess.
    :param key_map: A dictionary where keys represent the current keys in the input JSON,
                    and values represent the desired keys.
    :return: The modified JSON object with updated keys.
    """
    try:
        # Ensure obj_ip_json is a dictionary
        if not isinstance(obj_ip_json, dict):
            raise TypeError("The input JSON object is not a valid dictionary.")

        logger.debug(f"preprocess_keys >> obj_ip_json : {obj_ip_json}")

        # Refines the input JSON by ignore certain predefined keys setup as part of constants
        obj_ip_json = remove_keys_by_pattern(obj_ip_json)

        # Replace keys as per the mapping
        for old_key, new_key in key_map.items():
            if old_key in obj_ip_json:
                obj_ip_json[new_key] = obj_ip_json.pop(old_key)

        return obj_ip_json

    except (KeyError, TypeError) as key_type_ex:
        fail_msg = (
            f"Name of {obj_type} not appropriately defined in the input JSON. Please review the guideline "
            f"documentation."
        )
        logger.exception(f"Exception during key preprocessing for {obj_type}: {key_type_ex}")
        return prepare_exception(obj_type, "NO_NAME_DEFINED", inspect.currentframe().f_code.co_name, fail_msg)


def exit_process(log_type, message, exception=None, exit_code=None):
    """
    Logs an error or critical message and optionally exits the process.

    :param log_type: The type of log ("exception" or "critical").
    :param message: The message to log.
    :param exception: An optional exception object to log alongside the message.
    :param exit_code: An optional exit code for terminating the program.
    """
    if log_type == "exception":
        logger.exception(f"{message} : {exception}")
    elif log_type == "critical":
        logger.critical(f"{message} : {exception}")
    else:
        logger.error(f"Unsupported log type: {log_type}. Message: {message} : {exception}")

    if exit_code is not None:
        logger.critical(f"Exiting process with exit code {exit_code}.")
        sys.exit(exit_code)


def prepare_exception(obj_type, obj_name, func_name, failure_msg):
    """
    Prepares a structured error message for exceptions.

    :param obj_type: Type of the object (e.g., table, resource, or entity).
    :param obj_name: Name of the object for which the exception is being prepared.
    :param func_name: Name of the function where the exception occurred.
    :param failure_msg: Detailed message explaining the reason for failure.
    :return: A formatted error message string.
    """
    try:
        return ERROR_FORMAT.format(
            SNF_OBJ_TYPE=obj_type,
            SNF_OBJ_NAME=obj_name,
            VALIDATION_FUNC_NAME=func_name,
            VALIDATION_FAIL_MESSAGE=failure_msg,
        )
    except KeyError as ex:
        logger.error(
            f"Failed to prepare exception message. Missing keys in ERROR_FORMAT: {ex}"
        )
        return f"Error in exception preparation for {obj_type} ({obj_name}): {failure_msg}"


def pre_validate_user_metadata(obj_type, user_metadata_json):
    """
    Validates user metadata by initializing the corresponding class.

    :param obj_type: The type of the object to be validated.
    :param user_metadata_json: Dictionary containing user metadata.
    :return: An instance of the class if validation succeeds, or a structured error message if it fails.
    """
    try:
        # Retrieve the class for the object type
        class_name = CLASS_MAP.get(obj_type)
        if not class_name:
            fail_msg = f"Object type '{obj_type}' is not supported. Please check the CLASS_MAP."
            logger.error(fail_msg)
            return prepare_exception(
                obj_type,
                user_metadata_json.get("name", "NO_NAME_DEFINED"),
                inspect.currentframe().f_code.co_name,
                fail_msg
            )

        logger.debug(f"{class_name=}...user_metadata_json => {user_metadata_json}")
        # Attempt to initialize the class with user metadata
        return class_name(**user_metadata_json)

    except (KeyError, TypeError) as type_val_ex:
        logger.exception(
            f"Exception encountered while validating input JSON for object type '{obj_type}': {type_val_ex}"
        )
        fail_msg = (
            f"Mandatory columns are missing or invalid in the input. "
            f"Expected Mandatory Columns: {SNF_OBJ_MANDATORY_KEYS.get(obj_type, None)}"
        )
        return prepare_exception(
            obj_type,
            user_metadata_json.get("name", "NO_NAME_DEFINED"),
            inspect.currentframe().f_code.co_name,
            fail_msg
        )

def filter_eligible_rule_suites(rule_dict):
    """
    Filters and returns the keys from rule_dict where the value of 'required' is True.

    :param rule_dict: A dictionary where each key corresponds to a rule suite, and the value is a dictionary.
                       The value dictionaries must contain a key 'required' that indicates whether the rule is eligible.
    :return: A list of keys where the rule is marked as 'required' = True.
    """
    return [key for key, value in rule_dict.items() if value.get("required") is True]


def get_env_variables():
    """Retrieve and validate required environment variables."""
    env_vars = {}
    missing_vars = []

    for var in REQD_ENV_VARS:
        value = os.getenv(var)
        if value is None:
            missing_vars.append(var)
        else:
            env_vars[var] = value

    if missing_vars:
        logger.error("Missing required environment variables: %s", ", ".join(missing_vars))
        logger.error("Exiting run with exit code -1.")
        sys.exit(-1)
    return env_vars


def add_to_dict(ip_dict, ip_key, ip_value):
    """
    Feeds in on a dictionary and what key and value we wish to update in the key
    :param ip_dict: Incoming Dictionary
    :param ip_key: Associated Key for which value needs to be updated
    :param ip_value: Associated Value to be appended/added
    :return:
    """
    if ip_key in ip_dict:
        ip_dict[ip_key].append(ip_value)
    else:
        ip_dict[ip_key] = [ip_value]
    return ip_dict


def create_obj_type_name_map(user_json, object_type, snf_obj_type_name_dict):
    """
    Creates or updates a mapping of object types to their respective names in the given dictionary.

    This function reads a user JSON file, extracts the name corresponding to the given object type,
    and adds it to the provided dictionary that maps object types to names.

    :param user_json: Path to the user JSON file.
    :param object_type: The object type (used to fetch the corresponding name from the JSON).
    :param snf_obj_type_name_dict: Dictionary that maps object types to their names.
    :return: Updated dictionary with the new object type to name mapping.
    """
    # Read the content of the user JSON file
    user_snf_json = read_json(user_json)

    # Construct the key for the object type's name based on the provided object_type
    #user_name_key = f"{object_type}_name"
    user_name_key = OBJ_TYPE_NAME_MAP.get(object_type, None)

    # Retrieve the object name from the JSON using the constructed key
    snf_obj_name = user_snf_json.get(user_name_key)

    # Add the object type and its name to the mapping dictionary
    return add_to_dict(snf_obj_type_name_dict, object_type, snf_obj_name)


def retain_persona_roles(entity_dict):
    """
    This function processes a Snowflake object record dictionary (e.g., Warehouse, Database, Schema).
    It extracts and retains only the persona roles from the 'access_roles' array.

    :param entity_dict: Snowflake object record data dictionary, which may include access roles
    :return: Refined dictionary containing only the persona roles in the 'access_roles' field
    """
    # Initialize an empty list to store persona roles
    access_roles_list = []

    # Check if 'access_roles' is a list and extract each 'access_role'
    if isinstance(entity_dict.get('access_roles', None), list):
        for access_role_obj in entity_dict.get('access_roles', None):
            # Append only the 'access_role' field from each role object
            access_roles_list.append(access_role_obj.get('access_role', None))

    # Update the 'access_roles' field with the refined list of persona roles
    entity_dict['access_roles'] = access_roles_list

    return entity_dict


def generate_numeric_id(input_string, max_value=10 ** 8):
    """
    Generates a numeric ID from a given input string using SHA-256 hash.
    The resulting numeric ID is reduced to a smaller value using modulo operation.

    :param input_string: The input string for which the numeric ID is generated
    :param max_value: The maximum value for the generated numeric ID (default is 10^8)
    :return: A string representing the smaller numeric ID derived from the hash
    """
    # Generate SHA-256 hash of the input string
    hash_object = hashlib.sha256(input_string.encode())

    # Convert the hash to a hexadecimal string and then to an integer
    numeric_id = int(hash_object.hexdigest(), 16)

    # Reduce the size of the number using modulo operation
    return str(numeric_id % max_value)


def reset_key_based_on_lookup(src_dict, lookup_dict):
    """
    This function takes an input dictionary (src_dict) and uses a lookup dictionary to replace the keys.
    The keys from the lookup_dict are used to replace the original keys from src_dict.
    Essentially, the values in lookup_dict become the keys for src_dict.

    :param src_dict: Dict with the record we wish to ingest into Snowflake.
    :param lookup_dict: Mapping dictionary where src_dict keys are tied with Snowflake table columns.
    :return: Updated src_dict with keys replaced based on the lookup_dict.
    """
    new_dict = {}
    try:
        # Iterate over the items in src_dict and replace the keys based on lookup_dict
        for k, v in src_dict.items():
            new_key = lookup_dict.get(k)  # Get the new key from lookup_dict or keep the original key
            if new_key:  # If the new key exists in lookup_dict, assign the value
                new_dict[new_key] = v
            else:  # If no new key is found, use the original key
                new_dict[k] = v
        return new_dict
    except Exception as ex:
        # Log the exception details if an error occurs
        logger.exception(f"An exception encountered in reset_key_based_on_lookup: {ex}")
        logger.exception(f"This is src_dict: {src_dict}")
        logger.exception(f"This is lookup_dict: {lookup_dict}")
        return None
