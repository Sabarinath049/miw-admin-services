import argparse
import sys
import time
from datetime import datetime

from constants import S3_LOG_META_FILE_KEY
from constants import SNF_AC_REGION
from helpers.config_log import logger
from helpers.utils import read_json, get_env_variables
from orchestrate.orchestrate_metadata import preprocess_tf_dict, preprocess_roles, preprocess_rm_data, \
    perform_mpl_update, perform_metadata_logging

script_starttime = time.time()
logger.info(f"Python Metadata Entry Script start time : {datetime.now().strftime('%Y%m%d%H%M%S')}")

# Reading the Environment Variable
env_vars = get_env_variables()
env = env_vars["CODEBUILD_ENV"]
git_event = env_vars["CODEBUILD_WEBHOOK_EVENT"]
# pr_id = env_vars["CODEBUILD_WEBHOOK_TRIGGER"]
pr_id = env_vars["PR_NUMBER"]
src_branch = env_vars["CODEBUILD_WEBHOOK_HEAD_REF"]

# Reading Config File based on Environment and Loading all the Constants
configs = read_json(f"config/{env}/config.json")
TF_OUTPUT_BASE_PATH = configs.get("TF_OUTPUT_BASE_PATH")
logger.debug(f"Base path where user input JSONs are hosted : {TF_OUTPUT_BASE_PATH}")

if __name__ == "__main__":
    """Main script to handle metadata provisioning. Steps: S1 : Read the Terraform output and parse it. S2 : Validate 
    whether the TF Output and Input Metadata together are capable of all SNF Table fields for each object type. S3 : 
    Create records for each of the eligible metadata table, MPL table, and roles table. S4 : Perform a transaction 
    into Snowflake (Commit, Rollback)."""

    # Parse arguments: Input path for the Terraform output JSON
    parser = argparse.ArgumentParser(description="Identifies eligible objects for provisioning.")
    parser.add_argument(
        "-i", "--input",
        type=str,
        nargs="+",
        required=True,
        help="Absolute path of file with Terraform Output JSON"
    )
    args = parser.parse_args()

    # Initialize Terraform output file
    tf_output_json = ""

    # Check if input file is provided and read it
    if args.input[0]:
        tf_output_file = args.input[0]
        logger.debug(f"Reading Terraform output JSON from: {tf_output_file}")
        tf_output_json = read_json(tf_output_file)  # Read JSON data from the file

    # Preprocess the JSON if reading is successful
    if tf_output_json:
        logger.debug(f"tf_output_json : {tf_output_json}")

        # Process the Terraform dictionary
        logger.debug("Processing metadata...")
        processed_tf_dicts = preprocess_tf_dict(tf_output_json)
        processed_tf_dicts = [x for x in processed_tf_dicts if x is not None]
        logger.debug(f"Processed data: {processed_tf_dicts}")

        # Preprocess roles and RM data
        persona_roles_data, tech_roles_data, processed_tf_dicts = preprocess_roles(processed_tf_dicts)
        logger.debug(f"The persona_roles_data is : {persona_roles_data}")
        logger.debug(f"The tech_roles_data is : {tech_roles_data}")
        logger.debug(f"The updated processed_tf_dicts is : {processed_tf_dicts}")
        rm_data = preprocess_rm_data(processed_tf_dicts)

        # Combine all provisioned entities into a single list
        list_of_provisioned_entities = processed_tf_dicts + persona_roles_data + tech_roles_data + rm_data
        list_of_provisioned_entities = [x for x in list_of_provisioned_entities if x is not None]

        logger.debug(f"The list of provisioned entities is : {list_of_provisioned_entities}")

        if list_of_provisioned_entities:
            perform_mpl_update(list_of_provisioned_entities, env_vars)
            perform_metadata_logging(list_of_provisioned_entities, env_vars)
        else:
            logger.warning("No valid provisioned entities available for metadata logging. Skipping metadata update.")
    else:
        # Critical error if Terraform JSON couldn't be read
        logger.critical("Error encountered while reading Terraform output. Exiting with status code -1.")
        sys.exit(-1)

    # Calculate and log total runtime
    logger.info(f"Script end time: {datetime.now().strftime('%Y%m%d%H%M%S')}")
    script_endtime = time.time()  # Record the end time
    total_runtime = script_endtime - script_starttime  # Calculate runtime
    logger.info(f"Total runtime: {total_runtime:.2f} seconds")