import argparse
import sys
import time
from datetime import datetime
from constants import SNF_AC_REGION, FILE_DIFF_STATUS_DICT, DIFF_STATUS_STATIC_FILENAMES
from validations.unified_report import summarize_changes, parse_tfplan, beautify_summary
from helpers.config_log import logger
from helpers.utils import get_env_variables,generate_s3_client, read_text_file_from_s3

script_starttime = time.time()
logger.info(f"Python Unified Reporting start time : {datetime.now().strftime('%Y%m%d%H%M%S')}")

# Reading the Environment Variable
env_vars = get_env_variables()
env = env_vars["CODEBUILD_ENV"]
git_event = env_vars["CODEBUILD_WEBHOOK_EVENT"]
# pr_id = env_vars["CODEBUILD_WEBHOOK_TRIGGER"]
pr_id = env_vars["PR_NUMBER"]
src_branch = env_vars["CODEBUILD_WEBHOOK_HEAD_REF"]
eligible_files_str = env_vars["CODEBUILD_FILES_DIFF"]
s3_bucket = env_vars["S3_BUCKET_NAME"]

logger.debug(f"Environment Variables read : {env_vars}")

if __name__ == "__main__":
    # Parse arguments: List of User JSONs eligible for provisioning
    parser = argparse.ArgumentParser(description="Identifies and validates eligible objects for provisioning.")
    parser.add_argument(
        "-i", "--input",
        type=str,
        nargs="+",
        required=True,
        help="List of JSONs eligible for provisioning"
    )
    args = parser.parse_args()

    catalog_files = [
        file for file in args.input
        if "catalog_integrations" in str(file)
    ]

    logger.info("Catalog integration files:")

    for file in catalog_files:
        logger.info(file)

    s3_client = generate_s3_client(region_name=SNF_AC_REGION)

    # preparing terraform output for tags
    tags_tf_plan_output_s3_key = s3_bucket + '/validation/' +pr_id + "/tags_tf_plan_output/tags_tfplan.json"
    logger.debug(f"validation_driver >> main >> tags_tf_plan_output_s3_key : {tags_tf_plan_output_s3_key}")

    tags_parsed_tf_plan, tags_action_count = parse_tfplan(s3_client, tags_tf_plan_output_s3_key)
    logger.debug(f"validation_driver >> tags_parsed_tf_plan : {tags_parsed_tf_plan}")

    tags_tf_plan_summary, tag_unknowns = summarize_changes(tags_parsed_tf_plan)

    # Preparing for unified reporting
    # Read and prepare Terraform Output
    tf_plan_output_s3_key = s3_bucket + '/validation/' +pr_id + "/tf_plan_output/tfplan.json"
    logger.debug(f"validation_driver >> main >> tf_plan_output_s3_key : {tf_plan_output_s3_key}")

    parsed_tf_plan, action_count = parse_tfplan(s3_client, tf_plan_output_s3_key)
    logger.debug(f"validation_driver >> parsed_tf_plan : {parsed_tf_plan}")

    tf_plan_summary, unknowns = summarize_changes(parsed_tf_plan)

    # Read and Prepare the Validation Output
    val_err_s3_key = 'validation/' + pr_id + "/val_result/result.txt"
    val_resultset = read_text_file_from_s3(s3_client, s3_bucket.split("//")[1], val_err_s3_key)
    logger.debug(f"reporting_driver >> main >> val_resultset : {val_resultset}")

    if val_resultset:
        val_resultset_list = val_resultset.split("||")
    else:
        val_resultset_list = []

    # Call Function to Beautify Summaries and Validation Errors (if any)
    beautify_summary(action_count, tf_plan_summary, unknowns, val_resultset_list,tags_tf_plan_summary, tags_action_count, tag_unknowns)

    # Logic to Mark Pipeline failed - If any validation error is encountered or any object is bound to be updated or deleted,
    # please mark pipeline failed as a precautionary measure
    if val_resultset or action_count.get('delete', 0) > 0:
        logger.info("Since Validation or Terraform plan output isn't as per expectation, marking the CodeBuild as failed...!")
        sys.exit(1)