import inspect
from constants import OBJ_ATTRIBUTES_ENFORCE_RECREATE
from helpers.config_log import logger
from helpers.utils import prepare_exception
import os
import inspect
import json

def metadata_change_limiter(env_vars, file_diff_status_dict, files_per_pr_threshold):
    logger.debug(f"misc_validations >> metadata_change_limiter >> env_vars : {env_vars}")
    logger.debug(f"misc_validations >> metadata_change_limiter >> files_per_pr_threshold : {files_per_pr_threshold}")
    pr_file_count = env_vars['CODEBUILD_FILES_DIFF'].split("\n")
    logger.debug(f"Number of files to be processed this PR : {len(pr_file_count)}")
    if len(pr_file_count) <= files_per_pr_threshold:
        return "success"
    else:
        fail_msg = f"Number of Objects catered as part of PR ID {env_vars['CODEBUILD_WEBHOOK_TRIGGER']} is {len(pr_file_count)} and exceeding preset threshold of {files_per_pr_threshold}"
        return prepare_exception("PULL_REQUEST", str(env_vars['CODEBUILD_WEBHOOK_TRIGGER']).upper(), inspect.currentframe().f_code.co_name, fail_msg)

def validate_provisioning_branch(env_vars, file_diff_status_dict):
    base_branch = env_vars['CODEBUILD_WEBHOOK_BASE_REF']
    environment = "main" if env_vars['CODEBUILD_ENV'] == "prd" else env_vars['CODEBUILD_ENV']

    if base_branch == environment:
        return "success"

    fail_msg = (
        f"Source branch where the code is being merged i.e. {base_branch} "
        f"is different from the branch from where code will be picked up i.e. {environment}"
    )
    return prepare_exception(
        "PULL_REQUEST",
        env_vars['CODEBUILD_WEBHOOK_TRIGGER'].upper(),
        inspect.currentframe().f_code.co_name,
        fail_msg
    )


def validate_file_delete(env_vars, file_diff_status_dict):
    deleted_files_array = str(file_diff_status_dict['deleted']).split("\n")
    count_deleted_files = len(deleted_files_array) - 1
    if count_deleted_files > 0 :
        fail_msg = f" {count_deleted_files} files has been deleted as part of this PR. Files Deleted are : {str(deleted_files_array[:-1])}."
        return prepare_exception("PULL_REQUEST", str(env_vars['CODEBUILD_WEBHOOK_TRIGGER']).upper(),
                                 inspect.currentframe().f_code.co_name, fail_msg)
    else:
        return "success"

def validate_file_rename(env_vars, file_diff_status_dict):
    renamed_files_array = str(file_diff_status_dict['renamed']).split("\n")
    count_renamed_files = len(renamed_files_array) - 1
    if count_renamed_files > 0 :
        fail_msg = f" {count_renamed_files} files has been renamed as part of this PR. New file name post-renaming is/are : {str(renamed_files_array[:-1])}."
        return prepare_exception("PULL_REQUEST", str(env_vars['CODEBUILD_WEBHOOK_TRIGGER']).upper(),
                                 inspect.currentframe().f_code.co_name, fail_msg)
    else:
        return "success"

def validate_file_modification(env_vars, file_diff_status_dict):
    modified_files_array = str(file_diff_status_dict['modified']).split("\n")
    count_modified_files = len(modified_files_array) - 1
    if count_modified_files > 0 :
        fail_msg = f" ** APPROACH WITH CAUTION ** : {count_modified_files} files has been modified as part of this PR. Modified Files as part of PR is/are : {str(modified_files_array[:-1])}."
        fail_msg += "\n" + "Please refer MIW's below Lookup which suggests attributes for each object type which can possibly lead to destroy and recreate of an object!"
        fail_msg += "\n" + str(OBJ_ATTRIBUTES_ENFORCE_RECREATE)
        return prepare_exception("PULL_REQUEST", str(env_vars['CODEBUILD_WEBHOOK_TRIGGER']).upper(),
                                 inspect.currentframe().f_code.co_name, fail_msg)
    else:
        return "success"

def precheck_filename_vs_resource_name(ip_file_list):
    """
    Precheck to ensure filename matches the resource name inside JSON.
    Designed to be invoked from validation_driver BEFORE generate_obj_map().
    """
    import os
    from helpers.utils import read_json, prepare_exception

    errors = []

    for file_path in ip_file_list:
        if not file_path.endswith(".json"):
            continue

        filename = os.path.basename(file_path).replace(".json", "")

        try:
            data = read_json(file_path)
        except Exception as ex:
            errors.append(
                prepare_exception(
                    "FILE",
                    filename,
                    "precheck_filename_vs_resource_name",
                    f"Unable to read JSON file {file_path}: {ex}"
                )
            )
            continue

        resource_name = (
            data.get("database_name")
            or data.get("schema_name")
            or data.get("warehouse_name")
            or data.get("aad_group_name")
            or data.get("catalog_integration_name")
            or data.get("external_volume_name")
            or data.get("ps_account_id")
            or data.get("storage_integration_name")
            or data.get("provider_share_name")
        )

        if not resource_name:
            continue

        if filename.upper() != resource_name.upper():
            errors.append(
                prepare_exception(
                    "FILE",
                    resource_name,
                    "validate_resource_name_vs_filename",
                    (
                        f"File name '{filename}' must exactly match the resource name "
                        f"'{resource_name}'. Rename the file or correct the name inside JSON."
                    )
                )
            )

    return errors


def validate_ascii_json(file_path_list: list) -> str:
    """
    Validates that the provided JSON text is strictly ASCII-compliant
    AFTER decoding escape sequences.
    """
    errors = []
    # Step 1: Parse JSON (this converts \u2013 → actual character)
    for file_path in file_path_list:
        try:
            if not file_path.endswith(".json"):
                raise Exception(f"{file_path.split('/')[-1]} is not a valid file for validation")

            file_name = os.path.basename(file_path)
            with open(file_path, 'r', encoding='utf-8') as f:
                raw_json = f.read()

            data = json.loads(raw_json)
        except json.JSONDecodeError as e:
            errors.append(
                prepare_exception(
                    "FILE",
                    file_name,
                    "validate_ascii_json",
                    (
                        f"Invalid JSON in {file_name}: {e}"
                    )
                )
            )
            continue

        # Step 2: Convert back to string with real characters
        normalized_text = json.dumps(data, ensure_ascii=False)

        # Step 3: Validate characters
        for idx, ch in enumerate(normalized_text):
            if ord(ch) > 0x7F:
                errors.append(
                    prepare_exception(
                        "FILE",
                        file_name,
                        "validate_ascii_json",
                        (
                            f"Non-ASCII character detected in {file_name} at position {idx}: "
                            f"'{ch}' (U+{ord(ch):04X}). " 
                            "Only ASCII characters are allowed. "
                            "Example: use '-' (U+002D) instead of '–' (U+2013)."
                        )
                    )
                )
    return errors