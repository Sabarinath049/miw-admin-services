import json
import sys
import time
from dataclasses import dataclass

import snowflake.connector
from snowflake.connector import ProgrammingError

from constants import OBJ_TYPE_RULE_FUNC_PREFIX_MAP, SNF_CONTEXT_DETAILS, SNF_VALIDATION_SP, \
    SNF_POLL_INTERVAL_IN_SECS, SNF_POLL_MAX_RETRY, SNF_CRED_SECRET, SNF_AC_REGION
from helpers.config_log import logger
from helpers.utils import get_secret, generate_oauth_token


def get_snf_secret():
    """Retrieves Snowflake credentials from the secret manager."""
    secret = get_secret(SNF_CRED_SECRET, SNF_AC_REGION)
    return {
        "client_id": secret["client_id"],
        "client_secret": secret["client_secret"],
        "scope": secret["scope"],
        "account": secret["account"],
        "user": secret["user"]
    }


def pull_oauth_token(secret):
    """Generates the oauth token for Snowflake connection."""
    return generate_oauth_token(secret["client_id"], secret["client_secret"], secret["scope"])


def connect_to_snowflake(secret, oauth_token):
    """Establishes the Snowflake connection using oauth."""
    return snowflake.connector.connect(
        account=secret["account"],
        user=secret["user"],
        authenticator="oauth",
        token=oauth_token,
        warehouse=SNF_CONTEXT_DETAILS.get('warehouse', None),
        database=SNF_CONTEXT_DETAILS.get('database', None),
        schema=SNF_CONTEXT_DETAILS.get('schema', None),
        role=SNF_CONTEXT_DETAILS.get('role', None)
    )


def poll_for_sp_completion(snf_conn, sp_response, attempts):
    """
    Polls for the completion of a stored procedure query.

    :param snf_conn: Snowflake connection object.
    :param sp_response: The response object containing the stored procedure query ID.
    :param attempts: Number of retry attempts so far.
    """
    while snf_conn.is_still_running(snf_conn.get_query_status(sp_response)) and attempts < SNF_POLL_MAX_RETRY:
        logger.debug(
            f"Awaiting Stored Proc Query Completion => Attempt {attempts} of {SNF_POLL_MAX_RETRY - 1} with wait time: {SNF_POLL_INTERVAL_IN_SECS} seconds.")
        time.sleep(SNF_POLL_INTERVAL_IN_SECS)
        attempts += 1

    # If still running after max attempts, log and return None
    if snf_conn.is_still_running(snf_conn.get_query_status(sp_response)):
        logger.warning("Stored procedure did not complete within the allowed retry attempts.")
        return None


def fetch_sp_results(snf_cur, sp_response):
    """
    Retrieves the results from a stored procedure query after it completes.

    :param snf_cur: Snowflake cursor object.
    :param sp_response: The response object containing the stored procedure query ID.
    :return: Results from the stored procedure or None if error occurs.
    """
    try:
        snf_cur.get_results_from_sfqid(sp_response)
        return snf_cur.fetchall()
    except ProgrammingError as err:
        logger.exception(f"The stored procedure call has encountered an exception: {err}")
        return None


def prepare_snf_sp_argument(snf_sp_arg):
    """
    Prepares the Snowflake stored procedure argument by serializing it to JSON
    and handling special character escapes for SQL compatibility.

    :param snf_sp_arg: Argument to be passed to the stored procedure.
    :return: Prepared string argument for the stored procedure.
    """
    return json.dumps(snf_sp_arg).replace("'", "''")


def exec_snf_context(snf_cur):
    """
    Sets the Snowflake context (warehouse, database, schema) for the query execution.

    :param snf_cur: Snowflake cursor object.
    """
    logger.debug(f"exec_snf_context >> SNF_CONTEXT_DETAILS : {SNF_CONTEXT_DETAILS}")
    snf_cur.execute(f"USE WAREHOUSE {SNF_CONTEXT_DETAILS.get('warehouse')}")
    snf_cur.execute(f"USE DATABASE {SNF_CONTEXT_DETAILS.get('database')}")
    snf_cur.execute(f"USE SCHEMA {SNF_CONTEXT_DETAILS.get('schema')}")


def construct_proc_query(snf_sp_str_arg):
    """
    Constructs the Snowflake stored procedure call query with the provided argument.

    :param snf_sp_str_arg: The prepared argument for the stored procedure.
    :return: The full SQL query string to call the stored procedure.
    """
    return f"CALL {SNF_CONTEXT_DETAILS.get('database')}.{SNF_CONTEXT_DETAILS.get('schema')}.{SNF_VALIDATION_SP}('{snf_sp_str_arg}')"


def execute_query(snf_cur, proc_query):
    """
    Executes the given query asynchronously and returns the query ID.

    :param snf_cur: Snowflake cursor object.
    :param proc_query: The SQL query to execute.
    :return: The Snowflake query ID.
    """
    snf_cur.execute_async(proc_query)
    logger.debug(f"Executed stored procedure with SFQID: {snf_cur.sfqid}")
    return snf_cur.sfqid


def read_generic_rules(obj_type, rule_list):
    """
    Returns a list of generic rules that apply to the given object type (e.g., warehouse, database, schema).

    :param obj_type: The type of the object (e.g., warehouse, database, schema).
    :param rule_list: A list containing rule suites that may apply to the object type.
    :return: A tuple with two lists:
             - object_generic_python_rules: A list of applicable Python rules.
             - object_generic_snowflake_rules: A list of applicable Snowflake rules.
    """
    object_generic_python_rules = []
    object_generic_snowflake_rules = []

    for rule_suite in rule_list:
        if rule_suite:
            for rule_type, rules in rule_suite.items():
                if rules:  # Ensure there's at least one rule in the list
                    for rule in rules:
                        if rule and obj_type.strip().lower() in rule.get('param', []):
                            # Add to appropriate rule list based on rule type
                            if rule_type == "python":
                                object_generic_python_rules.append(rule)
                            elif rule_type == "snowflake":
                                object_generic_snowflake_rules.append(rule)

    return object_generic_python_rules, object_generic_snowflake_rules


def read_object_rules(obj_type, rule_list):
    """
    Filters rules for the given object type based on a prefix match in the function name.

    :param obj_type: The type of the object (e.g., warehouse, database, schema).
    :param rule_list: A list containing rule suites that may apply to the object type.
    :return: A tuple with two lists:
             - object_specific_python_rules: A list of Python-specific rules for the object type.
             - object_specific_snowflake_rules: A list of Snowflake-specific rules for the object type.
    """
    logger.debug(f"read_object_rules >> obj_type : {obj_type}")
    logger.debug(f"read_object_rules >> rule_list : {rule_list}")

    object_specific_python_rules = []
    object_specific_snowflake_rules = []

    # Get the prefix for the object type
    prefix_to_check = OBJ_TYPE_RULE_FUNC_PREFIX_MAP.get(obj_type)

    for rule_suite in rule_list:
        if rule_suite:
            for rule_type, rules in rule_suite.items():
                if rules:  # Ensure the rule list is not empty
                    logger.debug(f"Rules for {rule_type}: {rules}")
                    for rule in rules:
                        if rule and prefix_to_check in rule.get('function', ''):
                            # Add to the appropriate rule list based on the rule type
                            if rule_type == "python":
                                object_specific_python_rules.append(rule)
                            elif rule_type == "snowflake":
                                object_specific_snowflake_rules.append(rule)

    logger.debug(f"read_object_rules >> object_specific_python_rules : {object_specific_python_rules}")
    logger.debug(f"read_object_rules >> object_specific_snowflake_rules : {object_specific_snowflake_rules}")
    return object_specific_python_rules, object_specific_snowflake_rules


def extract_obj_specific_rules(snf_obj_type, active_rules_list):
    """
    Extracts the relevant Python and Snowflake rules for the given object type from the active rules list.

    :param snf_obj_type: The Snowflake object type (e.g., warehouse, database, schema).
    :param active_rules_list: A list of active rule suites, which should contain four elements.

    :return: A tuple containing two lists:
             - The first list contains all the Python-specific rules.
             - The second list contains all the Snowflake-specific rules.
    """
    # Ensure that the active rules list contains exactly four elements
    if len(active_rules_list) != 4:
        logger.warning("Expected active rules kit to contain 4 elements, but it contains %d elements!",
                       len(active_rules_list))
        return [], []  # Return empty lists if the check fails

    # Extract the relevant rules based on the object type
    python_generic_list, snowflake_generic_list = read_generic_rules(snf_obj_type, active_rules_list)
    python_specific_list, snowflake_specific_list = read_object_rules(snf_obj_type, active_rules_list)

    # Combine and return Python and Snowflake rules
    return python_generic_list + python_specific_list, snowflake_generic_list + snowflake_specific_list


def execute_python_rules(snf_obj, python_rule_kit):
    """
    Executes a list of Python-based validation rules on the given Snowflake object.

    :param snf_obj: The Snowflake object (e.g., warehouse, database).
    :param python_rule_kit: A list of dictionaries representing the Python rules,
                             where each dictionary contains the function name and parameters.

    :return: A list of results from each executed rule, or None if the input is invalid.
    """
    # Check if python_rule_kit is a list
    if not isinstance(python_rule_kit, list):
        logger.warning("The python rule kit provided is not of type list.")
        return None

    py_result_set = []  # List to store results of executed rules

    # Iterate over the list of rules
    for python_rule in python_rule_kit:
        rule_func = python_rule.get('function')
        rule_param = python_rule.get('param')

        logger.debug(f"Executing rule function: {rule_func} with parameter: {rule_param}")

        # Ensure rule_func and rule_param are valid
        if rule_func and rule_param is not None:
            # Get the method from the Snowflake object and check if it's callable
            extract_obj_method = getattr(snf_obj, rule_func, None)
            if callable(extract_obj_method):
                py_result_set.append(extract_obj_method(rule_param))
            else:
                logger.warning(f"The rule function '{rule_func}' is not callable on the object : {snf_obj}.")
        else:
            logger.warning(
                f"The rule function or parameter is invalid (function: {rule_func}, param: {rule_param}).")

    return py_result_set if py_result_set else None


def execute_snf_vals(snf_cur, snf_sp_arg):
    """
    Executes the Snowflake validation stored procedure with the provided arguments.

    :param snf_cur: Snowflake cursor object.
    :param snf_sp_arg: The arguments to pass to the stored procedure.
    :return: Snowflake query ID (sfqid) if execution is successful, None if no validation is required.
    """
    if not snf_sp_arg:
        logger.warning("No snowflake rule validations to be performed as part of this PR request...!")
        snf_cur.close()
        return None

    try:
        # Prepare the argument as a string for the stored procedure
        snf_sp_str_arg = prepare_snf_sp_argument(snf_sp_arg)

        # Set the context and execute the stored procedure asynchronously
        exec_snf_context(snf_cur)

        # Construct the procedure call query
        proc_query = construct_proc_query(snf_sp_str_arg)
        logger.debug(f"execute_snf_vals => proc_query : {proc_query}")
        # Execute the query and return the query ID
        return execute_query(snf_cur, proc_query)

    except Exception as ex:
        logger.exception(f"Snowflake rule validation stored procedure call wasn't successful due to: {ex}")
        return None


def retrieve_sp_result(snf_conn, snf_cur, sp_response):
    """
    Retrieves the result of a stored procedure execution, polling until completion.

    :param snf_conn: Snowflake connection object.
    :param snf_cur: Snowflake cursor object.
    :param sp_response: The response object containing the stored procedure query ID.
    :return: Results of the stored procedure or None in case of error.
    """
    attempts = 0
    try:
        # Wait for the stored procedure to complete (polling mechanism)
        poll_for_sp_completion(snf_conn, sp_response, attempts)

        # Retrieve results after the stored procedure finishes
        return fetch_sp_results(snf_cur, sp_response)

    except Exception as ex:
        logger.exception(
            f"Exception encountered while retrieving the result of stored proc query id: {sp_response} => {ex}")
        return None

    finally:
        snf_conn.close()


def build_snf_conn():
    """
    Establishes a connection to Snowflake using oauth authentication and sets the context (warehouse, database, schema).

    :return: A tuple containing the connection and cursor objects for interacting with Snowflake.
    """
    try:
        # Retrieve the Snowflake credentials from the secret manager
        secret = get_snf_secret()

        # Generate the oauth token
        oauth_token = pull_oauth_token(secret)

        # Establish the connection to Snowflake
        conn = connect_to_snowflake(secret, oauth_token)

        # Set the context for the connection (warehouse, database, schema)
        exec_snf_context(conn.cursor())

    except snowflake.connector.errors.Error as ex:
        logger.exception(f"An exception was encountered while connecting to Snowflake instance: {ex}")
        logger.exception("Exiting code with exit code -1.....!")
        sys.exit(-1)

    return conn, conn.cursor()


@dataclass
class Validator:
    def __init__(self):
        pass