import json
import re
from collections import defaultdict
from urllib.parse import urlparse
from helpers.config_log import logger
from colorama import Fore, Style, Back, init

def beautify_summary(action_count, tf_plan_summary, unknowns, val_err_list,tags_tf_plan_summary,tags_action_count,tag_unknowns, use_colors=True):
    """
    Beautifies the Terraform summary and prints in both markdown-style and optional color-coded format.
    """
    def colorize(text, color):
        return f"{color}{text}{Style.RESET_ALL}" if use_colors else text

    output = []
    output.append("\n🔵🔵🔵🔵🔵🔵 VALIDATION PIPELINE SUMMARY 🔵🔵🔵🔵🔵🔵")
    output.append("\n🔵🔵🔵🔵🔵🔵   TERRAFORM PLAN SUMMARY  🔵🔵🔵🔵🔵🔵")
    # Entity Count
    output.append("🔵🔵🔵Entity Count🔵🔵🔵")
    for action in ['create', 'update', 'delete']:
        count = action_count.get(action, 0) + tags_action_count.get(action, 0)
        emoji = "🟢" if action == 'create' else "🟡" if action == 'update' else "🔴"
        line = f"{emoji} {action.capitalize()}: {count}"
        output.append(colorize(line, Fore.GREEN if action == 'create' else Fore.YELLOW if action == 'update' else Fore.RED))

    # Tags change summary
    # Change Summary
    tag_creation_warning=""
    if tags_tf_plan_summary:
        output.append("\n🔵🔵🔵Pre-requisites Change Summary🔵🔵🔵")
        for line in tags_tf_plan_summary:
            output.append(colorize(f"- {line}", Fore.CYAN))
            if 'create' in line.lower() and 'tag' in line.lower():
                tag_creation_warning="Warning! Tag is getting created, please check pre-requisites for detailed terraform plan"

    # Change Summary
    if tf_plan_summary:
        output.append("\n🔵🔵🔵Change Summary🔵🔵🔵")
        for line in tf_plan_summary:
            output.append(colorize(f"- {line}", Fore.CYAN))

    # Unknowns
    if unknowns or tag_unknowns:
        output.append("\n🔵🔵🔵Complex Entities🔵🔵🔵")
        for item in tag_unknowns:
            output.append(colorize(f"- {item}", Fore.MAGENTA))
        for item in unknowns:
            output.append(colorize(f"- {item}", Fore.MAGENTA))

    output.append("\n🔵🔵🔵🔵🔵🔵  VALIDATION SUITE SUMMARY  🔵🔵🔵🔵🔵🔵")

    # Validation Failures
    if val_err_list:
        output.append("\n🔵🔵🔵Validation Failures🔵🔵🔵")
        output.append(f"\n🔴 Total Validation Failures Encountered : {len(val_err_list)}\n")
        for error in val_err_list:
            output.append(colorize(f"\n❌ {error}", Fore.RED))
        output.append("\n")
    else:
        output.append("\n🔵🔵🔵Validation Status🔵🔵🔵")
        output.append(f"🟢 No validation errors encountered in the process..!\n")
    
    if len(tag_creation_warning)>0:
        output.append("\n🔵🔵🔵 Warning Summary 🔵🔵🔵")
        output.append(tag_creation_warning)

    output.append("\n🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵")
    # Print the beautified output
    final_output = "\n".join(output)
    logger.info(final_output)


def categorize_resources(resources):
    """
    Categorize resources by their Snowflake type using regex.

    Args:
        resources (list): List of resource addresses.

    Returns:
        dict: Dictionary categorizing resources by type.
    """
    categorized = defaultdict(list)
    unknown = []
    for res in resources:
        # Match standard snowflake resource with dot notation
        if match := re.search(r"\.(snowflake_\w+)\.", res):
            resource_type = match.group(1)
        # Match resource types in bracket form e.g. snowflake_<type>[
        elif match := re.search(r"snowflake_(\w+)\[", res):
            resource_type = f"snowflake_{match.group(1)}"
        else:
            resource_type = "Complex Entitie"
            unknown.append(res)
        categorized[resource_type].append(res)

    logger.debug(f"unified_report >> categorize_resources >> unknown : {unknown}")
    return categorized, unknown


def summarize_resources(action, resources):
    """
    Summarize resource changes by type and count.

    Args:
        action (str): Action performed (create/update/delete).
        resources (list): List of resource addresses.

    Returns:
        list: Summarized descriptions of the resource actions.
    """
    if not resources:
        return None

    summaries = []
    unknowns = []
    categorized, unknown = categorize_resources(resources)

    for resource_type, items in categorized.items():
        count = len(items)
        readable_type = resource_type.replace("snowflake_", "").replace("_", " ").title()
        summary = f"{action.capitalize()} {count} {readable_type}{'s' if count > 1 else ''}"
        summaries.append(summary)

    if unknown:
        unknowns.extend(unknown)

    logger.debug(f"unified_report >> summarize_resources >> unknown : {unknowns}")
    return summaries, unknowns


def summarize_changes(change_data):
    """
    Produce a full summary of create, update, and delete actions.

    Args:
        change_data (dict): Dictionary of resource changes by action.

    Returns:
        list: List of summarized resource change descriptions.
    """
    summary_output = []
    agg_unknowns = []
    for action in ["create", "update", "delete"]:
        changes = change_data.get(action, [])
        if changes:
            summaries, unknowns = summarize_resources(action, changes)
            logger.debug(f"unified_report >> summarize_changes >> summaries : {summaries}")
            logger.debug(f"unified_report >> summarize_changes >> unknowns : {unknowns}")
            if summaries:
                summary_output.extend(summaries)
            if unknowns:
                agg_unknowns.extend(unknowns)
        else:
            logger.info(f"No entries to be process form Terraform plan for action type : {action}")

    logger.debug(f"unified_report >> summarize_changes >> agg_unknowns : {agg_unknowns}")
    return summary_output, agg_unknowns


def parse_tfplan(s3_client, s3_json_file_key):
    """
    Parse the Terraform plan JSON to extract resource changes.

    Args:
        json_path (str): Path to the Terraform plan JSON file.

    Returns:
        dict: Dictionary categorizing resource addresses by action.
    """

    parsed = urlparse(s3_json_file_key)
    bucket_name = parsed.netloc
    file_key = parsed.path.lstrip('/')

    logger.debug(f"unifed_report >>  parse_tfplan >> parsed : {parsed}")
    logger.debug(f"unifed_report >>  parse_tfplan >> bucket_name : {bucket_name}")
    logger.debug(f"unifed_report >>  parse_tfplan >> file_key : {file_key}")

    response = s3_client.get_object(Bucket=bucket_name, Key=file_key)
    tf_plan_out_content = response['Body'].read().decode('utf-8')

    tfplan = json.loads(tf_plan_out_content)

    actions_summary = {
        'create': [],
        'update': [],
        'delete': []
    }

    actions_count = {
        'create': None,
        'update': None,
        'delete': None
    }

    resource_changes = tfplan.get('resource_changes', [])

    for rc in resource_changes:
        action = rc.get('change', {}).get('actions', [])
        address = rc.get('address')

        if 'create' in action and 'delete' in action:
            # A create+delete combination means a "replace" operation
            actions_summary['update'].append(address)
        elif 'create' in action:
            actions_summary['create'].append(address)
        elif 'update' in action:
            actions_summary['update'].append(address)
        elif 'delete' in action:
            actions_summary['delete'].append(address)

    # Logging for debugging or CLI output

    logger.info("Resources to be created:")
    logger.info(f"  Number: {len(actions_summary['create'])}")
    actions_count['create'] = len(actions_summary['create'])
    for r in actions_summary['create']:
        logger.debug(f"  - {r}")

    logger.info("\nResources to be updated:")
    logger.info(f"  Number: {len(actions_summary['update'])}")
    actions_count['update'] = len(actions_summary['update'])
    for r in actions_summary['update']:
        logger.debug(f"  - {r}")

    logger.info("\nResources to be destroyed:")
    logger.info(f"  Number: {len(actions_summary['delete'])}")
    actions_count['delete'] = len(actions_summary['delete'])
    for r in actions_summary['delete']:
        logger.debug(f"  - {r}")

    return actions_summary, actions_count