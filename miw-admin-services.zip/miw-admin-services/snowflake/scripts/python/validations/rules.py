from dataclasses import dataclass
from typing import Dict

from helpers.config_log import logger
from helpers.utils import dict_safe_retrieval


def parse_object_rules(object_rules_dict, keys, rule_function, func_ags):
    '''
    Retrieve a dictionary from the object_rules_dict based on the keys, and apply a rule function to the
    retrieved dictionary along with additional function arguments.

    :param object_rules_dict: Dictionary containing the object rules.
    :param keys: Keys to retrieve the value from the object_rules_dict.
    :param rule_function: Function that processes the retrieved dictionary.
    :param func_ags: Additional arguments to pass to the rule_function.
    :return: Result of applying the rule_function to the retrieved dictionary and arguments.
    '''
    retrieved_dict = dict_safe_retrieval(object_rules_dict, keys)  # Retrieve the specific dictionary
    if retrieved_dict is not None:
        return list(retrieved_dict.values())
    else:
        return []

def merge_active_rules(generic_rules_dict, object_rules_dicts_list):
    """
    Merges active rules from generic and object-specific rule sets.

    :param generic_rules_dict: Dictionary containing active generic rules.
    :param object_rules_dicts_list: Dictionary containing active object-specific rules.
    :return: Merged dictionary containing 'python' and 'snowflake' rules.
    """
    logger.debug(f"merge_active_rules >> generic_rules_dict : {generic_rules_dict}")
    logger.debug(f"merge_active_rules >> object_rules_dicts_list : {object_rules_dicts_list}")

    return {
        'python': generic_rules_dict.get('python', []) + object_rules_dicts_list.get('python', []),
        'snowflake': generic_rules_dict.get('snowflake', []) + object_rules_dicts_list.get('snowflake', [])
    }


def merge_rules_dicts(rule_dicts_list):
    """
    Merges a list of rule dictionaries into a single dictionary with keys 'python' and 'snowflake'.
    If a key is found in multiple dictionaries, its values are appended to the respective lists.

    :param rule_dicts_list: List of dictionaries to merge, each containing 'python' and/or 'snowflake' keys.
    :return: A merged dictionary with 'python' and 'snowflake' as keys, containing all combined values.
    """
    merged_rule_dict = {'python': [], 'snowflake': []}
    logger.debug(f"merge_rules_dicts >> rule_dicts_list : {rule_dicts_list}")
    for rule_dict in rule_dicts_list:
        # Extend the merged dictionary with values from the input rule_dict
        if 'python' in rule_dict:
            merged_rule_dict['python'].extend(rule_dict['python'])
        if 'snowflake' in rule_dict:
            merged_rule_dict['snowflake'].extend(rule_dict['snowflake'])

    return merged_rule_dict


@dataclass
class Rules:
    required: bool

    def __init__(self, rule_dict):
        """
        Initializing the parent class 'Rules' and distributing the data to rule subclasses
        :param rule_dict: Dictionary containing initialization rules for the parent and its chile rule classes.
        """
        self.rule_dict = rule_dict

        self.TeamProfileValidation = TeamProfileValidation(
            self.rule_dict.get('team_profile_validation').get('required'))
        self.BusinessValidation = BusinessValidation(self.rule_dict.get('business_validation').get('required'))
        self.ConventionValidation = ConventionValidation(**self.rule_dict.get('convention_validation'))
        self.TechnicalValidation = TechnicalValidation(**self.rule_dict.get('technical_validation'))

    def check_suite_eligibility(self):
        return "Eligible" if self.required is True else "Not Eligible"

    def collate_active_validations(self):
        return [self.TeamProfileValidation.identify_team_profile_vals(),
                self.BusinessValidation.identify_business_vals(), self.ConventionValidation.identify_convention_vals(),
                self.TechnicalValidation.identify_tech_vals()]

    def identify_active_rule(self, rule_dict):
        """
        Identifies whether the rule in the provided dictionary is active.

        :param rule_dict: A dictionary representing the rule to be checked.
        :return: The rule dictionary if active, otherwise None.
        """
        if rule_dict:
            # Check if the 'isactive' key exists and is set to True
            if rule_dict.get('isactive', False) is True:
                return rule_dict  # Return the rule if it is active

            # Log a debug message if the rule is not active
            logger.debug(
                f"{self.__class__.__name__} suite's rule : {rule_dict.get('function', None)} hasn't been activated....!"
            )

        return None  # Return None if rule_dict is not active or is not provided

    def identify_active_obj_rules(self, rules_dict, rule_type):
        """
        Generalized method to identify active rules for a given rule type.

        :param rules_dict: Dictionary of rules categorized by type.
        :param rule_type: String indicating the type of rules (e.g., "python", "snowflake").
        :return: Dictionary with active rules under the given rule_type.
        """
        active_rules = []  # List to store active rules
        if rules_dict.get(rule_type):
            stack_specific_rules_dict = rules_dict.get(rule_type)

            # Iterate through each rule in the stack-specific rules dictionary
            for rule_key in stack_specific_rules_dict:
                rule_state = self.identify_active_rule(stack_specific_rules_dict.get(rule_key))

                # Only add the rule to the active_rules list if it is not None (i.e., it's active)
                if rule_state:
                    active_rules.append(rule_state)

        # Return the dictionary containing active rules under the specified rule_type
        return {rule_type: active_rules}

    def identify_active_generic_rules(self, generic_rules_dict):
        """
        Identifies and merges active Python and Snowflake rules from a given dictionary.

        :param generic_rules_dict: Dictionary containing rules for different rule types.
        :return: Dictionary with active Python and Snowflake rules.
        """
        python_rules_dict = self.identify_active_obj_rules(generic_rules_dict, "python")
        snf_rules_dict = self.identify_active_obj_rules(generic_rules_dict, "snowflake")

        # Merge the dictionaries with the active rules
        return {**python_rules_dict, **snf_rules_dict}


    def identify_active_object_rules(self, object_rules_dict):
        '''
        Identifies active rules for different Snowflake object types for both 'python' and 'snowflake' categories.

        :param object_rules_dict: Dictionary containing rules for various Snowflake objects.
        :return: Merged dictionary containing active rules for 'python' and 'snowflake' categories.
        '''
        logger.debug(f"identify_active_object_rules >> object_rules_dict : {object_rules_dict}")

        # List of object types to process
        object_types = ['warehouse', 'database', 'schema', 'persona_role','storage_integration','external_volume','catalog_integration']

        # Generate the rules for both 'python' and 'snowflake' types
        active_python_rules = [
            parse_object_rules(object_rules_dict, [obj_type, 'python'], self.identify_active_obj_rules, 'python')
            for obj_type in object_types
        ]
        logger.debug(f"identify_active_object_rules >> active_python_rules : {active_python_rules}")
        flattened_active_python_rules = [item for sublist in active_python_rules for item in sublist]
        active_snowflake_rules = [
            parse_object_rules(object_rules_dict, [obj_type, 'snowflake'], self.identify_active_obj_rules, 'snowflake')
            for obj_type in object_types
        ]
        logger.debug(f"identify_active_object_rules >> active_snowflake_rules : {active_snowflake_rules}")
        flattened_active_snowflake_rules = [item for sublist in active_snowflake_rules for item in sublist]
        all_active_rules = {"python": flattened_active_python_rules, "snowflake": flattened_active_snowflake_rules}
        return all_active_rules


    def identify_active_rules(self):
        """
        Identifies and merges active rules for both 'python' and 'snowflake' categories from generic and
        object-specific rule sets.

        :return: Dictionary containing merged active 'python' and 'snowflake' rules.
        """
        # Identify active rules for generic and object-specific rule sets
        generic_rules_dict = self.identify_active_generic_rules(self.generic)
        object_rules_dicts_list = self.identify_active_object_rules(self.objects)
        logger.debug(f"identify_active_rules >> generic_rules_dict : {generic_rules_dict}")
        logger.debug(f"identify_active_rules >> object_rules_dicts_list : {object_rules_dicts_list}")
        # Merge the rules from both sources
        return merge_active_rules(generic_rules_dict, object_rules_dicts_list)

    def validate(self):
        raise NotImplementedError("Each rule subclass must implement the 'validate' method.")


@dataclass
class TeamProfileValidation(Rules):
    def identify_active_rules(self):
        return None

    def identify_team_profile_vals(self):
        return self.identify_active_rules()


@dataclass
class BusinessValidation(Rules):
    def identify_active_rules(self):
        return None

    def identify_business_vals(self):
        return self.identify_active_rules()


@dataclass
class ConventionValidation(Rules):
    generic: Dict[str, Dict]
    objects: Dict[str, Dict]

    def identify_convention_vals(self):
        return self.identify_active_rules()


@dataclass
class TechnicalValidation(Rules):
    generic: Dict[str, Dict]
    objects: Dict[str, Dict]
    misc: Dict[str, Dict]
    def identify_tech_vals(self):
        return self.identify_active_rules()
