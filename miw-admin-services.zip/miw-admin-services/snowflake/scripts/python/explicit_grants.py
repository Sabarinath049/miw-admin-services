from validations.validators import build_snf_conn
from helpers.config_log import logger
import os
import json
from constants import SNF_CONTEXT_DETAILS,SNF_CRED_SECRET, SNF_AC_REGION
from helpers.utils import get_secret, generate_oauth_token
import sys


def connect_to_Snowflake(snf_role):
    import snowflake.connector
    secret = get_secret(SNF_CRED_SECRET, SNF_AC_REGION)
    oauth_token=generate_oauth_token(secret["client_id"], secret["client_secret"], secret["scope"])
    conn= snowflake.connector.connect(
    account=secret["account"],
    user=secret["user"],
    authenticator="oauth",
    token=oauth_token,
    role=snf_role 
    )
    return conn, conn.cursor()


def read_tfvars_file(file_path):
    """ Read tfvars file and deftermine admin roles"""
    object_mapping_to_admin_roles={"DATABASE":"DBADMIN","SCHEMA":"DBADMIN","WAREHOUSE":"WHADMIN"}
    file_contents=read_json(file_path, False).split('\n')
    modified_object_mapping_to_admin_roles={}
    for content in file_contents:
        if '=' in content:
            var=content.split('=')[0].strip()
            val=content.split('=')[1].strip()
            for k,v in object_mapping_to_admin_roles.items():
                if v.upper() in val.upper():
                    modified_object_mapping_to_admin_roles[k]=val.replace('"','')
    # print("Modified_object :", modified_object_mapping_to_admin_roles, flush=True)
    return modified_object_mapping_to_admin_roles



def read_json(file, is_json=True):
    """ Reading json file and parsing the string into python json object"""
    content=""
    if is_json:
        with open(file) as f:
            content=json.loads(f.read())
    else:
        with open(file) as f:
            content=f.read()
    return content

def process_grant_commands(command_list, modified_object_mapping_to_admin_roles):
    """Validate the grant command and then use the appropriate ADMIN role"""
    wh_role=[]
    db_role=[]
    
    for cmd in command_list:
        # print("Command list command: ",cmd, flush=True)
        for k,v in modified_object_mapping_to_admin_roles.items():
            if k.upper() in cmd.upper():
                if 'DATABASE' in k.upper():
                    db_role.append(cmd)
                else:
                    wh_role.append(cmd) 

    snf_conn, snf_cur = connect_to_Snowflake(snf_role=modified_object_mapping_to_admin_roles["WAREHOUSE"])
    snf_cur.execute("BEGIN")

    print("Executing Warehouse grants using warehouse role: ",wh_role, flush=True)
    
    for cmd in list(wh_role):
        try:
            snf_cur.execute(cmd.upper())
        except Exception as e:
            snf_cur.execute("ROLLBACK")
            print("Command Exceution failed: ", cmd, flush=True)
            raise Exception("Unable to execute the query due to the error: "+str(e))  
    
    snf_cur.execute("COMMIT")
    snf_cur.close()
    snf_conn.close()


    snf_conn, snf_cur = connect_to_Snowflake(snf_role=modified_object_mapping_to_admin_roles["DATABASE"])
    print("Executing Database grants using database role: ",db_role, flush=True)
    snf_cur.execute("BEGIN")
    for cmd in list(db_role):
        try:
            snf_cur.execute(cmd.upper())
        except Exception as e:
            snf_cur.execute("ROLLBACK")
            print("Command Exceution failed: ", cmd, flush=True)
            raise Exception("Unable to execute the query due to the error: "+str(e))  
    
    snf_cur.execute("COMMIT")
    snf_cur.close()
    snf_conn.close()
    return db_role+wh_role


def read_roles_files(modified_object_mapping_to_admin_roles):
    """ Read roles input metadata jsons and then assign explicit grants """
    input_base_folder = sys.argv[2]
    git_file_diff = os.getenv('NEW_DEPLOY_CODEBUILD_FILES_DIFF')
    print("The files passed to explicit grants are: ", git_file_diff)
    if git_file_diff is None:
        git_file_diff=[]
    else:
        git_file_diff=git_file_diff.split('\n')
    
    ## remove files other than .json
    modify_git_file_diff=[]
    for file in git_file_diff:
        if file.lower().endswith('.json'):
            modify_git_file_diff.append(file)

    git_file_diff=modify_git_file_diff
    
    # print("Files created for this PR",git_file_diff)
    filter_roles_files=[file for file in git_file_diff if 'roles/' in file.lower()]
    # print("Filtered the files to only use the roles",filter_roles_files)
    grant_cmds={}
    if len(filter_roles_files)>=1:
        for folder_files in filter_roles_files:
            before_process_grants=[]
            input_file = os.path.join(input_base_folder, folder_files)
            preprocess_file_name = input_file.rsplit('/', 1)
            # input_file = f"{preprocess_file_name[0]}/enriched_{preprocess_file_name[1]}"
            input_file = f"{preprocess_file_name[0]}/{preprocess_file_name[1]}"

            if os.path.exists(input_file):
                input_content=read_json(input_file)
                if 'grants' in input_content.keys():
                    if len(input_content['grants'])>0:
                        logger.info(f"Fetch the grants from the file {input_file} and executing them!!")
                        before_process_grants.extend(input_content['grants'])
                        # print(before_process_grants, flush=True)
                        ## process grants using the various admin roles based on grants
                        grant_cmds[input_file]=process_grant_commands(command_list=before_process_grants, modified_object_mapping_to_admin_roles=modified_object_mapping_to_admin_roles)
                        logger.info(f"The following grants are applied using {input_file} => {json.dumps(grant_cmds[input_file],indent=5)}")
                        logger.info(f"Executed the grants from the file {input_file} and grants are applied successfully!!")    
                else:
                    continue
            else:
                logger.warning(f"{input_file} doesn't exist, please validate!!")
    else:
        logger.warning("No files to grant explicit grants")

def run_explicit_grants():
    logger.info(f"Executing the python program explicit grants")
    tf_var_file_path=sys.argv[1]
    modified_object_mapping_to_admin_roles=read_tfvars_file(tf_var_file_path)
    logger.debug(f"Mapping the admin roles from tfvars file so that we don't have any hardcoded values for admin roles {json.dumps(modified_object_mapping_to_admin_roles, indent=5)}")
    grants=read_roles_files(modified_object_mapping_to_admin_roles)
    logger.info(f"Execution completed for the python program explicit grants")


if __name__ == "__main__":
    run_explicit_grants()
