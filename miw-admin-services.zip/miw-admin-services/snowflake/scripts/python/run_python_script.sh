#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e
export PYTHONUNBUFFERED=1


export PYTHON_SCRIPT=$(
  if [ "$2" = "validate" ]; then
    echo "validation_driver.py"
  elif [ "$2" = "unified_report" ]; then
    echo "reporting_driver.py"
  else
    echo "metadata_driver.py"
  fi
)

# Define the requirements file

REQUIREMENTS_FILE="requirements.txt"

# Step 1: Install dependencies
echo "Installing dependencies..."
if [ -f "$REQUIREMENTS_FILE" ]; then
    pip install -r $REQUIREMENTS_FILE --quiet
else
    echo "Error: $REQUIREMENTS_FILE not found!"
    exit 1
fi

# Step 2: Run the Python script
echo "Running Python script..."
cd $3

if [ -f "$PYTHON_SCRIPT" ]; then
    python $PYTHON_SCRIPT --input $1
    echo $?
else
    echo "Error: $PYTHON_SCRIPT not found...!"
    exit 1
fi

echo "Script execution completed successfully!"