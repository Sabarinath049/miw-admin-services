import json
import sys
from helpers.config_log import logger
import os

logger.info("Running preprocess to format output produced by Terraform")


# Preprocess output
def preprocess_output(input_json):
    """Used to preprocess output by removing type"""
    output = {}
    for i in input_json:
        output[i] = input_json[i]
        if 'type' in output[i]:
            del output[i]['type']
    return output


# Load JSON file
def load_json(filename):
    with open(filename, "r") as file:
        return json.load(file)


logger.debug(f"Reading final terraform output file -> {sys.argv[1]}")
try:
    final_output_v1 = load_json(sys.argv[1])
except Exception:
    print("final_output.json doesn't exist!!\nThus, just having empty outputs file")
    final_output_v1 = {}

logger.debug(f"Before processing -> {final_output_v1=}")
final_processed_json = preprocess_output(final_output_v1)

output_dir = sys.argv[2]
logger.info(f"\nAfter preprocessing -> {final_processed_json=}")


def remove_all_resource_access_roles(input_json):
    """Purpose of this function to remove dataintegrator tech roles to be removed while passing it to ROLES_METADATA_TBL"""
    resources = ['schema', 'warehouse']
    for key in resources:
        if f'{key}_outputs' not in input_json:
            continue

        for resource, resource_desc in input_json[f'{key}_outputs']['value'].items():
            if 'input_metadata' in resource_desc:
                for k, v in resource_desc['input_metadata'].items():
                    if 'access_roles' in k:
                        access_roles = []
                        for access_role in v:
                            if access_role != '{}' and 'dataintegrator' in access_role['access_role']:
                                continue
                            else:
                                access_roles.append(access_role)
                        if len(access_roles) >= 0:
                            resource_desc['input_metadata']['access_roles'] = access_roles
    return input_json


def rename_to_role_name_roles_output(input_json):
    """Purpose of this function to rename aad_group_name to role_name for ROLES_METADATA_TBL"""
    resources = ['roles']
    for key in resources:
        if f'{key}_outputs' not in input_json:
            continue

        for resource, resource_desc in input_json[f'{key}_outputs']['value'].items():
            if 'input_metadata' in resource_desc:
                input_metadata = {}
                for k, v in resource_desc['input_metadata'].items():
                    input_metadata[k] = v
                input_metadata['role_name'] = input_metadata['aad_group_name']
                resource_desc['input_metadata'] = input_metadata
    return input_json


logger.debug(f"Before removing data_integrator tech roles from warehouse and schema levels := {final_processed_json}")
final_processed_json = remove_all_resource_access_roles(final_processed_json)
logger.debug(f"After removing data_integrator tech roles from warehouse and schema levels := {final_processed_json}")

final_processed_json = rename_to_role_name_roles_output(final_processed_json)
logger.debug(f"After adding role_name to roles_output input_metadata := {final_processed_json}")

logger.info(f"\nFinal processed json produced -> {final_processed_json}")

# Output the final processed JSON to a file
with open(os.path.join(output_dir, 'processed_output.json'), 'w+') as f:
    f.write(json.dumps(final_processed_json))

logger.info(f"Created file {os.path.join(output_dir, 'processed_output.json')}")
logger.info("Completed executing the program preprocess_output.py")