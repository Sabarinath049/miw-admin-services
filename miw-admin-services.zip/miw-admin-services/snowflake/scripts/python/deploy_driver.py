from explicit_grants import run_explicit_grants
from orchestrate.provision import provision_catalog_integrations

def main():
    run_explicit_grants()
    provision_catalog_integrations()

if __name__ == "__main__":
    main()