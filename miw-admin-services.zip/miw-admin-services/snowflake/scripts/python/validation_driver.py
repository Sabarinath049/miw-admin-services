import argparse
import json
import sys
import time
from datetime import datetime

from constants import GIT_PATH_RULE_BOOK_MAP, OBJ_NAME_KEY_MAP, SNF_AC_REGION, SNF_CONTEXT_DETAILS, FILE_DIFF_STATUS_DICT, DIFF_STATUS_STATIC_FILENAMES
from validations.unified_report import summarize_changes, parse_tfplan, beautify_summary
from db.db_manager import perform_mpl_logging
from helpers.config_log import logger
from helpers.utils import read_json, get_env_variables,generate_s3_client, read_text_file_from_s3, write_content_to_s3
from orchestrate.orchestrate_val import generate_obj_map, generate_valid_snf_objs, apply_validation_rules, apply_misc_vals
from snowflake_objects.snowflake_objects import Catalog_Integration
from validations.misc_validations import precheck_filename_vs_resource_name, validate_ascii_json

script_starttime = time.time()
logger.info(f"Python Validation & Logging start time : {datetime.now().strftime('%Y%m%d%H%M%S')}")

# Reading the Environment Variable
env_vars = get_env_variables()
env = env_vars["CODEBUILD_ENV"]
git_event = env_vars["CODEBUILD_WEBHOOK_EVENT"]
# pr_id = env_vars["CODEBUILD_WEBHOOK_TRIGGER"]
pr_id = env_vars["PR_NUMBER"]
src_branch = env_vars["CODEBUILD_WEBHOOK_HEAD_REF"]
eligible_files_str = env_vars["CODEBUILD_FILES_DIFF"]
s3_bucket = env_vars["S3_BUCKET_NAME"]

logger.debug(f"Environment Variables read : {env_vars}")

# Reading Config File based on Environment and Loading all the Constants
configs = read_json(f"config/{env}/config.json")
rule_data = read_json(f"config/{env}/rule_book.json")

logger.debug(f"Rule Book : {rule_data}")


def cache_existing_catalog_integrations(s3_client, bucket_name, pr_id, ci_suffix="_CI"):
    """
    Runs 'SHOW CATALOG INTEGRATIONS' once for the whole PR and caches the resulting
    database names (with ci_suffix stripped) as a JSON file in S3, keyed by pr_id, so
    ci_check_db_not_in_existing_catalog_integrations doesn't need to query Snowflake
    again for every catalog integration file changed/updated in the PR.
    """
    from explicit_grants import connect_to_Snowflake

    cache_key = f"validation/{pr_id}/catalog_integrations/existing_catalog_integrations.json"

    snf_conn = None
    snf_cur = None
    try:
        snf_conn, snf_cur = connect_to_Snowflake(snf_role=SNF_CONTEXT_DETAILS.get("account_admin_role"))
        snf_cur.execute("SHOW CATALOG INTEGRATIONS")

        # Locate the 'name' column robustly using the cursor metadata.
        columns = [str(col[0]).lower() for col in snf_cur.description]
        name_idx = columns.index("name") if "name" in columns else 0

        existing_ci_dbs = set()
        for row in snf_cur.fetchall():
            ci_name = str(row[name_idx]).strip().upper()
            if ci_name.endswith(ci_suffix):
                ci_name = ci_name[: -len(ci_suffix)]
            existing_ci_dbs.add(ci_name)

        write_content_to_s3(s3_client, bucket_name, cache_key, json.dumps(sorted(existing_ci_dbs)))
    except Exception as ex:
        logger.error(f"Failed to cache existing catalog integrations to S3 (key: {cache_key}): {ex}")
    finally:
        if snf_cur is not None:
            snf_cur.close()
        if snf_conn is not None:
            snf_conn.close()


if __name__ == "__main__":
    """
    Main script to perform validation and logging for Snowflake objects.
    Steps:
    S1: Read the Rule Book JSON.
    S2: Parse and validate the user input JSONs.
    S3: Apply validation rules on valid Snowflake objects.
    S4: Log results and handle errors if validation fails.
    S5: Calculate runtime and publish logs to S3.
    """

    # Read the Rule Book (contains validation rules for objects)
    #rule_data = read_json(rules)

    # Parse arguments: List of User JSONs eligible for provisioning
    parser = argparse.ArgumentParser(description="Identifies and validates eligible objects for provisioning.")
    parser.add_argument(
        "-i", "--input",
        type=str,
        nargs="+",
        required=True,
        help="List of JSONs eligible for provisioning"
    )
    args = parser.parse_args()

    # Ensure base path for JSONs is provided, and all changed files are coming in as part of environment variable
    # The base path is attached to the changed files to populate list of files eligible for validation
    ip_file_list = []
    valid_ip_file_list = []
    filename_mismatch_errors = []

    if args.input[0] and eligible_files_str:
        eligible_files_list = eligible_files_str.split()
        for change_file in eligible_files_list:
            file_name = args.input[0] + "/" + change_file
            ip_file_list.append(file_name)

        logger.info(f"Files eligible for performing Validation are : {ip_file_list}")

        # Run filename check per file so bad files can be excluded from deeper validation
        for file_path in ip_file_list:
            logger.info(f"Running filename precheck for file: {file_path}")
            file_errors = precheck_filename_vs_resource_name([file_path])
            logger.info(f"Precheck errors for {file_path}: {file_errors}")

            # ASCII compliance check (fail fast)
            file_content_errors = validate_ascii_json([file_path])

            if file_errors:
                filename_mismatch_errors.extend(file_errors)
                for err in file_errors:
                    logger.error(err)
                    print(err)
            else:
                valid_ip_file_list.append(file_path)

            if file_content_errors:
                filename_mismatch_errors.extend(file_content_errors)
                for err in file_content_errors:
                    logger.error(err)
                    print(err)

    else:
        logger.critical("Base path for the JSONs or changed JSONs not provided or changed files not . Exiting with exit code -1.")
        sys.exit(-1)

    # Generate object map to identify the relationship between objects and rules
    obj_map = generate_obj_map(valid_ip_file_list, GIT_PATH_RULE_BOOK_MAP) if valid_ip_file_list else {}


    # Apply Misc. Validations (Non Snowflake Object Specific Validations) e.g. PR Validations
    s3_client = generate_s3_client(region_name=SNF_AC_REGION)
    base_git_diff_status_path = 'validation/' + pr_id + "/git_diff_files/"
    for key, value in DIFF_STATUS_STATIC_FILENAMES.items():
        FILE_DIFF_STATUS_DICT[key] = read_text_file_from_s3(s3_client, s3_bucket.split("//")[1], base_git_diff_status_path + value)

    logger.debug(f"validation_driver >> main >> FILE_DIFF_STATUS_DICT : {FILE_DIFF_STATUS_DICT}")

    #Reading the File Diffs with Status and assigning them a variable
    misc_val_err_list = apply_misc_vals(env_vars, FILE_DIFF_STATUS_DICT, rule_data)

    # Generate valid Snowflake objects and identify any pre-validation errors
    if obj_map:
        valid_snf_objs, pre_val_err_list = generate_valid_snf_objs(
            obj_map,
            args.input[0],
            GIT_PATH_RULE_BOOK_MAP,
            OBJ_NAME_KEY_MAP
        )
    else:
        valid_snf_objs, pre_val_err_list = {}, []

    # Fetch existing catalog integrations once per PR (instead of once per changed file).
    if any(
        isinstance(snf_obj, Catalog_Integration)
        for snf_obj_list in valid_snf_objs.values()
        for snf_obj in snf_obj_list
    ):
        cache_existing_catalog_integrations(s3_client, s3_bucket.split("//")[1], pr_id)

    # If there are validation errors, log and exit
    if pre_val_err_list:
        logger.error("Identified objects do not comply with the predefined template. Please review guidelines and "
                         "fix the PR")
        logger.error(f"Impacted Objects: {pre_val_err_list}")

        final_err_list = []

        if filename_mismatch_errors:
            final_err_list.extend(filename_mismatch_errors)

        if misc_val_err_list:
            final_err_list.extend(misc_val_err_list)

        if pre_val_err_list:
            final_err_list.extend(pre_val_err_list)

        val_err_s3_key = 'validation/' + pr_id + "/val_result/result.txt"
        val_err_str = "||".join(final_err_list)
        write_content_to_s3(s3_client, s3_bucket.split("//")[1], val_err_s3_key, val_err_str)

        sys.exit(-1)

    # If validation is successful, apply the validation rules on the valid Snowflake objects
    logger.debug(f"Valid Snowflake Object Instances: {valid_snf_objs}")
    val_err_list = apply_validation_rules(valid_snf_objs, rule_data) if valid_snf_objs else []

    # apply_validation_rules returns None or an empty list when everything passed.
    if val_err_list:
        logger.error(f"Validation error list: {val_err_list}")
    else:
        logger.info("All validations passed successfully. No validation errors found.")
        val_err_list = []

    if misc_val_err_list:
        val_err_list.extend(misc_val_err_list)

    if filename_mismatch_errors:
        val_err_list.extend(filename_mismatch_errors)

    val_err_s3_key = 'validation/' + pr_id + "/val_result/result.txt"
    val_err_str = "||".join(val_err_list)
    write_content_to_s3(s3_client, s3_bucket.split("//")[1], val_err_s3_key, val_err_str)


    # Perform logging for the MPL (Merge Pull Request) operation
    return_code = perform_mpl_logging(git_event, pr_id, src_branch)

    """
    # Preparing for unified reporting
    tf_plan_output_s3_key = s3_bucket + '/validation/' +pr_id + "/tf_plan_output/tfplan.json"
    logger.debug(f"validation_driver >> main >> tf_plan_output_s3_key : {tf_plan_output_s3_key}")

    parsed_tf_plan, action_count = parse_tfplan(s3_client, tf_plan_output_s3_key)
    logger.debug(f"validation_driver >> parsed_tf_plan : {parsed_tf_plan}")

    tf_plan_summary, unknowns = summarize_changes(parsed_tf_plan)

    # Call Function to Beautify Summaries and Validation Errors (if any)
    beautify_summary(action_count, tf_plan_summary, unknowns, val_err_list)
    """

    # Calculate and log the total runtime
    logger.info(f"Validation & Logging end time: {datetime.now().strftime('%Y%m%d%H%M%S')}")
    script_endtime = time.time()  # Record the end time
    total_runtime = script_endtime - script_starttime  # Calculate the script's runtime
    logger.info(f"Total runtime: {total_runtime:.2f} seconds")