import json

from constants import SUPPORTED_SNF_OBJS_LIST
from helpers.config_log import logger
from helpers.utils import create_obj_type_name_map, read_json, reverse_dict, \
    preprocess_keys, pre_validate_user_metadata, add_to_dict
from validations.rules import Rules
import validations.misc_validations as misc
from validations.validators import Validator, extract_obj_specific_rules, execute_python_rules, build_snf_conn, execute_snf_vals, retrieve_sp_result


def python_result_set_error_extractor(py_val_response):
    """
    Extracts error messages from a validation response.

    :param py_val_response: A dictionary where each object name maps to a list of rule responses.
    :return: A list of error messages (non-"success" responses).
    """
    py_err_list = []  # Initialize an empty list to hold error messages

    # Iterate through each object in the response dictionary
    for obj_name in py_val_response.keys():
        # Extend the error list with non-success responses
        py_err_list.extend(
            rule_response
            for rule_response in py_val_response.get(obj_name)
            if rule_response.strip().lower() != 'success'  # Consider non-'success' responses as errors
        )

    return py_err_list  # Return the list of errors


def snowflake_result_set_error_extractor(snf_val_response):
    """
    Extracts error messages from a Snowflake validation response.

    :param snf_val_response: A list where the first element contains the Snowflake validation response as a string.
    :return: A list of error messages or None if the response is not in the expected format.
    """
    # Check if the first element of the response contains the expected validation data
    if snf_val_response[0][0]:
        snf_val_res_dict = json.loads(snf_val_response[0][0])  # Parse the JSON response
        snf_err_list = []  # Initialize an empty list to hold error messages

        # Iterate through the dictionary to extract errors
        for snf_obj_key in snf_val_res_dict.keys():
            for obj_name in snf_val_res_dict.get(snf_obj_key):
                # Extend the error list with errors from each object
                snf_err_list.extend(error.get('error') for error in obj_name.get('errors', []))

    else:
        # Log a warning if the expected response structure is not present
        logger.warning(
            "Snowflake rule validation doesn't contain expected response. We are unable to proceed with parsing..!")
        return None  # Return None when response is not in expected format

    return snf_err_list  # Return the list of errors


def generate_obj_map(prov_json_list, git_rule_map):
    """
    Parses the rule book, incoming Snowflake object provisioning JSONs, and maps them to the rules based on GitHub
    paths.

    This function dynamically creates a rule suite for each Snowflake object based on the incoming user requests and
    the static GitHub rule mappings.

    :param prov_json_list: List of JSONs requested by the user for Snowflake object provisioning.
    :param git_rule_map: Static mapping between GitHub paths and rule book verbiage.
    :return: A dictionary mapping each Snowflake object type to its respective rules.
    """
    snf_obj_type_list = []  # List to hold identified Snowflake object types for this run
    snf_obj_type_name_map = {}  # Map to link Snowflake object types to their names

    # Iterate over the provisioning JSONs provided by the user
    for prov_json in prov_json_list:
        # Extract the GitHub path key from the provided JSON's path
        git_path_key = prov_json.split("/")[-2].lower()

        # Get the corresponding rule object type from the GitHub rule map
        git_rule_map_obj_type = git_rule_map.get(git_path_key)

        if git_rule_map_obj_type is not None:
            snf_obj_type_list.append(git_rule_map_obj_type)  # Add the identified object type to the list

            if git_rule_map_obj_type in SUPPORTED_SNF_OBJS_LIST:
                # If the object type is supported, map its name to the corresponding rule set
                create_obj_type_name_map(prov_json, git_rule_map_obj_type, snf_obj_type_name_map)
        else:
            # Log a warning if the GitHub path is not supported
            logger.warning(f"The GitHub path key '{git_path_key}' is not supported by MIW Validations for now...!")

    # Debug logs to inspect the lists and map created
    logger.debug(f"generate_obj_map >> snf_obj_type_list : {snf_obj_type_list}")
    logger.debug(f"generate_obj_map >> snf_obj_type_name_map : {snf_obj_type_name_map}")

    return snf_obj_type_name_map  # Return the mapping of Snowflake object types to their respective rules


def _process_individual_rule(obj_rule, obj_name):
    """
    Processes a single rule and returns the rules as a list of dictionaries.

    :param obj_rule: A rule definition from the rule kit.
    :param obj_name: The specific name of the Snowflake object.
    :return: A list of rule dictionaries.
    """
    rule_dicts = []
    param = obj_rule.get('param')

    if isinstance(param, dict):
        param_for_obj = param.get(str(obj_name.__class__.__name__).lower())
        if isinstance(param_for_obj, dict):
            obj_attribute = param_for_obj.get('key')
            extracted_rule_value = getattr(obj_name, obj_attribute, None)

            if isinstance(extracted_rule_value, list):
                # Add each value in the list as a separate rule
                for value in extracted_rule_value:
                    rule_dicts.append({obj_rule.get('function'): value})
            else:
                # Single value rule
                rule_dicts.append({obj_rule.get('function'): extracted_rule_value})
        else:
            # Basic scenario where param is not a dict
            rule_dicts.append({obj_rule.get('function'): [str(param_for_obj)]})
    else:
        # No parameter provided
        rule_dicts.append({obj_rule.get('function'): None})

    return rule_dicts


def _update_snf_rule_dict(snf_rule_dict, obj_type, obj_name, obj_specific_rules):
    """
    Updates the Snowflake rule dictionary with rules for the given object type and name.

    :param snf_rule_dict: The dictionary to update.
    :param obj_type: The type of Snowflake object.
    :param obj_name: The specific name of the Snowflake object.
    :param obj_specific_rules: A list of rules for the object.
    """
    entry = {"name": obj_name.name, "rules": obj_specific_rules}
    if obj_type in snf_rule_dict:
        snf_rule_dict[obj_type].append(entry)
    else:
        snf_rule_dict[obj_type] = [entry]


def prep_snf_rule_dict(snf_rule_dict, obj_type, obj_name, snf_rule_kit_for_obj):
    """
    Iteratively prepares the list of Snowflake application rules for a specific object type and object name.

    This function collects the Snowflake rules for a given object type and name and appends them to the
    provided dictionary that maps Snowflake object types to their corresponding rules.

    :param snf_rule_dict: The dictionary to accumulate Snowflake rules, keyed by object type.
    :param obj_type: The type of Snowflake object (e.g., 'database', 'schema').
    :param obj_name: The specific name of the Snowflake object.
    :param snf_rule_kit_for_obj: A list of rule definitions applicable to the given object name and type.
    :return: Updated `snf_rule_dict` containing the rules for the specified object type.
    """
    if obj_type and obj_name and snf_rule_kit_for_obj:  # Ensure all required inputs are provided
        obj_specific_rules = []  # List to store the rules for the specific object

        for obj_rule in snf_rule_kit_for_obj:
            obj_specific_rules.extend(_process_individual_rule(obj_rule, obj_name))

        _update_snf_rule_dict(snf_rule_dict, obj_type, obj_name, obj_specific_rules)

    logger.debug(f"snf_rule_dict inside prep_snf_rule_dict : {snf_rule_dict}")
    return snf_rule_dict  # Return the updated Snowflake rule dictionary


def generate_valid_snf_objs(snf_obj_map, base_json_path, git_path_map, obj_name_map):
    """
    Validates and processes Snowflake objects based on user-provided metadata JSON files.

    :param snf_obj_map: Dictionary containing Snowflake object types and their associated object names.
    :param base_json_path: Path where the Snowflake metadata JSON files are located.
    :param git_path_map: Mapping of GitHub paths to Snowflake object types.
    :param obj_name_map: Mapping of Snowflake object names to their respective attributes.
    :return: A tuple containing:
        - snf_valid_objs: Dictionary with valid Snowflake objects and their metadata.
        - pre_val_err_list: List of validation error messages encountered during preprocessing.
    """
    pre_val_err_list = []
    snf_valid_objs = {}
    reverse_git_path_map = reverse_dict(git_path_map)

    for obj_type in snf_obj_map:
        process_object_type(
            obj_type, snf_obj_map[obj_type], base_json_path, reverse_git_path_map, obj_name_map, snf_valid_objs, pre_val_err_list
        )

    return snf_valid_objs, pre_val_err_list


def process_object_type(obj_type, obj_names, base_json_path, reverse_git_path_map, obj_name_map, snf_valid_objs, pre_val_err_list):
    """
    Processes a specific Snowflake object type by validating its associated object names.

    :param obj_type: Snowflake object type (e.g., table, view).
    :param obj_names: List of Snowflake object names for the given type.
    :param base_json_path: Base path to Snowflake metadata JSON files.
    :param reverse_git_path_map: Reversed GitHub path mapping for easier lookups.
    :param obj_name_map: Mapping of Snowflake object names to their respective attributes.
    :param snf_valid_objs: Dictionary to store valid Snowflake objects.
    :param pre_val_err_list: List to collect validation errors.
    """
    for obj_name in obj_names:
        user_metadata_json = load_metadata_json(obj_type, obj_name, base_json_path, reverse_git_path_map)

        if obj_type.strip().lower() in SUPPORTED_SNF_OBJS_LIST:
            validate_and_add_object(obj_type, obj_name, user_metadata_json, obj_name_map, snf_valid_objs, pre_val_err_list)
        else:
            logger.warning(f"Unsupported Snowflake object type: {obj_type}")


def load_metadata_json(obj_type, obj_name, base_json_path, reverse_git_path_map):
    """
    Loads the metadata JSON for a specific Snowflake object.

    :param obj_type: Snowflake object type.
    :param obj_name: Snowflake object name.
    :param base_json_path: Base path to Snowflake metadata JSON files.
    :param reverse_git_path_map: Reversed GitHub path mapping for easier lookups.
    :return: The loaded metadata JSON.
    """
    file_path = f"{base_json_path}/{reverse_git_path_map.get(obj_type)}/{obj_name}.json"
    return read_json(file_path)


def validate_and_add_object(obj_type, obj_name, user_metadata_json, obj_name_map, snf_valid_objs, pre_val_err_list):
    """
    Validates the metadata JSON for a Snowflake object and adds it to the valid object's dictionary.

    :param obj_type: Snowflake object type.
    :param obj_name: Snowflake object name.
    :param user_metadata_json: Metadata JSON for the object.
    :param obj_name_map: Mapping of Snowflake object names to their respective attributes.
    :param snf_valid_objs: Dictionary to store valid Snowflake objects.
    :param pre_val_err_list: List to collect validation errors.
    """
    preproc_response = preprocess_keys(obj_type.strip().lower(), user_metadata_json, obj_name_map)
    logger.debug(f"Preprocessing response for {obj_name}: {preproc_response}")

    # If the preprocessing failed, add the response to error list.
    if isinstance(preproc_response, str):
        pre_val_err_list.append(preproc_response)
        return

    prevalid_response = pre_validate_user_metadata(obj_type.strip().lower(), preproc_response)
    logger.debug(f"Pre-validation response for {obj_name}: {prevalid_response}")

    if isinstance(prevalid_response, str):
        pre_val_err_list.append(prevalid_response)
        return

    logger.debug(f"Successfully validated {obj_type} object: {obj_name}")
    add_to_dict(snf_valid_objs, obj_type, prevalid_response)



def apply_validation_rules(snf_obj_dict, rule_json):
    """
    Applies validation rules on Snowflake objects using Python and Snowflake rules.
    Combines errors from both validations and returns the results.
    :param snf_obj_dict: Dictionary of Snowflake objects with object type as keys and object names as values.
    :param rule_json: JSON object containing the validation rules.
    :return: List of validation errors or None if no errors are found.
    """
    rules = Rules(rule_json)
    val = Validator()

    active_rule_kit = rules.collate_active_validations()

    py_result_set_dict, restructured_snf_rule_kit = validate_python_rules(snf_obj_dict, active_rule_kit)
    sp_response = validate_snowflake_rules(restructured_snf_rule_kit, val)

    return process_validation_results(py_result_set_dict, sp_response)


def validate_python_rules(snf_obj_dict, active_rule_kit):
    """
    Executes Python validation rules on Snowflake objects and prepares Snowflake rule input.
    :param snf_obj_dict: Dictionary of Snowflake objects with object type as keys and object names as values.
    :param active_rule_kit: Active validation rules.
    :return: A tuple (Python validation results, restructured Snowflake rule kit).
    """
    py_result_set_dict = {}
    restructured_snf_rule_kit = {}

    for snf_obj_type, snf_obj_name_list in snf_obj_dict.items():
        logger.debug(f"Processing Snowflake object type: {snf_obj_type}")
        python_rules, snowflake_rules = extract_obj_specific_rules(snf_obj_type, active_rule_kit)

        for snf_obj_name in snf_obj_name_list:
            py_result_set_dict[snf_obj_name.name] = execute_python_rules(snf_obj_name, python_rules)
            prep_snf_rule_dict(restructured_snf_rule_kit, snf_obj_type, snf_obj_name, snowflake_rules)

    logger.debug(f"Python validation results: {py_result_set_dict}")
    logger.debug(f"Prepared Snowflake rule kit: {restructured_snf_rule_kit}")
    return py_result_set_dict, restructured_snf_rule_kit


def validate_snowflake_rules(restructured_snf_rule_kit, val):
    """
    Executes Snowflake validation rules using a stored procedure.
    :param restructured_snf_rule_kit: Restructured rule kit for Snowflake validation.
    :param val: Validator object.
    :return: Stored procedure response from Snowflake validation.
    """
    snf_conn, snf_cur = build_snf_conn()

    if sp_run_qid := execute_snf_vals(snf_cur, restructured_snf_rule_kit):
        logger.debug(f"Snowflake validation query ID: {sp_run_qid}")
        sp_response = retrieve_sp_result(snf_conn, snf_cur, sp_run_qid)
        if sp_response:
            logger.debug(f"Snowflake validation response: {sp_response}")
            return sp_response

        logger.exception("Failed to retrieve results from Snowflake validation due to timeout.")
    else:
        logger.warning("No Snowflake rules executed.")
    return None


def process_validation_results(py_result_set_dict, sp_response):
    """
    Processes validation results from both Python and Snowflake validations.
    :param py_result_set_dict: Python validation results.
    :param sp_response: Snowflake validation results.
    :return: Combined list of validation errors or None if no errors are found.
    """
    if py_result_set_dict and sp_response:
        parsed_py_errors = python_result_set_error_extractor(py_result_set_dict)
        parsed_snf_errors = snowflake_result_set_error_extractor(sp_response)
        return parsed_py_errors + parsed_snf_errors

    if py_result_set_dict:
        return python_result_set_error_extractor(py_result_set_dict)

    if sp_response:
        return snowflake_result_set_error_extractor(sp_response)

    logger.info("No validation errors found. All Snowflake objects are compliant.")
    return None

def apply_misc_vals(env_vars, file_diff_status_dict, rule_data):
    """
    This function is to deal with misc. validations like PR's branch, Number of files as part of this PR etc.
    """
    misc_val_err_list = []

    if not rule_data['technical_validation']['misc']:
        logger.error(f"No miscellaneous technical validations present in the rulebook...! Contact Admin to enhance rulebook.")
        return []

    logger.debug("Kicking off Miscellaneous Validations...!")
    logger.debug(f"orchestrate_val >> apply_misc_vals >> rule_data : {rule_data['technical_validation']['misc']}")
    logger.debug(f"orchestrate_val >> apply_misc_vals >> env_vars : {env_vars}")

    # Executing Python Based Validations
    misc_rules = rule_data['technical_validation']['misc']['python']
    for misc_rule in misc_rules:
        logger.debug(f"orchestrate_val >> apply_misc_vals >> misc_rule : {misc_rule}")
        rule_dict = misc_rules[misc_rule]
        logger.debug(f"orchestrate_val >> apply_misc_vals >> rule_dict : {rule_dict}")
        if rule_dict['isactive'] is True:
            misc_val_func = getattr(misc, rule_dict['function'])

            # Calling the Misc Validation Function
            misc_val_result = misc_val_func(env_vars, file_diff_status_dict, **rule_dict['param'])
            logger.debug(f"Result for validation {misc_rule} is : {misc_val_result}")
            if "success" != misc_val_result:
                misc_val_err_list.append(misc_val_result)

    return misc_val_err_list