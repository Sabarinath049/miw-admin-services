import json
import sys
from pathlib import Path

from helpers.config_log import logger
from constants import SNF_CONTEXT_DETAILS
from explicit_grants import (
    connect_to_Snowflake,
    read_json
)


def build_call_statement(ci_obj):

    enable_vended = (
        ", ACCESS_DELEGATION_MODE = VENDED_CREDENTIALS"
        if str(
            ci_obj.get("enable_vended_credentials", "false")
        ).lower() == "true"
        else ""
    )

    sql = f"""
CALL {SNF_CONTEXT_DETAILS["database"]}.{SNF_CONTEXT_DETAILS["schema"]}.UPSERT_CATALOG_INTEGRATION_REFRESH_ONLY(

    VAR_CATALOG_NAMESPACE => PARSE_JSON(
        '{json.dumps(ci_obj["catalog_namespace"]).replace("'", "''")}'
    ),

    VAR_CATALOG_SOURCE        => '{ci_obj["catalog_source"]}',
    VAR_TABLE_FORMAT          => '{ci_obj["catalog_table_format"]}',

    VAR_REST_CATALOG_URI      => '{ci_obj["rest_catalog_uri"]}',
    VAR_REST_CATALOG_NAME     => '{ci_obj["rest_catalog_name"]}',
    VAR_REST_CATALOG_API_TYPE => '{ci_obj["rest_catalog_api_type"]}',
    LOCAL_REVAL_ENABLE_VENDED => {f"'{enable_vended}'" if enable_vended else "NULL"},

    VAR_REST_AUTH_TYPE        => '{ci_obj["rest_auth_type"]}',
    VAR_REST_AUTH_IAM_ROLE    => '{ci_obj["rest_auth_iam_role"]}',
    VAR_REST_AUTH_SIGN_REGION => '{ci_obj["rest_auth_sign_region"]}',

    VAR_ICEBERG_ENABLED       => {str(ci_obj["iceberg_enabled"]).upper()},
    VAR_REFRESH_INTERVAL_SECS => {int(ci_obj["catalog_refresh_interval_secs"])},
    VAR_COMMENT               => '{ci_obj.get("description", "").replace("'", "''")}',

    VAR_ACCESS_ROLES => PARSE_JSON(
        '{json.dumps(ci_obj["access_roles"]).replace("'", "''")}'
    ),

    VAR_UNIQUE_ROLES => PARSE_JSON(
        '{json.dumps(ci_obj.get("unique_roles_ro_rw", {})).replace("'", "''")}'
    ),

    VAR_INTAKE_ID                      => '{ci_obj["intake_id"]}',
    VAR_SNOWFLAKE_ACCOUNT_ID           => '{ci_obj["snowflake_account_id"]}',
    VAR_ENT_OR_FUNC_NAME               => '{ci_obj["enterprise_or_func_name"]}',
    VAR_ENTERPRISE_OR_FUNC_SUBGRP_NAME => '{ci_obj["enterprise_or_func_subgrp_name"]}',
    VAR_PRODUCT_GROUP_IDENTIFIER       => '{ci_obj["product_group_identifier"]}',
    VAR_DATA_LEADER                    => '{ci_obj["data_leader"]}',
    VAR_DATA_FIRST_CLASSIFICATION      => '{ci_obj["data_first_classification"]}',
    VAR_ENABLE_VENDED_CREDENTIALS      => '{ci_obj["enable_vended_credentials"]}',

    VAR_MTDT_DB_NAME                   => '{SNF_CONTEXT_DETAILS["database"]}',
    VAR_MTDT_SCHEMA_NAME               => '{SNF_CONTEXT_DETAILS["schema"]}'

)
"""

    return sql


def parse_sp_result(result):
    """
    Normalize stored procedure response into dictionary.
    Handles:
    - dict
    - JSON string
    - None
    """

    if result is None:
        return {}

    if isinstance(result, dict):
        return result

    if isinstance(result, str):

        try:
            return json.loads(result)

        except json.JSONDecodeError as e:

            logger.error(
                f"Failed to parse stored procedure JSON response: {str(e)}"
            )

            return {
                "status": "ERROR",
                "message": f"Invalid JSON response: {result}"
            }

    logger.warning(
        f"Unexpected stored procedure response type: {type(result)}"
    )

    return {
        "status": "ERROR",
        "message": f"Unexpected response type: {type(result)}"
    }


def provision_catalog_integrations():

    logger.info("Starting catalog integration provisioning")

    preprocess_output_folder = sys.argv[2]

    snf_role = SNF_CONTEXT_DETAILS["account_admin_role"]

    logger.info(
        f"Connecting to Snowflake using role: {snf_role}"
    )

    logger.debug(
        f"Using warehouse={SNF_CONTEXT_DETAILS['warehouse']}, "
        f"database={SNF_CONTEXT_DETAILS['database']}, "
        f"schema={SNF_CONTEXT_DETAILS['schema']}"
    )

    conn = None
    cur = None

    provisioning_summary = []

    try:

        conn, cur = connect_to_Snowflake(
            snf_role=snf_role
        )

        cur.execute(
            f"USE WAREHOUSE {SNF_CONTEXT_DETAILS['warehouse']}"
        )

        cur.execute(
            f"USE DATABASE {SNF_CONTEXT_DETAILS['database']}"
        )

        cur.execute(
            f"USE SCHEMA {SNF_CONTEXT_DETAILS['schema']}"
        )

        output_path = Path(preprocess_output_folder)

        logger.debug(
            f"Scanning preprocess folder: {output_path}"
        )

        json_files = [
            f for f in output_path.rglob("enriched_*.json")
            if "catalog_integrations" in str(f)
        ]

        logger.info(
            f"Catalog integration json files identified: "
            f"{len(json_files)}"
        )

        for file in json_files:

            logger.debug(
                f"Catalog integration file discovered: {file}"
            )

        if not json_files:

            logger.warning(
                "No catalog integration json files found for provisioning"
            )

            return

        processed_count = 0

        for file in json_files:

            try:

                logger.info(
                    f"Reading input file: {file}"
                )

                data = read_json(file)

            except Exception as e:

                logger.warning(
                    f"Skipping invalid json file {file}: {str(e)}"
                )

                provisioning_summary.append({
                    "catalog_integration": str(file),
                    "status": "INVALID_JSON"
                })

                continue

            if not isinstance(data, dict):

                logger.warning(
                    f"Skipping non-dictionary json file: {file}"
                )

                provisioning_summary.append({
                    "catalog_integration": str(file),
                    "status": "INVALID_FORMAT"
                })

                continue

            if "catalog_integration_name" not in data:

                logger.warning(
                    f"Skipping file without catalog_integration_name: {file}"
                )

                provisioning_summary.append({
                    "catalog_integration": str(file),
                    "status": "MISSING_NAME"
                })

                continue

            catalog_integration_name = data.get(
                "catalog_integration_name"
            )

            logger.info(
                f"Executing provisioning for catalog integration: "
                f"{catalog_integration_name}"
            )

            sql = build_call_statement(data)

            logger.debug(
                f"Generated SQL for "
                f"{catalog_integration_name}"
            )

            logger.debug(f"SQL:\n{sql}")

            try:

                # Execute stored procedure
                cur.execute(sql)

                row = cur.fetchone()

                raw_result = row[0] if row else None

                logger.debug(
                    f"Raw stored procedure response type: "
                    f"{type(raw_result)}"
                )

                logger.debug(
                    f"Raw stored procedure response: "
                    f"{raw_result}"
                )

                # Normalize response
                result = parse_sp_result(raw_result)

                logger.info(
                    "Parsed stored procedure response:\n"
                    + json.dumps(result, indent=2)
                )

                # Default final status
                final_status = "SUCCESS"

                steps = result.get("steps", [])

                for step in steps:

                    if step.get("step") == "NOOP_CATALOG_INTEGRATION":

                        final_status = "NO_CHANGE"

                        logger.info(
                            f"No changes detected for catalog integration "
                            f"{step.get('catalog_integration_name')}. "
                            f"Stored procedure skipped ALTER operation."
                        )

                # Handle failure response
                if result.get("status") == "ERROR":

                    logger.error(
                        f"Provisioning failed for "
                        f"{catalog_integration_name}"
                    )

                    logger.error(
                        json.dumps(result, indent=2)
                    )

                    provisioning_summary.append({
                        "catalog_integration": catalog_integration_name,
                        "status": "FAILED"
                    })

                    raise Exception(
                        f"Stored Procedure execution failed "
                        f"for {catalog_integration_name}"
                    )

                provisioning_summary.append({
                    "catalog_integration": catalog_integration_name,
                    "status": final_status
                })

                processed_count += 1

                logger.info(
                    f"Successfully provisioned catalog integration: "
                    f"{catalog_integration_name}"
                )

            except Exception as e:

                logger.exception(
                    f"Error provisioning catalog integration "
                    f"{catalog_integration_name}: {str(e)}"
                )

                provisioning_summary.append({
                    "catalog_integration": catalog_integration_name,
                    "status": "FAILED"
                })

                raise

        logger.info(
            "========== Catalog Integration Summary =========="
        )

        for item in provisioning_summary:

            logger.info(
                f"Catalog Integration: "
                f"{item['catalog_integration']} "
                f"| Status: {item['status']}"
            )

        logger.info(
            "================================================"
        )

        logger.info(
            f"Catalog integration provisioning completed successfully. "
            f"Processed {processed_count} catalog integration(s)."
        )

    except Exception as e:

        logger.exception(
            f"Catalog integration provisioning failed: {str(e)}"
        )

        logger.info(
            "========== Catalog Integration Summary =========="
        )

        for item in provisioning_summary:

            logger.info(
                f"Catalog Integration: "
                f"{item['catalog_integration']} "
                f"| Status: {item['status']}"
            )

        logger.info(
            "================================================"
        )

        raise

    finally:

        try:
            if cur:
                cur.close()

        except Exception as e:

            logger.warning(
                f"Failed to close cursor: {str(e)}"
            )

        try:
            if conn:
                conn.close()

        except Exception as e:

            logger.warning(
                f"Failed to close Snowflake connection: {str(e)}"
            )


if __name__ == "__main__":
    provision_catalog_integrations()