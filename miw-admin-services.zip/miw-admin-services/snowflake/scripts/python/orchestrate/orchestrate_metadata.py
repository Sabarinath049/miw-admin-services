import sys
import copy
from datetime import datetime, timezone

from constants import SEPERATOR, METADATA_TABLE_LIST, USER_INPUT_SNF_TBL_MAP, EXPLICIT_METADATA_HANDLING_OBJECTS
from db.db_manager import perform_mpl_logging, generate_table_objects, prepare_record, perform_metadata_entry, \
    create_db_insert_entry
from helpers.config_log import logger
from helpers.utils import extract_sub_dicts, validate_tf_output, generate_numeric_id, retain_persona_roles


def preprocess_tf_dict(tf_dict):
    """
    Preprocesses the Terraform dictionary to extract and validate entities based on predefined rules.

    :param tf_dict: Dictionary containing Terraform output data.
    :return: List of processed entities, validated and refined as per specific rules.
    """
    logger.debug(f"Parsed tf_dict is  {tf_dict}")
    parsed_dict = extract_sub_dicts(tf_dict, "_outputs")

    logger.debug(f"{parsed_dict=}")
    if not parsed_dict:
        logger.error("Terraform output wasn't adherent to the expected format. Exiting with exit code -1.")
        sys.exit(-1)

    processed_entities = []

    for snf_obj_type in parsed_dict.keys():
        for snf_obj_name_key in parsed_dict.get(snf_obj_type).keys():
            user_input = parsed_dict.get(snf_obj_type).get(snf_obj_name_key).get('input_metadata')
            logger.debug(f"preprocess_tf_dict >> {snf_obj_type=} {user_input=}")

            # Special handling for entities not provisioned by Terraform (e.g., RBAC and OAuth entities)
            if snf_obj_type.strip().lower() in EXPLICIT_METADATA_HANDLING_OBJECTS:
                processed_entities.append(user_input)
                continue

            # Get the Terraform output for validation
            tf_output = parsed_dict.get(snf_obj_type).get(snf_obj_name_key)

            logger.debug(f" preprocess_tf__dict >> {tf_output=}")

            # Ensure 'input_metadata' is not present in the Terraform output
            if tf_output:
                tf_output.pop('input_metadata', None)
                # tf_output=tf_output.get('input_metadata') or None

            logger.debug(f" preprocess_tf__dict >>  {tf_output=}")
            # Validate the Terraform output and append to the processed entities list
            processed_entities.append(
                validate_tf_output(snf_obj_type, snf_obj_name_key.split('.')[0], user_input, tf_output)
            )

    return processed_entities


def prep_rbac_role_attrs(user_input_dict):
    """
    Prepares a dictionary with attributes for an RBAC role.

    :param user_input_dict: Dictionary containing user input data for the role.
    :return: Dictionary with prepared RBAC role attributes.
    """
    return {
        'intake_id': user_input_dict.get('intake_id', None),
        'role_name': user_input_dict.get('aad_group_name', None),  # Azure Active Directory group name
        'role_type': 'PERSONA',  # Hardcoded role type as 'persona'
        'role_purpose': user_input_dict.get('purpose', None),  # Purpose of the role
        'parent_role': None,  # Parent role is not defined
        'role_owner': user_input_dict.get('role_owner_ds_id', None),  # Role owner's DS ID
        'role_owner_email': user_input_dict.get('role_owner_email_id', None),  # Role owner's email
        'ent_or_func_name': user_input_dict.get('enterprise_or_func_name', None),  # Enterprise or functional name
        'enterprise_or_func_subgrp_name': user_input_dict.get('enterprise_or_func_subgrp_name', None),  # enterprise_or_func_subgrp_name or Product Group name
        'data_leader': user_input_dict.get('data_leader', None),  # Data Leader
        'governance_and_access_lead': user_input_dict.get('governance_and_access_lead', None),  # Data Leader
        'access_roles_alias': user_input_dict.get('access_roles_alias',None),
        'sub_function': user_input_dict.get('sub_function', None)
    }


def prep_tech_role_attrs(access_role, tf_out_dict):
    """
    Prepares a dictionary with attributes for a technical role.

    :param access_role: Dictionary containing access role details.
    :param tf_out_dict: Dictionary containing Terraform output data.
    :return: Dictionary with prepared technical role attributes.
    """
    tech_role_name = access_role.get('tech_role', None)  # Retrieve the technical role name
    return {
        'intake_id': None,
        'role_name': tech_role_name,  # Technical role name
        'role_type': tech_role_name.split(SEPERATOR)[0] if tech_role_name else None,  # Extract role type from the name
        'role_purpose': None,
        'parent_role': access_role.get('access_role', None),  # Parent access role
        'role_owner': 'Minerva-MIW',
        'role_owner_email': None,  # Placeholder for the owner's email
        'ent_or_func_name': tf_out_dict.get('enterprise_or_func_name', None),  # Enterprise or functional name
        'enterprise_or_func_subgrp_name': tf_out_dict.get('enterprise_or_func_subgrp_name', None),  # enterprise_or_func_subgrp_name or Product Group name
        'data_leader': None,
        'governance_and_access_lead': None,
        'access_roles_alias': tf_out_dict.get('access_roles_alias',None),
        'sub_function': tf_out_dict.get('sub_function',None),
    }


def preprocess_roles(processed_tf_dicts):
    """
    Preprocess roles data for persona and tech roles from a list of processed Terraform dictionaries.

    :param processed_tf_dicts: List of processed dictionaries containing Terraform data.
    :return: A tuple of two lists: persona_roles_data and tech_roles_data.
    """

    # Create an Independent Object which is deep copy of processed_tf_dicts, this will be used while making changes to same object which we are iterating
    copy_processed_tf_dicts = copy.deepcopy(processed_tf_dicts)

    persona_roles_data = []
    tech_roles_data = []
    logger.debug(f"preprocess_roles >> processed_tf_dicts : {processed_tf_dicts}")
    for tf_dict in processed_tf_dicts:
        logger.debug(f"tf_dict for this iteration is : {tf_dict}")
        if tf_dict:
            # Handle Snowflake objects that have access roles defined
            if 'aad_group_name' not in tf_dict and 'access_roles' in tf_dict:
                logger.debug(f"in preprocess_roles: if condition {tf_dict=} ")
                for access_role in tf_dict.get('access_roles'):
                    # Prepare tech role data if 'tech_role' exists
                    if access_role.get('tech_role'):
                        tech_roles_data.append(prep_tech_role_attrs(access_role, tf_dict))

            # Handle RBAC-style requests explicitly for persona roles
            elif 'aad_group_name' in tf_dict:
                logger.debug(f"in preprocess_roles: elif condition {tf_dict=} ")
                persona_roles_data.append(prep_rbac_role_attrs(tf_dict))
                # Ensuring that we remove this persona role since it's part of the persona_roles_data list now.
                copy_processed_tf_dicts.remove(tf_dict)
                logger.debug(f"persona role aad_group name modified to role_name {tf_dict=} {processed_tf_dicts=} {persona_roles_data}")

            else:
                logger.debug("Since this is a terraform output element isn't required to account any persona or tech roles, bypassing it from role processing perspective")
                logger.debug(f"preprocess_roles >> tf_dict : {tf_dict}")
                continue
    return persona_roles_data, tech_roles_data, copy_processed_tf_dicts


def preprocess_rm_data(processed_tf_dicts):
    """
    Preprocess resource monitor data from a list of processed Terraform dictionaries.

    :param processed_tf_dicts: List of processed dictionaries containing Terraform data.
    :return: A list of dictionaries containing resource monitor details.
    """
    resource_monitor_data = []

    for tf_dict in processed_tf_dicts:
        if tf_dict:
            # Check if a resource monitor is attached in the current dictionary
            if 'attached_resource_monitor' in tf_dict:
                # Append resource monitor details to the list
                resource_monitor_data.append({
                    'rm_name': tf_dict.get('attached_resource_monitor'),
                    'associated_wh': tf_dict.get('warehouse_name'),
                    'credit_quota': tf_dict.get('monthly_credit_limit'),
                    'rm_type': tf_dict.get('rm_type', "Warehouse"),
                    'rm_frequency': tf_dict.get('rm_frequency', "Monthly"),
                    'alert_subscrbr_list': tf_dict.get('alert_subscribers_list'),
                    'ent_or_func_name': tf_dict.get('enterprise_or_func_name'),
                    'enterprise_or_func_subgrp_name': tf_dict.get('enterprise_or_func_subgrp_name'),
                    'product_group_identifier': tf_dict.get('product_group_identifier'),                    
                    'data_leader': tf_dict.get('data_leader')
                })
        else:
            continue

    return resource_monitor_data


def extract_snf_entities(provisioned_entities):
    """
    Extract Snowflake entity names from a list of provisioned entities.

    :param provisioned_entities: List of dictionaries containing provisioned entity details.
    :return: A deduplicated list of extracted Snowflake entity names.
    """
    entities_to_extract = {"database_name", "schema_name", "warehouse_name", "role_name", "rm_name", "sub_uuid","storage_integration_name","external_volume_name","catalog_integration_name"}
    entity_list = []

    logger.debug(f"\nprovisioned entities >> {provisioned_entities=}\n")
    for entity_dict in provisioned_entities:
        logger.debug(f"extract_snf_entities >> entity_dict : {entity_dict}")
        logger.debug(f"entities_to_extract >> entities_to_extract : {entities_to_extract}")
        # Collect values for keys that match the entities to extract
        entity_list.extend(entity_dict.get(key) for key in entities_to_extract if key in entity_dict)

    # Remove duplicates using a set and convert back to a list
    return list(set(entity_list))


def perform_mpl_update(list_of_provisioned_entities, env_vars):
    """
    Perform MPL (Master Provisioning Log) updates by logging relevant information.

    :param list_of_provisioned_entities: List of dictionaries representing provisioned Snowflake entities.
    :param env_vars: Dictionary containing required environment variables for the operation.
    """
    # Extract unique Snowflake entities from the list of provisioned entities
    entities_provisioned = extract_snf_entities(list_of_provisioned_entities)

    logger.debug(f"entities_provisioned >> entities_provisioned : {entities_provisioned}")

    # Read required environment variables
    git_event = env_vars["CODEBUILD_WEBHOOK_EVENT"]
    # pr_id = env_vars["CODEBUILD_WEBHOOK_TRIGGER"]
    pr_id = env_vars["PR_NUMBER"]
    src_branch = env_vars["CODEBUILD_WEBHOOK_HEAD_REF"]
    pr_merged_time = datetime.now(timezone.utc)  # Capture the PR merge time in UTC

    # Log the MPL update
    perform_mpl_logging(git_event, pr_id, src_branch, entities_provisioned, pr_merged_time)


def perform_metadata_logging(list_of_provisioned_entities, env_vars):
    """
    Logs metadata for provisioned entities and prepares records for metadata tables.

    :param list_of_provisioned_entities: List of dictionaries representing provisioned entities.
    :param env_vars: Dictionary of environment variables, including the webhook trigger for logging.
    """
    logger.debug(f"List of provisioned entities: {list_of_provisioned_entities}")
    insert_obj_list = []

    # Generate metadata table object mapping
    tbl_obj_dict = generate_table_objects(METADATA_TABLE_LIST)
    logger.debug(f"perform_metadata_logging >> tbl_obj_dict : {tbl_obj_dict}")
    for entity_dict in list_of_provisioned_entities:
        # Determine entity type and prepare metadata record
        if "database_name" in entity_dict:
            process_metadata_entry(
                entity_dict, "database_name", "DATABASE_METADATA_TBL", "database", tbl_obj_dict, insert_obj_list, env_vars
            )
        elif "schema_name" in entity_dict:
            process_metadata_entry(
                entity_dict, "schema_name", "SCHEMA_METADATA_TBL", "schema", tbl_obj_dict, insert_obj_list, env_vars
            )
        elif "warehouse_name" in entity_dict:
            process_metadata_entry(
                entity_dict, "warehouse_name", "WAREHOUSE_METADATA_TBL", "warehouse", tbl_obj_dict, insert_obj_list,
                env_vars
            )
        elif "role_name" in entity_dict:
            logger.debug(f"Processing role: {entity_dict}")
            process_metadata_entry(
                entity_dict, "role_name", "ROLES_METADATA_TBL", "roles", tbl_obj_dict, insert_obj_list, env_vars
            )
        elif "rm_name" in entity_dict:
            process_metadata_entry(
                entity_dict, "rm_name", "RESOURCE_MONITOR_METADATA_TBL", "resource_monitor", tbl_obj_dict, insert_obj_list,
                env_vars
            )
        elif "ps_account_id" in entity_dict:
            process_metadata_entry(
                entity_dict, "ps_account_id", "OAUTH_METADATA_TBL", "oauth", tbl_obj_dict, insert_obj_list,
                env_vars
            )
        elif "storage_integration_name" in entity_dict:
            process_metadata_entry(
                entity_dict, "storage_integration_name", "STORAGE_INTEGRATION_METADATA_TBL", "storage_integration", tbl_obj_dict, insert_obj_list,
                env_vars
            )
        elif "external_volume_name" in entity_dict:
            process_metadata_entry(
                entity_dict, "external_volume_name", "EXTERNAL_VOLUME_METADATA_TBL", "external_volume", tbl_obj_dict, insert_obj_list,
                env_vars
            )
        elif "catalog_integration_name" in entity_dict:
            process_metadata_entry(
                entity_dict, "catalog_integration_name", "CATALOG_INTEGRATION_METADATA_TBL", "catalog_integration", tbl_obj_dict, insert_obj_list,
                env_vars
            )
        else:
            logger.info(f"Object not supported for metadata entry : {entity_dict}")

    ## Remove Nones from insert_obj_list
    insert_obj_list = [i for i in insert_obj_list if i is not None]
    logger.debug(f"Insert object list for this iteration: {insert_obj_list}")
    perform_metadata_entry(insert_obj_list)


def process_metadata_entry(entity_dict, key, metadata_table_key, table_map_key, tbl_obj_dict, insert_obj_list,
                           env_vars):
    """
    Processes and prepares a metadata record for a specific entity.

    :param entity_dict: Dictionary containing entity details.
    :param key: Key used to identify the entity in the dictionary.
    :param metadata_table_key: Key to fetch the corresponding metadata table object.
    :param table_map_key: Key to fetch table-specific mappings.
    :param tbl_obj_dict: Dictionary containing metadata table objects.
    :param insert_obj_list: List to store prepared records for metadata insertion.
    :param env_vars: Dictionary of environment variables.
    """
    # Generate a unique numeric ID for the entity
    num_id = generate_numeric_id(entity_dict.get(key))
    id_attr_name=f"{key.replace(SEPERATOR+key.split(SEPERATOR)[-1],'')}_id"
    if id_attr_name == "ps_account_id":
        id_attr_name = "ps_id"
    # Retain persona roles for specific entity types
    refined_entity_dict = (
        retain_persona_roles(entity_dict) if key in ["database_name", "schema_name", "warehouse_name","storage_integration_name","external_volume_name","catalog_integration_name"] else entity_dict
    )

    # Prepare the record for insertion
    record = prepare_record(
        tbl_obj_dict.get(metadata_table_key),
        refined_entity_dict,
        USER_INPUT_SNF_TBL_MAP.get(table_map_key),
        id_attr_name,
        num_id,
        env_vars["PR_NUMBER"],
    )
    insert_obj_list.append(record)


def make_role_entry(role_dict, env_vars):
    """
    Prepares a role entry for insertion into the 'ROLES_METADATA' table.

    :param role_dict: Dictionary containing role information.
    :param env_vars: Dictionary containing environment variables (including webhook trigger).
    """
    # Generate metadata table objects
    tbl_obj_dict = generate_table_objects(METADATA_TABLE_LIST)

    # Process role if 'role_name' is present in the dictionary
    if "role_name" in role_dict:
        logger.debug(f"Processing role: {role_dict}")

        # Generate a unique numeric ID for the role
        role_num_id = generate_numeric_id(role_dict.get("role_name"))
        role_id_attr_name = "role_name".split(SEPERATOR)[0] + "_id"

        # Add generated ID to the role dictionary
        role_dict[role_id_attr_name] = role_num_id

        # Add additional metadata information to the role dictionary
        # role_dict["pr_id"] = env_vars["CODEBUILD_WEBHOOK_TRIGGER"]
        role_dict["pr_id"] = env_vars["PR_NUMBER"]
        role_dict["created_timestamp"] = datetime.now()

        logger.debug(f"Prepared record for insertion: {role_dict}")

        # Insert the role entry into the database
        create_db_insert_entry(tbl_obj_dict.get('ROLES_METADATA'), role_dict)
