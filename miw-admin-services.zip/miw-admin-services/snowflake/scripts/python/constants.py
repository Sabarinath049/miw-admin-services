import os

# Read the CODEBUILD_ENV environment variable
ENV = str(os.getenv('CODEBUILD_ENV', 'DEV')).upper()  # Default to 'DEV' if not set
env=os.getenv('env')

LOGGING_LEVEL = "DEBUG"

REQD_ENV_VARS = [
    "CODEBUILD_ENV",
    "CODEBUILD_WEBHOOK_EVENT",
    "CODEBUILD_WEBHOOK_TRIGGER",
    "CODEBUILD_WEBHOOK_BASE_REF",
    "CODEBUILD_WEBHOOK_HEAD_REF",
    "CODEBUILD_FILES_DIFF",
    "S3_BUCKET_NAME",
    "PR_NUMBER"
]

## Keys are the values from input json and values of the below dictionary can be used to cater the new keys that needs to be changed in input_json
mapping_critical_keys={
    "databases":{
        "enterprise_or_func_name": "enterprise_or_func_name",
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name",
        "product_group_identifier": "product_group_identifier"
    },
    "schemas":{
        "enterprise_or_func_name": "enterprise_or_func_name",
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name",
        "sub_group": "product_group_identifier"
    },
    "oauth":{
        "enterprise_or_func_name": "enterprise_or_func_name",
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name"
    },
    "roles":{
        "enterprise_or_func_name": "enterprise_or_func_name",
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name",
        "sub_function": "sub_function"
    },
    "storage_integrations":{
        "enterprise_or_func_name": "enterprise_or_func_name",
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name",
        "product_group_identifier": "product_group_identifier"
    },
    "external_volumes":{
        "enterprise_or_func_name": "enterprise_or_func_name",
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name",
        "product_group_identifier": "product_group_identifier"
    },
    "catalog_integrations":{
        "enterprise_or_func_name": "enterprise_or_func_name",
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name",
        "product_group_identifier": "product_group_identifier"
    },
    "warehouses":{
        "enterprise_or_func_name": "enterprise_or_func_name",
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name",
        "product_group_identifier": "product_group_identifier"
    }          
}

mapping_keys_src_system={
    "src_system":{
        "catalog_integrations":{
            "src_sys_name":"enterprise_or_func_subgrp_name",
            "src_sys_type":"enterprise_or_func_name"
        },
        "databases":{
            "src_sys_owner":"data_leader",
            "src_sys_name":"enterprise_or_func_subgrp_name",
            "src_sys_type":"enterprise_or_func_name"
        },
        "schemas":{
            "src_sys_name":"enterprise_or_func_subgrp_name",
            "src_sys_state":"subject_or_prod_name"
        },
        "oauth":{
            "src_sys_name":"enterprise_or_func_subgrp_name",
            "src_sys_type":"enterprise_or_func_name"
        },
        "external_volumes":{
            "src_sys_name":"enterprise_or_func_subgrp_name",
            "src_sys_type":"enterprise_or_func_name"
        }
    }
}

FILE_DIFF_STATUS_DICT = {
    "added" : {},
    "modified": {},
    "deleted": {},
    "renamed": {}
}

DIFF_STATUS_STATIC_FILENAMES = {
    "added": "git_diff_added_files.txt",
    "modified": "git_diff_modified_files.txt",
    "deleted": "git_diff_deleted_files.txt",
    "renamed": "git_diff_renamed_files.txt"
}

ERROR_FORMAT = "{SNF_OBJ_TYPE}:{SNF_OBJ_NAME}:{VALIDATION_FUNC_NAME}:{VALIDATION_FAIL_MESSAGE}"

SUPPORTED_SNF_OBJS_LIST = ["warehouse", "database", "schema", "persona", "oauth","storage_integration","catalog_integration","external_volume"]
GIT_PATH_RULE_BOOK_MAP = {
    "warehouses": "warehouse",
    "databases": "database",
    "schemas": "schema",
    "roles": "persona",
    "oauth": "oauth",
    "storage_integrations":"storage_integration",
    "external_volumes" : "external_volume",
    "catalog_integrations":"catalog_integration"
}


OBJ_TYPE_NAME_MAP = {
    "database": "database_name",
    "schema": "schema_name",
    "warehouse": "warehouse_name",
    "persona": "aad_group_name",
    "oauth": "ps_account_id",
    "storage_integration":"storage_integration_name",
    "external_volume" : "external_volume_name",
    "catalog_integration":"catalog_integration_name"
}

OBJ_NAME_KEY_MAP = {
    "warehouse_name": "name",
    "database_name": "name",
    "schema_name": "name",
    "aad_group_name": "name",
    "ps_account_id": "name",
    "storage_integration_name":"name",
    "external_volume_name" : "name",
    "catalog_integration_name":"name"
}

OBJ_ATTRIBUTES_ENFORCE_RECREATE = {
    "warehouse": ["NAME", "WAREHOUSE_SIZE", "MIN_CLUSTER_COUNT", "MAX_CLUSTER_COUNT", "WAREHOUSE_TYPE"],
    "database": ["NAME"],
    "schema": ["NAME"],
    "storage_integration": ["NAME", "STORAGE_PROVIDER", "STORAGE_AWS_ROLE_ARN"],
    "persona": ["NAME"],
    "oauth": ["NAME"],
    "external_volume": ["NAME", "STORAGE_PROVIDER", "STORAGE_AWS_ROLE_ARN","STORAGE_LOCATION_NAME"],
    "catalog_integration":["NAME","REST_AUTH_IAM_ROLE","REST_CATALOG_NAME","CATALOG_NAMESPACE","REST_CATALOG_API_TYPE","ENABLE_VENDED_CREDENTIALS"]
}

IP_JSON_KEY_PATTERNS_TO_IGNORE = ["comment", "answer"]

SNF_OBJ_MANDATORY_KEYS = {
    "warehouse": ["intake_id", "warehouse_name", "snowflake_account_id", "access_roles", "data_leader",
                  "description", "enterprise_or_func_name", "enterprise_or_func_subgrp_name","product_group_identifier",
                  "warehouse_counter", "warehouse_size", "monthly_credit_limit", "alert_subscribers_list",
                  "workload_category", "consumption_stack"],
    "database": ["intake_id", "database_name", "snowflake_account_id",  "description", "data_first_classification",
                 "enterprise_or_func_name", "enterprise_or_func_subgrp_name", "data_leader"],
    "schema": ["intake_id", "schema_name", "snowflake_account_id", "parent_db_name", "access_roles", "description",
               "data_first_classification","enterprise_or_func_name", "enterprise_or_func_subgrp_name", "product_group_identifier", "subject_or_prod_name", "data_product_manager", "lead_engineer", "governance_and_access_lead",
               "product_cost_id"],
    "persona": ["intake_id", "snowflake_account_id", "aad_group_name", "purpose", "role_owner_ds_id",
                "role_owner_email_id", "data_leader", "governance_and_access_lead", "enterprise_or_func_name", "enterprise_or_func_subgrp_name","sub_function"],
    "oauth": ["intake_id", "snowflake_account_id", "ps_account_id", "ps_account_email_id", "ps_account_owner", "data_product_manager",
              "lead_engineer", "governance_and_access_lead", "minerva_aad_group", "minerva-aad-group_owner", "azure_tenant_id", "oauth_resource_uri",
              "sub_uuid", "purpose", "consumption_stack", "einsight_uuid", "enterprise_or_func_name", "enterprise_or_func_subgrp_name"],
    "storage_integration":["intake_id", "storage_integration_name", "access_roles", "enterprise_or_func_name", "enterprise_or_func_subgrp_name", "product_group_identifier", "data_leader",
                    "data_first_classification", "storage_role_arn", "allowed_storage_locations", "description"],
    "external_volume":["intake_id","snowflake_account_id","external_volume_name","description","access_roles","storage_provider","storage_region",
                        "storage_role_arn","storage_base_url","allow_writes","enterprise_or_func_name", "enterprise_or_func_subgrp_name", "product_group_identifier","data_leader","data_first_classification","storage_access_point_arn",
                        "storage_external_id"],
    "catalog_integration":["intake_id", "snowflake_account_id", "catalog_integration_name", "description", "access_roles", "catalog_source", 
                    "catalog_table_format", "rest_catalog_uri", "rest_catalog_name", "rest_catalog_api_type", "catalog_namespace", "rest_auth_type", 
                    "rest_auth_iam_role", "rest_auth_sign_region", "iceberg_enabled", "enterprise_or_func_name", "enterprise_or_func_subgrp_name", "product_group_identifier", "data_leader", "data_first_classification",
                    "catalog_refresh_interval_secs","enable_vended_credentials"]
}

OBJ_TYPE_RULE_FUNC_PREFIX_MAP = {"warehouse": "wh", "database": "db", "schema": "sch", "persona": "pr", "oauth": "oth","storage_integration":"si","external_volume":"ev","catalog_integration":"ci"}
SEPERATOR = "_"


SNF_CONTEXT_DETAILS = {
    'database': '${env}_DTD_MIW_DB'.replace('${env}',ENV),
    'schema': 'FDP_SF_OBJECTS_METADATA_GBL_CUR_SC',
    'warehouse': f"{os.getenv('TF_VAR_warehouse')}",
    'role': f"{os.getenv('TF_VAR_db_pipln')}",
    # roles
    'db_pipeline_role': os.getenv('TF_VAR_db_pipln'),
    'account_admin_role': os.getenv('TF_VAR_account_admin_role'),
    'db_admin_role': os.getenv('TF_VAR_db_role'),
    'wh_admin_role': os.getenv('TF_VAR_wh_role'),
    'oauth_role': os.getenv('TF_VAR_oauth_role')
}

SNF_CRED_SECRET = os.getenv('TF_VAR_secret_manager_secret')
SNF_UNAME_PWD_SECRET = os.getenv('TF_VAR_secret_manager_secret')

SNF_AC_REGION = 'us-east-1'
SNF_VALIDATION_SP = 'VALIDATE_RESOURCES'
SNF_POLL_INTERVAL_IN_SECS = 10
SNF_POLL_MAX_RETRY = 3

MPL_TABLE_NAME = "MIW_PROVISIONING_LOG_TBL"
METADATA_TABLE_LIST = ["DATABASE_METADATA_TBL", "SCHEMA_METADATA_TBL", "WAREHOUSE_METADATA_TBL", "RESOURCE_MONITOR_METADATA_TBL",
                       "ROLES_METADATA_TBL", "OAUTH_METADATA_TBL","STORAGE_INTEGRATION_METADATA_TBL","CATALOG_INTEGRATION_METADATA_TBL","EXTERNAL_VOLUME_METADATA_TBL"]

OAUTH_URL=os.getenv('TF_VAR_oauth_url')

LOG_FOLDER = "logs"
S3_LOG_VAL_FILE_KEY = "pipeline/rule_validation/"
S3_LOG_META_FILE_KEY = "pipeline/metadata_entry/"

# Metadata Entry
USER_INPUT_SNF_TBL_MAP = {
    "database": {
        "intake_id": "intake_id",
        "database_name": "database_name",
        "description": "description",
        "data_first_classification": "data_first_classification",
        "enterprise_or_func_name": "ent_or_func_name",
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name",
        "product_group_identifier": "product_group_identifier",
        "data_leader": "data_leader",
        "database_type": "db_type"
    },
    "schema": {
        "intake_id": "intake_id",
        "schema_name": "schema_name",
        "parent_db_name": "parent_db_name",
        "access_roles": "access_roles",
        "description": "description",
        "data_first_classification": "data_first_classification",
        "enterprise_or_func_name": "enterprise_or_func_name",
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name",
        "product_group_identifier": "product_group_identifier",        
        "subject_or_prod_name": "subject_or_prod_name",
        "data_product_manager": "data_product_manager",
        "lead_engineer": "lead_engineer",
        "governance_and_access_lead": "governance_and_access_lead",
        "product_cost_id": "product_cost_id",
        "data_retention_in_days": "data_retention_in_days",
        "schema_external_volume": "attached_external_volume",
        "schema_catalog": "schema_catalog"
    },
    "warehouse": {
        "intake_id": "intake_id",
        "warehouse_name": "warehouse_name",
        "access_roles": "access_roles",
        "description": "description",
        "warehouse_size": "warehouse_size",
        "auto_suspend_in_seconds": "auto_suspend_in_seconds",
        "min_cluster_count": "min_cluster_count",
        "max_cluster_count": "max_cluster_count",
        "scaling_policy": "scaling_policy",
        "monthly_credit_limit": "monthly_credit_limit",
        "warehouse_type": "warehouse_type",
        "attached_resource_monitor": "attached_resource_monitor",
        "alert_subscribers_list": "alert_subscrbr_list",
        "workload_category": "workload_category",
        "consumption_stack": "consumption_stack",
        "warehouse_counter": "warehouse_counter",
        "enterprise_or_func_name": "ent_or_func_name",
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name",
        "product_group_identifier": "product_group_identifier",
        "data_leader": "data_leader"
    },
    "resource_monitor": {
        "rm_name": "rm_name",
        "associated_wh": "associated_wh",
        "credit_quota": "credit_quota",
        "rm_type": "rm_type",
        "rm_frequency": "rm_frequency",
        "alert_subscrbr_list": "alert_subscrbr_list",
        "ent_or_func_name": "ent_or_func_name",
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name",
        "product_group_identifier": "product_group_identifier",
        "data_leader": "data_leader"
    },
    "roles": {
        "intake_id": "intake_id",
        "role_name": "role_name",
        "role_type": "role_type",
        "role_purpose": "role_purpose",
        "parent_role": "parent_role",
        "role_owner": "role_owner",
        "role_owner_email": "role_owner_email",
        "ent_or_func_name": "ent_or_func_name",
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name",
        "data_leader": "data_leader",
        "governance_and_access_lead": "governance_and_access_lead",
        "access_roles_alias":"access_roles_alias",
        "sub_function":"sub_function"
    },
    "oauth": {
        "intake_id": "intake_id",
        "ps_account_id": "ps_account_id",
        "ps_account_email_id": "ps_email_id",
        "ps_account_owner": "ps_account_owner",
        "lead_engineer": "lead_engineer",
        "data_product_manager": "data_product_manager",
        "governance_and_access_lead": "governance_and_access_lead",
        "minerva_aad_group": "aad_group",
        "minerva_aad_group_owner": "aad_group_owner",
        "sub_uuid": "attached_sub_uuid",
        "purpose": "purpose",
        "consumption_stack": "consumption_stack",
        "enterprise_or_func_name": "ent_or_func_name",
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name"
    },
    "storage_integration": {
        "intake_id": "intake_id",
        "storage_integration_name": "storage_integration_name",
        "access_roles": "access_roles",
        "enterprise_or_func_name": "ent_or_func_name",
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name",
        "product_group_identifier": "product_group_identifier",
        "data_leader": "data_leader",
        "data_first_classification": "data_first_classification",
        "stage_type": "stage_type",
        "storage_role_arn": "storage_role_arn",
        "allowed_storage_locations": "allowed_storage_locations",
        "blocked_storage_locations": "blocked_storage_locations",
        "description": "description"
    },
    "external_volume":{
      "intake_id": "intake_id",
      "snowflake_account_id": "snowflake_account_id",
      "external_volume_name": "external_volume_name",
      "description": "description",
      "access_roles": "access_roles",
      "storage_provider": "storage_provider",
      "storage_region": "storage_region",
      "storage_role_arn": "storage_role_arn",
      "storage_base_url": "storage_base_url",
      "allow_writes": "allow_writes",
      "enterprise_or_func_name": "ent_or_func_name",
      "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name",
      "product_group_identifier": "product_group_identifier",
      "data_leader": "data_leader",
      "data_first_classification": "data_first_classification",
      "storage_access_point_arn": "storage_access_point_arn",
      "storage_external_id": "storage_external_id"
    },
    "catalog_integration": {
        "intake_id": "intake_id",
        "snowflake_account_id": "snowflake_account_id",
        "catalog_integration_name": "catalog_integration_name", 
        "description": "description", 
        "access_roles": "access_roles", 
        "catalog_source": "catalog_source", 
        "catalog_table_format": "catalog_table_format", 
        "rest_catalog_uri": "rest_catalog_uri", 
        "rest_catalog_name": "rest_catalog_name", 
        "rest_catalog_api_type": "rest_catalog_api_type", 
        "catalog_namespace": "catalog_namespace", 
        "rest_auth_type": "rest_auth_type", 
        "rest_auth_iam_role": "rest_auth_iam_role", 
        "rest_auth_sign_region": "rest_auth_sign_region", 
        "iceberg_enabled": "iceberg_enabled", 
        "enterprise_or_func_name": "ent_or_func_name", 
        "enterprise_or_func_subgrp_name": "enterprise_or_func_subgrp_name",
        "product_group_identifier": "product_group_identifier",
        "data_leader": "data_leader", 
        "data_first_classification": "data_first_classification", 
        "catalog_refresh_interval_secs": "catalog_refresh_interval_secs",
        "enable_vended_credentials" :"enable_vended_credentials"
    }
}

SNF_OBJ_DEFAULT_MAP = {
    "database": {
        "database_type": "PERMANENT"
    },
    "schema": {
        "port": None,
        "data_retention_in_days": 1,
        "schema_external_volume": None,
        "schema_catalog": "SNOWFLAKE"
    },
    "warehouse": {
        "warehouse_type": "Standard",
        "auto_suspend_in_seconds": 60,
        "auto_resume": True,
        "min_cluster_count": 1,
        "max_cluster_count": 1,
        "scaling_policy": "Economy",
        "query_timeout_in_seconds": 0,
        "statement_queued_timeout_in_seconds": 120,
        "max_concurrency_level": 8
    },
    "storage_integration" :{
        "stage_type": "external_stage",
        "storage_provider": "s3",
        "storage_integration_enabled": True
    },
    "persona": {
        "access_roles_alias":[],
        "grants":[]
    },
    "external_volume" :{
        "storage_provider": "s3",
        "allow_writes": True,
        "encryption_type": "AWS_SSE_S3",
        "encryption_key_id": "",
        "private_link_enabled": False
    },
    "catalog_integration":{
        "catalog_refresh_interval_secs":30,
        "enable_vended_credentials":"true"
    }
}

METADATA_SNF_TABLE_MAP = {
    "db": "DATABASE_METADATA_TBL",
    "schema": "SCHEMA_METADATA_TBL",
    "warehouse": "WAREHOUSE_METADATA_TBL",
    "roles": "ROLES_METADATA_TBL",
    "oauth": "OAUTH_METADATA_TBL",
    "storage_integration":"STORAGE_INTEGRATION_METADATA_TBL",
    "external_volume" : "EXTERNAL_VOLUME_METADATA_TBL",
    "catalog_integration":"CATALOG_INTEGRATION_METADATA_TBL"
}

EXPLICIT_METADATA_HANDLING_OBJECTS = ["roles", "oauth","storage_integration","external_volume","catalog_integration"]

METADATA_MATCH_KEYS = {
    "DATABASE_METADATA_TBL": ["database_name"],
    "SCHEMA_METADATA_TBL": ["schema_name"],
    "WAREHOUSE_METADATA_TBL": ["warehouse_name"],
    "ROLES_METADATA_TBL": ["role_name"],
    "RESOURCE_MONITOR_METADATA_TBL": ["rm_name"],
    "OAUTH_METADATA_TBL": ["ps_account_id"],
    "STORAGE_INTEGRATION_METADATA_TBL": ["storage_integration_name"],
    "EXTERNAL_VOLUME_METADATA_TBL": ["external_volume_name"],
    "CATALOG_INTEGRATION_METADATA_TBL": ["catalog_integration_name"]
}