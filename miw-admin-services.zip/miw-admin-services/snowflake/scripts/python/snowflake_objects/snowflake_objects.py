import inspect
import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)

from constants import ERROR_FORMAT, SEPERATOR, SNF_OBJ_DEFAULT_MAP


def load_config(config_path: str) -> Dict:
    """
    Loads a JSON configuration file from the specified path.

    :param config_path: Path to the JSON configuration file.
    :return: A dictionary containing the configuration data.
    :raises FileNotFoundError: If the file does not exist.
    :raises json.JSONDecodeError: If the file is not valid JSON.
    :raises IOError: If there is an issue reading the file.
    """
    try:
        with open(config_path, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        raise FileNotFoundError(f"Configuration file not found at path: {config_path}")
    except json.JSONDecodeError:
        raise ValueError(f"Invalid JSON format in configuration file: {config_path}")
    except IOError as e:
        raise IOError(f"An error occurred while reading the configuration file: {e}")


def preprocess_keys(obj_ip_json: Dict, key_map: Dict) -> Dict:
    """
    Preprocesses keys in a JSON-like dictionary by replacing old keys with new ones based on a mapping.
    This function does not modify the original dictionary; it returns a new one.

    :param obj_ip_json: The input dictionary to preprocess.
    :param key_map: A dictionary mapping old keys to new keys.
    :return: A new dictionary with keys replaced as per the mapping.
    """
    try:
        updated_json = {
            key_map.get(key, key): value for key, value in obj_ip_json.items()
        }
        return updated_json
    except AttributeError as e:
        raise ValueError("Invalid input: obj_ip_json and key_map must be dictionaries.") from e


def prepare_exception(obj_type: str, obj_name: str, func_name: str, failure_msg: str) -> str:
    """
    Prepares a formatted exception message based on the provided parameters.

    :param obj_type: The type of the Snowflake object.
    :param obj_name: The name of the Snowflake object.
    :param func_name: The name of the validation function.
    :param failure_msg: The failure message explaining the issue.
    :return: A formatted error message string.
    """
    if not isinstance(ERROR_FORMAT, str):
        raise ValueError("ERROR_FORMAT must be a valid string format template.")

    try:
        return ERROR_FORMAT.format(
            SNF_OBJ_TYPE=obj_type,
            SNF_OBJ_NAME=obj_name,
            VALIDATION_FUNC_NAME=func_name,
            VALIDATION_FAIL_MESSAGE=failure_msg
        )
    except KeyError as e:
        raise ValueError(
            f"Missing placeholders in ERROR_FORMAT: {e}. Ensure it contains the required placeholders."
        ) from e


@dataclass
class SnowflakeObject:
    """
    Base class for Snowflake objects, providing common validation methods.

    Each subclass must implement its own `validate` method to define custom validation rules.
    """

    name: str  # Assuming `name` is a common attribute for all Snowflake objects.

    @staticmethod
    def validate(obj) -> List[str]:
        """
        Placeholder for validation method to be implemented by subclasses.
        """
        raise NotImplementedError("Validation must be implemented in subclass")

    def __str__(self) -> str:
        """
        Returns a string representation of the Snowflake object.
        """
        return f"{self.__class__.__name__}: {self.name}"

    def validate_length(self, length_threshold_dict: Dict[str, int]) -> str:
        """
        Validates the length of the object's name against a threshold.

        :param length_threshold_dict: Dictionary mapping object types to their length thresholds.
        :return: "success" if validation passes, otherwise an error message.
        """
        obj_type = str(self.__class__.__name__).lower()
        length_threshold = length_threshold_dict.get(obj_type)
        if len(self.name) < length_threshold:
            return "success"
        fail_msg = f"Overall length of object name exceeds the threshold of {length_threshold}"
        return prepare_exception(obj_type, self.name, inspect.currentframe().f_code.co_name, fail_msg)

    def restrict_public_access(self, obj_access_role_keys: Dict[str, str]) -> str:
        """
        Ensures no privileges are granted to the Snowflake PUBLIC role.

        :param obj_access_role_keys: Dictionary mapping object types to their access role attribute names.
        :return: "success" if validation passes, otherwise an error message.
        """
        obj_type = str(self.__class__.__name__).lower()
        if not (access_role_attr_name := obj_access_role_keys.get(obj_type)):
            return prepare_exception(
                obj_type, self.name, inspect.currentframe().f_code.co_name,
                "RESTRICT_PUBLIC_ACCESS rule isn't correctly configured in the rulebook. Please contact the MIW team."
            )
        access_roles_list = getattr(self, access_role_attr_name)
        for role in access_roles_list:
            if str(role).strip().lower() == "public":
                return prepare_exception(
                    obj_type, self.name, inspect.currentframe().f_code.co_name,
                    "No additional privileges can be provided to Snowflake's PUBLIC role."
                )
        return "success"

    def separator_count(self, sep_count_lookup_dict: Dict[str, int]) -> str:
        """
        Validates the separator count in the object's name.

        :param sep_count_lookup_dict: Dictionary mapping object types to their expected separator counts.
        :return: "success" if validation passes, otherwise an error message.
        """
        obj_type = str(self.__class__.__name__).lower()
        expected_count = sep_count_lookup_dict.get(obj_type, 0)
        actual_count = len(str(self.name).split(SEPERATOR)) - 1
        if actual_count <= expected_count:
            return "success"
        fail_msg = (
            "Naming standards for your Snowflake object do not adhere to Minerva standards. Please read request guide or reach out to MIW Team."
        )
        return prepare_exception(obj_type, self.name, inspect.currentframe().f_code.co_name, fail_msg)

    def prefix_check(self, prefix_lookup_dict: Dict[str, List[str]]) -> str:
        """
        Validates the prefix of the object's name.

        :param prefix_lookup_dict: Dictionary mapping object types to their allowed prefixes.
        :return: "success" if validation passes, otherwise an error message.
        """
        return self._prefix_suffix_helper(0, prefix_lookup_dict, "Prefix for object type")

    def suffix_check(self, suffix_lookup_dict: Dict[str, List[str]]) -> str:
        """
        Validates the suffix of the object's name.

        :param suffix_lookup_dict: Dictionary mapping object types to their allowed suffixes.
        :return: "success" if validation passes, otherwise an error message.
        """
        return self._prefix_suffix_helper(-1, suffix_lookup_dict, "Suffix for object type")

    def _prefix_suffix_helper(self, position: int, lookup_dict: Dict[str, List[str]], descriptor: str) -> str:
        """
        Common helper method for prefix and suffix checks.

        :param position: Index position to check in the object's name split by SEPERATOR.
        :param lookup_dict: Dictionary mapping object types to their allowed prefixes/suffixes.
        :param descriptor: String descriptor for the error message.
        :return: "success" if validation passes, otherwise an error message.
        """
        obj_type = str(self.__class__.__name__).lower()
        allowed_values = lookup_dict.get(obj_type, [])
        if str(self.name).split(SEPERATOR)[position] in allowed_values:
            return "success"
        fail_msg = f"{descriptor} '{obj_type}' must be one of: {allowed_values}"
        return prepare_exception(obj_type, self.name, inspect.currentframe().f_code.co_name, fail_msg)


    def segment_value_check(
        self,
        segment_rules: Dict[str, Dict[str, Dict[str, List[str]]]],
        profile_whitelist: List[str] = None,   # NEW: force which profiles to evaluate
        prefer_first_success: bool = True       # NEW: short-circuit on first success
    ) -> str:
        """
        Validates object name segments against multiple profile rules.

        SUCCESS: if ANY profile in the evaluated set matches.
        FAILURE: if NONE match.

        If profile_whitelist is provided, only those profiles are evaluated (in that order).
        Otherwise, the function auto-detects a reasonable order:

        SCHEMAS (UPDATED to your spec):
        • BEFORE (row-based) guard:
            If any layer token (RAW/CLN/CURATED/SERVING) is present anywhere,
            the name MUST NOT start with FDP/BDP. (Mutual exclusion)
        • AFTER (new/target naming):
            Prefer NEW_SCHEMA -> tail must be <LAYER>_<ENV>_SC, i.e. LAYER at -3 (one of
            RAW/CURATED), ENV at -2 (SBX/DEV/STG/PRD), SC at -1.
            NEW_SCHEMA_RAW_SERVING -> tail must be RAW_SERVING_<ENV>_SC, i.e. RAW at -4,
            SERVING at -3, ENV at -2, SC at -1.
        • If NO layer token is present:
            Require OLD_SCHEMA_ENP_LEVEL (must start with FDP/BDP and end with SC).
        • (Optional legacy) OLD_SCHEMA_SOURCE_LEVEL if tail looks like <ENV>_SC and the
            profile is present/enabled in the rule book.
        • NEW_SCHEMA_V2 (<ENV>_<LAYER>_SC) is intentionally NOT preferred now to push the
            new target naming; leave commented if you ever want to allow it.

        DATABASES (unchanged):
        • Prefer NEW_DATABASE if looks like SF_*_(SRC|DP)_DB,
        • Consider OLD_DATABASE if starts with ENV and ends with DB.

        Notes:
        - Robust to DB rules that mark 'DB' at position 3 or at position -1.
        - Uses ANY-profile-match semantics as requested.
        """

        obj_type = str(self.__class__.__name__).lower()  # "database" | "schema" | "warehouse" ...
        name = str(self.name).upper()

        logger.info("[segment_value_check] INVOKED name='%s' type='%s'", name, obj_type)

        # Load rules for this object type
        all_rules_for_type = (segment_rules or {}).get(obj_type, {})
        if not all_rules_for_type:
            msg = f"No segment rules defined for object type '{obj_type}'"
            logger.error("[segment_value_check] %s", msg)
            return prepare_exception(obj_type, name, inspect.currentframe().f_code.co_name, msg)

        # Split name
        parts = [p.strip().upper() for p in name.split(SEPERATOR) if p.strip()]
        logger.debug("[segment_value_check] Segments: %s", parts)
        logger.debug("[segment_value_check] Profiles available for '%s': %s", obj_type, list(all_rules_for_type.keys()))

        # ---- helper to read allowed values safely from rules ----
        def _vals(rule_name: str, pos_key: int) -> List[str]:
            try:
                return [str(x).upper() for x in (all_rules_for_type.get(rule_name, {}).get(str(pos_key), []) or [])]
            except Exception:
                return []

        # ---- Collect canonical sets from your rules (for auto-detect) ----
        # For schemas
        # ENV candidates from profiles that define them
        env_vals_schema = set(
            _vals("OLD_SCHEMA_SOURCE_LEVEL", -3)
            + _vals("NEW_SCHEMA", -2)
            + _vals("NEW_SCHEMA_V2", -2)          # ENV is at -2 in NEW_SCHEMA_V2
            + _vals("NEW_SCHEMA_PRODUCT_SERVING", -2)
            + _vals("NEW_SCHEMA_RAW_SERVING", -2) # ENV is at -2 in NEW_SCHEMA_RAW_SERVING
        )
        # Layer tokens:
        #   - NEW_SCHEMA expects LAYER at -3 (RAW/CURATED)
        #   - NEW_SCHEMA_V2 expects LAYER at -3 (RAW/CLN), ENV at -2
        #   - NEW_SCHEMA_RAW_SERVING expects RAW at -4, SERVING at -3, ENV at -2
        #   - NEW_SCHEMA_PRODUCT_SERVING expects SERVING at -4, PURPOSE at -3, ENV at -2
        layer_vals_new              = set(_vals("NEW_SCHEMA", -3))
        layer_vals_v2               = set(_vals("NEW_SCHEMA_V2", -3))   # LAYER is at -3 in NEW_SCHEMA_V2
        layer_vals_serving          = set(_vals("NEW_SCHEMA_PRODUCT_SERVING", -4))
        layer_vals_raw_serving_outer = set(_vals("NEW_SCHEMA_RAW_SERVING", -4))  # RAW at -4
        layer_vals_raw_serving_inner = set(_vals("NEW_SCHEMA_RAW_SERVING", -3))  # SERVING at -3
        layer_vals_any = (
            set(layer_vals_new)
            .union(layer_vals_v2)
            .union(layer_vals_serving)
            .union(layer_vals_raw_serving_outer)
            .union(layer_vals_raw_serving_inner)
        )

        # SC suffix across all schema profiles
        must_end_sc = set(
            _vals("OLD_SCHEMA_SOURCE_LEVEL", -1)
            + _vals("OLD_SCHEMA_ENP_LEVEL", -1)
            + _vals("NEW_SCHEMA", -1)
            + _vals("NEW_SCHEMA_V2", -1)
            + _vals("NEW_SCHEMA_PRODUCT_SERVING", -1)
            + _vals("NEW_SCHEMA_RAW_SERVING", -1)
        )

        # Enterprise prefix FDP/BDP
        must_start_fdp = set(_vals("OLD_SCHEMA_ENP_LEVEL", 0))

        # For databases (unchanged)
        env_vals_db   = set(_vals("OLD_DATABASE", 0))
        sf_prefix_db  = set(_vals("NEW_DATABASE", 0))  # typically {"SF"}
        role_vals_db  = set(_vals("NEW_DATABASE", -2)) # {"SRC","DP"} under NEW_DATABASE
        # Accept 'DB' being specified at pos 3 or at pos -1 (some repos differ)
        db_token_new_pos3  = set(_vals("NEW_DATABASE", 3))
        db_token_old_pos3  = set(_vals("OLD_DATABASE", 3))
        db_token_new_posm1 = set(_vals("NEW_DATABASE", -1))
        db_token_old_posm1 = set(_vals("OLD_DATABASE", -1))
        db_tokens_any_pos3 = db_token_new_pos3.union(db_token_old_pos3)
        db_tokens_any_posm1= db_token_new_posm1.union(db_token_old_posm1)
        # If config only provided one style, normalise a default token 'DB' for heuristics
        db_token = "DB"

        # ---- Decide which profiles to evaluate (order matters) ----
        if profile_whitelist:
            profiles_to_check = [p for p in profile_whitelist if p in all_rules_for_type]
            logger.info("[segment_value_check] Using profile_whitelist for '%s': %s", obj_type, profiles_to_check)
        else:
            profiles_to_check = list(all_rules_for_type.keys())
            candidates: List[str] = []

            if obj_type == "schema":
                # ---- BEFORE mutual exclusion guard ----
                has_layer_anywhere = any(p in layer_vals_any for p in parts)
                has_enterprise_prefix = bool(parts and parts[0] in must_start_fdp)
                if has_layer_anywhere and has_enterprise_prefix:
                    found_layers = [p for p in parts if p in layer_vals_any]
                    msg = (
                        f"Schema '{name}' mixes layer token(s) {found_layers} with enterprise prefix "
                        f"'{parts[0]}' — not allowed. Names with RAW/CLN/CURATED/RAW_SERVING/SERVING "
                        f"must NOT start with FDP/BDP."
                    )
                    logger.error("[segment_value_check] %s", msg)
                    return prepare_exception(obj_type, name, inspect.currentframe().f_code.co_name, msg)

                # Helper recognizers for ordering/prioritization
                def is_tail_layer_env_sc() -> bool:
                    """Detect ..._<LAYER>_<ENV>_SC (NEW_SCHEMA) — target AFTER pattern"""
                    if len(parts) < 3:
                        return False
                    last, pen, ant = parts[-1], parts[-2], parts[-3]
                    return (
                        (last in must_end_sc or last == "SC")
                        and (not env_vals_schema or pen in env_vals_schema)
                        and (not layer_vals_new or ant in layer_vals_new)
                    )

                def is_tail_env_sc() -> bool:
                    """Detect ..._<ENV>_SC (OLD_SCHEMA_SOURCE_LEVEL)"""
                    if len(parts) < 2:
                        return False
                    last, pen = parts[-1], parts[-2]
                    return (
                        (last in must_end_sc or last == "SC")
                        and (not env_vals_schema or pen in env_vals_schema)
                    )

                def is_tail_serving_purpose_env_sc() -> bool:
                    """Detect ..._SERVING_<PURPOSE>_<ENV>_SC (NEW_SCHEMA_PRODUCT_SERVING) — product serving pattern"""
                    if len(parts) < 4:
                        return False
                    last, pen, ant, quad = parts[-1], parts[-2], parts[-3], parts[-4]
                    return (
                        (last in must_end_sc or last == "SC")
                        and (not env_vals_schema or pen in env_vals_schema)
                        and (not layer_vals_serving or quad in layer_vals_serving)
                    )

                def is_tail_raw_serving_env_sc() -> bool:
                    """Detect ..._RAW_SERVING_<ENV>_SC (NEW_SCHEMA_RAW_SERVING) — raw serving pattern"""
                    if len(parts) < 4:
                        return False
                    last, pen, ant, quad = parts[-1], parts[-2], parts[-3], parts[-4]
                    return (
                        (last in must_end_sc or last == "SC")
                        and (not env_vals_schema or pen in env_vals_schema)
                        and (not layer_vals_raw_serving_inner or ant in layer_vals_raw_serving_inner)
                        and (not layer_vals_raw_serving_outer or quad in layer_vals_raw_serving_outer)
                    )

                if has_layer_anywhere:
                    # NEW_SCHEMA_PRODUCT_SERVING takes priority if tail matches SERVING_<PURPOSE>_<ENV>_SC
                    if is_tail_serving_purpose_env_sc() and "NEW_SCHEMA_PRODUCT_SERVING" in all_rules_for_type:
                        candidates.append("NEW_SCHEMA_PRODUCT_SERVING")

                    # NEW_SCHEMA_RAW_SERVING takes priority if tail matches RAW_SERVING_<ENV>_SC
                    if is_tail_raw_serving_env_sc() and "NEW_SCHEMA_RAW_SERVING" in all_rules_for_type:
                        candidates.append("NEW_SCHEMA_RAW_SERVING")

                    # AFTER rule: enforce/try NEW_SCHEMA next (<LAYER>_<ENV>_SC)
                    if is_tail_layer_env_sc() and "NEW_SCHEMA" in all_rules_for_type:
                        candidates.append("NEW_SCHEMA")
                    else:
                        # Even if heuristic is not decisive, still try NEW_SCHEMA to enforce shape
                        if "NEW_SCHEMA" in all_rules_for_type:
                            candidates.append("NEW_SCHEMA")

                    # NEW_SCHEMA_V2 (<ENV>_<LAYER>_SC) is now active
                    if "NEW_SCHEMA_V2" in all_rules_for_type and "NEW_SCHEMA_V2" not in candidates:
                        candidates.append("NEW_SCHEMA_V2")

                else:
                    # No layer tokens -> enterprise naming must be applied
                    if has_enterprise_prefix and (parts[-1] in must_end_sc or parts[-1] == "SC"):
                        if "OLD_SCHEMA_ENP_LEVEL" in all_rules_for_type:
                            candidates.append("OLD_SCHEMA_ENP_LEVEL")

                    # Optional legacy source-level naming (<ENV>_SC)
                    if is_tail_env_sc() and "OLD_SCHEMA_SOURCE_LEVEL" in all_rules_for_type:
                        candidates.append("OLD_SCHEMA_SOURCE_LEVEL")

            elif obj_type == "database":
                # Heuristic: NEW_DATABASE if looks like SF_*_(SRC|DP)_DB
                looks_new = False
                if len(parts) >= 4:
                    # Try both positions for DB token: pos 3 OR last
                    pos3_db_ok  = (len(parts) > 3 and ((db_tokens_any_pos3 and parts[3] in db_tokens_any_pos3) or (parts[3] == db_token)))
                    last_db_ok  = ((db_tokens_any_posm1 and parts[-1] in db_tokens_any_posm1) or (parts[-1] == db_token))
                    sf_ok       = (not sf_prefix_db or parts[0] in sf_prefix_db or parts[0] == "SF")
                    role_ok     = (not role_vals_db or parts[-2] in role_vals_db)  # expects SRC/DP before DB in NEW
                    looks_new   = sf_ok and role_ok and (pos3_db_ok or last_db_ok)
                if looks_new:
                    candidates.append("NEW_DATABASE")

                # Heuristic: OLD_DATABASE if starts with ENV and ends with DB
                looks_old = False
                if len(parts) >= 2:
                    env_ok    = (not env_vals_db or parts[0] in env_vals_db)  # ENV = SBX/DEV/STG/PRD per environment
                    # Accept DB token at pos 3 OR at last
                    pos3_db_ok = (len(parts) > 3 and ((db_tokens_any_pos3 and parts[3] in db_tokens_any_pos3) or (parts[3] == db_token)))
                    last_db_ok = ((db_tokens_any_posm1 and parts[-1] in db_tokens_any_posm1) or (parts[-1] == db_token))
                    looks_old  = env_ok and (pos3_db_ok or last_db_ok)
                if looks_old:
                    candidates.append("OLD_DATABASE")

            # Compose final order (candidates first, then remaining)
            remainder = [p for p in profiles_to_check if p not in candidates]
            profiles_to_check = []
            for p in candidates + remainder:
                if p in all_rules_for_type and p not in profiles_to_check:
                    profiles_to_check.append(p)

        logger.info("[segment_value_check] Evaluating profiles (in order) for '%s': %s", obj_type, profiles_to_check)

        successful_profiles: List[str] = []
        failed_profiles: Dict[str, List[str]] = {}

        def resolve_index(pos: int, n: int):
            if n == 0:
                return False, "object contains no name segments"
            if pos >= 0:
                if pos < n:
                    return True, pos
                return False, f"position {pos} missing — object has only {n} segments"
            idx = n + pos
            if idx < 0:
                return False, f"position {pos} missing — object has only {n} segments"
            return True, idx

        # Evaluate each selected profile
        for profile_name in profiles_to_check:
            ruleset = all_rules_for_type.get(profile_name, {})
            profile_ok = True
            reasons: List[str] = []

            logger.info("[segment_value_check] Checking profile '%s'...", profile_name)

            for pos_str, allowed in (ruleset or {}).items():
                try:
                    pos = int(pos_str)
                except Exception:
                    profile_ok = False
                    reason = f"invalid index key '{pos_str}' — must be integer (negative allowed)"
                    logger.error("[segment_value_check][%s] %s", profile_name, reason)
                    reasons.append(reason)
                    continue

                ok, idx_or_reason = resolve_index(pos, len(parts))
                if not ok:
                    profile_ok = False
                    logger.error("[segment_value_check][%s] %s", profile_name, idx_or_reason)
                    reasons.append(idx_or_reason)
                    continue

                idx = idx_or_reason
                value = parts[idx]
                allowed_norm = [str(x).upper() for x in allowed]

                if value not in allowed_norm:
                    profile_ok = False
                    msg = f"position {pos} ('{value}') must be one of {allowed_norm}"
                    logger.error("[segment_value_check][%s] %s", profile_name, msg)
                    reasons.append(msg)

            if profile_ok:
                logger.info("[segment_value_check] ✔ Profile matched: %s", profile_name)
                if prefer_first_success:
                    return "success"
                successful_profiles.append(profile_name)
            else:
                logger.info("[segment_value_check] ❌ Profile failed: %s", profile_name)
                failed_profiles[profile_name] = reasons

        if successful_profiles:
            logger.info("[segment_value_check] SUCCESS via profile(s): %s", successful_profiles)
            return "success"

        # Build error
        lines = [f"{name} failed all validation profiles for type '{obj_type}':"]
        for profile, reasons in failed_profiles.items():
            lines.append(f"- {profile}:")
            for r in reasons:
                lines.append(f"    • {r}")
        final_msg = "\n".join(lines)
        logger.error("[segment_value_check] FAILURE\n%s", final_msg)
        return prepare_exception(obj_type, name, inspect.currentframe().f_code.co_name, final_msg)
        
@dataclass
class Warehouse(SnowflakeObject):
    """
    Represents a Snowflake Warehouse object with attributes and validation methods.
    """
    intake_id: str
    name: str
    snowflake_account_id: str
    access_roles: list
    data_leader: str
    description: str
    enterprise_or_func_name: str
    enterprise_or_func_subgrp_name: str
    product_group_identifier: str
    warehouse_size: str
    monthly_credit_limit: int
    alert_subscribers_list: list
    workload_category: list
    consumption_stack: list
    warehouse_counter : int

    # Optional attributes with default values from configuration
    warehouse_type: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("warehouse", {}).get("warehouse_type", "Standard")
    )
    auto_suspend_in_seconds: Optional[int] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("warehouse", {}).get("auto_suspend_in_seconds", 60)
    )
    auto_resume: Optional[bool] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("warehouse", {}).get("auto_resume", True)
    )
    min_cluster_count: Optional[int] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("warehouse", {}).get("min_cluster_count", 1)
    )
    max_cluster_count: Optional[int] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("warehouse", {}).get("max_cluster_count", 1)
    )
    scaling_policy: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("warehouse", {}).get("scaling_policy", "Economy")
    )
    query_timeout_in_seconds: Optional[int] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("warehouse", {}).get("query_timeout_in_seconds", 0)
    )
    statement_queued_timeout_in_seconds: Optional[int] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("warehouse", {}).get("statement_queued_timeout_in_seconds", 0)
    )
    max_concurrency_level: Optional[int] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("warehouse", {}).get("max_concurrency_level", 8)
    )
    
    def __str__(self) -> str:
        """
        Returns the name of the Warehouse object.
        """
        return self.name

    def wh_size_validate(self, allowed_wh_sizes: dict) -> str:
        """
        Validates the warehouse size against the allowed sizes.

        :param allowed_wh_sizes: Dictionary containing accepted warehouse sizes.
        :return: "success" if validation passes, otherwise an error message.
        """
        if str(self.warehouse_size).upper() not in allowed_wh_sizes.get("accepted_sizes", []):
            failure_msg = (
                f"Allowed warehouse sizes are: {allowed_wh_sizes.get('accepted_sizes', [])} while user has requested {self.warehouse_size}."
            )
            return prepare_exception(self.__class__.__name__.lower(), self.name, inspect.currentframe().f_code.co_name, failure_msg)
        return "success"

    def wh_credits_validate(self, max_allowed_credits: dict) -> str:
        """
        Validates the monthly credit limit against the maximum allowed.

        :param max_allowed_credits: Dictionary containing the maximum allowed monthly credits.
        :return: "success" if validation passes, otherwise an error message.
        """
        if self.monthly_credit_limit > max_allowed_credits.get("monthly_credit_limit", 500):
            failure_msg = (
                f"Maximum allowed monthly credits are: {max_allowed_credits.get('monthly_credit_limit', 500)} while user has requested {self.monthly_credit_limit}."
            )
            return prepare_exception(self.__class__.__name__.lower(), self.name, inspect.currentframe().f_code.co_name, failure_msg)
        return "success"

    def wh_autosuspend_validate(self, max_allowed_autosuspend: dict) -> str:
        """
        Validates the auto-suspend duration against the maximum allowed.

        :param max_allowed_autosuspend: Dictionary containing the maximum allowed auto-suspend duration.
        :return: "success" if validation passes, otherwise an error message.
        """
        if self.auto_suspend_in_seconds:
            if self.auto_suspend_in_seconds > max_allowed_autosuspend.get("max_allowed_autosuspend", 60):
                failure_msg = (
                    f"Maximum allowed auto-suspend duration is: {max_allowed_autosuspend.get('max_allowed_autosuspend', 60)} seconds while user has requested {self.auto_suspend_in_seconds}."
                )
                return prepare_exception(self.__class__.__name__.lower(), self.name, inspect.currentframe().f_code.co_name, failure_msg)
            return "success"
        else:
            return "success"

    def wh_type_validate(self, warehouse_types: dict) -> str:
        """
        Validates the warehouse type against the allowed types per Minerva.

        :param warehouse_types: Dictionary containing acceptable warehouse types.
        :return: "success" if validation passes, otherwise an error message.
        """
        if self.warehouse_type:
            if str(self.warehouse_type).upper() not in warehouse_types.get("accepted_warehouse_types", []):
                failure_msg = (
                    f"Allowed warehouse types are: {warehouse_types.get('accepted_warehouse_types', [])} while user has requested {self.warehouse_type}."
                )
                return prepare_exception(self.__class__.__name__.lower(), self.name, inspect.currentframe().f_code.co_name, failure_msg)
            return "success"
        else:
            return "success"

    def wh_max_cluster_count_validate(self, cluster_max_count: dict) -> str:
        """
        Validates the warehouse's max cluster count against the allowed cluster count per Minerva.

        :param cluster_max_count: Dictionary containing acceptable max_cluster_count.
        :return: "success" if validation passes, otherwise an error message.
        """
        if self.max_cluster_count:
            if self.max_cluster_count > cluster_max_count.get("max_allowed_cluster_count", 0):
                failure_msg = (
                    f"Maximum allowed cluster count is: {cluster_max_count.get('max_allowed_cluster_count', 10)} while user has requested {self.max_cluster_count}."
                )
                return prepare_exception(self.__class__.__name__.lower(), self.name, inspect.currentframe().f_code.co_name, failure_msg)
            return "success"
        else:
            return "success"

    def wh_scaling_policy_validate(self, scaling_policies: dict) -> str:
        """
        Validates the warehouse's scaling policy against the allowed scaling policy per Minerva.

        :param scaling_policies: Dictionary containing acceptable scaling policies.
        :return: "success" if validation passes, otherwise an error message.
        """
        if self.scaling_policy:
            if str(self.scaling_policy).upper() not in scaling_policies.get("accepted_scaling_policies", []):
                failure_msg = (
                    f"Allowed warehouse scaling policies are: {scaling_policies.get('accepted_scaling_policies', [])} while user has requested {self.scaling_policy}."
                )
                return prepare_exception(self.__class__.__name__.lower(), self.name, inspect.currentframe().f_code.co_name, failure_msg)
            return "success"
        else:
            return "success"

    def wh_query_timeout_in_seconds_validate(self, query_timeout: dict) -> str:
        """
        Validates the warehouse's query timeout against the allowed query timeout per Minerva.

        :param query_timeout: Dictionary containing acceptable limit of query timeout.
        :return: "success" if validation passes, otherwise an error message.
        """
        if self.query_timeout_in_seconds:
            if self.query_timeout_in_seconds > query_timeout.get("max_allowed_query_timeout", 1800):
                failure_msg = (
                    f"Maximum allowed query timeout is: {query_timeout.get('max_allowed_query_timeout', 1800)} seconds while user has requested {self.query_timeout_in_seconds}."
                )
                return prepare_exception(self.__class__.__name__.lower(), self.name, inspect.currentframe().f_code.co_name, failure_msg)
            return "success"
        else:
            return "success"

    def wh_statement_queued_timeout_in_seconds_validate(self, statement_queue_timeout: dict) -> str:
        """
        Validates the warehouse's statement queue timeout against the allowed statement queue timeout per Minerva.

        :param statement_queue_timeout: Dictionary containing acceptable statement queue timeout.
        :return: "success" if validation passes, otherwise an error message.
        """
        if self.statement_queued_timeout_in_seconds:
            if self.statement_queued_timeout_in_seconds > statement_queue_timeout.get("max_allowed_statement_queue_timeout", 120):
                failure_msg = (
                    f"Maximum allowed statement queue timeout is: {statement_queue_timeout.get('max_allowed_statement_queue_timeout', 120)} while user has requested {self.statement_queued_timeout_in_seconds}."
                )
                return prepare_exception(self.__class__.__name__.lower(), self.name, inspect.currentframe().f_code.co_name, failure_msg)
            return "success"
        else:
            return "success"

    def wh_max_concurrency_level_validate(self, concurrency: dict) -> str:
        """
        Validates the warehouse's concurrency against the allowed concurrency as per Minerva.

        :param concurrency: Dictionary containing acceptable limit of concurrency.
        :return: "success" if validation passes, otherwise an error message.
        """
        if self.max_concurrency_level:
            if self.max_concurrency_level > concurrency.get("max_allowed_concurrency", 8):
                failure_msg = (
                    f"Maximum allowed concurrency is: {concurrency.get('max_allowed_concurrency', 8)} while user has requested {self.max_concurrency_level}."
                )
                return prepare_exception(self.__class__.__name__.lower(), self.name, inspect.currentframe().f_code.co_name, failure_msg)
            return "success"
        else:
            return "success"

    def wh_alert_subscriber_list_validate(self, email_threshold_count: dict) -> str:
        """
        Validates the warehouse's alert subscriber list against predefined rules for Minerva Snowflake Warehouses

        :param email_threshold_count: Number of distinct Email IDs mentioned by user under alert_subscriber_list
        :return: "success" if validation passes, otherwise an error message.
        """
        # Validating Presence of Values in Alert Subscriber List
        failure_msgs = []
        max_allowed = email_threshold_count.get("max_allowed_emails", 5)

        if not self.alert_subscribers_list:
            failure_msgs.append(
                "User hasn't mentioned email IDs in the alert subscriber list. "
                "It's a mandatory attribute to ensure resource monitor alerts get triggered in case of threshold breaches."
            )
            return prepare_exception(self.__class__.__name__.lower(), self.name, inspect.currentframe().f_code.co_name,
                                     "\n".join(failure_msgs))

        # Ensure all emails are uppercase
        if not str(self.alert_subscribers_list).isupper():
            failure_msgs.append(
                f"Email IDs provided are not in uppercase while Snowflake expects them to be. "
            )

        # Check threshold
        if len(self.alert_subscribers_list) > max_allowed:
            failure_msgs.append(
                f"Maximum allowed emails: {max_allowed}, but user has provided "
                f"{len(self.alert_subscribers_list)} emails."
            )

        if failure_msgs:
            failure_msgs.append(f"User Provided Email List for your reference : {self.alert_subscribers_list}")
            return prepare_exception(self.__class__.__name__.lower(), self.name, inspect.currentframe().f_code.co_name,
                                     "\n".join(failure_msgs))

        return "success"



@dataclass
class Database(SnowflakeObject):
    intake_id: str
    name: str
    snowflake_account_id: str
    description: str
    data_first_classification: str
    enterprise_or_func_name: str
    enterprise_or_func_subgrp_name: str
    data_leader: str

    database_type: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("database").get("database_type", "PERMANENT"))

    product_group_identifier: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("database").get("product_group_identifier", "NA"))


    def __str__(self):
        return self.name



@dataclass
class Schema(SnowflakeObject):
    intake_id: str
    name: str
    snowflake_account_id: str
    parent_db_name: str
    access_roles: list
    description: str
    data_first_classification: str
    enterprise_or_func_name: str
    enterprise_or_func_subgrp_name: str
    product_group_identifier: str
    subject_or_prod_name: str
    data_product_manager: str
    lead_engineer: str
    product_cost_id: str
    governance_and_access_lead: str

    port: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("schema").get("port", ""))
    data_retention_in_days: Optional[int] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("schema").get("data_retention_in_days", 1))
    schema_external_volume: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("schema").get("schema_external_volume", None))
    schema_catalog: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("schema").get("schema_catalog", "SNOWFLAKE"))


    def __str__(self):
        return self.name

    def sch_restrict_data_retention(self, retention_threshold_dict) -> str:
        if self.data_retention_in_days > retention_threshold_dict.get('db_retention_threshold'):
            failure_msg = f"Maximum allowed data retention threshold for schema as per Minerva for now is : {retention_threshold_dict.get('db_retention_threshold')}"
            return prepare_exception(str(self.__class__.__name__).lower(), self.name,
                                     inspect.currentframe().f_code.co_name, failure_msg)
        else:
            return "success"

    def sch_data_classification_validate(self, data_classifications) -> str:
        """
        Validates the data classification against the allowed classifications.

        :param data_classifications: Dictionary containing accepted data classifications.
        :return: "success" if validation passes, otherwise an error message.
        """
        if str(self.data_first_classification) not in data_classifications.get("accepted_data_classifications", []):
            failure_msg = (
                f"Allowed Data Classifications are: {data_classifications.get('accepted_data_classifications', [])} while user has requested {self.data_first_classification}."
            )
            return prepare_exception(self.__class__.__name__.lower(), self.name, inspect.currentframe().f_code.co_name, failure_msg)
        return "success"

@dataclass
class Persona(SnowflakeObject):
    intake_id: str
    name: str
    snowflake_account_id: str
    purpose: str
    role_owner_ds_id: str
    role_owner_email_id: str
    data_leader: str
    governance_and_access_lead: str
    enterprise_or_func_name: str
    enterprise_or_func_subgrp_name: str
    sub_function: str

    grants: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("persona").get("grants", []))
    access_roles_alias: Optional[list] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("persona").get("access_roles_alias", []))
    def __str__(self):
        return self.name


@dataclass
class OAuth(SnowflakeObject):
    intake_id: str
    snowflake_account_id: str
    name: str
    ps_account_email_id: str
    ps_account_owner: str
    data_product_manager: str
    lead_engineer: str
    governance_and_access_lead: str
    minerva_aad_group: list
    minerva_aad_group_owner: str
    azure_tenant_id: str
    oauth_resource_uri: str
    sub_uuid: str
    purpose: str
    consumption_stack: str
    einsight_uuid: str
    enterprise_or_func_name: str
    enterprise_or_func_subgrp_name: str

    def __str__(self):
        return self.name

    def oauth_proc_roles_only_check(self, validate_dict) -> str:
        """
        Validates that all roles in minerva_aad_group for OAuth requests are allowed proc personas only.
        Allowed values:
        - procdataengineer
        - procdataconsumer

        If any non-allowed role is found, return a validation-layer error.
        """
        obj_type = str(self.__class__.__name__).lower()

        # Read config from rule book param
        obj_cfg = validate_dict.get(obj_type, {}) if isinstance(validate_dict, dict) else {}

        key = obj_cfg.get("key", "minerva_aad_group")
        allowed_values = obj_cfg.get(
            "allowed_values",
            ["procdataengineer", "procdataconsumer"]
        )
        case_sensitive = obj_cfg.get("case_sensitive", False)
        error_message = obj_cfg.get(
            "error_message",
            "OAuth requests in Snowflake PROD must contain only procdataengineer or procdataconsumer roles in minerva_aad_group. "
            "OAuth users are intended strictly for programmatic access."
        )

        aad_groups = getattr(self, key, None)

        # If no aad groups provided, let other validations handle mandatory checks
        if not aad_groups:
            return "success"

        # Normalize to list
        if not isinstance(aad_groups, list):
            aad_groups = [aad_groups]

        # Normalize allowed values
        if case_sensitive:
            allowed_tokens = [str(val).strip() for val in allowed_values]
            invalid_roles = [
                role for role in aad_groups
                if not any(token in str(role).strip() for token in allowed_tokens)
            ]
        else:
            allowed_tokens = [str(val).strip().lower() for val in allowed_values]
            invalid_roles = [
                role for role in aad_groups
                if not any(token in str(role).strip().lower() for token in allowed_tokens)
            ]

        if invalid_roles:
            failure_msg = (
                f"{error_message} Invalid roles: {', '.join(invalid_roles)}. "
                f"Allowed proc personas: {', '.join(allowed_values)}"
            )
            return prepare_exception(
                obj_type,
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )

        return "success"

    def oauth_sub_uuid_uniqueness_check(self, validate_dict) -> str:
        """
        Ensures the sub_uuid of this OAuth request is not used by any other OAuth metadata
        file in the branch being validated (i.e. sub_uuid must be unique for the environment).

        :param validate_dict: Dictionary containing (under the 'oauth' key):
            - key: Attribute holding the sub uuid (default 'sub_uuid').
            - oauth_dir: OAuth metadata folder relative to CODEBUILD_SRC_DIR (default 'snowflake/oauth').
        :return: "success" if sub_uuid is unique, otherwise an error message.
        """
        import glob
        import os

        obj_type = str(self.__class__.__name__).lower()
        func_name = inspect.currentframe().f_code.co_name
        obj_cfg = validate_dict.get(obj_type, {}) if isinstance(validate_dict, dict) else {}
        key = obj_cfg.get("key", "sub_uuid")
        oauth_rel_dir = obj_cfg.get("oauth_dir", "snowflake/oauth")

        current_sub_uuid = str(getattr(self, key, "") or "").strip()
        # Missing values are reported by the mandatory key checks.
        if not current_sub_uuid:
            return "success"

        oauth_dir = os.path.join(os.getenv("CODEBUILD_SRC_DIR", ""), oauth_rel_dir)
        if not os.path.isdir(oauth_dir):
            return prepare_exception(
                obj_type,
                self.name,
                func_name,
                f"Unable to locate OAuth metadata directory '{oauth_dir}' to verify {key} uniqueness."
            )

        own_file_name = f"{str(self.name).strip()}.json".lower()
        duplicate_files = []
        for file_path in sorted(glob.glob(os.path.join(oauth_dir, "*.json"))):
            file_name = os.path.basename(file_path)
            if file_name.lower() == own_file_name:
                continue
            try:
                with open(file_path, "r", encoding="utf-8") as file:
                    other_sub_uuid = str(json.load(file).get(key, "") or "").strip()
            except Exception as ex:
                logger.warning(
                    "[oauth_sub_uuid_uniqueness_check] Skipping unreadable OAuth file '%s': %s",
                    file_path, ex
                )
                continue
            if other_sub_uuid.lower() == current_sub_uuid.lower():
                duplicate_files.append(file_name)

        if duplicate_files:
            failure_msg = (
                f"Validation Error: {key} '{current_sub_uuid}' must be unique, but it is already used in "
                f"the following OAuth file(s): {duplicate_files}."
            )
            return prepare_exception(obj_type, self.name, func_name, failure_msg)

        return "success"

@dataclass
class Storage_Integration(SnowflakeObject):
    intake_id: str
    snowflake_account_id: str
    name: str
    access_roles: list
    enterprise_or_func_name: str
    enterprise_or_func_subgrp_name: str
    product_group_identifier: str      
    data_leader: str
    data_first_classification: str
    storage_role_arn: str
    allowed_storage_locations: list
    description: str

    blocked_storage_locations: Optional[list] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("storage_integration").get("blocked_storage_locations", []))

    stage_type: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("storage_integration").get("stage_type", "external_stage"))

    storage_provider: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("storage_integration").get("storage_provider", "s3"))

    storage_integration_enabled: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("storage_integration").get("storage_integration_enabled", True))

    def __str__(self):
        return self.name

    def si_check_role_arn(self, validate_dict) -> str:
        # arn:aws:iam::633391536196:role/miw-sbx-codepipeline-role
        for key in validate_dict['params']:
            if key not in self.storage_role_arn:
                failure_msg = f"The role ARN should be defined as per Minerva for now is : {validate_dict.get('sample_arn')}"
                return prepare_exception(str(self.__class__.__name__).lower(), self.name,
                                        inspect.currentframe().f_code.co_name, failure_msg)
            else:
                return "success"

@dataclass
class External_Volume(SnowflakeObject):
    intake_id: str
    snowflake_account_id: str
    name: str
    description: str
    access_roles: list
    storage_region : str
    storage_role_arn : str
    storage_base_url : str
    enterprise_or_func_name: str
    enterprise_or_func_subgrp_name: str
    product_group_identifier: str
    data_leader: str
    data_first_classification: str
    storage_access_point_arn: str
    storage_external_id: str

    storage_provider: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("external_volume").get("storage_provider", "s3"))

    allow_writes: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("external_volume").get("allow_writes", True))

    encryption_type: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("external_volume").get("encryption_type", "AWS_SSE_S3"))

    encryption_key_id: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("external_volume").get("encryption_key_id", ""))

    private_link_enabled: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("external_volume").get("private_link_enabled", "False"))

    def __str__(self):
        return self.name

    def ev_check_role_arn(self, validate_dict) -> str:
        # arn:aws:iam::633391536196:role/miw-sbx-codepipeline-role
        for key in validate_dict['params']:
            if key not in self.storage_role_arn:
                failure_msg = f"The role ARN should be defined as per Minerva for now is : {validate_dict.get('sample_arn')}"
                return prepare_exception(str(self.__class__.__name__).lower(), self.name,
                                        inspect.currentframe().f_code.co_name, failure_msg)
            else:
                return "success"

@dataclass
class Catalog_Integration(SnowflakeObject):
    intake_id : str
    snowflake_account_id :str
    name :str
    description : str
    access_roles : list
    catalog_source :str
    catalog_table_format :str
    rest_catalog_uri :str
    rest_catalog_name :str
    rest_catalog_api_type :str
    catalog_namespace : list
    rest_auth_type :str
    rest_auth_iam_role :str
    rest_auth_sign_region :str
    iceberg_enabled :str
    enterprise_or_func_name :str
    enterprise_or_func_subgrp_name :str
    product_group_identifier :str
    data_leader :str
    data_first_classification :str
    enable_vended_credentials: str
   
    catalog_refresh_interval_secs: Optional[str] = field(
        default_factory=lambda: SNF_OBJ_DEFAULT_MAP.get("catalog_refresh_interval_secs").get("catalog_refresh_interval_secs", 3600))
    
    def __str__(self):
        return self.name

    def ci_check_role_arn(self, validate_dict) -> str:
        # arn:aws:iam::633391536196:role/miw-sbx-codepipeline-role
        for key in validate_dict['params']:
            if key not in self.rest_auth_iam_role:
                failure_msg = f" The role ARN should be defined as per Minerva for now is : {validate_dict.get('sample_arn')}"
                return prepare_exception(str(self.__class__.__name__).lower(), self.name,
                                        inspect.currentframe().f_code.co_name, failure_msg)
            else:
                return "success"


    def ci_check_catalog_refresh_interval_secs(self, validate_dict) -> str:
        """
        Validates that catalog_refresh_interval_secs is not less than the allowed minimum.
        Values greater than or equal to 3600 seconds should pass.
        """
        min_allowed = validate_dict.get("min_allowed_refresh_interval_secs", 3600)
        # error_message = validate_dict.get(
        #     "error_message",
        #     "Validation failed: Entered value for catalog_refresh_interval_secs is below the minimum allowed threshold."
        # )

        try:
            entered_value = int(self.catalog_refresh_interval_secs)
        except (TypeError, ValueError):
            failure_msg = (
                f"Entered value for catalog_refresh_interval_secs is "
                f"'{self.catalog_refresh_interval_secs}', which is not a valid integer."
            )
            return prepare_exception(
                str(self.__class__.__name__).lower(),
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )

        if entered_value < min_allowed:
            failure_msg = (
                f"Validation Error: The entered value for catalog_refresh_interval_secs is {entered_value} seconds. "
                f"The minimum allowed value is 1 hour (3600 seconds). "
                f"Please enter a value greater than or equal to 3600 seconds. "
                f"If you need refresh interval less than 1 hour, please reach out to the MIW team for approval."
            )
            return prepare_exception(
                str(self.__class__.__name__).lower(),
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )

        return "success"
    
    def ci_check_catalog_namespace_db_naming(self, validate_dict) -> str:
        """
        Validates database naming within catalog_namespace.
        The AWS account referenced by rest_catalog_name decides which token set applies:
        CMP accounts require one of cmp_required_db_name_tokens (e.g. 'curated'/'serving'/
        'internal') in every database name, lakehouse accounts require one of
        lh_required_db_name_tokens (e.g. 'raw'/'raw_serving'/'internal'). A
        rest_catalog_name that belongs to neither list fails the rule.
        :param validate_dict: Dictionary containing:
            - cmp_rest_catalog_names / cmp_required_db_name_tokens
            - lh_rest_catalog_names / lh_required_db_name_tokens
        :return: "success" if validation passes, otherwise an error message.
        """
        obj_type = str(self.__class__.__name__).lower()

        cmp_catalog_names = [
            str(name).strip() for name in validate_dict.get("cmp_rest_catalog_names", [])
        ]
        cmp_required_tokens = validate_dict.get("cmp_required_db_name_tokens", [])

        lh_catalog_names = [
            str(name).strip() for name in validate_dict.get("lh_rest_catalog_names", [])
        ]
        lh_required_tokens = validate_dict.get("lh_required_db_name_tokens", [])

        required_tokens = []
        if str(self.rest_catalog_name).strip() in cmp_catalog_names:
            required_tokens = cmp_required_tokens
        elif str(self.rest_catalog_name).strip() in lh_catalog_names:
            required_tokens = lh_required_tokens
        else:
            # If rest_catalog_name is not in either list, Validation should fail with invalid catalog name error.
            failure_msg = (
                f"Validation Error: The rest_catalog_name '{self.rest_catalog_name}' is not recognized as a valid catalog name. "
                f"Please ensure that the rest_catalog_name is one of the following: {cmp_catalog_names + lh_catalog_names}."
            )
            return prepare_exception(
                obj_type,
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )

        # catalog_namespace is allowed to be a single string in the metadata JSON.
        catalog_namespace = self.catalog_namespace or []
        if isinstance(catalog_namespace, str):
            catalog_namespace = [catalog_namespace]

        db_names = [str(db).strip() for db in catalog_namespace if str(db).strip()]
        if not db_names:
            failure_msg = (
                "catalog_namespace is empty. At least one database name must be provided so that "
                f"it can be validated against the required token(s) {required_tokens}."
            )
            return prepare_exception(
                obj_type,
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )

        non_compliant_dbs = [
            db_name
            for db_name in db_names
            if not any(str(token).lower() in db_name.lower() for token in required_tokens)
        ]

        if non_compliant_dbs:
            failure_msg = (
                f"Validation Error: Since rest_catalog_name is '{self.rest_catalog_name}'  "
                f"every database name in catalog_namespace must "
                f"contain one of {required_tokens} in its name. "
                f"Non-compliant database name(s): {non_compliant_dbs}."
            )
            return prepare_exception(
                str(self.__class__.__name__).lower(),
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )

        return "success"

    def ci_check_rest_catalog_name_in_iam_role(self, validate_dict) -> str:
        """
        Validates that the AWS account id embedded in rest_auth_iam_role matches rest_catalog_name.
        rest_auth_iam_role is expected in the format:
            arn:aws:iam::<account_id>:role/<role_name>
        where <account_id> must equal rest_catalog_name.
        :param validate_dict: Dictionary containing:
            - sample_arn: Sample ARN used in the failure message for guidance.
        :return: "success" if validation passes, otherwise an error message.
        """
        sample_arn = validate_dict.get("sample_arn", "arn:aws:iam::<rest_catalog_name>:role/<role_name>")
        rest_auth_iam_role = str(self.rest_auth_iam_role).strip()
        rest_catalog_name = str(self.rest_catalog_name).strip()

        # ARN format: arn:aws:iam::<account_id>:role/<role_name>
        arn_parts = rest_auth_iam_role.split(":")
        arn_account_id = arn_parts[4].strip() if len(arn_parts) >= 6 else None

        if not arn_account_id or not arn_account_id.isdigit():
            failure_msg = (
                f"Unable to extract the AWS account id from rest_auth_iam_role '{rest_auth_iam_role}'. "
                f"Expected format: '{sample_arn}'."
            )
            return prepare_exception(
                str(self.__class__.__name__).lower(),
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )

        if arn_account_id != rest_catalog_name:
            failure_msg = (
                f"Validation Error: The AWS account id '{arn_account_id}' present in rest_auth_iam_role "
                f"'{rest_auth_iam_role}' must match with rest_catalog_name '{rest_catalog_name}'. "
                f"Expected format: '{sample_arn}'."
            )
            return prepare_exception(
                str(self.__class__.__name__).lower(),
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )

        return "success"

    def ci_check_db_not_in_existing_catalog_integrations(self, validate_dict) -> str:
        """
        Ensures that no database listed in catalog_namespace already has a catalog
        integration created in Snowflake.
        A catalog integration is created with a '_CI' suffix appended to the database
        name (e.g. database 'MY_DB' -> catalog integration 'MY_DB_CI'). This rule fetches
        the already created catalog integrations via 'SHOW CATALOG INTEGRATIONS', strips
        the '_CI' suffix from each, and compares (in upper case) against every database
        name in catalog_namespace.
        Updating an existing catalog integration (for example changing
        catalog_refresh_interval_secs) must NOT fail this rule. When the catalog
        integration file is MODIFIED in the PR, the duplicate check is applied only to the
        databases that were newly ADDED to catalog_namespace in this PR (determined by
        diffing against the base branch version of the file). If no databases were added
        (e.g. only the refresh interval changed), the rule passes. Brand-new catalog
        integrations arrive as ADDED files, in which case every database is validated.
        :param validate_dict: Dictionary containing:
            - ci_suffix: Suffix appended to the db name when the catalog integration is created (default '_CI').
            - error_message: Optional custom error message.
        :return: "success" if no conflict is found, otherwise an error message.
        """
        obj_type = str(self.__class__.__name__).lower()
        ci_suffix = str(validate_dict.get("ci_suffix", "_CI")).upper()
        # error_message = validate_dict.get(
        #     "error_message",
        #     "One or more databases in catalog_namespace already have a catalog integration created in Snowflake."
        # )

        # Lazy import to avoid circular import at module load time.
        from constants import FILE_DIFF_STATUS_DICT

        current_dbs = [
            str(db).strip() for db in (self.catalog_namespace or []) if str(db).strip()
        ]

        # Identify whether this catalog integration's file was MODIFIED (an update) in the PR.
        modified_files = FILE_DIFF_STATUS_DICT.get("modified") or ""
        modified_tokens = [
            token.strip()
            for token in str(modified_files).replace("\n", " ").split()
            if token.strip()
        ]
        expected_file_name = f"{str(self.name).strip()}.json".lower()
        matched_rel_path = next(
            (token for token in modified_tokens if token.lower().split("/")[-1] == expected_file_name),
            None
        )

        if matched_rel_path:
            # This is an update to an existing catalog integration. Only the databases newly
            # added to catalog_namespace in this PR should be validated. Diff the current
            # namespace against the base branch version of the file to find the added ones.
            base_dbs = self._fetch_base_catalog_namespace(matched_rel_path)
            if isinstance(base_dbs, str):
                # An error message was returned (base version could not be determined).
                return base_dbs

            base_dbs_upper = {str(db).strip().upper() for db in base_dbs}
            dbs_to_check = [db for db in current_dbs if db.upper() not in base_dbs_upper]

            # No databases were added in this PR (e.g. only refresh interval changed) -> pass.
            if not dbs_to_check:
                return "success"
        else:
            # Brand-new catalog integration (ADDED file) or non-diff run: validate all databases.
            dbs_to_check = current_dbs

        # SHOW CATALOG INTEGRATIONS is expensive and this rule runs once per catalog
        # integration file in the PR, so the result is cached in S3 for this PR run.
        existing_ci_dbs = self._get_existing_catalog_integration_dbs(validate_dict, ci_suffix)
        if isinstance(existing_ci_dbs, str):
            return existing_ci_dbs

        conflicting_dbs = [
            db_name
            for db_name in dbs_to_check
            if str(db_name).strip().upper() in existing_ci_dbs
        ]

        if conflicting_dbs:
            failure_msg = (
                f"Validation Error: The following database(s) from catalog_namespace already have an "
                f"existing catalog integration in Snowflake: "
                f"{conflicting_dbs}."
            )
            return prepare_exception(
                obj_type,
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )

        return "success"

    def _get_existing_catalog_integration_dbs(self, validate_dict, ci_suffix):
        """
        Returns the set of database names (without the ci_suffix) that already have a
        catalog integration in Snowflake.
        'SHOW CATALOG INTEGRATIONS' is run once per PR by validation_driver.py's
        cache_existing_catalog_integrations, which writes the result to S3 (keyed by
        PR_NUMBER). This just reads that cached file so the query isn't repeated for
        every catalog integration file changed/updated in the PR. If the cache is
        missing (e.g. a standalone/manual run), it falls back to querying Snowflake directly.
        :param validate_dict: Dictionary optionally containing 'cache_s3_key' to override
            the default S3 cache key.
        :param ci_suffix: Suffix to strip from each catalog integration name (e.g. '_CI').
        :return: A set of existing database names on success, or a prepare_exception error string.
        """
        import os

        # Lazy imports to avoid circular import at module load time.
        from constants import SNF_AC_REGION, SNF_CONTEXT_DETAILS
        from helpers.utils import generate_s3_client, read_text_file_from_s3

        obj_type = str(self.__class__.__name__).lower()
        pr_id = str(os.getenv("PR_NUMBER", "manual")).strip()
        raw_bucket = str(os.getenv("S3_BUCKET_NAME", "")).strip()
        bucket_name = raw_bucket.split("//")[1] if "//" in raw_bucket else raw_bucket
        cache_key = str(validate_dict.get(
            "cache_s3_key",
            f"validation/{pr_id}/catalog_integrations/existing_catalog_integrations.json"
        ))

        s3_client = generate_s3_client(region_name=SNF_AC_REGION)

        if bucket_name:
            cached_content = read_text_file_from_s3(s3_client, bucket_name, cache_key)
            if cached_content:
                try:
                    return set(json.loads(cached_content))
                except Exception as ex:
                    logger.warning(
                        "[_get_existing_catalog_integration_dbs] Failed to parse cached existing "
                        "catalog integrations from S3 (key: %s), falling back to Snowflake. Reason: %s",
                        cache_key, ex
                    )

        # Cache missing or unreadable: fall back to querying Snowflake directly.
        from explicit_grants import connect_to_Snowflake

        snf_conn = None
        snf_cur = None
        try:
            snf_conn, snf_cur = connect_to_Snowflake(
                snf_role=SNF_CONTEXT_DETAILS.get("account_admin_role")
            )
            snf_cur.execute("SHOW CATALOG INTEGRATIONS")

            # Locate the 'name' column robustly using the cursor metadata.
            columns = [str(col[0]).lower() for col in snf_cur.description]
            name_idx = columns.index("name") if "name" in columns else 0

            existing_ci_dbs = set()
            for row in snf_cur.fetchall():
                ci_name = str(row[name_idx]).strip().upper()
                if ci_name.endswith(ci_suffix):
                    ci_name = ci_name[: -len(ci_suffix)]
                existing_ci_dbs.add(ci_name)
        except Exception as ex:
            failure_msg = (
                f" Unable to verify existing catalog integrations in Snowflake due to: {ex}"
            )
            return prepare_exception(
                obj_type,
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )
        finally:
            if snf_cur is not None:
                snf_cur.close()
            if snf_conn is not None:
                snf_conn.close()

        return existing_ci_dbs

    def _get_newly_added_dbs(self):
        """
        Returns the list of database names newly added to catalog_namespace in this PR.
        For a MODIFIED catalog integration file, only databases added on top of the base
        branch version are returned. For a brand-new (ADDED) file, every database is
        returned. Returns a prepare_exception error string if the base branch version of a
        modified file could not be determined.
        """
        from constants import FILE_DIFF_STATUS_DICT

        current_dbs = [
            str(db).strip() for db in (self.catalog_namespace or []) if str(db).strip()
        ]

        # Identify whether this catalog integration's file was MODIFIED (an update) in the PR.
        modified_files = FILE_DIFF_STATUS_DICT.get("modified") or ""
        modified_tokens = [
            token.strip()
            for token in str(modified_files).replace("\n", " ").split()
            if token.strip()
        ]
        expected_file_name = f"{str(self.name).strip()}.json".lower()
        matched_rel_path = next(
            (token for token in modified_tokens if token.lower().split("/")[-1] == expected_file_name),
            None
        )

        if not matched_rel_path:
            # Brand-new catalog integration (ADDED file) or non-diff run: all databases are new.
            return current_dbs

        # Update to an existing catalog integration: diff against the base branch version.
        base_dbs = self._fetch_base_catalog_namespace(matched_rel_path)
        if isinstance(base_dbs, str):
            # An error message was returned (base version could not be determined).
            return base_dbs

        base_dbs_upper = {str(db).strip().upper() for db in base_dbs}
        return [db for db in current_dbs if db.upper() not in base_dbs_upper]

    def _assume_cross_account_credentials(self, validate_dict, aws_account_id, region):
        """
        Assumes the cross-account deploy role in the given AWS account (using CodeBuild's
        cross-account access) and returns the temporary credentials dict.
        :param validate_dict: Rule params, optionally overriding 'assume_role_arn_template'
            (with '{account_id}' and '{env}' placeholders) and 'role_session_name'.
        :param aws_account_id: Account to assume the deploy role into.
        :param region: Region for the STS client.
        :return: The STS Credentials dict on success, or a prepare_exception error string.
        """
        import os
        import boto3
        from botocore.exceptions import ClientError, BotoCoreError

        assume_role_arn_template = str(validate_dict.get(
            "assume_role_arn_template",
            "arn:aws:iam::{account_id}:role/minerva-{env}-corp-miw-cross-acc-deploy-role"
        ))
        role_session_name = str(validate_dict.get("role_session_name", "miw-ci-iam-role-validation"))
        env = str(os.getenv("CODEBUILD_ENV", "")).strip().lower()
        assume_role_arn = assume_role_arn_template.format(account_id=aws_account_id, env=env)

        try:
            sts_client = boto3.client("sts", region_name=region)
            assumed_role = sts_client.assume_role(
                RoleArn=assume_role_arn,
                RoleSessionName=role_session_name
            )
            return assumed_role["Credentials"]
        except (ClientError, BotoCoreError, KeyError) as ex:
            failure_msg = (
                f" Unable to assume role '{assume_role_arn}' in AWS account "
                f"'{aws_account_id}'. Reason: {ex}"
            )
            return prepare_exception(
                str(self.__class__.__name__).lower(),
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )

    def ci_check_catalog_namespace_exists_in_glue(self, validate_dict) -> str:
        """
        Ensures every database newly added to catalog_namespace already exists as a Glue
        database in AWS Lake Formation, in the AWS account referenced by rest_catalog_name.
        Catalog namespaces are AWS Glue databases. This rule assumes the cross-account
        deploy role in the rest_catalog_name account (using CodeBuild's cross-account
        access) and queries that account's Glue Data Catalog (in rest_auth_sign_region)
        for each newly added database. Only the databases added in this PR are checked;
        updates that add no new database pass.
        :param validate_dict: Dictionary containing:
            - assume_role_arn_template: ARN template of the cross-account role to assume,
              with '{account_id}' and '{env}' placeholders.
            - role_session_name: STS session name used when assuming the cross-account role.
            - error_message: Optional custom error message.
        :return: "success" if every newly added database exists, otherwise an error message.
        """
        obj_type = str(self.__class__.__name__).lower()
        # error_message = validate_dict.get(
        #     "error_message",
        #     "One or more newly added databases in catalog_namespace do not exist as Glue "
        #     "databases in AWS Lake Formation for the referenced AWS account."
        # )

        dbs_to_check = self._get_newly_added_dbs()
        if isinstance(dbs_to_check, str):
            # An error message was returned (base version could not be determined).
            return dbs_to_check

        # No databases were added in this PR -> nothing to validate.
        if not dbs_to_check:
            return "success"

        # Lazy imports to avoid circular import at module load time.
        import boto3
        from botocore.exceptions import ClientError, BotoCoreError

        aws_account_id = str(self.rest_catalog_name).strip()
        region = str(self.rest_auth_sign_region).strip() or "us-east-1"

        # Assume the cross-account deploy role in the rest_catalog_name account to query Glue there.
        creds = self._assume_cross_account_credentials(validate_dict, aws_account_id, region)
        if isinstance(creds, str):
            return creds

        glue_client = boto3.client(
            "glue",
            region_name=region,
            aws_access_key_id=creds["AccessKeyId"],
            aws_secret_access_key=creds["SecretAccessKey"],
            aws_session_token=creds["SessionToken"],
        )

        missing_dbs = []
        for db_name in dbs_to_check:
            try:
                glue_client.get_database(CatalogId=aws_account_id, Name=str(db_name).strip())
            except ClientError as ce:
                if ce.response.get("Error", {}).get("Code") == "EntityNotFoundException":
                    missing_dbs.append(db_name)
                else:
                    failure_msg = (
                        f" Unable to verify Glue database '{db_name}' in AWS account "
                        f"'{aws_account_id}' (region '{region}'). Reason: {ce}"
                    )
                    return prepare_exception(
                        obj_type,
                        self.name,
                        inspect.currentframe().f_code.co_name,
                        failure_msg
                    )
            except BotoCoreError as be:
                failure_msg = (
                    f" Unable to verify Glue database '{db_name}' in AWS account "
                    f"'{aws_account_id}' (region '{region}'). Reason: {be}"
                )
                return prepare_exception(
                    obj_type,
                    self.name,
                    inspect.currentframe().f_code.co_name,
                    failure_msg
                )

        if missing_dbs:
            failure_msg = (
                f"Validation Error: The following database(s) from catalog_namespace were not "
                f"found as Glue databases in AWS account '{aws_account_id}' (region '{region}'): "
                f"{missing_dbs}."
            )
            return prepare_exception(
                obj_type,
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )

        return "success"

    def ci_check_rest_auth_iam_role_exists(self, validate_dict) -> str:
        """
        Ensures the IAM role referenced by rest_auth_iam_role exists in the
        rest_catalog_name AWS account.
        IAM get_role always resolves against the calling account, and CodeBuild runs in a
        different account than rest_catalog_name. This rule therefore assumes the
        cross-account deploy role in the rest_catalog_name account (using CodeBuild's
        cross-account access) and looks the role up with those temporary credentials.
        rest_auth_iam_role is expected in the format
        'arn:aws:iam::<rest_catalog_name>:role/<role_name>'.
        :param validate_dict: Dictionary containing:
            - assume_role_arn_template: ARN template of the cross-account role to assume,
              with '{account_id}' and '{env}' placeholders.
            - role_session_name: STS session name used when assuming the cross-account role.
            - error_message: Optional custom error message.
        :return: "success" if the IAM role exists, otherwise an error message.
        """
        obj_type = str(self.__class__.__name__).lower()
        # error_message = validate_dict.get(
        #     "error_message",
        #     "The IAM role referenced by rest_auth_iam_role does not exist in the referenced AWS account."
        # )

        rest_auth_iam_role = str(self.rest_auth_iam_role).strip()
        aws_account_id = str(self.rest_catalog_name).strip()
        region = str(self.rest_auth_sign_region).strip() or "us-east-1"

        # Extract the IAM role name (last path component) from the ARN.
        role_name = (
            rest_auth_iam_role.split("role/")[-1].split("/")[-1]
            if "role/" in rest_auth_iam_role else ""
        )
        if not role_name:
            failure_msg = (
                f" Unable to extract the IAM role name from rest_auth_iam_role "
                f"'{rest_auth_iam_role}'. Expected format: "
                f"'arn:aws:iam::<rest_catalog_name>:role/<role_name>'."
            )
            return prepare_exception(
                obj_type,
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )

        # Lazy imports to avoid circular import at module load time.
        import boto3
        from botocore.exceptions import ClientError, BotoCoreError

        # IAM get_role only resolves roles in the calling account, so assume the
        # cross-account deploy role in the rest_catalog_name account to look the role up there.
        creds = self._assume_cross_account_credentials(validate_dict, aws_account_id, region)
        if isinstance(creds, str):
            return creds

        iam_client = boto3.client(
            "iam",
            region_name=region,
            aws_access_key_id=creds["AccessKeyId"],
            aws_secret_access_key=creds["SecretAccessKey"],
            aws_session_token=creds["SessionToken"],
        )

        try:
            iam_client.get_role(RoleName=role_name)
        except ClientError as ce:
            if ce.response.get("Error", {}).get("Code") == "NoSuchEntity":
                failure_msg = (
                    f"Validation Error: IAM role '{role_name}' was not found in AWS account '{aws_account_id}'. "
                )
                return prepare_exception(
                    obj_type,
                    self.name,
                    inspect.currentframe().f_code.co_name,
                    failure_msg
                )
            failure_msg = (
                f" Unable to verify IAM role '{role_name}' in AWS account "
                f"'{aws_account_id}'. Reason: {ce}"
            )
            return prepare_exception(
                obj_type,
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )
        except BotoCoreError as be:
            failure_msg = (
                f" Unable to verify IAM role '{role_name}' in AWS account "
                f"'{aws_account_id}'. Reason: {be}"
            )
            return prepare_exception(
                obj_type,
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )

        return "success"

    def _fetch_base_catalog_namespace(self, matched_rel_path):
        """
        Retrieves catalog_namespace from the base branch version of this catalog
        integration's metadata file (i.e. the state before this PR).
        Runs 'git show origin/<base_ref>:snowflake/<matched_rel_path>' against the source
        repository to read the previous version of the file and extract its
        catalog_namespace list.
        :param matched_rel_path: The PR-diff relative path (after 'snowflake/') of the file.
        :return: A list of database names from the base version's catalog_namespace, or a
                 prepare_exception error string if the base version could not be determined.
        """
        import os
        import subprocess

        obj_type = str(self.__class__.__name__).lower()
        repo_dir = os.getenv("CODEBUILD_SRC_DIR")
        base_ref = str(os.getenv("CODEBUILD_WEBHOOK_BASE_REF", "")).strip()
        git_file_path = f"snowflake/{matched_rel_path}"

        candidate_refs = [f"origin/{base_ref}", base_ref] if base_ref else []

        base_content = None
        last_error = "Base branch reference (CODEBUILD_WEBHOOK_BASE_REF) is not set."
        for ref in candidate_refs:
            try:
                completed = subprocess.run(
                    ["git", "show", f"{ref}:{git_file_path}"],
                    cwd=repo_dir,
                    capture_output=True,
                    text=True
                )
            except Exception as ex:
                last_error = str(ex)
                continue

            if completed.returncode == 0:
                base_content = completed.stdout
                break
            last_error = completed.stderr.strip()

        if base_content is None:
            failure_msg = (
                " Unable to determine the base branch version of catalog_namespace for this "
                f"catalog integration (file: {git_file_path}, base_ref: '{base_ref}'). "
                f"Reason: {last_error}"
            )
            return prepare_exception(
                obj_type,
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )

        try:
            base_json = json.loads(base_content)
        except Exception as ex:
            failure_msg = (
                f" Unable to parse the base branch version of file {git_file_path} as JSON "
                f"while determining newly added databases. Reason: {ex}"
            )
            return prepare_exception(
                obj_type,
                self.name,
                inspect.currentframe().f_code.co_name,
                failure_msg
            )

        base_namespace = base_json.get("catalog_namespace", [])
        if isinstance(base_namespace, str):
            base_namespace = [base_namespace]

        return [str(db).strip() for db in (base_namespace or []) if str(db).strip()]
