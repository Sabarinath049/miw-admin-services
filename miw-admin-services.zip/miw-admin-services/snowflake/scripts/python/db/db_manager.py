import json
from urllib.parse import quote_plus
from datetime import datetime, timezone

from sqlalchemy import create_engine, Table, MetaData, select, update, inspect, and_
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.exc import SQLAlchemyError

from constants import SNF_CRED_SECRET, SNF_AC_REGION, MPL_TABLE_NAME, SNF_CONTEXT_DETAILS, SNF_UNAME_PWD_SECRET,METADATA_MATCH_KEYS
from helpers.config_log import logger
from helpers.utils import get_secret, generate_oauth_token, exit_process, reset_key_based_on_lookup

'''
def create_sqlalchmy_engine():
    """
    Creates a SQLAlchemy engine for connecting to a Snowflake database using oauth authentication.

    :return: A SQLAlchemy engine object configured for Snowflake.
    :raises: Terminates the process with an error log if engine creation fails.
    """
    try:
        # Retrieve secrets from the AWS Secrets Manager
        secret = get_secret(SNF_CRED_SECRET, SNF_AC_REGION)
        client_id = secret["client_id"]
        client_secret = secret["client_secret"]
        scope = secret["scope"]
        account = secret["account"]
        user = secret["user"]

        # Generate an oauth token
        oauth_token = generate_oauth_token(client_id, client_secret, scope)

        # Retrieve Snowflake connection context details
        db_name = SNF_CONTEXT_DETAILS.get('database', None)
        schema_name = SNF_CONTEXT_DETAILS.get('schema', None)
        wh_name = SNF_CONTEXT_DETAILS.get('warehouse', None)

        # Create the SQLAlchemy engine
        eng = create_engine(
            f"snowflake://{user}@{account}/{db_name}/{schema_name}?warehouse={wh_name}&authenticator=oauth&token={oauth_token}"
        )
        logger.debug("SQLAlchemy Engine creation was successful...!")
        return eng
    except Exception as ex:
        # Log the exception and terminate the process
        exit_process('exception', 'Exception encountered while SQLAlchemy engine creation', ex)
        exit_process('exception', 'Exiting code with exit code -1.....!', None, -1)
'''

def create_sqlalchmy_engine():
    """
    Creates a SQLAlchemy engine for connecting to a Snowflake database using oauth authentication.

    :return: A SQLAlchemy engine object configured for Snowflake.
    :raises: Terminates the process with an error log if engine creation fails.
    """
    try:
        # Retrieve secrets from the AWS Secrets Manager
        secret = get_secret(SNF_CRED_SECRET, SNF_AC_REGION)
        client_id = secret["client_id"]
        client_secret = secret["client_secret"]
        scope = secret["scope"]
        account = secret["account"]
        user = secret["user"]

        # Generate an oauth token
        oauth_token = generate_oauth_token(client_id, client_secret, scope)

        # Retrieve Snowflake connection context details
        db_name = SNF_CONTEXT_DETAILS.get('database', None)
        schema_name = SNF_CONTEXT_DETAILS.get('schema', None)
        wh_name = SNF_CONTEXT_DETAILS.get('warehouse', None)
        role_name = SNF_CONTEXT_DETAILS.get('role', None)

        # Create the SQLAlchemy engine
        eng = create_engine(
            f"snowflake://{user}@{account}/{db_name}/{schema_name}?warehouse={wh_name}&authenticator=oauth&token={oauth_token}&role={role_name}"
        )
        logger.debug("SQLAlchemy Engine creation was successful...!")
        return eng
    except Exception as ex:
        # Log the exception and terminate the process
        exit_process('exception', 'Exception encountered while SQLAlchemy engine creation', ex)
        exit_process('exception', 'Exiting code with exit code -1.....!', None, -1)


def retrieve_snf_table(engine, table_name):
    """
    Retrieves the Snowflake table object using the provided SQLAlchemy engine.

    :param engine: SQLAlchemy engine connected to the Snowflake database.
    :param table_name: Name of the table to be retrieved.
    :return: SQLAlchemy Table object for the specified table.
    :raises: Terminates the process with an error log if table retrieval fails.
    """
    try:
        # Inspect the database engine for the table's column metadata
        inspector = inspect(engine)
        logger.debug(f"table name: {table_name}")
        tbl_cols = inspector.get_columns(table_name)
        logger.debug("Columns extracted from table are:")
        logger.debug([col['name'] for col in tbl_cols])

        # Create and load the table object
        metadata = MetaData()
        table_obj = Table(table_name, metadata, autoload_with=engine)
        logger.debug(f"Table '{table_name}' object instantiated successfully.")
        return table_obj
    except Exception as ex:
        # Log the exception and terminate the process
        exit_process('exception', f'Exception encountered while creating the Snowflake table object : {table_name} =>', ex)
        exit_process('exception', 'Exiting code with exit code -1.', None, -1)


def create_mpl_record(snf_eng, provisioning_log, pr_id, pr_status, source_branch):
    """
    Creates a new record in the provisioning log table.

    :param snf_eng: SQLAlchemy engine connected to the Snowflake database.
    :param provisioning_log: SQLAlchemy Table object representing the provisioning log table.
    :param pr_id: Pull request identifier.
    :param pr_status: Status of the pull request.
    :param source_branch: Source branch or fork of the pull request.
    :return: None
    """
    current_time = datetime.now(timezone.utc)
    try:
        # Prepare the insert statement
        insert_stmt = insert(provisioning_log).values(
            pr_id=pr_id,
            pr_status=pr_status,
            source_branch_or_fork=source_branch,
            objects_provisioned_list=None,
            created_at=current_time,
            updated_at=current_time,
            created_timestamp=current_time,
            updated_timestamp=current_time
        )

        # Execute the insertion in a transaction
        with snf_eng.begin() as conn:
            insert_result = conn.execute(insert_stmt)
            conn.commit()

        logger.debug(f"The resultant object from insertion is: {insert_result}")
        logger.info(f"Record successfully inserted into MPL table for PR_ID: {pr_id}")
    except SQLAlchemyError as e:
        logger.error(f"Error encountered while inserting a record in MPL table for PR_ID: {pr_id} => {e}")


def update_record(snf_eng, provisioning_log, pr_id, pr_status, source_branch, obj_prov_list=None, merged_ts=None):
    """
    Updates an existing record in the provisioning log table.

    :param snf_eng: SQLAlchemy engine connected to the Snowflake database.
    :param provisioning_log: SQLAlchemy Table object representing the provisioning log table.
    :param pr_id: Pull request identifier to update.
    :param pr_status: Updated status of the pull request.
    :param source_branch: Updated source branch or fork of the pull request.
    :param obj_prov_list: Optional; List of objects provisioned for the pull request.
    :param merged_ts: Optional; Timestamp when the pull request was merged.
    :return: None
    """
    current_time = datetime.now(timezone.utc)
    try:
        # Serialize the object provisioned list to JSON if provided
        obj_prov_list_json = json.dumps(obj_prov_list) if obj_prov_list is not None else None

        # Prepare the update statement
        update_stmt = (
            update(provisioning_log)
            .where(provisioning_log.c.pr_id == pr_id)
            .values(
                pr_status=pr_status,
                source_branch_or_fork=source_branch,
                objects_provisioned_list=obj_prov_list_json,
                updated_at=current_time,
                merged_at=merged_ts,
                updated_timestamp=current_time
            )
            .execution_options(synchronize_session="fetch")
        )

        # Execute the update in a transaction
        with snf_eng.begin() as conn:
            update_result = conn.execute(update_stmt)

            if update_result.rowcount == 0:
                logger.debug(f"No record found to update in MPL table for PR_ID: {pr_id}.")
            else:
                logger.debug(
                    f"Number of record(s) updated in MPL table for PR_ID: {pr_id}: {update_result.rowcount}"
                )
    except SQLAlchemyError as e:
        logger.error(f"Error encountered while updating a record in MPL table for PR_ID: {pr_id} => {e}")


def record_exists(snf_eng, provisioning_log, pr_identifier):
    """
    Checks if a record exists for a given PR_ID in the provisioning log table.

    :param snf_eng: SQLAlchemy engine connected to the Snowflake database.
    :param provisioning_log: SQLAlchemy Table object representing the provisioning log table.
    :param pr_identifier: Pull request identifier to check for existence.
    :return: True if the record exists, False otherwise.
    """
    try:
        # Prepare the query to check for the PR_ID
        query = select(provisioning_log.columns.pr_id).where(provisioning_log.columns.pr_id == pr_identifier)

        # Execute the query
        with snf_eng.begin() as conn:
            select_result = conn.execute(query).fetchall()

            # Log the number of results retrieved
            logger.debug(
                f"Number of results retrieved while validating presence of PR_ID {pr_identifier}: {len(select_result)}"
            )

            # Return True if a record is found, False otherwise
            return bool(select_result)
    except SQLAlchemyError as e:
        logger.error(f"Error encountered while checking for PR_ID {pr_identifier} in MPL table: {e}")
        return False


def perform_mpl_logging(pr_event, pr_id, src_branch, obj_prov_list=None, merged_ts=None):
    """
    Handles logging for provisioning events in the MPL table.

    Depending on the pull request (PR) event type, this function creates or updates a record in the MPL table.

    :param pr_event: The type of pull request event (e.g., "PULL_REQUEST_CREATED", "PULL_REQUEST_UPDATED").
    :param pr_id: The unique identifier of the pull request.
    :param src_branch: The source branch or fork of the pull request.
    :param obj_prov_list: Optional; A list of objects provisioned for the PR.
    :param merged_ts: Optional; The timestamp when the PR was merged.
    """
    # Create the SQLAlchemy engine and retrieve the MPL table object
    engine = create_sqlalchmy_engine()
    tbl_obj = retrieve_snf_table(engine, MPL_TABLE_NAME)
    logger.debug(f"perform_mpl_logging >> pr_event : {pr_event}")
    if pr_event in {"PULL_REQUEST_CREATED", "PULL_REQUEST_OPENED"}:
        # Insert a new record for a created pull request
        create_mpl_record(engine, tbl_obj, pr_id, pr_event, src_branch)
    elif pr_event in {"PULL_REQUEST_UPDATED", "PULL_REQUEST_REOPENED", "PULL_REQUEST_MERGED"}:
        # Update the record if it exists, otherwise create a new one
        if record_exists(engine, tbl_obj, pr_id):
            logger.debug(
                f"Record with PR_ID {pr_id} found in the {MPL_TABLE_NAME} table. Preparing to update the entry."
            )
            update_record(engine, tbl_obj, pr_id, pr_event, src_branch, obj_prov_list, merged_ts)
        else:
            logger.warning(f"No existing record found for PR_ID: {pr_id}. Creating a new one.")
            create_mpl_record(engine, tbl_obj, pr_id, pr_event, src_branch)


def generate_table_objects(tbl_name_list):
    """
    Generates SQLAlchemy table objects for a list of table names.

    This function retrieves the table metadata and creates table objects for
    the specified tables using the SQLAlchemy engine.

    :param tbl_name_list: List of table names to generate objects for.
    :return: A dictionary where keys are table names and values are SQLAlchemy table objects.
    """
    tbl_obj_dict = {}
    engine = create_sqlalchmy_engine()

    for table_name in tbl_name_list:
        tbl_obj = retrieve_snf_table(engine, table_name)
        if tbl_obj is not None:
            tbl_obj_dict[tbl_obj.name] = tbl_obj

    return tbl_obj_dict


def create_db_insert_entry(table_obj, record_dict):
    record_dict = serialize_special_fields(dict(record_dict))
    return insert(table_obj).values(**record_dict)

def serialize_special_fields(record_dict):
    """
    Convert lists/dicts to JSON strings before Snowflake insert/update.
    Keeps strings, numbers, datetimes, booleans as-is.
    """
    for key, value in record_dict.items():
        if value is not None and isinstance(value, (list, dict)):
            record_dict[key] = json.dumps(value)
    return record_dict

def metadata_record_exists(conn, table_obj, record_dict, match_keys):
    try:
        conditions = [table_obj.c[key] == record_dict[key] for key in match_keys if key in record_dict]
        if not conditions:
            logger.warning(f"No valid match keys found for table {table_obj.name}")
            return False

        query = select(table_obj).where(and_(*conditions))
        result = conn.execute(query).fetchone()
        return result is not None
    except SQLAlchemyError as e:
        logger.error(f"Error while checking existence in {table_obj.name}: {e}")
        raise
    
def update_metadata_record(conn, table_obj, record_dict, match_keys):
    try:
        update_dict = dict(record_dict)

        # Do not overwrite created timestamp on update
        update_dict.pop("created_timestamp", None)

        update_dict = serialize_special_fields(update_dict)

        conditions = [table_obj.c[key] == record_dict[key] for key in match_keys if key in record_dict]
        if not conditions:
            logger.warning(f"No valid match keys found for update in {table_obj.name}")
            return

        update_stmt = (
            update(table_obj)
            .where(and_(*conditions))
            .values(**update_dict)
            .execution_options(synchronize_session="fetch")
        )
        conn.execute(update_stmt)
        logger.info(f"Updated existing record in {table_obj.name}")
    except SQLAlchemyError as e:
        logger.error(f"Error while updating record in {table_obj.name}: {e}")
        raise
    
def insert_metadata_record(conn, table_obj, record_dict):
    try:
        record_dict = dict(record_dict)
        record_dict["created_timestamp"] = record_dict.get("created_timestamp", datetime.now())
        insert_stmt = create_db_insert_entry(table_obj, serialize_special_fields(record_dict))
        conn.execute(insert_stmt)
        logger.info(f"Inserted new record into {table_obj.name}")
    except SQLAlchemyError as e:
        logger.error(f"Error while inserting record into {table_obj.name}: {e}")
        raise


def prepare_record(tbl_object, record_dict, dict_snf_lookup, id_attr_name, obj_num_id, pr_id):
    """
    Prepares a record dictionary for insertion into the database.

    This function:
    1. Resets the keys in the provided record dictionary based on the lookup dictionary.
    2. Adds additional required fields like `id_attr_name`, `pr_id`, and `created_timestamp`.
    3. Verifies if all required columns from the table are present in the record dictionary.

    :param tbl_object: SQLAlchemy table object representing the target database table.
    :param record_dict: Dictionary containing the record data to insert.
    :param dict_snf_lookup: Mapping dictionary used to reset the keys in `record_dict`.
    :param id_attr_name: The name of the ID attribute for the record (e.g., primary key).
    :param obj_num_id: The numeric ID value to be assigned to `id_attr_name`.
    :param pr_id: The pull request ID to be assigned to the record.
    :return: SQLAlchemy insert statement if all required attributes are present, else None.
    """
    logger.debug(f"prepare_record => tbl_object : {tbl_object}")
    logger.debug(f"Input record dictionary: {record_dict}")
    logger.debug(f"Lookup dictionary for key reset: {dict_snf_lookup}")

    # Reset keys in the record dictionary based on the lookup dictionary
    refined_record_dict = reset_key_based_on_lookup(record_dict, dict_snf_lookup)

    # Add additional required fields
    refined_record_dict[id_attr_name] = obj_num_id
    refined_record_dict["pr_id"] = pr_id
    refined_record_dict["created_timestamp"] = datetime.now()

    ## Checking if the value is list then explicitly converting into a string
    # refined_record_dict = {key: str(val) if isinstance(val, list) else val for key, val in refined_record_dict.items()}


    logger.debug(f"Refined record dictionary before validation: {refined_record_dict}")

    # Extract the column names from the table and check for missing columns
    table_extracted_col_names = [column.name for column in tbl_object.columns]
    logger.debug(f"Table columns table_extracted_col_names : {table_extracted_col_names}")
    missing_columns = [column for column in table_extracted_col_names if column not in refined_record_dict]

    if missing_columns:
        logger.warning(f"Missing columns in the record dictionary: {missing_columns}")
        return None

    # If there are additional columns in the record_dict compared to table_cols,
    # the extra columns needs to be trimmed
    extra_columns = [column for column in refined_record_dict if column not in table_extracted_col_names]
    if extra_columns:
        logger.debug(f"Extra columns present for object : {tbl_object}, trimming the columns : {extra_columns}")
        logger.debug(f"prepare_record >> extra_columns : {extra_columns}")
        refined_record_dict = {key: value for key, value in refined_record_dict.items() if key not in extra_columns}
        logger.debug(f"refined_record_dict after trimming extra columns : {refined_record_dict}")

    logger.debug("All required attributes are present in the record dictionary.")

    logger.debug(f"prepare_record => tbl_object : {tbl_object}")
    logger.debug(f"prepare_record => refined_record_dict : {refined_record_dict}")

    # Return the insert statement
    return {"table_obj": tbl_object, "record_dict": refined_record_dict}


def perform_metadata_entry(record_payload_list):
    """
    Performs metadata entry by upserting records into the database.

    Each item in record_payload_list is expected to be:
    {
        "table_obj": <sqlalchemy table>,
        "table_name": <table name>,   # optional
        "record_dict": <refined record dict>
    }
    """
    engine = create_sqlalchmy_engine()

    try:
        with engine.begin() as conn:
            for payload in record_payload_list:
                if not payload:
                    continue

                table_obj = payload.get("table_obj")
                record_dict = payload.get("record_dict")

                if table_obj is None or record_dict is None:
                    logger.warning(f"Invalid payload encountered: {payload}")
                    continue

                table_name = payload.get("table_name", table_obj.name)
                match_keys = METADATA_MATCH_KEYS.get(table_name)

                if not match_keys:
                    logger.warning(f"No match keys configured for table {table_name}. Skipping record.")
                    continue

                if metadata_record_exists(conn, table_obj, record_dict, match_keys):
                    update_metadata_record(conn, table_obj, record_dict, match_keys)
                else:
                    insert_metadata_record(conn, table_obj, record_dict)

        logger.info("Metadata records processed successfully using insert/update logic.")
    except SQLAlchemyError as e:
        logger.error(f"Error encountered while processing metadata records: {e}")
        raise