output "warehouse_outputs" {
  value = {
    for k, v in module.warehouse :
    k => {
      warehouse_name            = v.warehouse_name
      description               = v.description
      warehouse_size            = v.warehouse_size
      auto_suspend_in_seconds   = v.auto_suspend_in_seconds
      auto_resume               = v.auto_resume
      max_cluster_count         = v.max_cluster_count
      scaling_policy            = v.scaling_policy
      query_timeout_in_seconds  = v.query_timeout_in_seconds
      input_metadata            = v.input_metadata
      attached_resource_monitor = v.attached_resource_monitor
      war_unique_roles          = v.war_unique_roles
      test_unique_roles         = v.test_unique_roles
      # war_deduped_roles_map     = v.war_deduped_roles_map
      # war_grouped_roles         = v.war_grouped_roles
    }
  }
}

output "database_outputs" {
  value = {
    for k, v in module.db :
    k => {
      database_name  = v.database_name
      input_metadata = v.input_metadata
    }
  }
}

output "schema_outputs" {
  value = {
    for k, v in module.schema :
    k => {
      schema_database                = v.schema_database
      schema_name                    = v.schema_name
      description                    = v.description
      input_metadata                 = v.input_metadata
      # debug_schema_name              = v.debug_schema_name
      # static_roles                   = v.static_roles
      # static_privileges              = v.static_privileges
      # filtered_deduped_roles_map     = v.filtered_deduped_roles_map
      # dataintegrator_roles_map       = v.dataintegrator_roles_map
      # data_integrator_privileges     = v.data_integrator_privileges
      # non_data_integrator_privileges = v.non_data_integrator_privileges
      # data_integrator_privileges     = v.data_integrator_privileges
      # unique_roles                   = v.unique_roles
      access_roles              = v.access_roles
      ro_tech_roles_privileges = v.ro_tech_roles_privileges
      rw_tech_roles_privileges = v.rw_tech_roles_privileges
    }
  }
}

output "roles_outputs" {
  value = {
    for k, v in module.roles :
    k => {
      input_metadata = v.input_metadata
    }
  }
}

output "oauth_outputs" {
  value = {
    for k, v in module.oauth :
    k => {
      input_metadata = v.input_metadata
      data_consumer_roles = v.data_consumer_roles
    }
  }
}

output "storage_integration_outputs" {
  value = {
    for k, v in module.storage_integrations :
    k => {
      input_metadata           = v.input_metadata
    }
  }
}

output "external_volume_outputs" {
  value = {
    for k, v in module.external_volumes :
    k => {
      evol_name           = v.evol_name
      input_metadata      = v.input_metadata
    }
  }
}

# output "catalog_integration_outputs" {
#   value = {
#     for k, v in module.catalog_integrations :
#     k => {
#       input_metadata           = v.input_metadata
#     }
#   }
# }

output "tag_parsed_configs" {
  value=local.tag_parsed_configs
}