output "input_metadata" {
  value = var.input_metadata
}

output "oauth_user_name"{
  value = var.sub_uuid
}

output "display_name" {
  value = var.sub_uuid
}

output "login_name" {
  value = var.sub_uuid
}

output "default_role" {
  value = element(var.access_roles, 0)
} 

output "granted_roles" {
  value = toset(slice(var.access_roles, 1, length(var.access_roles)))
}

output "data_consumer_roles" {
  value =  local.data_consumer_roles
}