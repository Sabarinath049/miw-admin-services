resource "snowflake_service_user" "oauth_user_creation" {
  provider = snowflake.miw_dtd_miw_oauthadmin_pr
  name         = var.sub_uuid
  login_name   = var.sub_uuid
  comment      = var.comment
  display_name = var.sub_uuid
  default_role = element(var.access_roles, 0)
  lifecycle {
    ignore_changes = [
      network_policy,
      rsa_public_key_2,
      rsa_public_key
    ]
  }
}

resource "snowflake_grant_account_role" "grant_roles_to_oauth_user" {
  provider = snowflake.miw_dtd_miw_oauthadmin_pr
  for_each = length(var.access_roles) > 0 ? toset(slice(var.access_roles, 0, length(var.access_roles))) : []
  role_name = upper(each.value)
  user_name = snowflake_service_user.oauth_user_creation.name
}


## Grant PAT token access to Dataconsumer role only on specific sub_uuid if access_roles contains dataconsumer
locals {
  data_consumer_roles = toset([
    for role in var.access_roles : role
    if strcontains(lower(role), "dataconsumer")
  ])
}

resource "snowflake_grant_privileges_to_account_role" "oauth_privileges_data_consumer" {
  provider = snowflake.miw_dtd_miw_accountadmin_pr
  for_each = local.data_consumer_roles
  privileges        = ["MODIFY PROGRAMMATIC AUTHENTICATION METHODS"]
  account_role_name = upper(each.key)
  on_account_object {
    object_type = "USER"
    object_name = var.sub_uuid
  }
  always_apply = true
  depends_on = [snowflake_service_user.oauth_user_creation]
}