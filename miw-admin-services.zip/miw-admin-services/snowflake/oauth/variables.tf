variable "project" {}
variable "env" {}
variable "input_metadata" {}
variable "sub_uuid" {}
variable "access_roles" {}
variable "comment" {}