bucket         = "minerva-dev-corp-miw-tfstate-430118842002-useast1"
key            = "snowflake/dev/prerequisites/snowflake.json"
region         = "us-east-1"
dynamodb_table = "minerva-dev-corp-miw-tfstate-dynamodb-table"