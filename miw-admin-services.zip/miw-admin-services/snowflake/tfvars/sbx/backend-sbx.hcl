bucket         = "minerva-snd-corp-miw-tfstate-442426855665-useast1"
key            = "snowflake/sbx/${PRODUCT_KEY}/snowflake.json"
region         = "us-east-1"
dynamodb_table = "minerva-snd-corp-miw-tfstate-dynamodb-table"