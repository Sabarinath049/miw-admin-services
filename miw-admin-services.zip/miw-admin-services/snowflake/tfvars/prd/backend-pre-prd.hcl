bucket         = "minerva-prd-corp-miw-tfstate-255914130710-useast1"
key            = "snowflake/prd/prerequisites/snowflake.json"
region         = "us-east-1"
dynamodb_table = "minerva-prd-corp-miw-tfstate-dynamodb-table"
