variable "project" {}
variable "env" {}
variable "access_roles" {}
variable "input_metadata" {}
variable "db_role" {}
variable "tags" {}
variable "tag_database" {}
variable "tag_schema" {}
variable "catalog_integration_name" {}
variable "catalog_namespace" {}
variable "enterprise_or_func_name" {}
variable "unique_roles" {}
variable "access_roles_ci_map" {}
variable "catalog_source" { type = string }
variable "catalog_table_format" { type = string }
variable "rest_catalog_uri" { type = string }
variable "rest_catalog_name" { type = string }
variable "rest_catalog_api_type" { type = string }
variable "rest_auth_type" { type = string }
variable "rest_auth_iam_role" { type = string }
variable "rest_auth_sign_region" { type = string }
variable "enterprise_or_func_subgrp_name" { type = string }
variable "catalog_refresh_interval_secs" { type = number }
variable "iceberg_enabled" { type = bool }