# locals {
#   reval_catalog_refresh_interval_secs = contains(keys(var.input_metadata), "catalog_refresh_interval_secs") ? var.input_metadata.catalog_refresh_interval_secs : 30
#
#   reval_enable_vended_credentials = (
#   contains(keys(var.input_metadata), "enable_vended_credentials") &&
#   lower(var.input_metadata.enable_vended_credentials) == "true"
#   ) ? ", ACCESS_DELEGATION_MODE = VENDED_CREDENTIALS" : ""
#
#   new_metadata = {
#     catalog_refresh_interval_secs   = local.reval_catalog_refresh_interval_secs
#     enable_vended_credentials_local = local.reval_enable_vended_credentials
#   }
#   merged_metadata = merge(var.input_metadata, local.new_metadata)
#
#   catalog_namespace_map = {
#     for ns in var.catalog_namespace :
#     "${ns}_ci" => ns
#   }
# }
#
# ## Creating catalog integration using snowflake query execute in terraform
# resource "snowflake_execute" "miw_catalog_integration" {
#   for_each = local.catalog_namespace_map
#   provider = snowflake.miw_dtd_miw_accountadmin_pr
#
#   # Force-quote all strings; leave booleans/numbers unquoted.
#   execute = <<SQL
#   CALL "${upper(var.env)}_DTD_MIW_DB".FDP_SF_OBJECTS_METADATA_GBL_CUR_SC.UPSERT_CATALOG_INTEGRATION_REFRESH_ONLY(
#     NAME                      => ${format("'%s'", each.key)},
#     VAR_CATALOG_SOURCE        => ${format("'%s'", upper(var.catalog_source))},
#     VAR_TABLE_FORMAT          => ${format("'%s'", upper(var.catalog_table_format))},
#     EACH_VALUE_NAMESPACE      => ${format("'%s'", each.value)},
#
#     VAR_REST_CATALOG_URI      => ${format("'%s'", replace(var.rest_catalog_uri, "'", "''"))},
#     VAR_REST_CATALOG_NAME     => ${format("'%s'", replace(var.rest_catalog_name, "'", "''"))},
#     VAR_REST_CATALOG_API_TYPE => ${format("'%s'", upper(var.rest_catalog_api_type))},
#     LOCAL_REVAL_ENABLE_VENDED => ${format("'%s'", coalesce(local.reval_enable_vended_credentials, ""))},
#
#     VAR_REST_AUTH_TYPE        => ${format("'%s'", upper(var.rest_auth_type))},
#     VAR_REST_AUTH_IAM_ROLE    => ${format("'%s'", var.rest_auth_iam_role)},
#     VAR_REST_AUTH_SIGN_REGION => ${format("'%s'", lower(var.rest_auth_sign_region))},
#
#     VAR_ICEBERG_ENABLED       => ${var.iceberg_enabled},              -- boolean: keep unquoted
#     VAR_REFRESH_INTERVAL_SECS => ${var.catalog_refresh_interval_secs}, -- number: keep unquoted
#     VAR_COMMENT               => ${format("'%s'", replace(
#   "Integration with Iceberg REST catalog created for enterprise_or_func_subgrp_name ${var.enterprise_or_func_subgrp_name}",
# "'", "''"))}
#   );
#   SQL
#   revert = "DROP CATALOG INTEGRATION ${each.key}"
#   query  = "SHOW CATALOG INTEGRATIONS LIKE '%${each.key}%'"
# }