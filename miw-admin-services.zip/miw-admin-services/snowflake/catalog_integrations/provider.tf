terraform {
  required_providers {
    snowflake = {
      source  = "snowflakedb/snowflake"
      version = "1.0.5"
      configuration_aliases = [
        snowflake.miw_dtd_miw_accountadmin_pr,
      ]
    }
  }
}