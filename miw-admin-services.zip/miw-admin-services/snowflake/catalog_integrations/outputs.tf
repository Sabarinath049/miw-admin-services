# output "input_metadata" {
#   value = local.merged_metadata
# }