# locals {
#   access_roles_map = {
#     for role in var.access_roles : role.access_role => {
#       tech_role = role.tech_role
#       grants    = role.grants
#     }
#   }
# }
#
# # # Resource to create tech roles
# resource "snowflake_account_role" "miw_stg_int_tech_role" {
#   provider = snowflake.miw_dtd_miw_accountadmin_pr
#   for_each = var.unique_roles
#   name     = each.key
#   comment  = "Technical role for ${var.catalog_integration_name}"
#   lifecycle {
#     prevent_destroy = true
#   }
# }
#
# # # Resource to grant privileges on storage_integration to account roles
# resource "snowflake_grant_privileges_to_account_role" "grant_perm_on_catalog_integration" {
#   provider = snowflake.miw_dtd_miw_accountadmin_pr
#   for_each = var.access_roles_ci_map
#   on_account_object {
#     object_type = "INTEGRATION"
#     object_name = upper(each.value.catalog_integration)
#   }
#   privileges        = each.value.grants
#   always_apply      = true
#   account_role_name = snowflake_account_role.miw_stg_int_tech_role[each.value.tech_role].name
#   depends_on = [snowflake_account_role.miw_stg_int_tech_role]
# }
#
# # # Resource to grant tech role to access role
# resource "snowflake_grant_account_role" "stg_int_grant_tech_to_access_role" {
#   provider         = snowflake.miw_dtd_miw_accountadmin_pr
#   for_each         = local.access_roles_map  # Use converted map
#   role_name        = snowflake_account_role.miw_stg_int_tech_role[each.value.tech_role].name
#   parent_role_name = upper(each.key)  # access role name
# }