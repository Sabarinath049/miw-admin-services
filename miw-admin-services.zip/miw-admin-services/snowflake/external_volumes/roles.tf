locals {
  access_roles_map = {
    for role in var.access_roles : role.access_role => {
      tech_role = role.tech_role
      grants    = role.grants
    }
  }
}

# Resource to create account roles
resource "snowflake_account_role" "miw_evol_tech_role" {
  provider = snowflake.miw_dtd_miw_accountadmin_pr
  for_each = var.unique_roles
  name     = each.key
  comment  = "Technical role for ${var.external_volume_name}"
  lifecycle {
    prevent_destroy = true
  }
}

# Resource to grant privileges on warehouse to account roles
resource "snowflake_grant_privileges_to_account_role" "grant_perm_on_evol" {
  provider = snowflake.miw_dtd_miw_accountadmin_pr
  for_each = var.unique_roles
  on_account_object {
    object_type = "EXTERNAL VOLUME"
    object_name = snowflake_external_volume.miw_evol.name
  }
  privileges        = each.value
  always_apply      = true
  account_role_name = snowflake_account_role.miw_evol_tech_role[each.key].name
}

resource "snowflake_grant_account_role" "evol_grant_tech_to_access_role" {
  provider         = snowflake.miw_dtd_miw_accountadmin_pr
  for_each         = local.access_roles_map
  role_name        = snowflake_account_role.miw_evol_tech_role[each.value.tech_role].name
  parent_role_name = upper(each.key)
  depends_on = [snowflake_account_role.miw_evol_tech_role]
}