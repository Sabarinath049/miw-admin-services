output "evol_name" {
  value = snowflake_external_volume.miw_evol.name
}

output "input_metadata" {
  value = var.input_metadata
}