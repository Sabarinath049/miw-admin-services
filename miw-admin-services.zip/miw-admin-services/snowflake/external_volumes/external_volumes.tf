locals {
  reval_storage_provider     = contains(keys(var.input_metadata), "storage_provider") ? var.input_metadata.storage_provider : var.storage_provider
  reval_allow_writes         = contains(keys(var.input_metadata), "allow_writes") ? var.input_metadata.allow_writes : var.allow_writes
  reval_encryption_type      = contains(keys(var.input_metadata), "encryption_type") ? var.input_metadata.encryption_type : var.encryption_type
  reval_private_link_enabled = contains(keys(var.input_metadata), "private_link_enabled") ? var.input_metadata.private_link_enabled : var.private_link_enabled
}

resource "snowflake_external_volume" "miw_evol" {
  provider     = snowflake.miw_dtd_miw_accountadmin_pr
  name         = var.external_volume_name
  allow_writes = local.reval_allow_writes
  comment      = "The external volume is created by ${var.enterprise_or_func_subgrp_name} domain and ${var.enterprise_or_func_name} enterprise."
  storage_location {
    storage_base_url      = var.storage_base_url
    storage_location_name = var.storage_location_name
    storage_provider      = local.reval_storage_provider
    storage_aws_role_arn  = var.storage_role_arn
    encryption_type       = local.reval_encryption_type
  }
  lifecycle {
    prevent_destroy = true
  }
}