module "prerequisites" {
  count                      = var.apply_prerequisites ? 1 : 0
  source                     = "./prerequisites"
  db_pipln                   = var.db_pipln
  tag_database               = var.tag_database
  tag_schema                 = var.tag_schema
  tag_parsed_configs         = local.tag_parsed_configs
  integrator_persona_mapping = var.integrator_persona_mapping
  tag_tech_role              = var.tag_tech_role
  tag_tech_role_rw           = local.tag_tech_role_rw
  tag_tech_role_ro           = local.tag_tech_role_ro
  providers = {
    snowflake.miw_dtd_miw_dbadmin_pr = snowflake.miw_dtd_miw_dbadmin_pr
  }
}

module "warehouse" {
  for_each                            = local.warehouse_parsed_configs
  source                              = "./warehouses"
  project                             = var.project
  env                                 = var.env
  wh_role                             = var.wh_role
  warehouse_name                      = each.value.warehouse_name
  warehouse_type                      = var.warehouse_type
  description                         = each.value.description
  warehouse_size                      = each.value.warehouse_size
  auto_suspend_in_seconds             = var.auto_suspend_in_seconds
  auto_resume                         = var.auto_resume
  min_cluster_count                   = var.min_cluster_count
  max_cluster_count                   = var.max_cluster_count
  scaling_policy                      = var.scaling_policy
  query_timeout_in_seconds            = var.query_timeout_in_seconds
  statement_queued_timeout_in_seconds = var.statement_queued_timeout_in_seconds
  max_concurrency_level               = var.max_concurrency_level
  access_roles                        = each.value.access_roles
  monthly_credit_limit                = each.value.monthly_credit_limit
  alert_subscribers_list              = each.value.alert_subscribers_list
  tags                                = each.value.tags
  tag_database                        = var.tag_database
  tag_schema                          = var.tag_schema
  input_metadata                      = each.value
  all_wh_role                         = var.integrator_persona_mapping[0]
  providers = {
    snowflake.miw_dtd_miw_whadmin_pr = snowflake.miw_dtd_miw_whadmin_pr
  }
}

module "db" {
  for_each       = local.database_parsed_configs
  source         = "./db"
  project        = var.project
  env            = var.env
  database_name  = each.value.database_name
  description    = each.value.description
  database_type  = var.database_type
  input_metadata = each.value
  tags           = each.value.tags
  tag_database   = var.tag_database
  tag_schema     = var.tag_schema
  providers = {
    snowflake.miw_dtd_miw_dbadmin_pr = snowflake.miw_dtd_miw_dbadmin_pr
  }
}

module "schema" {
  for_each                         = local.schema_parsed_configs
  depends_on                       = [module.db]
  source                           = "./schema"
  project                          = var.project
  env                              = var.env
  db_role                          = var.db_role
  parent_db_name                   = each.value.parent_db_name != "" ? each.value.parent_db_name : module.db[each.key].database_name
  schema_name                      = each.value.schema_name
  description                      = each.value.description
  access_roles                     = each.value.access_roles
  data_retention_in_days           = var.data_retention_in_days
  schema_catalog                   = var.schema_catalog
  schema_object_related_privileges = each.value.schema_object_related_privileges
  input_metadata                   = each.value
  tags                             = each.value.tags
  tag_database                     = var.tag_database
  tag_schema                       = var.tag_schema
  all_tags                         = local.tag_parsed_configs
  tag_tech_role                    = var.tag_tech_role
  tag_tech_role_rw                 = local.tag_tech_role_rw
  tag_tech_role_ro                 = local.tag_tech_role_ro
  all_sch_role                     = var.integrator_persona_mapping[1]
  providers = {
    snowflake.miw_dtd_miw_dbadmin_pr = snowflake.miw_dtd_miw_dbadmin_pr
  }
}

module "roles" {
  for_each            = local.rbac_parsed_configs
  source              = "./roles"
  project             = var.project
  env                 = var.env
  persona_parent_role = var.persona_parent_role
  defined_role_name   = each.value.aad_group_name
  input_metadata      = each.value
  access_roles_alias  = each.value.access_roles_alias
  all_sch_role        = var.integrator_persona_mapping[1]
  all_wh_role         = var.integrator_persona_mapping[0]
  providers = {
    snowflake.miw_dtd_miw_dbadmin_pr = snowflake.miw_dtd_miw_dbadmin_pr,
    snowflake.miw_dtd_miw_whadmin_pr = snowflake.miw_dtd_miw_whadmin_pr
  }
}

module "oauth" {
  for_each       = local.oauth_parsed_configs
  source         = "./oauth"
  project        = var.project
  env            = var.env
  sub_uuid       = each.value.sub_uuid
  comment        = each.value.purpose
  access_roles   = each.value.minerva_aad_group
  input_metadata = each.value
  providers = {
    snowflake.miw_dtd_miw_oauthadmin_pr = snowflake.miw_dtd_miw_oauthadmin_pr,
    snowflake.miw_dtd_miw_accountadmin_pr = snowflake.miw_dtd_miw_accountadmin_pr
  }
}

module "storage_integrations" {
  for_each                    = local.storage_integrations_parsed_configs
  source                      = "./storage_integrations"
  project                     = var.project
  env                         = var.env
  db_role                     = var.db_role
  storage_integration_name    = each.value.storage_integration_name
  storage_provider            = upper(var.storage_provider)
  access_roles                = each.value.access_roles
  storage_integration_enabled = var.storage_integration_enabled
  storage_role_arn            = each.value.storage_role_arn
  allowed_storage_locations   = each.value.allowed_storage_locations
  blocked_storage_locations   = var.blocked_storage_locations
  stage_type                  = upper(var.stage_type)
  enterprise_or_func_subgrp_name                      = each.value.enterprise_or_func_subgrp_name
  enterprise_or_func_name     = each.value.enterprise_or_func_name
  tags                        = each.value.tags
  tag_database                = var.tag_database
  tag_schema                  = var.tag_schema
  input_metadata              = each.value
  providers = {
    snowflake.miw_dtd_miw_accountadmin_pr = snowflake.miw_dtd_miw_accountadmin_pr
  }
}

module "external_volumes" {
  for_each                = local.external_volumes_parsed_configs
  source                  = "./external_volumes"
  project                 = var.project
  env                     = var.env
  external_volume_name    = each.value.external_volume_name
  storage_base_url        = each.value.storage_base_url
  storage_role_arn        = each.value.storage_role_arn
  allow_writes            = each.value.allow_writes
  enterprise_or_func_subgrp_name                  = each.value.enterprise_or_func_subgrp_name
  enterprise_or_func_name = each.value.enterprise_or_func_name
  storage_provider        = each.value.storage_provider
  access_roles            = each.value.access_roles
  unique_roles            = each.value.unique_roles_ro_rw
  storage_location_name   = each.value.external_volume_name
  private_link_enabled    = "False"
  encryption_type         = "AWS_SSE_S3"
  input_metadata          = each.value
  providers = {
    snowflake.miw_dtd_miw_accountadmin_pr = snowflake.miw_dtd_miw_accountadmin_pr
  }
}

# module "catalog_integrations" {
#   for_each                      = local.catalog_integrations_parsed_configs
#   source                        = "./catalog_integrations"
#   project                       = var.project
#   env                           = var.env
#   db_role                       = var.db_role
#   enterprise_or_func_subgrp_name                        = each.value.enterprise_or_func_subgrp_name
#   access_roles                  = each.value.access_roles
#   tags                          = each.value.tags
#   tag_database                  = var.tag_database
#   tag_schema                    = var.tag_schema
#   input_metadata                = each.value
#   catalog_integration_name      = each.value.catalog_integration_name
#   catalog_source                = each.value.catalog_source
#   catalog_table_format          = each.value.catalog_table_format
#   catalog_namespace             = each.value.catalog_namespace
#   rest_catalog_uri              = each.value.rest_catalog_uri
#   rest_catalog_name             = each.value.rest_catalog_name
#   rest_catalog_api_type         = each.value.rest_catalog_api_type
#   rest_auth_type                = each.value.rest_auth_type
#   rest_auth_iam_role            = each.value.rest_auth_iam_role
#   rest_auth_sign_region         = each.value.rest_auth_sign_region
#   iceberg_enabled               = each.value.iceberg_enabled
#   catalog_refresh_interval_secs = each.value.catalog_refresh_interval_secs
#   enterprise_or_func_name       = each.value.enterprise_or_func_name
#   unique_roles                  = each.value.unique_roles_ro_rw
#   access_roles_ci_map           = each.value.access_roles_ci_map
#   providers = {
#     snowflake.miw_dtd_miw_accountadmin_pr = snowflake.miw_dtd_miw_accountadmin_pr
#   }
# }