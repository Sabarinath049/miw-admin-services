resource "snowflake_tag" "miw_tag" {
  provider       = snowflake.miw_dtd_miw_dbadmin_pr
  for_each       = var.tag_parsed_configs
  name           = each.key
  database       = var.tag_database
  schema         = var.tag_schema
  allowed_values = length(each.value.allowed_values) > 0 ? each.value.allowed_values : null
}

# Resource to create account all_db, all_sch and all_wh roles
resource "snowflake_account_role" "miw_all_resource_tech_role" {
  provider = snowflake.miw_dtd_miw_dbadmin_pr
  for_each = toset(var.integrator_persona_mapping)
  name     = upper(each.value)
  comment  = "Technical role created ${each.value}"
  lifecycle {
    prevent_destroy = true
  }
}

## Creating database role for tag approach
resource "snowflake_database_role" "miw_tag_tech_role" {
  provider = snowflake.miw_dtd_miw_dbadmin_pr
  for_each = var.tag_tech_role
  name     = each.key
  comment  = "Technical role for tagging purpose"
  database = var.tag_database
}

# Tag Database usage privilege to all the roles except data integrator
resource "snowflake_grant_privileges_to_database_role" "grant_usage_on_tag_db" {
  provider           = snowflake.miw_dtd_miw_dbadmin_pr
  for_each           = var.tag_tech_role
  on_database        = var.tag_database
  privileges         = ["USAGE"]
  database_role_name = "${var.tag_database}.${each.key}"
  always_apply       = true
  depends_on         = [snowflake_database_role.miw_tag_tech_role]
}

# Tag schema usage privilege to all the roles except data integrator
resource "snowflake_grant_privileges_to_database_role" "grant_usage_on_tag_sch" {
  provider     = snowflake.miw_dtd_miw_dbadmin_pr
  for_each     = var.tag_tech_role
  always_apply = true
  on_schema {
    schema_name = "${var.tag_database}.${var.tag_schema}"
  }
  privileges         = ["USAGE"]
  database_role_name = "${var.tag_database}.${each.key}"
  depends_on         = [snowflake_database_role.miw_tag_tech_role]
}

## Granting apply tag privilege on all the tags to the role RW
resource "snowflake_grant_privileges_to_database_role" "grant_apply_on_tag_to_tag_tech_role" {
  provider     = snowflake.miw_dtd_miw_dbadmin_pr
  for_each     = var.tag_parsed_configs
  always_apply = true
  on_schema_object {
    object_type = "TAG"
    object_name = "${var.tag_database}.${var.tag_schema}.${each.key}"
  }
  privileges         = ["APPLY"]
  database_role_name = "${var.tag_database}.${var.tag_tech_role_rw}"
  depends_on         = [snowflake_database_role.miw_tag_tech_role, snowflake_tag.miw_tag]
}