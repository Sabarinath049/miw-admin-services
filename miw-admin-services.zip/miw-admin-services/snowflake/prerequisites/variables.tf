variable "db_pipln" {}
variable "tag_database" {}
variable "tag_schema" {}
variable "tag_parsed_configs" {}
variable "integrator_persona_mapping" {}
variable "tag_tech_role_rw" {}
variable "tag_tech_role_ro" {}
variable "tag_tech_role" {}

locals {
  existing_role_names = toset(flatten([
    for r in data.snowflake_account_roles.all.account_roles :
    [
      for role in r.show_output :
      upper(role.name)
    ]
  ]))

  input_roles = toset([for r in var.integrator_persona_mapping : upper(r)])
  roles_to_create = setsubtract(local.input_roles, local.existing_role_names)

  resolved_wh_role = (
    lookup(snowflake_account_role.miw_all_resource_tech_role, upper(var.integrator_persona_mapping[0]), null) != null ?
    snowflake_account_role.miw_all_resource_tech_role[upper(var.integrator_persona_mapping[0])].name :
    upper(var.integrator_persona_mapping[0])
  )

  resolved_sch_role = (
    lookup(snowflake_account_role.miw_all_resource_tech_role, upper(var.integrator_persona_mapping[1]), null) != null ?
    snowflake_account_role.miw_all_resource_tech_role[upper(var.integrator_persona_mapping[1])].name :
    upper(var.integrator_persona_mapping[1])
  )
}