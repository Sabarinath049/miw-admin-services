output "tags_output" {
  value = {
    for k, v in snowflake_tag.miw_tag : k => {
      id                   = v.id
      name                 = v.name
      database             = v.database
      schema               = v.schema
      fully_qualified_name = v.fully_qualified_name
    }
  }
  description = "Map of all tag metadata created"
}

output "resolved_wh_role" {
  value = local.resolved_wh_role
}

output "resolved_sch_role" {
  value = local.resolved_sch_role
}