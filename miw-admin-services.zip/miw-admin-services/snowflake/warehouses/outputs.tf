output "warehouse_name" {
  value = snowflake_warehouse.miw_warehouse.name
}

output "description" {
  value = snowflake_warehouse.miw_warehouse.comment
}

output "warehouse_size" {
  value = snowflake_warehouse.miw_warehouse.warehouse_size
}

output "auto_suspend_in_seconds" {
  value = snowflake_warehouse.miw_warehouse.auto_suspend
}

output "auto_resume" {
  value = snowflake_warehouse.miw_warehouse.auto_resume
}

output "max_cluster_count" {
  value = snowflake_warehouse.miw_warehouse.max_cluster_count
}

output "scaling_policy" {
  value = snowflake_warehouse.miw_warehouse.scaling_policy
}

output "query_timeout_in_seconds" {
  value = snowflake_warehouse.miw_warehouse.statement_timeout_in_seconds
}

output "attached_resource_monitor" {
  value = snowflake_warehouse.miw_warehouse.resource_monitor
}

output "warehouse_tech_roles" {
  value = [ for role in snowflake_account_role.miw_wh_tech_role : role.name ]
}

output "snowflake_existing_roles" {
  value = [ for role in data.snowflake_account_roles.miw_existing_role : role ]
}

output "existing_roles" {
  value = data.snowflake_account_roles.miw_existing_role
}

output "input_metadata" {
  value = local.merged_metadata
}

output "war_existing_roles" {
  value = data.snowflake_account_roles.miw_existing_role
}

output "war_unique_roles" {
  value = local.unique_roles
}

output "test_unique_roles" {
  value= { for k, v in local.unique_roles : k => v if v.access_role != "dataintegrator" }
}

output "war_deduped_roles_map" {
  value = local.deduped_roles_map
}

output "war_grouped_roles" {
  value = local.grouped_roles
}

output "access_roles" {
  value = var.access_roles
}
