locals {
  reval_warehouse_type                      = contains(keys(var.input_metadata), "warehouse_type") ? var.input_metadata.warehouse_type : var.warehouse_type
  reval_auto_suspend_in_seconds             = contains(keys(var.input_metadata), "auto_suspend_in_seconds") ? var.input_metadata.auto_suspend_in_seconds : var.auto_suspend_in_seconds
  reval_auto_resume                         = contains(keys(var.input_metadata), "auto_resume") ? var.input_metadata.auto_resume : var.auto_resume
  reval_min_cluster_count                   = contains(keys(var.input_metadata), "min_cluster_count") ? var.input_metadata.min_cluster_count : var.min_cluster_count
  reval_max_cluster_count                   = contains(keys(var.input_metadata), "max_cluster_count") ? var.input_metadata.max_cluster_count : var.max_cluster_count
  reval_scaling_policy                      = contains(keys(var.input_metadata), "scaling_policy") ? var.input_metadata.scaling_policy : var.scaling_policy
  reval_query_timeout_in_seconds            = contains(keys(var.input_metadata), "query_timeout_in_seconds") ? var.input_metadata.query_timeout_in_seconds : var.query_timeout_in_seconds
  reval_statement_queued_timeout_in_seconds = contains(keys(var.input_metadata), "statement_queued_timeout_in_seconds") ? var.input_metadata.statement_queued_timeout_in_seconds : var.statement_queued_timeout_in_seconds
  reval_max_concurrency_level               = contains(keys(var.input_metadata), "max_concurrency_level") ? var.input_metadata.max_concurrency_level : var.max_concurrency_level

  new_metadata = {
    warehouse_type                      = local.reval_warehouse_type
    auto_suspend_in_seconds             = local.reval_auto_suspend_in_seconds
    auto_resume                         = local.reval_auto_resume
    min_cluster_count                   = local.reval_min_cluster_count
    max_cluster_count                   = local.reval_max_cluster_count
    scaling_policy                      = local.reval_scaling_policy
    query_timeout_in_seconds            = local.reval_query_timeout_in_seconds
    statement_queued_timeout_in_seconds = local.reval_statement_queued_timeout_in_seconds
    max_concurrency_level               = local.reval_max_concurrency_level
  }

  merged_metadata = merge(var.input_metadata, local.new_metadata)

}

resource "snowflake_resource_monitor" "miw_monitor" {
  provider        = snowflake.miw_dtd_miw_whadmin_pr
  name            = "${var.project}-${var.env}-monitor-${var.warehouse_name}"
  credit_quota    = var.monthly_credit_limit
  notify_triggers = [50, 75, 90, 98]
  suspend_trigger = 100
  notify_users    = var.alert_subscribers_list
  lifecycle {
    prevent_destroy = true
  }
}

resource "snowflake_warehouse" "miw_warehouse" {
  provider                            = snowflake.miw_dtd_miw_whadmin_pr
  name                                = var.warehouse_name
  comment                             = var.description
  warehouse_size                      = var.warehouse_size
  auto_suspend                        = local.reval_auto_suspend_in_seconds
  auto_resume                         = local.reval_auto_resume
  min_cluster_count                   = local.reval_min_cluster_count
  max_cluster_count                   = local.reval_max_cluster_count
  scaling_policy                      = local.reval_scaling_policy
  statement_timeout_in_seconds        = local.reval_query_timeout_in_seconds
  max_concurrency_level               = local.reval_max_concurrency_level
  warehouse_type                      = upper(local.reval_warehouse_type)
  statement_queued_timeout_in_seconds = local.reval_statement_queued_timeout_in_seconds
  resource_monitor                    = snowflake_resource_monitor.miw_monitor.name
  lifecycle {
    prevent_destroy = true
  }
}

resource "snowflake_tag_association" "wh_tag_association" {
  provider = snowflake.miw_dtd_miw_whadmin_pr
  for_each = var.tags
  object_identifiers = [snowflake_warehouse.miw_warehouse.fully_qualified_name]
  object_type        = "WAREHOUSE"
  tag_id             = "${var.tag_database}.${var.tag_schema}.${each.key}"
  tag_value          = each.value
}