variable "warehouse_name" {}
variable "description" {}
variable "warehouse_size" {}
variable "auto_suspend_in_seconds" {}
variable "auto_resume" {}
variable "min_cluster_count" {}
variable "max_cluster_count" {}
variable "scaling_policy" {}
variable "query_timeout_in_seconds" {}
variable "monthly_credit_limit" {}
variable "wh_role" {}
variable "alert_subscribers_list" {}
variable "all_wh_role" {}
variable "access_roles" {
  description = "List of access roles"
  type = list(object({
    access_role = string
    tech_role   = string
    grants      = list(string)
  }))
}
variable "project" {}
variable "env" {}
variable "input_metadata" {}
variable "warehouse_type" {}
variable "statement_queued_timeout_in_seconds" {}
variable "max_concurrency_level" {}
variable "tags" {}
variable "tag_database" {}
variable "tag_schema" {}
# variable "tag_keys" {}