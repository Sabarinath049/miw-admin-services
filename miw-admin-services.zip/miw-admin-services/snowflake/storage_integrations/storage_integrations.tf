locals {
  reval_blocked_storage_locations   = contains(keys(var.input_metadata), "blocked_storage_locations") ? var.input_metadata.blocked_storage_locations : var.blocked_storage_locations
  reval_stage_type                  = contains(keys(var.input_metadata), "stage_type") ? var.input_metadata.stage_type : var.stage_type
  reval_storage_provider            = contains(keys(var.input_metadata), "storage_provider") ? var.input_metadata.storage_provider : var.storage_provider
  reval_storage_integration_enabled = contains(keys(var.input_metadata), "storage_integration_enabled") ? var.input_metadata.storage_integration_enabled : var.storage_integration_enabled

  new_metadata = {
    blocked_storage_locations   = local.reval_blocked_storage_locations
    stage_type                  = local.reval_stage_type
    storage_provider            = local.reval_storage_provider
    storage_integration_enabled = local.reval_storage_integration_enabled
  }

  merged_metadata = merge(var.input_metadata, local.new_metadata)

}

resource "snowflake_storage_integration" "create_miw_integration" {
  provider                  = snowflake.miw_dtd_miw_accountadmin_pr
  name                      = var.storage_integration_name
  comment                   = "A storage integration created by ${var.enterprise_or_func_subgrp_name} enterprise_or_func_subgrp_name and ${var.enterprise_or_func_name} enterprise."
  type                      = upper(local.reval_stage_type)
  enabled                   = local.reval_storage_integration_enabled
  storage_provider          = upper(local.reval_storage_provider)
  storage_aws_role_arn      = var.storage_role_arn
  storage_allowed_locations = var.allowed_storage_locations
  storage_blocked_locations = local.reval_blocked_storage_locations
  lifecycle {
    prevent_destroy = true
  }
}

resource "snowflake_tag_association" "si_tag_association" {
  provider = snowflake.miw_dtd_miw_accountadmin_pr
  for_each = var.tags
  object_identifiers = [snowflake_storage_integration.create_miw_integration.fully_qualified_name]
  object_type        = "INTEGRATION"
  tag_id             = "${var.tag_database}.${var.tag_schema}.${each.key}"
  tag_value          = each.value
}