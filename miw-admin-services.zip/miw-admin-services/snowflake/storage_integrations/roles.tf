# Data block to fetch existing account roles
data "snowflake_account_roles" "miw_existing_role" {
  for_each = { for role in var.access_roles : "${role.tech_role}_${role.access_role}" => role }
  like     = each.value.tech_role
}

# Data block to fetch existing grants for parent roles
data "snowflake_grants" "stg_int_parent_role_grants" {
  grants_to {
    account_role = var.db_role
  }
}

# Local to determine new roles (filter out existing roles with the same comment)
locals {
  new_roles = {
    for key, role in var.access_roles : "${role.tech_role}_${role.access_role}" => role
    if(
    !can(data.snowflake_account_roles.miw_existing_role[key]) ||
    try(length(data.snowflake_account_roles.miw_existing_role[key].account_roles), 0) == 0
    ) || (
    can(data.snowflake_account_roles.miw_existing_role[key]) &&
    try(
      data.snowflake_account_roles.miw_existing_role[key].account_roles.show_output[0].comment,
      ""
    ) != "Technical role for ${role.access_role}"
    )
  }
}

# Step 1: Group roles by tech_role (avoiding duplicate keys)
locals {
  grouped_roles = {
    for role in local.new_roles : role.tech_role => {
      tech_role    = role.tech_role
      access_roles = [role.access_role]  # Initial list, to be merged later
      grants       = role.grants
    }...
  }
}

# Step 2: Deduplicate roles by merging access_roles and grants
locals {
  deduped_roles_map = {
    for tech_role, grouped in local.grouped_roles : tech_role => {
      tech_role    = tech_role
      access_roles = distinct(flatten([for r in local.new_roles : r.access_role if r.tech_role == tech_role]))
      grants       = distinct(flatten([for r in local.new_roles : r.grants if r.tech_role == tech_role]))
    }
  }
}

# Final unique roles
locals {
  unique_roles = {
    for role in flatten([
      for r in local.deduped_roles_map : [
        for access_role in r.access_roles : {
          tech_role   = r.tech_role
          access_role = access_role
        }
      ]
    ]) : "${role.tech_role}_${role.access_role}" => role
  }
}

# Resource to create account roles
resource "snowflake_account_role" "miw_stg_int_tech_role" {
  provider = snowflake.miw_dtd_miw_accountadmin_pr
  for_each = local.deduped_roles_map
  name     = each.value.tech_role
  comment  = "Technical role for ${join(", ", each.value.access_roles)}"
  lifecycle {
    prevent_destroy = true
  }
}

# # Resource to grant privileges on storage_integration to account roles
resource "snowflake_grant_privileges_to_account_role" "grant_perm_on_storage_integration" {
  provider = snowflake.miw_dtd_miw_accountadmin_pr
  for_each = local.deduped_roles_map
  on_account_object {
    object_type = "INTEGRATION"
    object_name = snowflake_storage_integration.create_miw_integration.name
  }
  privileges        = each.value.grants
  always_apply      = true
  account_role_name = snowflake_account_role.miw_stg_int_tech_role[each.key].name
}

# Resource to grant account roles to parent roles
resource "snowflake_grant_account_role" "stg_int_grant_tech_to_access_role" {
  provider         = snowflake.miw_dtd_miw_accountadmin_pr
  for_each         = local.unique_roles
  role_name        = snowflake_account_role.miw_stg_int_tech_role[each.value.tech_role].name
  parent_role_name = upper(each.value.access_role)
}