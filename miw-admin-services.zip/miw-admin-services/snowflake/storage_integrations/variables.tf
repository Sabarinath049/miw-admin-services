variable "project" {}
variable "env" {}
variable "storage_integration_name" {}
variable "access_roles" {}
variable "allowed_storage_locations" {}
variable "storage_role_arn" {}
variable "storage_provider" {}
variable "stage_type" {}
variable "storage_integration_enabled" {}
variable "enterprise_or_func_name" {}
variable "enterprise_or_func_subgrp_name" {}
variable "input_metadata" {}
variable "db_role" {}
variable "blocked_storage_locations" {}
variable "tags" {}
variable "tag_database" {}
variable "tag_schema" {}
# variable "tag_keys" {}
