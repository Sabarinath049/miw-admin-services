output "input_metadata" {
  value = merge(local.merged_metadata, { "storage_integration_name" = snowflake_storage_integration.create_miw_integration.name })
}