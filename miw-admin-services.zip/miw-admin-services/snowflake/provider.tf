terraform {
  required_providers {
    snowflake = {
      source  = "snowflakedb/snowflake"
      version = "1.0.5"
      configuration_aliases = [
        snowflake.miw_dtd_miw_whadmin_pr,
        snowflake.miw_dtd_miw_oauthadmin_pr,
        snowflake.miw_dtd_miw_dbadmin_pr,
        snowflake.miw_dtd_miw_accountadmin_pr,
      ]
    }
  }
}

provider "http" {}

provider "snowflake" {
  user                     = local.snf_credentials.user
  authenticator            = "OAuth"
  token                    = local.oauth_token
  organization_name        = local.organization_name
  account_name             = local.account_name
  role                     = var.wh_role
  preview_features_enabled = ["snowflake_storage_integration_resource"]
}

provider "snowflake" {
  alias             = "miw_dtd_miw_whadmin_pr"
  user              = local.snf_credentials.user
  authenticator     = "OAuth"
  token             = local.oauth_token
  account_name      = local.account_name
  role              = var.wh_role
  organization_name = local.organization_name
}

provider "snowflake" {
  alias             = "miw_dtd_miw_oauthadmin_pr"
  user              = local.snf_credentials.user
  authenticator     = "OAuth"
  token             = local.oauth_token
  account_name      = local.account_name
  role              = var.oauth_role
  organization_name = local.organization_name
}

provider "snowflake" {
  alias             = "miw_dtd_miw_accountadmin_pr"
  user              = local.snf_credentials.user
  authenticator     = "OAuth"
  token             = local.oauth_token
  account_name      = local.account_name
  role              = var.account_admin_role
  organization_name = local.organization_name
  warehouse         = var.warehouse
  preview_features_enabled = [
    "snowflake_storage_integration_resource",
    "snowflake_external_volume_resource"
  ]
}

provider "snowflake" {
  alias             = "miw_dtd_miw_dbadmin_pr"
  user              = local.snf_credentials.user
  authenticator     = "OAuth"
  token             = local.oauth_token
  account_name      = local.account_name
  role              = var.db_role
  organization_name = local.organization_name
  warehouse         = var.warehouse
}