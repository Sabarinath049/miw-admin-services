variable "metadata_poc_repo" {}
variable "tags_dir" {}
variable "project" {}
variable "env" {}
variable "wh_role" {}
variable "db_role" {}
variable "oauth_role" {}
variable "db_pipln" {}
variable "oauth_url" {}
variable "integrator_persona_mapping" {}
variable "database_type" {}
variable "data_retention_in_days" {}
variable "schema_catalog" {}
variable "blocked_storage_locations" {}
variable "stage_type" {}
variable "storage_provider" {}
variable "storage_integration_enabled" {}
variable "persona_parent_role" {}
variable "warehouse_type" {}
variable "auto_suspend_in_seconds" {}
variable "auto_resume" {}
variable "min_cluster_count" {}
variable "max_cluster_count" {}
variable "scaling_policy" {}
variable "query_timeout_in_seconds" {}
variable "statement_queued_timeout_in_seconds" {}
variable "max_concurrency_level" {}
variable "account_admin_role" {}
variable "tag_database" {}
variable "tag_schema" {}
variable "warehouse" {}
variable "bucket" {}
variable "region" {}
variable "tag_tech_role" {}
variable "apply_prerequisites" {}
variable "secret_manager_secret" {}
locals {
  snf_credentials   = jsondecode(data.aws_secretsmanager_secret_version.snf_cred_secret_version.secret_string)
  oauth_token       = jsondecode(data.http.oauth_token.response_body)["access_token"]
  account_name      = split("-", local.snf_credentials.account)[1]
  organization_name = split("-", local.snf_credentials.account)[0]

  warehouse_config_files   = fileset(var.metadata_poc_repo, "warehouses/*.json") # Recursive search for all json
  warehouse_parsed_configs = { for file in local.warehouse_config_files : basename(file) => jsondecode(file("${var.metadata_poc_repo}/${file}")) }

  database_config_files   = fileset(var.metadata_poc_repo, "databases/*.json") # Recursive search for all json
  database_parsed_configs = { for file in local.database_config_files : basename(file) => jsondecode(file("${var.metadata_poc_repo}/${file}")) }

  schema_config_files   = fileset(var.metadata_poc_repo, "schemas/*.json") # Recursive search for all json
  schema_parsed_configs = { for file in local.schema_config_files : basename(file) => jsondecode(file("${var.metadata_poc_repo}/${file}")) }

  rbac_config_files   = fileset(var.metadata_poc_repo, "roles/*.json") # Recursive search for all json
  rbac_parsed_configs = { for file in local.rbac_config_files : basename(file) => jsondecode(file("${var.metadata_poc_repo}/${file}")) }

  oauth_config_files   = fileset(var.metadata_poc_repo, "oauth/*.json") # Recursive search for all json
  oauth_parsed_configs = { for file in local.oauth_config_files : basename(file) => jsondecode(file("${var.metadata_poc_repo}/${file}")) }

  storage_integrations_config_files   = fileset(var.metadata_poc_repo, "storage_integrations/*.json") # Recursive search for all json
  storage_integrations_parsed_configs = { for file in local.storage_integrations_config_files : basename(file) => jsondecode(file("${var.metadata_poc_repo}/${file}")) }

  external_volumes_config_files   = fileset(var.metadata_poc_repo, "external_volumes/*.json") # Recursive search for all json
  external_volumes_parsed_configs = { for file in local.external_volumes_config_files : basename(file) => jsondecode(file("${var.metadata_poc_repo}/${file}")) }

#   catalog_integrations_config_files   = fileset(var.metadata_poc_repo, "catalog_integrations/*.json") # Recursive search for all json
#   catalog_integrations_parsed_configs = { for file in local.catalog_integrations_config_files : basename(file) => jsondecode(file("${var.metadata_poc_repo}/${file}")) }

  tag_config_content = jsondecode(file("${var.tags_dir}/tags/tag_config_file.json"))
  tag_parsed_configs = local.tag_config_content

  tag_tech_role_rw = one([
   for k in keys(var.tag_tech_role)
   : k if endswith(k, "_RW")
 ])

 tag_tech_role_ro = one([
   for k in keys(var.tag_tech_role)
   : k if endswith(k, "_RO")
 ])
}