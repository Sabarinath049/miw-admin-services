output "input_metadata" {
  value = merge(var.input_metadata, { "role_name" = var.defined_role_name })
}
