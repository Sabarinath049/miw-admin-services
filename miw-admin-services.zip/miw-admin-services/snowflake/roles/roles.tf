# # # Resource to grant Persona role to snowflake admin role
resource "snowflake_grant_account_role" "tr_grant_persona_role_to_snow_admin" {
  provider = snowflake.miw_dtd_miw_whadmin_pr
  role_name        = upper(var.defined_role_name)
  parent_role_name = var.persona_parent_role
}

# Resource to grant technical roles to persona role for WH
resource "snowflake_grant_account_role" "tr_grant_tech_to_access_role_for_all_wh" {
  provider = snowflake.miw_dtd_miw_whadmin_pr
  for_each = {
    for key, value in var.access_roles_alias :
    key => value
    if value.tech_role==var.all_wh_role
  }
  role_name        = each.value.tech_role
  parent_role_name = upper(each.value.access_role)
}

# Resource to grant technical roles to persona role for WH
resource "snowflake_grant_account_role" "tr_grant_tech_to_access_role_for_all_sch" {
  provider = snowflake.miw_dtd_miw_dbadmin_pr
  for_each = {
    for key, value in var.access_roles_alias :
    key => value
    if value.tech_role==var.all_sch_role
  }
  role_name        = each.value.tech_role
  parent_role_name = upper(each.value.access_role)
}
