variable "project" {}
variable "env" {}
variable "input_metadata" {}
variable "access_roles_alias" {}
variable "all_sch_role" {}
variable "all_wh_role" {}
variable "persona_parent_role" {}
variable "defined_role_name" {}