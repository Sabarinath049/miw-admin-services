#
# resource "snowflake_procedure" "miw_proc" {
#   name     = "miw-stored-proc"
#   database = snowflake_database.miw_db.name
#   schema   = snowflake_schema.miw_schema.name
#   language = "SQL"
#   comment             = "Procedure with 2 arguments"
#   return_type         = "VARCHAR"
#   execute_as          = "CALLER"
#   null_input_behavior = "RETURNS NULL ON NULL INPUT"
#
#   # Dynamically create arguments
#   dynamic "arguments" {
#     for_each = var.arguments
#     content {
#       name = arguments.value.name
#       type = arguments.value.type
#     }
#   }
#
#   statement = <<EOT
#   BEGIN
#     -- Use all arguments to return a concatenated message
#     RETURN 'Message: ' || message || ', Status: ' || status || ', User ID: ' || user_id || ', Timestamp: ' || timestamp;
#   END;
#   EOT
# }