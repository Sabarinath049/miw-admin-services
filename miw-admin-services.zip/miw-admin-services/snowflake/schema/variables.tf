variable "parent_db_name" {}
variable "schema_name" {}
variable "description" {}
variable "project" {}
variable "env" {}
variable "input_metadata" {}
variable "db_role" {}
variable "all_sch_role" {}
variable "data_retention_in_days" {}   
variable "schema_catalog" {}
variable "tags" {}
variable "tag_database" {}
variable "tag_schema" {}
variable "all_tags" {}
variable "tag_tech_role" {}
variable "tag_tech_role_ro" {}
variable "tag_tech_role_rw" {}
# variable "tag_keys" {}
variable "schema_object_related_privileges" {
  description = "Map of roles to their schema object related privileges"
  type = map(map(list(string)))
}
variable "access_roles" {
  description = "List of access roles"
  type = list(object({
    access_role = string
    tech_role   = string
    grants      = list(string)
  }))
}