locals {
  reval_data_retention_in_days = contains(keys(var.input_metadata), "data_retention_in_days") ? var.input_metadata.data_retention_in_days : var.data_retention_in_days
  reval_schema_catalog         = contains(keys(var.input_metadata), "schema_catalog") ? var.input_metadata.schema_catalog : var.schema_catalog

  new_metadata = {
    data_retention_in_days = local.reval_data_retention_in_days
    schema_catalog         = local.reval_schema_catalog
  }

  merged_metadata = merge(var.input_metadata, local.new_metadata)
}

resource "snowflake_schema" "miw_schema" {
  provider                    = snowflake.miw_dtd_miw_dbadmin_pr
  database                    = var.parent_db_name
  name                        = var.schema_name
  comment                     = var.description
  data_retention_time_in_days = local.reval_data_retention_in_days
  catalog                     = local.reval_schema_catalog
  lifecycle {
    prevent_destroy = true
    ignore_changes = [
      comment,
      catalog,
      data_retention_time_in_days,
      external_volume
    ]
  }
}

resource "snowflake_tag_association" "sch_tag_association" {
  provider = snowflake.miw_dtd_miw_dbadmin_pr
  for_each = var.tags
  object_identifiers = [snowflake_schema.miw_schema.fully_qualified_name]
  object_type        = "SCHEMA"
  tag_id             = "${var.tag_database}.${var.tag_schema}.${each.key}"
  tag_value          = each.value
}