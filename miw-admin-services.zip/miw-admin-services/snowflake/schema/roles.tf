locals {
  # Static role processing
  static_roles = {
    for role in var.access_roles :
    "${role.tech_role}_${role.access_role}" => role
  }

  rw_tech_roles_privileges = merge([
   for role in var.access_roles :
   {
     "${role.tech_role}_${role.access_role}" = {
       tech_role     = role.tech_role
       access_role   = role.access_role
     }
   } if endswith(role.tech_role, "RW")
 ]...)

  ro_tech_roles_privileges = merge([
   for role in var.access_roles :
   {
     "${role.tech_role}_${role.access_role}" = {
       tech_role     = role.tech_role
       access_role   = role.access_role
     }
   } if endswith(role.tech_role, "RO") && role.tech_role!=var.all_sch_role
 ]...)

  # Static privilege mapping
  static_privileges = merge([
    for role in var.access_roles : {
      "${role.tech_role}_${role.access_role}" = {
        tech_role     = role.tech_role
        access_role   = role.access_role
        grants        = role.grants
        is_integrator =  strcontains(role.access_role, "dataintegrator")
        object_privileges = try(
          var.schema_object_related_privileges[
            element(split("_", role.tech_role), length(split("_", role.tech_role)) - 1)
          ],
          {}
        )
      }
    }
  ]...)

  # Final filtered maps (completely static)
  filtered_deduped_roles_map = {
    for k, v in local.static_privileges :
    k => v if !v.is_integrator
  }

  dataintegrator_roles_map = {
    for k, v in local.static_privileges :
    k => v if v.is_integrator
  }

  data_integrator_privileges = merge([
    for k, v in local.static_privileges :
    {
      for object_type, privileges in try(v.object_privileges, {}) :
      "${k}_${object_type}" => {
        tech_role   = v.tech_role
        object_type = object_type
        privileges  = privileges
      }
    } if v.is_integrator
  ]...)

  non_data_integrator_privileges = merge([
    for k, v in local.static_privileges :
    {
      for object_type, privileges in try(v.object_privileges, {}) :
      "${k}_${object_type}" => {
        tech_role   = v.tech_role
        object_type = object_type
        privileges  = privileges
      }
    } if !v.is_integrator
  ]...)
 
  unique_roles = {
    for k, v in local.static_roles :
    k => v if try(!strcontains(v.access_role, "dataintegrator"), false)
  }

  ## Used for assigning data integrator roles
  data_integrator_unique_roles = {
  for k, v in local.static_roles :
  k => v
  if try(
    strcontains(v.access_role, "dataintegrator") && v.access_role != "dataintegrator",
    false
  )
}
}

resource "snowflake_database_role" "miw_schema_tech_role" {
  provider = snowflake.miw_dtd_miw_dbadmin_pr
  for_each = {
    # Group by tech_role and aggregate access_roles
    for tech_role in distinct([for k, v in local.filtered_deduped_roles_map : v.tech_role]) :
    tech_role => {
      tech_role    = tech_role
      access_roles = distinct(flatten([
        for k, v in local.filtered_deduped_roles_map :
        v.access_role if v.tech_role == tech_role
      ]))
      grants = distinct(flatten([
        for k, v in local.filtered_deduped_roles_map :
        v.grants if v.tech_role == tech_role
      ]))
    }
  }
  name     = each.value.tech_role
  comment  = "Technical role for: ${join(", ", each.value.access_roles)}"
  database = var.parent_db_name
  lifecycle {
    prevent_destroy = true
  }
}

# Database Privileges for Technical Roles
resource "snowflake_grant_privileges_to_database_role" "grant_perm_on_database" {
  provider           = snowflake.miw_dtd_miw_dbadmin_pr
  for_each           = local.filtered_deduped_roles_map
  on_database        = var.parent_db_name
  privileges         = ["USAGE"]
  always_apply       = true
  database_role_name = "${var.parent_db_name}.${each.value.tech_role}"
  depends_on         = [snowflake_schema.miw_schema, snowflake_database_role.miw_schema_tech_role]
}

resource "snowflake_grant_privileges_to_account_role" "grant_perm_on_all_database" {
  provider           = snowflake.miw_dtd_miw_dbadmin_pr
  on_account_object {
    object_type = "DATABASE"
    object_name = var.parent_db_name
  }
  privileges         = ["USAGE"]
  always_apply       = true
  account_role_name = var.all_sch_role
  depends_on         = [snowflake_schema.miw_schema, snowflake_database_role.miw_schema_tech_role]
}

# Schema Privileges for Technical Roles
resource "snowflake_grant_privileges_to_database_role" "grant_perm_on_schema" {
  provider = snowflake.miw_dtd_miw_dbadmin_pr
  for_each = local.filtered_deduped_roles_map
  on_schema {
    schema_name = snowflake_schema.miw_schema.fully_qualified_name
  }
  privileges         = each.value.grants
  always_apply       = true
  database_role_name = "${var.parent_db_name}.${each.value.tech_role}"
  depends_on         = [snowflake_database_role.miw_schema_tech_role]
}

# # Resource to grant privileges on schema to account roles
resource "snowflake_grant_privileges_to_account_role" "grant_perm_on_schema_all_sch" {
  provider = snowflake.miw_dtd_miw_dbadmin_pr
  for_each = local.dataintegrator_roles_map
  on_schema {
    schema_name = snowflake_schema.miw_schema.fully_qualified_name
  }
  always_apply      = true
  account_role_name = var.all_sch_role
  privileges        = each.value.grants
}

# Current Object Privileges (Non-Data Integrator)
resource "snowflake_grant_privileges_to_database_role" "curr_obj_privileges" {
  provider           = snowflake.miw_dtd_miw_dbadmin_pr
  for_each           = local.non_data_integrator_privileges
  privileges         = each.value.privileges
  database_role_name = "${var.parent_db_name}.${each.value.tech_role}"
  on_schema_object {
    all {
      object_type_plural = each.value.object_type
      in_schema          = snowflake_schema.miw_schema.fully_qualified_name
    }
  }
  depends_on = [snowflake_schema.miw_schema,snowflake_database_role.miw_schema_tech_role]
  # lifecycle {
  #   prevent_destroy = true
  # }
}

# Future Object Privileges (Non-Data Integrator)
resource "snowflake_grant_privileges_to_database_role" "future_obj_privileges" {
  provider           = snowflake.miw_dtd_miw_dbadmin_pr
  for_each           = local.non_data_integrator_privileges
  privileges         = each.value.privileges
  database_role_name = "${var.parent_db_name}.${each.value.tech_role}"
  on_schema_object {
    future {
      object_type_plural = each.value.object_type
      in_schema          = snowflake_schema.miw_schema.fully_qualified_name
    }
  }
  depends_on = [snowflake_schema.miw_schema,snowflake_database_role.miw_schema_tech_role]
  # lifecycle {
  #   prevent_destroy = true
  # }
}

# Data Integrator Privileges
resource "snowflake_grant_privileges_to_account_role" "curr_obj_privileges_all_sch" {
  provider          = snowflake.miw_dtd_miw_dbadmin_pr
  for_each          = local.data_integrator_privileges
  privileges        = each.value.privileges
  account_role_name = var.all_sch_role
  on_schema_object {
    all {
      object_type_plural = each.value.object_type
      in_schema          = snowflake_schema.miw_schema.fully_qualified_name
    }
  }
  depends_on = [snowflake_schema.miw_schema]

  # lifecycle {
  #   prevent_destroy = true
  # }
}

resource "snowflake_grant_privileges_to_account_role" "future_obj_privileges_all_sch" {
  provider          = snowflake.miw_dtd_miw_dbadmin_pr
  for_each          = local.data_integrator_privileges
  privileges        = each.value.privileges
  account_role_name = var.all_sch_role # Assuming the first access role
  on_schema_object {
    future {
      object_type_plural = each.value.object_type
      in_schema          = snowflake_schema.miw_schema.fully_qualified_name
    }
  }
  depends_on = [snowflake_schema.miw_schema]
  # lifecycle {
  #   prevent_destroy = true
  # }
}

# Role Grants
resource "snowflake_grant_database_role" "sch_grant_tech_to_access_role" {
  provider           = snowflake.miw_dtd_miw_dbadmin_pr
  for_each           = local.unique_roles
  database_role_name = "${var.parent_db_name}.${each.value.tech_role}"
  parent_role_name   = upper(each.value.access_role)
  depends_on = [snowflake_schema.miw_schema, snowflake_database_role.miw_schema_tech_role]
}

## Role grant of ALL_SC role to dataintegrator role
resource "snowflake_grant_account_role" "sch_grant_tech_to_access_role_data_integrator_strcontains" {
  provider           = snowflake.miw_dtd_miw_dbadmin_pr
  for_each           = local.data_integrator_unique_roles
  role_name          = var.all_sch_role
  parent_role_name   = upper(each.value.access_role)
  depends_on = [snowflake_schema.miw_schema, snowflake_database_role.miw_schema_tech_role]
}

## grant tag_tech_role to access_role for rw
resource "snowflake_grant_database_role" "sch_grant_tag_tech_role_to_access_rw_role" {
  provider           = snowflake.miw_dtd_miw_dbadmin_pr
  for_each           = local.rw_tech_roles_privileges
  database_role_name = "${var.tag_database}.${var.tag_tech_role_rw}"
  parent_role_name   = upper(each.value.access_role)
  depends_on = [snowflake_schema.miw_schema]
}

## grant tag_tech_role to access_role for ro
resource "snowflake_grant_database_role" "sch_grant_tag_tech_role_to_access_ro_role" {
  provider           = snowflake.miw_dtd_miw_dbadmin_pr
  for_each           = local.ro_tech_roles_privileges
  database_role_name = "${var.tag_database}.${var.tag_tech_role_ro}"
  parent_role_name   = upper(each.value.access_role)
  depends_on = [snowflake_schema.miw_schema]
}

# Resource to grant tag ro role to all_Sch_role
resource "snowflake_grant_database_role" "sch_grant_tag_tech_role_to_access_ro_role_all_sch_role" {
  provider              = snowflake.miw_dtd_miw_dbadmin_pr
  database_role_name    = "${var.tag_database}.${var.tag_tech_role_ro}"
  parent_role_name      = var.all_sch_role
}


# Resource to grant account roles to parent roles
resource "snowflake_grant_account_role" "sch_grant_tech_to_access_role_all_sch" {
  provider         = snowflake.miw_dtd_miw_dbadmin_pr
  role_name        = var.all_sch_role
  parent_role_name = var.db_role
}