output "schema_name" {
  value = snowflake_schema.miw_schema.name
}

output "description" {
  value = snowflake_schema.miw_schema.comment
}

output "schema_database" {
  value = snowflake_schema.miw_schema.database
}

output "input_metadata" {
  value = local.merged_metadata
}

output "static_roles" {
  value = local.static_roles
}

output "static_privileges" {
  value = local.static_privileges
}

output "filtered_deduped_roles_map" {
  value = local.filtered_deduped_roles_map
}

output "dataintegrator_roles_map" {
  value = local.dataintegrator_roles_map
}

output "data_integrator_privileges" {
  value = local.data_integrator_privileges
}

output "non_data_integrator_privileges" {
  value = local.non_data_integrator_privileges
}

output "unique_roles" {
  value = local.unique_roles
}

output "uppercase_database_role_names" {
  value = {
    for k, role in snowflake_database_role.miw_schema_tech_role :
    k => role
  }
}

output "uppercase_database_fully_qual_role_names" {
  value = {
    for k, role in snowflake_database_role.miw_schema_tech_role :
    k => upper(role.fully_qualified_name)
  }
}

output "debug_schema_name" {
  value = snowflake_schema.miw_schema.fully_qualified_name
}

output "debug_role_names" {
  value = tomap({
    for k, v in snowflake_database_role.miw_schema_tech_role :
    k => "${var.parent_db_name}.${format("\"%s\"", replace(v.name, "\".\"", "."))}"
  })
}

output "test_role_names" {
  value = tomap({
    for k, v in snowflake_database_role.miw_schema_tech_role :
    k => {
      schema_database = format("\"%s\"", replace(v.fully_qualified_name, "\".\"", "."))
      schema_name     = format("\"%s\"", replace("${var.parent_db_name}.${v.name}", "\".\"", "."))
      final_name      = format("\"%s\".\"%s\"", var.parent_db_name, v.name)
    }
  })
}

output "access_roles" {
  value = var.access_roles
}

output "rw_tech_roles_privileges" {
  value = local.rw_tech_roles_privileges
}

output "ro_tech_roles_privileges" {
  value= local.ro_tech_roles_privileges
}