output "database_name" {
  value = snowflake_database.miw_db.name
}

# output "db_existing_roles" {
#   value = data.snowflake_database_roles.miw_existing_role
# }

# output "access_roles" {
#   value = var.access_roles
# }

# output "database_tech_roles" {
#   value = [ for role in snowflake_account_role.miw_db_tech_role : role.name ]
# }

# output "new_roles" {
#   value = local.new_roles
# }

# output "grouped_roles" {
#   value = local.grouped_roles
# }

# output "deduped_roles_map" {
#   value = local.deduped_roles_map
# }

# output "unique_roles" {
#   value = local.unique_roles
# }

output "input_metadata" {
  value = local.merged_metadata
}
