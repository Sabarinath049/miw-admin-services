variable "database_name" {}
variable "description" {}
variable "project" {}
variable "env" {}
variable "tags" {}
# variable "tag_keys" {}
variable "input_metadata" {}
variable "database_type" {}
variable "tag_database" {}
variable "tag_schema" {}
# variable "db_role" {}
# variable "access_roles" {
#   description = "List of access roles"
#   type = list(object({
#     access_role = string
#     tech_role   = string
#     grants      = list(string)
#   }))
# }