locals {
  reval_database_type = contains(keys(var.input_metadata), "database_type") ? var.input_metadata.database_type : var.database_type
  is_permanent        = upper(local.reval_database_type) == "PERMANENT" ? false : true

  new_metadata = {
    database_type = local.reval_database_type
  }

  merged_metadata = merge(var.input_metadata, local.new_metadata)
}

resource "snowflake_database" "miw_db" {
  provider     = snowflake.miw_dtd_miw_dbadmin_pr
  name         = var.database_name
  comment      = var.description
  is_transient = local.is_permanent
  lifecycle {
    prevent_destroy = true
  }
}

resource "snowflake_tag_association" "db_tag_association" {
  provider = snowflake.miw_dtd_miw_dbadmin_pr
  for_each = var.tags
  object_identifiers = [snowflake_database.miw_db.fully_qualified_name]
  object_type        = "DATABASE"
  tag_id             = "${var.tag_database}.${var.tag_schema}.${each.key}"
  tag_value          = each.value
}