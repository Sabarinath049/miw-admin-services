# # Data block to fetch existing account roles
# data "snowflake_database_roles" "miw_existing_role" {
#   for_each    = { for role in var.access_roles : "${role.tech_role}_${role.access_role}" => role }
#   like        = each.value.tech_role
#   in_database = var.database_name
# }

# # Local to determine new roles (filter out existing roles with the same comment)
# locals {
#   new_roles = {
#     for key, role in var.access_roles : "${role.tech_role}_${role.access_role}" => role
#     if(
#       !can(data.snowflake_database_roles.miw_existing_role[key]) ||
#       try(length(data.snowflake_database_roles.miw_existing_role[key].account_roles), 0) == 0
#       ) || (
#       can(data.snowflake_database_roles.miw_existing_role[key]) &&
#       try(
#         data.snowflake_database_roles.miw_existing_role[key].account_roles.show_output[0].comment,
#         ""
#       ) != "Technical role for ${role.access_role}"
#     )
#   }
# }

# # Step 1: Group roles by tech_role (avoiding duplicate keys)
# locals {
#   grouped_roles = {
#     for role in local.new_roles : role.tech_role => {
#       tech_role    = role.tech_role
#       access_roles = [role.access_role] # Initial list, to be merged later
#       grants       = role.grants
#     }...
#   }
# }

# # Step 2: Deduplicate roles by merging access_roles and grants
# locals {
#   deduped_roles_map = {
#     for tech_role, grouped in local.grouped_roles : tech_role => {
#       tech_role    = tech_role
#       access_roles = distinct(flatten([for r in local.new_roles : r.access_role if r.tech_role == tech_role]))
#       grants       = distinct(flatten([for r in local.new_roles : r.grants if r.tech_role == tech_role]))
#     }
#   }
# }

# # Final unique roles
# locals {
#   unique_roles = {
#     for role in flatten([
#       for r in local.deduped_roles_map : [
#         for access_role in r.access_roles : {
#           tech_role   = r.tech_role
#           access_role = access_role
#         }
#       ]
#     ]) : "${role.tech_role}_${role.access_role}" => role
#   }
# }

# # Resource to create account roles
# resource "snowflake_database_role" "miw_db_tech_role" {
#   provider = snowflake.miw_dtd_miw_dbadmin_pr
#   for_each = { for k, v in local.deduped_roles_map : k => v if !contains(v.access_roles, "dataintegrator") }
#   name     = each.value.tech_role
#   comment  = "Technical role for ${join(", ", each.value.access_roles)}"
#   database = var.database_name
# }

# # # Resource to grant privileges on database to account roles
# resource "snowflake_grant_privileges_to_database_role" "grant_perm_on_database" {
#   provider           = snowflake.miw_dtd_miw_dbadmin_pr
#   for_each           = { for k, v in local.deduped_roles_map : k => v if !contains(v.access_roles, "dataintegrator") }
#   on_database        = snowflake_database.miw_db.name
#   privileges         = each.value.grants
#   always_apply       = true
#   database_role_name = snowflake_database_role.miw_db_tech_role[each.key].fully_qualified_name
# }

# # # Resource to grant privileges on database to account roles for all_db role
# resource "snowflake_grant_privileges_to_account_role" "grant_perm_on_database_all_db_role" {
#   provider = snowflake.miw_dtd_miw_dbadmin_pr
#   for_each = { for k, v in local.deduped_roles_map : k => v if contains(v.access_roles, "dataintegrator") }
#   on_account_object {
#     object_type = "DATABASE"
#     object_name = snowflake_database.miw_db.name
#   }
#   privileges        = each.value.grants
#   always_apply      = true
#   account_role_name = var.all_db_role
# }

# # Resource to grant account roles to parent roles
# resource "snowflake_grant_database_role" "db_grant_tech_to_access_role" {
#   provider           = snowflake.miw_dtd_miw_dbadmin_pr
#   for_each           = { for k, v in local.unique_roles : k => v if v.access_role != "dataintegrator" }
#   database_role_name = snowflake_database_role.miw_db_tech_role[each.value.tech_role].fully_qualified_name
#   parent_role_name   = each.value.access_role
# }

# resource "snowflake_grant_account_role" "db_grant_tech_to_access_role_all_db_role" {
#   provider         = snowflake.miw_dtd_miw_dbadmin_pr
#   role_name        = var.all_db_role
#   parent_role_name = var.db_role
# }