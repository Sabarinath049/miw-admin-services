data "aws_secretsmanager_secret" "snf_cred_secret" {
  name = var.secret_manager_secret
}

data "aws_secretsmanager_secret_version" "snf_cred_secret_version" {
  secret_id = data.aws_secretsmanager_secret.snf_cred_secret.id
}

data "http" "oauth_token" {
  url    = var.oauth_url
  method = "POST"

  request_headers = {
    "Content-Type" = "application/x-www-form-urlencoded"
  }

  request_body = "grant_type=client_credentials&client_id=${local.snf_credentials.client_id}&client_secret=${local.snf_credentials.client_secret}&scope=${local.snf_credentials.scope}"
}
