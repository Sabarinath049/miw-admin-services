data "terraform_remote_state" "source" {
  backend = "s3"
  config = {
    bucket = var.bucket
    key    = "snowflake/${var.env}/prerequisites/snowflake.json"
    region = var.region
  }
}