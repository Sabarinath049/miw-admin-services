# miw-admin-services

Administrative Infrastructure-as-Code (IaC) and tooling for the **Minerva Integrated Warehouse (MIW)** platform. This repository provisions and manages the **Snowflake** account-level objects (warehouses, databases, schemas, roles, OAuth integrations, storage/external/catalog integrations, stored procedures) and the **AWS Lakehouse** stack (S3, Glue, Lake Formation, IAM, EventBridge, Lambda) that together back the Minerva data platform.

It also contains operational utilities for Snowflake backup / restore (Python + Bash) and the AWS CodeBuild / CodePipeline glue that drives all deployments.

---

## Table of Contents

1. [High-level architecture](#high-level-architecture)
2. [Repository layout](#repository-layout)
3. [The Snowflake stack (`snowflake/`)](#the-snowflake-stack-snowflake)
4. [The AWS Lakehouse stack (`aws_lakehouse/`)](#the-aws-lakehouse-stack-aws_lakehouse)
5. [Backup & restore tooling (root)](#backup--restore-tooling-root)
6. [CI/CD pipelines](#cicd-pipelines)
7. [Environments](#environments)
8. [Local development](#local-development)
9. [Conventions](#conventions)

---

## High-level architecture

The repo is split into three independently-deployable concerns that share the same CI/CD bootstrap pattern:

| Area | What it provisions | Tech |
|---|---|---|
| `snowflake/` | Snowflake account objects (warehouses, DBs, schemas, RBAC, OAuth, integrations, procs) | Terraform + Snowflake provider |
| `aws_lakehouse/` | AWS data-lake objects (S3, Glue DBs/crawlers, Lake Formation, IAM, EventBridge, Lambda) | Terraform + Python preprocessors |
| Root utilities | Snowflake backup / restore SQL generation | Python + Bash, run from CodeBuild |

All deployments are driven by **AWS CodeBuild** projects whose `buildspec.yml` files live next to the code they build. State is stored remotely in **S3** with **DynamoDB** state-locking, and Snowflake authentication uses **OAuth2 client-credentials** tokens fetched from **AWS Secrets Manager** at runtime — there are no plaintext Snowflake passwords anywhere in the repo.

---

## Repository layout

```text
miw-admin-services/
├── README.md                    ← (this file)
├── CODEBASE_REVIEW.md           ← internal review / open issues
├── backup.sh                    ← Snowflake backup/restore orchestration (CodeBuild entrypoint)
├── generate_query.py            ← generates backup / restore / rename SQL from Snowflake metadata
├── utils.py                     ← SQL formatting helpers used by generate_query.py
├── requirements.txt             ← Python deps for the backup tooling
│
├── snowflake/                   ← Terraform stack for Snowflake objects
│   ├── main.tf                  ← top-level module wiring (warehouse, db, schema, roles, oauth, …)
│   ├── provider.tf              ← Snowflake provider + role-aliased providers
│   ├── data.tf                  ← Secrets Manager + OAuth token data sources
│   ├── variables.tf / output.tf
│   ├── backend.tf / remote_state.tf
│   ├── tfvars/{dev,sbx,prd}/    ← per-environment variable values
│   ├── prerequisites/           ← tags, RBAC bootstrap
│   ├── warehouses/              ← Snowflake warehouse module
│   ├── db/                      ← database module
│   ├── schema/                  ← schema module (with prevent_destroy)
│   ├── roles/                   ← functional/access role module
│   ├── oauth/                   ← OAuth security integration module
│   ├── storage_integrations/    ← STORAGE INTEGRATION module
│   ├── external_volumes/        ← EXTERNAL VOLUME module (Iceberg)
│   ├── catalog_integrations/    ← CATALOG INTEGRATION module (Iceberg / REST)
│   ├── stored_procedure/        ← stored procedure module
│   └── scripts/{python,sql,preprocess}/  ← helpers invoked by the pipeline
│
├── aws_lakehouse/               ← AWS data-lake stack
│   ├── build/                   ← CodeBuild entrypoints + helpers
│   │   ├── buildspec.yml        ← AWS CodeBuild spec
│   │   ├── aws_lakehouse.sh     ← top-level driver
│   │   ├── pr_handler.sh        ← PR diff → files-to-deploy
│   │   ├── executor.sh          ← terraform plan/apply per resource group
│   │   ├── import_logic.sh      ← brown-field `terraform import`
│   │   ├── fetch_existing_resources.sh
│   │   └── helpers.sh
│   ├── python/                  ← preprocessing / validation drivers
│   │   ├── preprocess_driver.py ← YAML → JSON, expansion, defaults
│   │   ├── validation_driver.py ← schema + governance checks
│   │   ├── metadata_driver.py
│   │   ├── create_glue_db.py / register_s3_location_lf.py
│   │   ├── get_files.py / get_warnings_errors.py
│   │   ├── helpers/             ← config_log, preprocessor, utils, validator
│   │   └── requirements.txt
│   ├── terraform/               ← per-resource-group Terraform roots
│   │   ├── access_controls/     ← Lake Formation grants + IAM
│   │   ├── data_federation/
│   │   ├── glue_crawler/
│   │   ├── glue_db/
│   │   ├── prerequisites/
│   │   ├── resource_policy/
│   │   ├── s3/
│   │   └── tfvars/
│   └── data_discovery/          ← serverless auto-tagging of new Glue DBs
│       ├── eventbridge/         ← EventBridge rule definition
│       ├── iam/                 ← Lambda + EB invoke roles
│       └── lambda/              ← Python Lambda + env vars
│
└── aws-codepipeline-terraform/
    └── buildspec.yml            ← CodeBuild spec used by the Snowflake CodePipeline
```

---

## The Snowflake stack (`snowflake/`)

A single Terraform root composes a number of small reusable modules. Each module is invoked with `for_each` over a parsed-metadata local map, so adding a new warehouse, DB, schema, role, etc. is a metadata change — not a code change.

### Module map (declared in `main.tf`)

| Module | Purpose | Key Snowflake provider role |
|---|---|---|
| `prerequisites` | Account-level tags, technical RBAC scaffolding | `dbadmin` |
| `warehouse` | Virtual warehouses + monthly credit limits + alert subscribers | `whadmin` |
| `db` | Databases + tags | `dbadmin` |
| `schema` | Schemas + access roles + retention + tags (with `prevent_destroy`) | `dbadmin` |
| `roles` | Functional roles mapped to AAD groups | `dbadmin` + `whadmin` |
| `oauth` | OAuth security integrations per consumer | `oauthadmin` + `accountadmin` |
| `storage_integrations` | S3 storage integrations | `accountadmin` |
| `external_volumes` | Iceberg external volumes | `accountadmin` |
| `catalog_integrations` | Iceberg / REST catalog integrations | `accountadmin` |
| `stored_procedure` | Stored procedures | varies |

### Provider / authentication pattern

`provider.tf` declares the `snowflake` provider with **five role-aliased copies** (default + `whadmin`, `oauthadmin`, `accountadmin`, `dbadmin`). Modules receive only the alias they need, enforcing **least privilege per resource type**.

`data.tf` pulls Snowflake client credentials from AWS Secrets Manager and POSTs to Azure AD's `oauth2/v2.0/token` endpoint via the `http` data source. The resulting access token is fed into every aliased `snowflake` provider as `token = local.oauth_token`.

### Per-environment configuration

`snowflake/tfvars/{dev,sbx,prd}/terraform.tfvars` holds environment-specific values (account, role names, OAuth URL, S3 bucket for state, etc.). The buildspec in `aws-codepipeline-terraform/buildspec.yml` exports each line as a `TF_VAR_*` so Terraform picks it up.

### Helper scripts (`snowflake/scripts/`)

* `preprocess/` — converts source YAML metadata into the JSON shape Terraform `locals` expect.
* `python/` — Python utilities invoked from the pipeline (e.g. metadata expansion).
* `sql/` — one-off / bootstrap SQL run via SnowSQL.

---

## The AWS Lakehouse stack (`aws_lakehouse/`)

Unlike the Snowflake stack, the Lakehouse code is **per-resource-group Terraform roots** (`terraform/s3/`, `terraform/glue_db/`, etc.) that are selectively applied based on which YAML metadata files changed in the PR.

### Build flow (`aws_lakehouse/build/`)

1. **`buildspec.yml`** — installs Terraform 1.5.0 + Python deps; pulls a GitHub token from Secrets Manager; resolves the PR head/base refs.
2. **`pr_handler.sh`** — diffs the PR to produce `temp/file_diff.txt` (the list of metadata files to act on).
3. **`aws_lakehouse.sh`** — top-level driver:
   * runs `python/preprocess_driver.py` to turn YAML → normalized JSON,
   * uploads/fetches the `product_key.txt` from S3 (cross-build state),
   * calls `fetch_existing_resources.sh` to snapshot the current AWS state,
   * runs `python/validation_driver.py` for schema + governance-tag checks,
   * delegates per-resource-group `plan`/`apply` to `executor.sh`.
4. **`import_logic.sh`** — performs `terraform import` for brown-field resources discovered by the fetch step.
5. **`helpers.sh`** — shared bash functions sourced by the others.

### Python drivers (`aws_lakehouse/python/`)

| File | Role |
|---|---|
| `preprocess_driver.py` | YAML → JSON, defaults expansion, "relevant files" computation |
| `validation_driver.py` | runs validators in `helpers/validator.py` against governance tag definitions |
| `metadata_driver.py` | drives metadata enrichment passes |
| `create_glue_db.py` | direct Glue DB creation (used outside Terraform where needed) |
| `register_s3_location_lf.py` | registers S3 prefixes with Lake Formation |
| `get_files.py` | resolves the file diff list when running on a forked PR |
| `get_warnings_errors.py` | parses Terraform output for surfaced warnings/errors |
| `constants.py` | shared constants (paths, keys, etc.) |
| `helpers/` | `config_log`, `preprocessor`, `utils`, `validator` |

### Terraform roots (`aws_lakehouse/terraform/`)

Each subfolder is a self-contained Terraform root with its own `backend.tf` / `provider.tf` / `variables.tf` and is applied independently:

* `prerequisites/` – Lake Formation admins, baseline IAM
* `s3/` – buckets + bucket policies
* `resource_policy/` – S3 / Lake Formation resource policies
* `glue_db/` – Glue databases
* `glue_crawler/` – Glue crawlers
* `access_controls/` – Lake Formation `LF-Tag` grants + IAM role bindings
* `data_federation/` – federated query setup

### Data discovery automation (`aws_lakehouse/data_discovery/`)

A small serverless component that auto-applies a Lake Formation tag (default `dev_discoverability=enabled`) to any newly-created Glue database whose name contains a configured keyword (default `_cln_`). It is composed of:

* `eventbridge/` – the EB rule JSON,
* `lambda/` – the Python handler + `environment_variables.json`,
* `iam/` – the Lambda execution role + the EB → Lambda invoke role.

---

## Backup & restore tooling (root)

Operational scripts to clone a Snowflake database to a `BKP_*` copy and to regenerate DDL from the backup if a restore is needed.

### `backup.sh`

CodeBuild entrypoint. Steps:

1. Pulls Snowflake OAuth client credentials from Secrets Manager.
2. Installs SnowSQL silently (if missing).
3. Exchanges the client credentials for an Azure AD OAuth token → `OAUTH_TOKEN`.
4. Walks metadata JSON files, groups them by `enterprise_or_func_subgrp_name`.
5. In `MODE=backup` it emits `CREATE DATABASE BKP_<db> CLONE <db>` + `terraform state` re-pointing commands. In `MODE=restore` it invokes `generate_query.py` to regenerate object DDL.

### `generate_query.py`

* Connects to Snowflake (OAuth by default, password fallback via `--not-oauth`).
* `generate_rename_db_statements` – emits an `ALTER DATABASE … RENAME TO BKP_…`.
* `generate_full_backup_restore_sqls` – walks per-DB JSON files and dumps `CREATE OR REPLACE` DDL for each object kind (file formats, stages, etc.).
* `generate_role_access_query` – regenerates `GRANT … ON … TO ROLE …` from access metadata.

### `utils.py`

Pure-Python SQL formatters used by `generate_query.py`:

* `get_file_format_query(new_db, schema, row)` – `CREATE OR REPLACE FILE FORMAT …`
* `get_stage_query(...)` – `CREATE OR REPLACE STAGE …`
* `format_query_list(queries)` – joins a list of statements with separators.
* `save_queries_to_file(queries, path)` – writes them to disk.

### `requirements.txt`

Python dependencies for the backup tooling — chiefly `snowflake-connector-python`, `boto3`, `python-dotenv`, `cryptography`, `PyJWT`.

---

## CI/CD pipelines

Two CodeBuild projects, both following the same pattern:

| Pipeline | Buildspec | Builds |
|---|---|---|
| Snowflake objects | `aws-codepipeline-terraform/buildspec.yml` | `snowflake/` Terraform |
| Lakehouse | `aws_lakehouse/build/buildspec.yml` | `aws_lakehouse/terraform/*` Terraform + python preprocessing |

Common steps:

1. Install Terraform 1.5.0, `make`, `jq`.
2. Read `tfvars/$env/terraform.tfvars` and re-export every line as `TF_VAR_*`.
3. Pull a GitHub PAT from Secrets Manager and configure `git` credentials.
4. Resolve the PR head/base ref (works for direct PRs, forked PRs, manual triggers, and CodePipeline merged-PR runs).
5. Compute the file diff for the PR.
6. Run preprocessing / validation (Lakehouse only).
7. Run `terraform init` (with S3 backend) → `plan` → `apply`.

`$env` is selected per pipeline (`sbx` / `dev` / `prd`) and drives the tfvars folder, the target Snowflake roles, and the target AWS account.

---

## Environments

Three environments are defined symmetrically across both stacks:

| Env | Snowflake roles suffix | tfvars folder |
|---|---|---|
| `sbx` | `_SBX` | `tfvars/sbx/` |
| `dev` | `_DEV` | `tfvars/dev/` |
| `prd` | `_PRD` | `tfvars/prd/` |

Promotion path: **PR into `sbx` → `dev` → `main` (prd)**. The buildspec maps `prd` to the `main` git branch.

---

## Local development

The repo is intended to run inside CodeBuild, but the Python pieces can be exercised locally:

```powershell
# from the repo root
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

# expected env vars (place in a .env next to generate_query.py)
#   USER, OAUTH_TOKEN, ACCOUNT_NAME, SF_ROLE,
#   DATABASE_NAME, restored_db, SCHEMA_FOLDER, LOG_LEVEL
python generate_query.py --help
```

Terraform modules can be `terraform init`-ed standalone if you supply matching backend/tfvars values, but real applies should always go through CodeBuild so that OAuth tokens are minted from the shared service principal.

---

## Conventions

* **Metadata-driven** — almost nothing is hard-coded in `.tf`; resources are produced by `for_each` over locals built from JSON metadata files.
* **Role-per-operation** — every Terraform module accepts a Snowflake provider alias scoped to the minimum role needed (`whadmin` / `dbadmin` / `oauthadmin` / `accountadmin`).
* **No plaintext secrets** — all credentials come from AWS Secrets Manager at build time. `.gitignore` excludes `*.tfstate`, `secrets.tf`, build artifacts.
* **`prevent_destroy = true`** is set on `snowflake_schema` resources to guard against accidental drops in production.
* **Remote state** — every Terraform root configures an S3 backend with a DynamoDB lock table, both named per-environment.
* **One responsibility per Terraform root** in the lakehouse stack so that PR diffs map cleanly to the smallest possible `apply`.

For a list of currently-known issues and remediation priorities, see [CODEBASE_REVIEW.md](CODEBASE_REVIEW.md).

